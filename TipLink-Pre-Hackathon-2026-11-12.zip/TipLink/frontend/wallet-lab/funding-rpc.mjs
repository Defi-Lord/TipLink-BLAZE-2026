import {CHECKPOINT,verifyProviderIdentity} from './live-funding-core.mjs';
export const PROVIDER = 'wss://rostrum.riften.net:443';
const READ_METHODS = new Set(['server.version','server.features','blockchain.block.header','blockchain.scripthash.listunspent','blockchain.transaction.get','blockchain.scripthash.get_history','blockchain.headers.subscribe']);
import {decodeTransaction,encodeTransaction,hexToBin,binToHex} from '@bitauth/libauth';
export const BCH_PROVIDERS=[PROVIDER,'wss://electroncash.dk:50004','wss://bch.loping.net:50004'];
const CROSS_CHECKED=new Set(['blockchain.scripthash.listunspent','blockchain.scripthash.get_history']);
function fingerprint(rows,method){
 if(!Array.isArray(rows))throw Error('Provider returned invalid funding data.');
 return JSON.stringify(rows.map(row=>{
  const height=row?.height;
  if(!Number.isSafeInteger(height)||height< -1||typeof row?.tx_hash!=='string'||!/^[a-f0-9]{64}$/i.test(row.tx_hash))throw Error('Provider returned invalid funding data.');
  if(method==='blockchain.scripthash.get_history')return [row.tx_hash.toLowerCase(),Math.max(0,height)];
  if(!Number.isSafeInteger(row.tx_pos)||row.tx_pos<0||!['string','number'].includes(typeof row.value)||!/^\d{1,16}$/.test(String(row.value)))throw Error('Provider returned invalid funding data.');
  return [row.tx_hash.toLowerCase(),Math.max(0,height),row.tx_pos,String(row.value)];
 }).map(row=>JSON.stringify(row)).sort());
}
async function openCrossCheckedRpc(options){
 const results=await Promise.allSettled((options.providers??BCH_PROVIDERS).map(async url=>{
  const rpc=await openRpc({...options,url});
  try{
   await rpc.call('server.version',['TipLink','1.4.3']);
   const features=await rpc.call('server.features',[]);
   const header=await rpc.call('blockchain.block.header',[CHECKPOINT.height]);
   verifyProviderIdentity(features,header);
   return rpc;
  }catch(error){rpc.close();throw error;}
 }));
 const peers=results.filter(result=>result.status==='fulfilled').map(result=>result.value);
 if(peers.length<2){peers.forEach(peer=>peer.close());throw Error('Could not connect to two BCH providers. Try again shortly.',{cause:new AggregateError(results.filter(result=>result.status==='rejected').map(result=>result.reason))});}
 const primary=peers[0];
 return {
  close(){peers.forEach(peer=>peer.close());},
  async call(method,params=[]){
   if(method==='blockchain.transaction.broadcast')return primary.call(method,params);
   if(!CROSS_CHECKED.has(method)){
    for(const peer of peers){
     try{return await peer.call(method,params);}
     catch(error){if(peer===peers.at(-1)||options.signal?.aborted)throw error;}
    }
   }
   const answers=await Promise.allSettled(peers.map(peer=>peer.call(method,params)));
   const seen=new Map();
   for(const answer of answers){
    if(answer.status!=='fulfilled')continue;
    let key;
    try{key=fingerprint(answer.value,method);}catch{continue;}
    if(seen.has(key))return seen.get(key);
    seen.set(key,answer.value);
   }
   throw Error('BCH providers did not agree on funding. Try again shortly.');
  }
 };
}
export function openFundingRpc({signal,Socket,timeoutMs,providers}={}){
 const options={signal,Socket,timeoutMs,providers};
 return Socket&&!providers?openRpc(options):openCrossCheckedRpc(options);
}
export function openTransactionRpc({signedHex,signal,Socket,timeoutMs,providers}={}){
 if(typeof signedHex!=='string'||signedHex.length>40000||!/^(?:[a-f0-9]{2})+$/.test(signedHex))throw Error('Invalid reviewed transaction.');
 const tx=decodeTransaction(hexToBin(signedHex));if(typeof tx==='string'||binToHex(encodeTransaction(tx))!==signedHex||!tx.inputs.length||!tx.outputs.length)throw Error('Invalid reviewed transaction.');
 const options={signal,Socket,timeoutMs,providers,permittedHex:signedHex};
 return Socket&&!providers?openRpc(options):openCrossCheckedRpc(options);
}
async function openRpc({ signal, Socket = globalThis.WebSocket, timeoutMs = 12000,permittedHex,url=PROVIDER } = {}) {
  if (signal?.aborted) throw new Error('Funding lookup cancelled.');
  const socket = new Socket(url);
  const pending = new Map(); let id = 0; let stopped = false; let sent = false; let openReject;
  function close(reason = 'Provider connection closed.') {
    if (stopped) return; stopped = true;
    clearTimeout(connectTimer);signal?.removeEventListener('abort',abort);
    openReject?.(new Error(reason));
    for(const p of pending.values()){clearTimeout(p.timer);p.reject(new Error(reason));}pending.clear();
    try{socket.close();}catch{}
  }
  const abort = () => close('Funding lookup cancelled.');
  const connectTimer = setTimeout(()=>close('Provider connection timed out.'),timeoutMs);
  signal?.addEventListener('abort',abort,{once:true});
  socket.addEventListener('error',()=>close('Cannot connect to funding provider.'));
  socket.addEventListener('close',()=>close());
  socket.addEventListener('message',event=>{
    if(typeof event.data!=='string' || event.data.length>2200000){close('Provider response exceeded supported limits.');return;}
    try {
      for(const line of event.data.split('\n').filter(Boolean)) {
        const parsed=JSON.parse(line); const messages=Array.isArray(parsed)?parsed:[parsed];
        for(const msg of messages) {
          if(!msg || typeof msg!=='object')throw new Error('Malformed response');
          const p=pending.get(msg.id);if(!p)continue;
          clearTimeout(p.timer);pending.delete(msg.id);
          if(msg.error)p.reject(new Error('Funding provider rejected a read request.'));
          else if(Object.hasOwn(msg,'result'))p.resolve(msg.result);
          else p.reject(new Error('Provider returned an invalid response.'));
        }
      }
    } catch {close('Funding provider returned malformed JSON.');}
  });
  await new Promise((resolve,reject)=>{openReject=reject;socket.addEventListener('open',()=>{if(stopped)return;clearTimeout(connectTimer);openReject=null;resolve();},{once:true});});
  return {
    call(method,params=[]) {
      if(method==='blockchain.transaction.broadcast'){if(!permittedHex)return Promise.reject(new Error('Only allowlisted read methods are available. Broadcast requires an explicit reviewed transaction.'));if(sent||!Array.isArray(params)||params.length!==1||params[0]!==permittedHex)return Promise.reject(new Error('Broadcast requires the exact reviewed transaction and one explicit attempt.'));sent=true;}else if(!READ_METHODS.has(method))return Promise.reject(new Error('Only allowlisted read methods are available.'));
      if(stopped || signal?.aborted)return Promise.reject(new Error('Funding lookup cancelled or closed.'));
      return new Promise((resolve,reject)=>{
        const requestId=++id;
        const timer=setTimeout(()=>{pending.delete(requestId);reject(new Error('Funding provider request timed out.'));},timeoutMs);
        pending.set(requestId,{resolve,reject,timer});
        try{socket.send(JSON.stringify({jsonrpc:'2.0',id:requestId,method,params}));}catch{clearTimeout(timer);pending.delete(requestId);reject(new Error('Provider request could not be sent.'));}
      });
    }, close,
  };
}
