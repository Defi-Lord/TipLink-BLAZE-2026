import {StatusMark} from './StatusReaction.jsx';
import {startReceiptMonitor} from './receipt-monitor.mjs';
import {selectExportRequests} from './business-export.mjs';
import React,{useCallback,useEffect,useRef,useState} from 'react';
import makeQr from 'qrcode-generator';
import './wallet-login.css';
import './payment-receipts.css';
import './business-workspace.css';
import {parseBusinessAmount,createMerchantClient,validateSavedInvoice,savedInvoiceUrl,savedInvoiceUri,invoiceActive,receiptLabel,invoiceCsv,fetchInvoiceCheckout} from './business-core.mjs';
import {formatBch,validateRecipient} from './preview-core.mjs';
import {LinkArtwork} from './HomeScreen.jsx';
const WalletLogin=React.lazy(()=>import('./WalletLogin.jsx').then(module=>({default:module.WalletLogin})));
function PaymentQR({value}){try{const qr=makeQr(0,'M');qr.addData(value);qr.make();return <div className="qr" role="img" aria-label="Invoice payment QR" dangerouslySetInnerHTML={{__html:qr.createSvgTag({cellSize:4,margin:2,scalable:true})}}/>;}catch{return <p>Copy the address or payment URI instead.</p>;}}
export function BusinessWorkspace(){
 const[session,setSession]=useState(null),[loading,setLoading]=useState(true),[mode,setMode]=useState('login'),[manualBusy,setBusy]=useState(false),[walletBusy,setWalletBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState(''),[items,setItems]=useState([]),[created,setCreated]=useState(null),[section,setSection]=useState('requests'),[cancel,setCancel]=useState(null),[receiptRequest,setReceiptRequest]=useState(null),[requestKey,setRequestKey]=useState(()=>crypto.randomUUID()),[now,setNow]=useState(Date.now());
 const [composerOpen,setComposerOpen]=useState(false);
 const [selectedId,setSelectedId]=useState(null);
 const [backgroundChecks,setBackgroundChecks]=useState(false);
 const [autoCheck,setAutoCheck]=useState(false),[autoBusy,setAutoBusy]=useState(false),[autoError,setAutoError]=useState('');
 const busy=manualBusy||autoBusy;
 const client=useRef(null),live=useRef(true);
 const requestDraft=useRef({});
 const monitorState=useRef(null);
 monitorState.current={items,busy:busy||walletBusy};
 useEffect(()=>{
  if(!autoCheck||backgroundChecks||!session||session.profileComplete===false)return;
  return startReceiptMonitor({
   readState:()=>({...monitorState.current,hidden:document.hidden}),
   request:(path,options)=>client.current.request(path,options),
   onItems:updated=>{setItems(updated);setAutoError('');},
   onBusy:value=>{if(live.current)setAutoBusy(value);},
   onError:error=>{
    setAutoError(error.status===401?'Sign in again to continue automatic checks.':'Automatic check delayed. We will retry shortly.');
    if(error.status===401)resetWorkspace();
   },
  });
 },[autoCheck,backgroundChecks,session?.id,session?.profileComplete]);

 const [exportFrom,setExportFrom]=useState(''),[exportTo,setExportTo]=useState(''),[exportStatus,setExportStatus]=useState('all');
 let exportItems=[],exportError='';
 try{exportItems=selectExportRequests(items,{from:exportFrom,to:exportTo,status:exportStatus},now);}catch(error){exportError=error.message;}
 useEffect(()=>{live.current=true;const abort=new AbortController();client.current=createMerchantClient({signal:abort.signal});client.current.request('/auth/session').then(async result=>{if(!live.current)return;setAutoCheck(false);setSession(result.account);const list=await client.current.request('/invoices');if(live.current){setItems(list.items.map(validateSavedInvoice));setBackgroundChecks(list.backgroundChecks===true);}}).catch(e=>{if(live.current&&e.status!==401&&e.name!=='AbortError')setError(e.message);}).finally(()=>{if(live.current)setLoading(false);});const timer=setInterval(()=>setNow(Date.now()),1000);return()=>{live.current=false;abort.abort();clearInterval(timer);};},[]);
 async function run(work){setError('');setNotice('');setBusy(true);try{await work();}catch(e){if(live.current&&e.name!=='AbortError'){setError(e.message);if(e.status===401)resetWorkspace();}}finally{if(live.current)setBusy(false);}}
 async function refresh(){const result=await client.current.request('/invoices');if(live.current){setItems(result.items.map(validateSavedInvoice));setBackgroundChecks(result.backgroundChecks===true);}}
 async function auth(e){e.preventDefault();const form=e.currentTarget;const email=form.elements.email.value,password=form.elements.password.value;const displayName=form.elements.displayName?.value;await run(async()=>{if(mode==='register')await client.current.request('/auth/register',{method:'POST',body:{email,password,displayName}});const result=await client.current.request('/auth/login',{method:'POST',body:{email,password}});if(live.current){setItems([]);setCancel(null);setReceiptRequest(null);setAutoCheck(false);setSession(result.account);setCreated(null);}await refresh();});form.elements.password.value='';}
 async function save(e){e.preventDefault();const form=e.currentTarget;await run(async()=>{const body={requestKey,amountBch:formatBch(parseBusinessAmount(form.elements.amount.value)),address:validateRecipient(form.elements.address.value).address,memo:form.elements.memo.value,hours:Number(form.elements.hours.value)};const result=await client.current.request('/invoices',{method:'POST',body});const invoice=validateSavedInvoice(result.invoice);if(live.current){requestDraft.current={};setCreated(invoice);setRequestKey(crypto.randomUUID());}await refresh();});}
 async function walletSuccess(result){if(!live.current)return;setWalletBusy(false);setItems([]);setCreated(null);setCancel(null);setReceiptRequest(null);setAutoCheck(false);setSession(result.account);if(result.account.profileComplete!==false)await run(refresh);}
 async function profile(e){e.preventDefault();const displayName=e.currentTarget.elements.displayName.value;await run(async()=>{const result=await client.current.request('/profile',{method:'PATCH',body:{displayName}});if(live.current){setAutoCheck(false);setSession(result.account);setNotice('Business name saved.');}await refresh();});}
 async function exportCsv(){
  await run(async()=>{
   const exportedAt=Date.now();
   const selected=selectExportRequests(items,{from:exportFrom,to:exportTo,status:exportStatus},exportedAt);
   if(!selected.length)throw Error('No requests match these export filters.');
   const blob=new Blob([invoiceCsv(selected,exportedAt)],{type:'text/csv;charset=utf-8'});
   const url=URL.createObjectURL(blob);
   const a=document.createElement('a');
   a.href=url;
   a.download='TipLink-requests-'+new Date(exportedAt).toISOString().slice(0,10)+'.csv';
   document.body.append(a);
   try{a.click();setNotice('CSV download started for '+selected.length+' request'+(selected.length===1?'':'s')+'.');}
   finally{a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  });
 }
 async function checkReceipt(e){e.preventDefault();const txid=e.currentTarget.elements.txid.value.trim();await run(async()=>{await client.current.request('/invoices/'+receiptRequest.id+'/receipt',{method:'POST',body:{txid,acknowledgeAssignment:true}});await refresh();if(live.current){setReceiptRequest(null);setNotice('Receipt checked. Review its current status below.');}});}
 async function copy(value){try{await navigator.clipboard.writeText(value);if(live.current)setNotice('Link copied. Share it with your customer.');}catch{if(live.current)setError('Clipboard unavailable. Select the link and copy it.');}}
 function closeComposer(){
  if(manualBusy)return;
  setComposerOpen(false);
  setCreated(null);
  setError('');
  setNotice('');
 }
 function openComposer(){
  setCreated(null);
  setError('');
  setNotice('');
  setComposerOpen(true);
 }
 function openRequest(id){
  setSelectedId(id);
  setCancel(null);
  setReceiptRequest(null);
  setError('');
  setNotice('');
 }
 function closeRequest(){
  if(!manualBusy)openRequest(null);
 }
 function resetWorkspace(){
  requestDraft.current={};
  setRequestKey(crypto.randomUUID());
  setAutoCheck(false);
  setSession(null);
  setItems([]);
  setCreated(null);
  setCancel(null);
  setReceiptRequest(null);
  setSelectedId(null);
  setComposerOpen(false);
  setExportFrom('');
  setExportTo('');
  setExportStatus('all');
  setSection('requests');
 }
 async function signOut(){
  await run(async()=>{
   await client.current.request('/auth/logout',{method:'POST',body:{}});
   if(live.current)resetWorkspace();
  });
 }

 if(loading)return <section className="panel" role="status">Opening your business workspace…</section>;
 const hasWorkspace = session && session.profileComplete !== false;
 const selected = hasWorkspace ? items.find(item=>item.id===selectedId) : null;
 const showComposer = hasWorkspace && composerOpen;
 const requestRows = items.map(item=>({
  item,
  status: item.state==='cancelled' ? 'Cancelled' : invoiceActive(item,now) ? 'Open' : 'Expired',
  receipt: requestReceipt(item.receipt,now),
 }));
 const shownRows = exportStatus==='all' ? requestRows : requestRows.filter(row=>row.status.toLowerCase()===exportStatus);
 const selectedLink = selected ? savedInvoiceUrl(selected,location.href) : '';
 const messages = <>{error && <div className="error" role="alert">{error}</div>}{notice && <div className="notice" role="status">{notice}</div>}</>;

 return <div className="business-workspace business-dashboard">
  <header className="business-heading">
   <div>
    <h1 tabIndex={-1}>Business</h1>
    <p>Create, share, and track BCH payment requests.</p>
   </div>
   {hasWorkspace && section==='requests' && <button type="button" className="primary business-create-request"
    aria-haspopup="dialog" onClick={openComposer}>+ New request</button>}
   {session && !hasWorkspace && <button type="button" className="secondary" disabled={busy||walletBusy} onClick={signOut}>Sign out</button>}
  </header>
  {!showComposer && !selected && messages}
 {!session ? <div className="business-auth"><section className="story-panel"><span className="eyebrow">A LITTLE LESS CHASING.</span><h2>Your work.<br/><em>Your way.</em></h2><LinkArtwork/><p>Save a request. Share a link. Keep a clear record.</p></section><div className="panel business-auth-card"><React.Suspense fallback={<p>Loading wallet sign-in…</p>}><WalletLogin request={(path,options)=>client.current.request(path,options)} onSuccess={walletSuccess} disabled={busy} onBusyChange={setWalletBusy}/></React.Suspense><p className="business-email-label">Or continue with email</p><form onSubmit={auth}><div className="send-mode" role="group" aria-label="Business account access"><button type="button" disabled={busy||walletBusy} className={mode==='login'?'active':''} onClick={()=>setMode('login')}>Sign in</button><button type="button" disabled={busy||walletBusy} className={mode==='register'?'active':''} onClick={()=>setMode('register')}>Create account</button></div><h2>{mode==='register'?'Make room for your business.':'Welcome back.'}</h2>{mode==='register'&&<label>Business display name<input name="displayName" minLength={2} maxLength={80} required autoComplete="organization"/><small>Shown publicly on your payment requests.</small></label>}<label>Email<input name="email" type="email" required maxLength={254} autoComplete="username"/></label><label>Password<input name="password" type="password" minLength={14} maxLength={128} required autoComplete={mode==='register'?'new-password':'current-password'}/><small>At least 14 characters. This is separate from your wallet and recovery-file password.</small></label><button className="primary full" disabled={busy||walletBusy} type="submit">{busy?'Opening your workspace…':mode==='register'?'Create business account':'Sign in to Business'}</button><p className="fine">Email verification and password reset are not available yet. Your wallet words and claim keys are never needed here.</p></form></div></div>:session.profileComplete===false?<section className="panel wallet-profile"><span className="tag">YOU’RE SIGNED IN WITH YOUR WALLET</span><h2>What should we call your business?</h2><p>No email or password required. This name will appear on your public payment requests.</p><form onSubmit={profile}><label>Business name<input name="displayName" minLength={2} maxLength={80} required autoComplete="organization"/></label><button className="primary full" disabled={busy||walletBusy}>Save business name</button></form><p className="fine">Keep access to this wallet. Email recovery for wallet-only accounts is not implemented yet.</p></section> : <>
   <nav className="business-dashboard-tabs" aria-label="Business sections">
    {[['requests','Requests'],['calculator','Calculator'],['settings','Settings']].map(([key,label])=>
     <button key={key} type="button" aria-pressed={section===key} onClick={()=>{setSection(key);setError('');setNotice('');}}>{label}</button>)}
   </nav>
   {section==='calculator' && <BusinessCalculator request={options=>client.current.request('/quotes',options)} onError={setError}/>}
   {section==='settings' && <div className="business-settings">
    <section className="panel">
     <h2>Business profile</h2>
     <form className="business-dialog-form" onSubmit={profile}>
      <label>Business display name<input key={session.displayName} name="displayName" defaultValue={session.displayName}
       minLength={2} maxLength={80} required autoComplete="organization"/></label>
      <small>This name appears on your public payment requests.</small>
      <button type="submit" className="secondary" disabled={busy||walletBusy}>Save business name</button>
     </form>
     <details className="business-wallet-link">
      <summary>Wallet sign-in</summary>
      {session.walletAddress ? <><p>Your sign-in wallet is linked.</p><code>{session.walletAddress}</code>
       <p className="fine">Use this wallet to sign in to this business.</p></> :
       <React.Suspense fallback={<p>Loading wallet sign-in…</p>}><WalletLogin
        request={(path,options)=>client.current.request(path,options)} onSuccess={walletSuccess}
        disabled={busy} onBusyChange={setWalletBusy} link/></React.Suspense>}
     </details>
     <button type="button" className="secondary" disabled={busy||walletBusy} onClick={signOut}>Sign out</button>
    </section>
    <section className="panel">
     <h2>Payment receipts</h2>
     <p>{backgroundChecks?'The server rechecks linked payments after you close TipLink.':'TipLink can recheck linked payments while Business is open and the tab is visible.'}</p>
     {!backgroundChecks && <label className="business-checkbox"><input type="checkbox" checked={autoCheck}
      disabled={walletBusy} onChange={e=>{setAutoCheck(e.target.checked);setAutoError('');}}/>Automatic checks</label>}
     {autoCheck && !backgroundChecks && <p className="fine" role="status">{autoError||(autoBusy?'Checking a linked payment…':'Automatic checks are on.')}</p>}
     <p className="fine">Link a transaction using Check payment. Payment confirmations are reported by the network provider.</p>
    </section>
   </div>}
   {section==='requests' && <>
    <dl className="business-request-summary" aria-label="Latest 100 requests">
     <div><dt>Saved requests</dt><dd>{requestRows.length}</dd></div>
     <div><dt>Open requests</dt><dd>{requestRows.filter(row=>row.status==='Open').length}</dd></div>
     <div><dt>Confirmed receipts</dt><dd>{requestRows.filter(row=>row.receipt.tone==='confirmed').length}</dd></div>
    </dl>
    <section className="business-requests-card" aria-labelledby="business-requests-title">
     <div className="business-requests-toolbar">
      <h2 id="business-requests-title">Payment requests</h2>
      <label>Request status<select value={exportStatus} onChange={e=>setExportStatus(e.target.value)}>
       <option value="all">All statuses</option><option value="open">Open</option>
       <option value="expired">Expired</option><option value="cancelled">Cancelled</option>
      </select></label>
      <button type="button" className="secondary" disabled={busy||walletBusy||!exportItems.length||!!exportError} onClick={exportCsv}>Export CSV</button>
     </div>
     {shownRows.length ? <div className="business-request-table-wrap">
      <table className="business-request-table" role="table">
       <thead role="rowgroup"><tr role="row">
        <th role="columnheader" scope="col">Request</th><th role="columnheader" scope="col">Amount</th>
        <th role="columnheader" scope="col">Request status</th><th role="columnheader" scope="col">Payment receipt</th>
       </tr></thead>
       <tbody role="rowgroup">{shownRows.map(({item,status,receipt})=>
        <tr key={item.id} role="row">
         <td role="cell"><button type="button" className="business-request-open" aria-haspopup="dialog" onClick={()=>openRequest(item.id)}>
          {item.memo||'Payment request'}
         </button></td>
         <td role="cell" className="business-request-amount">{formatBch(BigInt(item.amountSats))} BCH</td>
         <td role="cell"><span className={`business-badge business-badge--${status.toLowerCase()}`}>{status}</span></td>
         <td role="cell"><span className={`business-badge business-badge--${receipt.tone}`}>{receipt.label}</span></td>
        </tr>)}</tbody>
      </table>
     </div> : <div className="empty"><h3>{items.length?'No requests match this status':'No payment requests yet'}</h3>
      <p>{items.length?'Choose another status to see more requests.':'Create a request to share an exact BCH amount.'}</p></div>}
     <div className="business-requests-footer">
      <details>
       <summary>CSV export dates</summary>
       <div className="business-export-controls" role="group" aria-label="CSV export dates">
        <label>Created from · UTC<input type="date" value={exportFrom} onChange={e=>setExportFrom(e.target.value)}/></label>
        <label>Created through · UTC<input type="date" value={exportTo} onChange={e=>setExportTo(e.target.value)}/></label>
       </div>
       <p className="fine">{exportError||`${exportItems.length} of ${items.length} loaded requests selected for export. The status filter also applies.`}</p>
      </details>
      <button type="button" className="text-button" disabled={busy||walletBusy} onClick={()=>run(refresh)}>Refresh list</button>
     </div>
    </section>
   </>}
   {showComposer && <BusinessDialog title={created?'Payment request ready':'New payment request'} onClose={closeComposer} busy={manualBusy}>
    {messages}
    {created ? <>
     <p className="status-reaction"><StatusMark tone="success"/>Saved to your Business workspace.</p>
     <div className="result-amount">{formatBch(BigInt(created.amountSats))}<span>BCH</span></div>
     <label>Checkout link<textarea readOnly rows={3} value={savedInvoiceUrl(created,location.href)} onFocus={e=>e.target.select()}/></label>
     <div className="button-row">
      <button type="button" className="primary" onClick={()=>copy(savedInvoiceUrl(created,location.href))}>Copy link</button>
      <a className="secondary" href={savedInvoiceUrl(created,location.href)}>Open checkout</a>
     </div>
    </> : <form className="business-dialog-form" onSubmit={save}
     onChange={event=>{requestDraft.current[event.target.name]=event.target.value;}}>
     <label>Exact amount · BCH<input name="amount" inputMode="decimal" defaultValue={requestDraft.current.amount??'0.001'} required/></label>
     <label>Your BCH receiving address<input name="address" defaultValue={requestDraft.current.address} required spellCheck={false}
      autoComplete="off" placeholder="bitcoincash:q…"/><small>Generate a fresh BCH receiving address in your wallet for each request.</small></label>
     <label>Public note · optional<input name="memo" maxLength={160} defaultValue={requestDraft.current.memo}
      placeholder="e.g. Website deposit"/><small>Anyone holding the checkout link can read this note.</small></label>
     <label>Request lifetime<select name="hours" defaultValue={requestDraft.current.hours??'24'}>
      <option value="1">1 hour</option><option value="24">24 hours</option><option value="168">7 days</option><option value="720">30 days</option>
     </select></label>
     <button className="primary full" disabled={busy||walletBusy} type="submit">{busy?'Saving…':'Save payment request'}</button>
    </form>}
   </BusinessDialog>}
   {selected && <BusinessDialog title={selected.memo||'Payment request'} onClose={closeRequest} busy={manualBusy}>
    {messages}
    <dl className="recipient-summary">
     <div><dt>Amount</dt><dd>{formatBch(BigInt(selected.amountSats))} BCH</dd></div>
     <div><dt>Request status</dt><dd>{requestRows.find(row=>row.item.id===selectedId).status}</dd></div>
     <div><dt>Payment receipt</dt><dd>{selected.receiptEligible===false?'Verify directly in your wallet':receiptLabel(selected.receipt,now)}</dd></div>
     <div><dt>Created</dt><dd>{new Date(selected.createdAt).toLocaleString()}</dd></div>
     {selected.receipt && <div><dt>Receipt last checked</dt><dd>{new Date(selected.receipt.checkedAt).toLocaleString()}</dd></div>}
    </dl>
    {!receiptRequest && !cancel && <>
     <label>Checkout link<textarea readOnly rows={3} value={selectedLink} onFocus={e=>e.target.select()}/></label>
     <div className="button-row">
      <button type="button" className="primary" onClick={()=>copy(selectedLink)}>Copy link</button>
      <a className="secondary" href={selectedLink}>Open checkout</a>
     </div>
     <div className="button-row">
      {selected.receiptEligible!==false&&<button type="button" className="secondary" disabled={busy||walletBusy} onClick={()=>{setReceiptRequest(selected);setError('');setNotice('');}}>
       {selected.receipt?'Recheck receipt':'Check payment'}
      </button>}
      {invoiceActive(selected,now) && <button type="button" className="text-button" disabled={busy||walletBusy} onClick={()=>{setCancel(selected);setError('');setNotice('');}}>Cancel request</button>}
     </div>
    </>}
    {receiptRequest && <form className="business-dialog-form" onSubmit={checkReceipt}>
     <h3>Check this payment</h3>
     <label>Customer’s BCH transaction ID<input key={receiptRequest.id} name="txid" defaultValue={receiptRequest.receipt?.txid||''}
      readOnly={!!receiptRequest.receipt} required pattern="[a-fA-F0-9]{64}" minLength={64} maxLength={64}
      spellCheck={false} autoComplete="off" placeholder="64 characters from the payment receipt"/></label>
     <label className="receipt-consent"><input type="checkbox" required/>I confirm the customer supplied this transaction for this request.</label>
     <p className="fine">TipLink checks for one exact BCH output to your receiving address. Confirm with the customer which request they paid. Partial and combined payments need manual review.</p>
     <p className="fine">This shares the transaction ID and receiving script hash with BCH network providers. Confirmations are provider-reported and need rechecking after one minute.</p>
     <div className="button-row">
      <button type="submit" className="primary" disabled={busy||walletBusy}>{busy?'Checking the network…':'Check receipt'}</button>
      <button type="button" className="secondary" disabled={busy||walletBusy} onClick={()=>setReceiptRequest(null)}>Back to request</button>
     </div>
    </form>}
    {cancel && <div className="business-cancel">
     <h3>Cancel this payment request?</h3>
     <p>This closes the checkout. Payments already sent to your BCH address cannot be reversed here.</p>
     <div className="button-row">
      <button type="button" className="secondary" disabled={busy||walletBusy} onClick={()=>setCancel(null)}>Keep request</button>
      <button type="button" className="primary" disabled={busy||walletBusy} onClick={()=>run(async()=>{
       await client.current.request('/invoices/'+cancel.id+'/cancel',{method:'POST',body:{expectedVersion:cancel.version}});
       if(live.current){setCancel(null);setCreated(null);}
       await refresh();
      })}>Cancel this request</button>
     </div>
    </div>}
   </BusinessDialog>}
  </>}
 </div>;
}

function requestReceipt(receipt,now){
 if(!receipt)return {label:'No receipt',tone:'none'};
 const label=receiptLabel(receipt,now);
 if(label==='Confirmed · provider reported')return {label:'Confirmed',tone:'confirmed'};
 if(label==='Seen · awaiting confirmation')return {label:'Awaiting confirmation',tone:'pending'};
 return {label,tone:'warning'};
}

function BusinessDialog({title,onClose,busy,children}){
 const modal=useRef(null),heading=useRef(null);
 useEffect(()=>{
  const dialog=modal.current;
  dialog.showModal();
  return ()=>dialog.close();
 },[]);
 useEffect(()=>{heading.current.focus();},[title]);
 return <dialog ref={modal} className="business-dialog" aria-labelledby="business-dialog-title"
  onCancel={event=>{event.preventDefault();onClose();}}
  onClick={event=>{if(event.target===modal.current)onClose();}}>
  <div className="business-dialog-body">
   <header>
    <h2 id="business-dialog-title" ref={heading} tabIndex={-1}>{title}</h2>
    <button type="button" className="sheet-close" disabled={busy} aria-label="Close dialog" onClick={onClose}>×</button>
   </header>
   {children}
  </div>
 </dialog>;
}

export function BusinessCalculator({request,onError}){
 const[result,setResult]=useState(null),[busy,setBusy]=useState(false);const live=useRef(true);useEffect(()=>()=>{live.current=false;},[]);
 async function calculate(e){e.preventDefault();onError('');setResult(null);setBusy(true);const f=e.currentTarget;try{const r=await request({method:'POST',body:{kind:f.elements.kind.value,recipientSats:parseBusinessAmount(f.elements.recipient.value).toString(),fundingFeeSats:parseBusinessAmount(f.elements.funding.value,true).toString(),claimFeeSats:parseBusinessAmount(f.elements.claim.value,true).toString()}});if(live.current)setResult(r);}catch(e){if(live.current&&e.name!=='AbortError')onError(e.message);}finally{if(live.current)setBusy(false);}}
 return <div className="business-request-grid"><form className="panel" onSubmit={calculate}><span className="tag">SMART CALCULATOR</span><h2>A little clarity.</h2><p>Start with what should reach the recipient. See the pilot total and proposed platform fee separately.</p><label>Payment type<select name="kind"><option value="merchant">Merchant payment</option><option value="personal">Personal link</option></select></label><label>Recipient receives · BCH<input name="recipient" defaultValue="0.01" required inputMode="decimal"/></label><label>Funding fee estimate · BCH<input name="funding" defaultValue="0.000003" required inputMode="decimal"/></label><label>Claim fee estimate · BCH<input name="claim" defaultValue="0.000002" required inputMode="decimal"/></label><button className="primary full" type="submit" disabled={busy}>{busy?'Calculating…':'Calculate estimate'}</button><p className="fine">Network fees are your estimates. No live rate or fiat conversion is fetched.</p></form><section className="panel"><span className="eyebrow">THE BREAKDOWN</span>{result?<><dl className="recipient-summary">{[['Recipient receives',result.recipientSats],['Network fees · estimate',result.networkFeeEstimateSats],['Proposed platform fee',result.proposedPlatformFeeSats],['Pilot total · no platform fee',result.pilotTotalEstimateSats],['Total with proposed fee',result.proposedTotalEstimateSats]].map(([label,value])=><div key={label}><dt>{label}</dt><dd>{formatBch(BigInt(value))} BCH</dd></div>)}</dl><p className="notice">Planning estimate only. No payment or platform fee is collected.</p></>:<div className="empty"><h2>Know what it adds up to.</h2><p>Your estimate will appear here.</p></div>}</section></div>;
}
const CHECKOUT_WINDOW_MS=10000;

export function InvoiceCheckout({id,now=Date.now()}){
 const [record,setRecord]=useState(null);
 const [error,setError]=useState('');
 const [notice,setNotice]=useState('');
 const [checking,setChecking]=useState(false);
 const [readyUntil,setReadyUntil]=useState(0);
 const request=useRef(null);
 const check=useCallback(async (action)=>{
  request.current?.abort();
  const controller=new AbortController();
  request.current=controller;
  const timeout=setTimeout(()=>controller.abort(),8000);
  setChecking(true);
  setReadyUntil(0);
  setError('');
  setNotice('');
  try{
   const invoice=await fetchInvoiceCheckout(id,{signal:controller.signal});
   if(controller.signal.aborted)return;
   setRecord(invoice);
   if(!action||!invoiceActive(invoice))return;
   if(action==='show'){
    setReadyUntil(Date.now()+CHECKOUT_WINDOW_MS);
    return;
   }
   const value=action==='address'?invoice.address:savedInvoiceUri(invoice);
   try{
    await navigator.clipboard.writeText(value);
    if(!controller.signal.aborted)setNotice('Copied.');
   }catch{
    if(!controller.signal.aborted){
     setReadyUntil(Date.now()+CHECKOUT_WINDOW_MS);
     setNotice('Clipboard unavailable. Select the address or scan the QR code below.');
    }
   }
  }catch(failure){
   if(request.current===controller)setError(controller.signal.aborted?'The request check timed out. Try again.':failure.message);
  }finally{
   clearTimeout(timeout);
   if(request.current===controller)setChecking(false);
  }
 },[id]);
 useEffect(()=>{
  check();
  function refreshOnReturn(){
   if(document.visibilityState==='visible')check();
   else setReadyUntil(0);
  }
  document.addEventListener('visibilitychange',refreshOnReturn);
  return()=>{
   const controller=request.current;
   request.current=null;
   controller?.abort();
   document.removeEventListener('visibilitychange',refreshOnReturn);
  };
 },[check]);
 if(error)return <section className="panel invalid"><h1 tabIndex={-1}>Request unavailable</h1><p>{error}</p><button className="primary" onClick={()=>check()}>Try again</button></section>;
 if(!record)return <section className="panel" role="status">Opening payment request…</section>;
 const active=invoiceActive(record,now);
 const ready=active&&now<readyUntil&&!checking;
 const uri=ready?savedInvoiceUri(record,now):'';
 function openWallet(event){
  if(Date.now()>=readyUntil||!invoiceActive(record)){
   event.preventDefault();
   void check('show');
  }
 }
 return <div className="public-checkout">
  <div className="checkout-story"><span className="eyebrow">A CLEAR REQUEST. A SIMPLE PAYMENT.</span><h1 tabIndex={-1}>Pay the person.<br/>Keep it <em>simple.</em></h1><p>Check the exact amount and receiving address before opening your wallet.</p><div className="midnight-checkout-art"><LinkArtwork/></div></div>
  <section className="panel checkout-card">
   <span className="tag">SAVED BUSINESS REQUEST</span>
   <h2><bdi>{record.merchantName}</bdi></h2>
   <p className="identity-note">Business name supplied by the account holder. Check the recipient before paying.</p>
   <div className="checkout-value">{formatBch(BigInt(record.amountSats))}<span>BCH</span></div>
   {record.memo&&<div className="memo"><small>THE NOTE</small><p><bdi>{record.memo}</bdi></p></div>}
   <div className="checkout-line"><span>Request expires</span><b>{new Date(record.expiresAt).toLocaleString()}</b></div>
   {active?<>
    {ready?<>
     <div className="address-box"><small>BCH MAINNET RECEIVING ADDRESS</small><p><bdi>{record.address.split(':')[1].slice(0,6)}…{record.address.slice(-6)}</bdi></p><code>{record.address}</code><button className="text-button" onClick={()=>check('address')}>Copy address</button></div>
     <PaymentQR value={uri}/>
     <a className="primary full" href={uri} onClick={openWallet}>Open in BCH wallet →</a>
     <button className="secondary full" onClick={()=>check('uri')}>Copy payment URI</button>
    </>:<button className="primary full" disabled={checking} onClick={()=>check('show')}>{checking?'Checking request…':'Show payment details'}</button>}
    <p className="fine">Your wallet reviews and sends the payment. Network fees are additional. No TipLink platform fee is collected.</p>
   </>:<div className="notice">{record.state==='cancelled'?'This request was cancelled.':'This request is not active or has expired.'} Ask the merchant for a new request.</div>}
   {notice&&<p role="status">{notice}</p>}
   <div className="notice">Check your wallet for payment confirmation. Cancelling a request cannot reverse a payment.</div>
   <button className="text-button" disabled={checking} onClick={()=>check()}>Reload request details</button>
  </section>
 </div>;
}
