import React,{useEffect,useRef,useState} from 'react';
export function Brand({markOnly=false}){return <span className={`brand-lockup ${markOnly?'mark-only':''}`}><svg className="brand-mark" width="38" height="38" viewBox="0 0 64 64" fill="none" aria-hidden="true"><path d="M20 13l24 13-12 21" stroke="#cefa48" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round"/><path d="M26 28L13 42l10 8" stroke="#a7ecfa" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round"/><circle cx="31" cy="53" r="4.5" fill="#f1f8ff"/></svg>{!markOnly&&<span className="brand-type">tiplink</span>}</span>;}
function initialTheme(){try{const value=localStorage.getItem('tiplink.midnight.appearance.v1');return ['light','dark','system'].includes(value)?value:'dark';}catch{return'dark';}}
export function useAppExperience(){
 const [theme,setTheme]=useState(initialTheme);const [systemDark,setSystemDark]=useState(()=>matchMedia('(prefers-color-scheme: dark)').matches);const [menu,setMenu]=useState(null);const [motionEnabled,setMotionEnabled]=useState(()=>{try{return localStorage.getItem('tiplink.motion.v1')!=='off';}catch{return true;}});const [installEvent,setInstallEvent]=useState(null);const [installed,setInstalled]=useState(()=>matchMedia('(display-mode: standalone)').matches||navigator.standalone===true);const [installMessage,setInstallMessage]=useState('');const [keyboardOpen,setKeyboardOpen]=useState(false);
 const resolvedTheme=theme==='system'?(systemDark?'dark':'light'):theme;
 useEffect(()=>{const query=matchMedia('(prefers-color-scheme: dark)');const update=e=>setSystemDark(e.matches);query.addEventListener('change',update);return()=>query.removeEventListener('change',update);},[]);
 useEffect(()=>{try{localStorage.setItem('tiplink.midnight.appearance.v1',theme);}catch{}document.documentElement.style.colorScheme=resolvedTheme;document.documentElement.style.backgroundColor=resolvedTheme==='dark'?'#03111c':'#eef4fa';document.querySelector('meta[name="theme-color"]')?.setAttribute('content',resolvedTheme==='dark'?'#03111c':'#eef4fa');},[theme,resolvedTheme]);
 useEffect(()=>{const before=e=>{e.preventDefault();setInstallEvent(e);};const done=()=>{setInstalled(true);setInstallEvent(null);setInstallMessage('TipLink has been added to this device.');};window.addEventListener('beforeinstallprompt',before);window.addEventListener('appinstalled',done);return()=>{window.removeEventListener('beforeinstallprompt',before);window.removeEventListener('appinstalled',done);};},[]);
 useEffect(()=>{const viewport=window.visualViewport;if(!viewport)return;let baseline=viewport.height;const update=()=>{const focused=/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName||'');if(!focused)baseline=Math.max(baseline,viewport.height);setKeyboardOpen(focused&&viewport.height<baseline*.78);};viewport.addEventListener('resize',update);document.addEventListener('focusin',update);document.addEventListener('focusout',update);return()=>{viewport.removeEventListener('resize',update);document.removeEventListener('focusin',update);document.removeEventListener('focusout',update);};},[]);
 async function install(){if(installed)return;if(installEvent){try{await installEvent.prompt();const choice=await installEvent.userChoice;setInstallMessage(choice.outcome==='accepted'?'Installation requested. Follow your browser to finish.':'You can add TipLink later from your browser menu.');setInstallEvent(null);}catch{setInstallMessage('Use your browser menu and choose Install app or Add to Home Screen.');}}else setInstallMessage('iPhone/iPad: open the browser Share menu, then Add to Home Screen. Android: open the browser menu, then Install app or Add to Home Screen. Desktop: use the browser’s install option. Availability varies by browser.');}
 useEffect(()=>{try{localStorage.setItem('tiplink.motion.v1',motionEnabled?'on':'off');}catch{}},[motionEnabled]);
 return{theme,setTheme,resolvedTheme,menu,moreOpen:menu!==null,openMore:()=>setMenu('more'),openSettings:()=>setMenu('settings'),closeMore:()=>setMenu(null),motionEnabled,setMotionEnabled,installed,canPrompt:!!installEvent,install,installMessage,keyboardOpen,canShare:typeof navigator.share==='function',async shareLink(url,title){try{await navigator.share({url,title});}catch(e){if(e.name!=='AbortError')throw e;}}};
}
export function AppPreferences({experience:e,onNavigate,activePage}){
 const ref=useRef(null);
 const previousFocus=useRef(null);
 const skipRestore=useRef(false);
 useEffect(()=>{
  const dialog=ref.current;
  if(e.moreOpen&&!dialog.open){
   previousFocus.current=document.activeElement;
   skipRestore.current=false;
   dialog.showModal();
  }else if(!e.moreOpen&&dialog.open){
   dialog.close();
   if(!skipRestore.current)previousFocus.current?.focus();
  }
 },[e.moreOpen]);
 useEffect(()=>{if(e.menu==='settings')ref.current?.querySelector('.sheet-close')?.focus();},[e.menu]);

 function navigate(page){
  skipRestore.current=page!==activePage;
  onNavigate(page);
 }

 return <dialog ref={ref} className={`preferences-sheet dashboard-menu ${e.resolvedTheme==='dark'?'sheet-dark':''}`} aria-labelledby="preferences-title"
   onCancel={event=>{event.preventDefault();e.closeMore();}} onClick={event=>{if(event.target===ref.current)e.closeMore();}}>
   <div className="sheet-handle" aria-hidden="true"/>
   <header className="sheet-header">
     <h2 id="preferences-title">{e.menu==='settings'?'Settings & tools':'More'}</h2>
     <button type="button" className="sheet-close" onClick={e.closeMore} aria-label="Close app menu" autoFocus>×</button>
   </header>
   {e.menu==='more'&&<div className="sheet-actions dashboard-menu-links">
     {[
       ['wallet','▣','Wallet'],
       ['business','▤','Business'],
       ['cash','↔','Cash in & out'],
     ].map(([page,icon,label])=><button key={page} type="button" aria-current={page===activePage?'page':undefined} onClick={()=>navigate(page)}>
       <span className="setting-icon" aria-hidden="true">{icon}</span><b>{label}</b><i aria-hidden="true">›</i>
     </button>)}
     <button type="button" onClick={e.openSettings}><span className="setting-icon" aria-hidden="true">⚙</span><b>Settings &amp; tools</b><i aria-hidden="true">›</i></button>
   </div>}
   {e.menu==='settings'&&<>
     <div className="appearance-block">
       <span className="settings-label">Appearance</span>
       <div className="theme-options" role="group" aria-label="Appearance">
         {[['light','☀','Light'],['dark','☾','Dark'],['system','◐','System']].map(([value,icon,label])=>
           <button key={value} type="button" aria-pressed={e.theme===value} className={e.theme===value?'active':''} onClick={()=>e.setTheme(value)}><span aria-hidden="true">{icon}</span>{label}</button>
         )}
       </div>
     </div>
     <label className="dashboard-motion-option"><input type="checkbox" checked={e.motionEnabled} onChange={event=>e.setMotionEnabled(event.target.checked)}/> Play animations</label>
     <div className="sheet-actions dashboard-menu-links">
       <button type="button" onClick={e.install} disabled={e.installed}><span className="setting-icon" aria-hidden="true">↓</span><b>{e.installed?'Added to your home screen':e.canPrompt?'Install TipLink':'Add to your home screen'}</b></button>
       <button type="button" onClick={()=>navigate('tools')}><span className="setting-icon" aria-hidden="true">⌘</span><b>Developer tools</b><i aria-hidden="true">›</i></button>
     </div>
     {e.installMessage&&<p className="install-message" role="status">{e.installMessage}</p>}
   </>}
 </dialog>;
}
