import React, {useState} from 'react';
import {LinkArtwork} from './HomeScreen.jsx';
import {formatBch} from './preview-core.mjs';
import {readTransactionReceipts, transactionStatusLabel} from './transaction-journal.mjs';

const receiptTitles = {
  funding: 'Link funding',
  claim: 'Incoming payment',
  recovery: 'Recovery',
  'wallet-send': 'Wallet payment',
};

export function MobileDashboard({records, now, navigate, Icon}) {
  const [{receipts, unavailable}] = useState(() => {
    try {
      return {receipts: readTransactionReceipts(), unavailable: false};
    } catch {
      return {receipts: [], unavailable: true};
    }
  });

  const activity = [
    ...receipts.map(receipt => ({
      id: receipt.txid,
      title: receiptTitles[receipt.kind] ?? 'Transaction',
      time: receipt.createdAt,
      detail: transactionStatusLabel(receipt, now),
    })),
    ...records.map(record => ({
      id: record.id,
      title: record.kind === 'request' ? 'Payment request' : 'Demo link',
      time: record.createdAt,
      detail: formatBch(BigInt(record.sats)) + ' BCH',
    })),
  ].sort((first, second) => second.time - first.time).slice(0, 3);

  return <div className="mobile-home">
    <h1 tabIndex={-1}>Home</h1>
    <section className="dashboard-hero" aria-labelledby="dashboard-intro">
      <LinkArtwork priority/>
      <div className="dashboard-intro">
        <h2 id="dashboard-intro">Send a little.<br/>Mean <em>a lot.</em></h2>
        <p>Send or request BCH by link.</p>
      </div>
    </section>
    <div className="dashboard-actions">
      <button type="button" onClick={() => navigate('send')}><Icon name="send" size={27}/>Send money</button>
      <button type="button" onClick={() => navigate('request')}><Icon name="links" size={27}/>Request payment</button>
    </div>
    <section className="dashboard-activity" aria-labelledby="dashboard-activity">
      <div className="dashboard-section-heading">
        <h2 id="dashboard-activity">Recent activity</h2>
        <button type="button" onClick={() => navigate('activity')}>View all <Icon name="arrow" size={16}/></button>
      </div>
      {activity.length > 0 && <ul>
        {activity.map(item => <li key={item.id}>
          <span className="dashboard-activity-icon"><Icon name="activity"/></span>
          <div><strong>{item.title}</strong><small>{item.detail}</small></div>
        </li>)}
      </ul>}
      {(unavailable || !activity.length) && <div className="dashboard-empty">
        <span className="dashboard-activity-icon"><Icon name="activity"/></span>
        <div>
          <strong>{unavailable ? 'Receipts unavailable' : 'No activity yet'}</strong>
          <small>{unavailable ? 'Open Activity to check your saved receipts.' : 'Links and transfers on this device will appear here.'}</small>
        </div>
      </div>}
    </section>
  </div>;
}
