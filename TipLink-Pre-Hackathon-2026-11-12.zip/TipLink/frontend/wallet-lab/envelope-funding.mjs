import {binToHex,hexToBin,encodeTransaction,decodeTransaction,hashTransaction,createVirtualMachineBCH,decodeAuthenticationInstructions} from '@bitauth/libauth';
import {verifyWalletScanRows} from './wallet-address-core.mjs';
import {validateEnvelopeDraft} from './envelope-draft.mjs';
import {buildEnvelopeSpend} from './envelope-core.mjs';
const MAX=2100000000000000n;const MAX_AGE=60000;
function validateSnapshot({manager,state,snapshot,now}){
 if(snapshot?.manager!==manager)throw Error('Funding snapshot belongs to another wallet or path set.');
 const rows=verifyWalletScanRows(manager,state,snapshot.rows);
 const data=snapshot.value;const checkedAt=Date.parse(data?.checkedAt);if(!Number.isFinite(now)||!Number.isFinite(checkedAt)||now<checkedAt||now-checkedAt>MAX_AGE)throw Error('Funding snapshot expired. Refresh funding.');
 if(data.network!=='BCH mainnet'||data.checkpoint!==898374||data.scannedScripts!==rows.length||!Array.isArray(data.candidates)||data.candidates.length>128)throw Error('A checked BCH mainnet snapshot is required.');
 const seen=new Set();let sum=0n;const candidates=data.candidates.map(c=>{
  const row=rows.find(r=>r.path===c.path&&r.index===c.addressIndex);
  if(!row||row.scriptHex!==c.scriptHex||c.status!=='RAW VERIFIED; PROVIDER REPORTS UNSPENT'||!Number.isSafeInteger(c.height)||c.height< -1||typeof c.txid!=='string'||!/^[a-f0-9]{64}$/.test(c.txid)||!Number.isSafeInteger(c.index)||c.index<0||c.index>0xffffffff||typeof c.sats!=='string'||!/^[1-9]\d*$/.test(c.sats)||BigInt(c.sats)>MAX||Object.hasOwn(c,'token')||Object.hasOwn(c,'tokenData'))throw Error('Invalid wallet-bound BCH funding candidate.');
  const key=`${c.txid}:${c.index}`;if(seen.has(key))throw Error('Duplicate funding outpoint.');seen.add(key);sum+=BigInt(c.sats);return{...c};
 });if(sum>MAX)throw Error('Aggregate funding outside supported range.');
 return{rows,data,checkedAt,candidates:candidates.filter(c=>c.height>0)};
}
function buildParent(draft,utxos,changeRow,feeRate){
 const amount=BigInt(draft.amountSats);const inputs=utxos.map(c=>({outpointTransactionHash:hexToBin(c.txid),outpointIndex:c.index,sequenceNumber:0xffffffff,unlockingBytecode:new Uint8Array()}));const total=utxos.reduce((s,c)=>s+BigInt(c.sats),0n);
 const outputs=[{lockingBytecode:hexToBin(draft.contract.scriptHex),valueSatoshis:amount}];const make=out=>({version:2,locktime:0,inputs,outputs:out});const size=out=>encodeTransaction({...make(out),inputs:inputs.map(i=>({...i,unlockingBytecode:new Uint8Array(108)}))}).length;
 let estimatedSignedBytes=size(outputs),feeSats=BigInt(estimatedSignedBytes*feeRate),changeSats=0n;
 const excess=total-amount-feeSats;if(excess<0n)throw Error('Insufficient funding.');
 if(excess>0n){outputs.push({lockingBytecode:hexToBin(changeRow.scriptHex),valueSatoshis:1000n});estimatedSignedBytes=size(outputs);feeSats=BigInt(estimatedSignedBytes*feeRate);changeSats=total-amount-feeSats;if(changeSats<1000n)throw Error('Change below minimum.');outputs[1].valueSatoshis=changeSats;}
 return{transaction:make(outputs),estimatedSignedBytes,feeSats,changeSats,totalInputSats:total};
}
export function prepareEnvelopeFunding({manager,state,snapshot,draft,feeRate=1,now=Date.now()}){
 const d=validateEnvelopeDraft(draft);if(!Number.isSafeInteger(feeRate)||feeRate<1||feeRate>100)throw Error('Fee rate must be 1–100 sats/byte.');
 if(d.createdAt>now||d.contract.reclaimAfter*1000-now<900000)throw Error('Draft recovery time must be at least 15 minutes ahead. Create a new draft.');
 const{rows,data,checkedAt,candidates}=validateSnapshot({manager,state,snapshot,now});if(!candidates.length)throw Error('No confirmed BCH-only funding found in the scanned wallet paths.');
 const changeRow=rows.find(r=>r.path==='change'&&r.index===0);candidates.sort((a,b)=>BigInt(a.sats)===BigInt(b.sats)?`${a.txid}:${a.index}`.localeCompare(`${b.txid}:${b.index}`):BigInt(a.sats)>BigInt(b.sats)?-1:1);
 const selected=[];let parent;for(const coin of candidates.slice(0,20)){selected.push(coin);try{parent=buildParent(d,selected,changeRow,feeRate);break;}catch(e){if(!['Insufficient funding.','Change below minimum.'].includes(e.message))throw e;}}
 if(!parent)throw Error('Confirmed funding cannot cover the envelope, fee and valid change.');
 const estimate=buildEnvelopeSpend({contract:d.contract,utxo:{txid:'00'.repeat(32),index:0,sats:d.amountSats,scriptHex:d.contract.scriptHex},destination:changeRow.address,privateKeyHex:d.claimPrivateKey,feeRate});
 const unsignedHex=binToHex(encodeTransaction(parent.transaction));
 return{mode:'ENVELOPE FUNDING — SIGN ONLY, NO BROADCAST',manager,rows,draftContract:d.contract,amountSats:BigInt(d.amountSats),...parent,unsignedHex,changeAddress:changeRow.address,feeRate,claimFeeEstimateSats:estimate.feeSats,claimNetEstimateSats:estimate.receiveSats,sourceOutputs:selected.map((c,i)=>({...parent.transaction.inputs[i],lockingBytecode:hexToBin(c.scriptHex),valueSatoshis:BigInt(c.sats)})),inputPaths:selected.map((c,i)=>[i,c.path,c.addressIndex]),checkedAt:data.checkedAt,expiresAt:new Date(checkedAt+MAX_AGE).toISOString()};
}
export function envelopeSigningRequest(plan){return{transaction:{transaction:plan.unsignedHex,sourceOutputs:plan.sourceOutputs.map(o=>({...o,lockingBytecode:Uint8Array.from(o.lockingBytecode),outpointTransactionHash:Uint8Array.from(o.outpointTransactionHash),unlockingBytecode:new Uint8Array()})),broadcast:false,userPrompt:'TipLink envelope funding — approve only. TipLink will ask separately before sending this exact transaction.'},inputPaths:plan.inputPaths.map(p=>[...p])};}
export function verifySignedEnvelopeFunding(signedHex,plan){
 if(typeof signedHex!=='string'||signedHex.length>40000||!/^(?:[a-fA-F0-9]{2})+$/.test(signedHex))throw Error('Wallet returned invalid transaction bytes.');
 const tx=decodeTransaction(hexToBin(signedHex));if(typeof tx==='string'||binToHex(encodeTransaction(tx))!==signedHex.toLowerCase())throw Error('Wallet returned a noncanonical transaction.');
 if(tx.inputs.length!==plan.transaction.inputs.length||tx.outputs.length!==plan.transaction.outputs.length)throw Error('Wallet changed transaction inputs or outputs.');
 const stripped={...tx,inputs:tx.inputs.map(i=>({...i,unlockingBytecode:new Uint8Array()}))};if(binToHex(encodeTransaction(stripped))!==plan.unsignedHex)throw Error('Wallet changed the reviewed funding plan.');
 for(const input of tx.inputs){const instructions=decodeAuthenticationInstructions(input.unlockingBytecode);if(instructions.length!==2||instructions.some(i=>!('data'in i))||instructions[0].data.length<9||![0x41,0x61].includes(instructions[0].data.at(-1))||instructions[1].data.length!==33)throw Error('Wallet must return standard compressed-key P2PKH signatures using SIGHASH_ALL | FORKID, with optional UTXOS.');}
 const bytes=signedHex.length/2;if(bytes>plan.estimatedSignedBytes)throw Error('Wallet transaction exceeds the reviewed size allowance.');
 if(plan.totalInputSats-tx.outputs.reduce((s,o)=>s+o.valueSatoshis,0n)!==plan.feeSats)throw Error('Wallet fee does not reconcile.');
 const valid=createVirtualMachineBCH().verify({transaction:tx,sourceOutputs:plan.sourceOutputs});if(valid!==true)throw Error('Wallet signatures failed local BCH verification.');
 return{txid:hashTransaction(hexToBin(signedHex)),signedHex:signedHex.toLowerCase(),bytes,feeSats:plan.feeSats,status:'SIGNED AND VERIFIED LOCALLY; NOT BROADCAST BY TIPLINK'};
}
export async function requestEnvelopeSignature({manager,state,plan,signal,now=Date.now()}){
 if(signal?.aborted)throw Error('Signing cancelled.');if(manager!==plan.manager)throw Error('Wallet changed. Prepare again.');verifyWalletScanRows(manager,state,plan.rows);
 if(!Number.isFinite(now)||now<Date.parse(plan.checkedAt)||now>=Date.parse(plan.expiresAt))throw Error('Funding review expired. Prepare again.');
 if(typeof manager.signTransaction!=='function')throw Error('Wallet does not expose signing.');
 const response=await manager.signTransaction(envelopeSigningRequest(plan),{signal});if(signal?.aborted)throw Error('Signing cancelled.');if(response?.error)throw Error('Wallet declined or could not sign this request.');
 verifyWalletScanRows(manager,state,plan.rows);return verifySignedEnvelopeFunding(response?.signedTransaction,plan);
}
