// Bounded read-only lookup. The claim key is never passed to the provider.
import {sha256,hexToBin,binToHex,decodeTransaction,encodeTransaction,hashTransaction} from '@bitauth/libauth';
import {validateClaimTransfer,encodeClaimTransfer} from './envelope-handoff.mjs';
import {CHECKPOINT,verifyProviderIdentity,validateUnspentList} from './live-funding-core.mjs';
import {buildEnvelopeSpend} from './envelope-core.mjs';
const scriptHash=script=>binToHex(sha256.hash(hexToBin(script)).reverse());
export async function lookupClaimFunding({transfer,rpc,signal,now=()=>Date.now()}){
 const t=validateClaimTransfer(transfer);const check=()=>{if(signal?.aborted)throw Error('Claim check cancelled.');};
 check();await rpc.call('server.version',['TipLink claim check','1.4.3']);check();
 const features=await rpc.call('server.features',[]);check();const header=await rpc.call('blockchain.block.header',[CHECKPOINT.height]);check();verifyProviderIdentity(features,header);
 const hash=scriptHash(t.contract.scriptHex);const list=validateUnspentList(await rpc.call('blockchain.scripthash.listunspent',[hash,'include_tokens']));check();
 const item=list.find(o=>o.txid===t.utxo.txid&&o.index===t.utxo.index);
 if(!item)return{status:'unavailable',checkedAt:now(),message:'The provider does not report this envelope as unspent. It may be unfunded, already claimed, recovered or unavailable.'};
 if(item.sats!==t.utxo.sats)throw Error('The provider amount does not match the claim link.');
 const raw=await rpc.call('blockchain.transaction.get',[t.utxo.txid,false]);check();
 if(typeof raw!=='string'||raw.length>40000||!/^(?:[a-fA-F0-9]{2})+$/.test(raw))throw Error('Invalid envelope funding transaction.');
 const tx=decodeTransaction(hexToBin(raw));if(typeof tx==='string'||binToHex(encodeTransaction(tx))!==raw.toLowerCase()||hashTransaction(hexToBin(raw))!==t.utxo.txid)throw Error('Envelope funding transaction ID mismatch.');
 const output=tx.outputs[t.utxo.index];if(!output||output.token!==undefined||output.valueSatoshis!==BigInt(t.utxo.sats)||binToHex(output.lockingBytecode)!==t.utxo.scriptHex)throw Error('The funded output does not match this envelope.');
 if(tx.inputs.length===1&&tx.inputs[0].outpointIndex===0xffffffff&&tx.inputs[0].outpointTransactionHash.every(x=>x===0))throw Error('Coinbase funding is unsupported.');
 const fresh=validateUnspentList(await rpc.call('blockchain.scripthash.listunspent',[hash,'include_tokens']));check();const current=fresh.find(o=>o.txid===item.txid&&o.index===item.index);
 if(!current||current.sats!==item.sats)throw Error('Envelope funding changed during the check. Check again.');
 const checkedAt=now();if(!Number.isSafeInteger(checkedAt)||checkedAt<0)throw Error('Invalid check time.');
 return{status:current.height>0?'confirmed':'unconfirmed',height:current.height,checkedAt,identity:encodeClaimTransfer(t),message:'Raw transaction verified locally; unspent and confirmation status reported by one provider. No SPV verification.'};
}
export function prepareRecipientClaim({transfer,snapshot,destination,feeRate=1,now=Date.now()}){
 const t=validateClaimTransfer(transfer);
 if(!snapshot||snapshot.status!=='confirmed'||snapshot.height<=0||snapshot.identity!==encodeClaimTransfer(t)||!Number.isSafeInteger(now)||!Number.isSafeInteger(snapshot.checkedAt)||now<snapshot.checkedAt||now-snapshot.checkedAt>=30000)throw Error('Check confirmed envelope funding again before preparing a claim.');
 return buildEnvelopeSpend({contract:t.contract,utxo:t.utxo,destination,privateKeyHex:t.claimPrivateKey,feeRate});
}
