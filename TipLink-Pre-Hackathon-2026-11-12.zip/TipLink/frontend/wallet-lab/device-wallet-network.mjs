import {binToHex,hexToBin,decodeTransaction,encodeTransaction,hashTransaction,secp256k1,encodeDataPush,generateSigningSerializationBCH,sha256,createVirtualMachineBCH} from '@bitauth/libauth';
import {validateDeviceWallet} from './device-wallet-core.mjs';
import {validateRecipient} from './preview-core.mjs';
import {checkNetwork,hashScript,checkPublishedTransaction} from './broadcast-core.mjs';
import {validateUnspentList} from './live-funding-core.mjs';
const MAX_LISTED_OUTPUTS=10000;
const MAX_SCAN_OUTPUTS=128;
const MAX_SEND_INPUTS=20;
const READ_BATCH_SIZE=8;
function largestFirst(a,b){
 const difference=BigInt(b.sats)-BigInt(a.sats);
 return difference===0n?a.txid.localeCompare(b.txid)||a.index-b.index:difference>0n?1:-1;
}
function confirmedInputs(coins){
 return coins.filter(c=>c.height>0).sort(largestFirst).slice(0,MAX_SEND_INPUTS);
}
const check=signal=>{if(signal?.aborted)throw Error('Wallet check cancelled.');};
export async function lookupDeviceWallet({wallet,rpc,signal,now=()=>Date.now()}){
 const w=validateDeviceWallet(wallet);
 await checkNetwork(rpc,signal);
 const hash=hashScript(w.scriptHex);
 const readOutputs=async()=>validateUnspentList(await rpc.call('blockchain.scripthash.listunspent',[hash,'include_tokens']),MAX_LISTED_OUTPUTS);
 const allOutputs=await readOutputs();
 const listed=allOutputs.sort((a,b)=>Number(b.height>0)-Number(a.height>0)||largestFirst(a,b)).slice(0,MAX_SCAN_OUTPUTS);
 const unscannedOutputs=allOutputs.length-listed.length;
 const coins=[];let excludedTokens=0,excludedCoinbase=0;
 const byTransaction=new Map();
 for(const item of listed){
  const group=byTransaction.get(item.txid)??[];
  group.push(item);
  byTransaction.set(item.txid,group);
 }
 const groups=[...byTransaction];
 for(let offset=0;offset<groups.length;offset+=READ_BATCH_SIZE){
  check(signal);
  await Promise.all(groups.slice(offset,offset+READ_BATCH_SIZE).map(async ([txid,items])=>{
   const raw=await rpc.call('blockchain.transaction.get',[txid,false]);
   check(signal);
   if(typeof raw!=='string'||raw.length>2000000||!/^(?:[a-fA-F0-9]{2})+$/.test(raw))throw Error('Could not verify a wallet transaction.');
   const bytes=hexToBin(raw),tx=decodeTransaction(bytes);
   if(typeof tx==='string'||!tx.inputs.length||binToHex(encodeTransaction(tx))!==raw.toLowerCase()||hashTransaction(bytes)!==txid)throw Error('Wallet transaction ID mismatch.');
   const coinbase=tx.inputs.length===1&&tx.inputs[0].outpointIndex===0xffffffff&&tx.inputs[0].outpointTransactionHash.every(v=>v===0);
   for(const item of items){
    const output=tx.outputs[item.index];
    if(!output||binToHex(output.lockingBytecode)!==w.scriptHex||output.valueSatoshis!==BigInt(item.sats))throw Error('Wallet output does not match its receiving address.');
    if(output.token!==undefined){excludedTokens++;continue;}
    if(coinbase){excludedCoinbase++;continue;}
    coins.push({txid,index:item.index,sats:item.sats,height:item.height,scriptHex:w.scriptHex});
   }
  }));
 }
 const fresh=await readOutputs();
 const byOutpoint=new Map(fresh.map(row=>[row.key,row]));
 if(fresh.length!==allOutputs.length||listed.some(row=>{
  const current=byOutpoint.get(row.key);
  return !current||current.sats!==row.sats||current.height!==row.height;
 }))throw Error('Wallet funding changed. Refresh before continuing.');
 check(signal);
 const confirmedSats=coins.filter(c=>c.height>0).reduce((s,c)=>s+BigInt(c.sats),0n),pendingSats=coins.filter(c=>c.height<=0).reduce((s,c)=>s+BigInt(c.sats),0n);if(confirmedSats+pendingSats>2100000000000000n)throw Error('Wallet amount exceeds supported range.');
 return{address:w.address,scriptHex:w.scriptHex,coins,confirmedSats,pendingSats,excludedTokens,excludedCoinbase,unscannedOutputs,checkedAt:now()};
}
export function prepareDeviceWalletSend({wallet,snapshot,destination,feeRate=1,now=Date.now()}){
 const w=validateDeviceWallet(wallet);if(!snapshot||snapshot.address!==w.address||snapshot.scriptHex!==w.scriptHex||!Number.isSafeInteger(now)||!Number.isSafeInteger(snapshot.checkedAt)||now<snapshot.checkedAt||now-snapshot.checkedAt>=30000||!Array.isArray(snapshot.coins)||snapshot.coins.length>MAX_SCAN_OUTPUTS)throw Error('Refresh this wallet before reviewing a payment.');
 if(!Number.isSafeInteger(feeRate)||feeRate<1||feeRate>100)throw Error('Invalid network fee estimate.');
 const recipient=validateRecipient(destination);if(recipient.address===w.address)throw Error('Choose a different BCH receiving address.');
 const seen=new Set();let confirmed=0n,pending=0n;
 for(const c of snapshot.coins){const key=c.txid+':'+c.index;if(typeof c.txid!=='string'||!/^[a-f0-9]{64}$/.test(c.txid)||!Number.isSafeInteger(c.index)||c.index<0||c.index>0xffffffff||typeof c.sats!=='string'||!/^[1-9]\d{0,15}$/.test(c.sats)||BigInt(c.sats)>2100000000000000n||!Number.isSafeInteger(c.height)||c.height< -1||c.scriptHex!==w.scriptHex||seen.has(key)||Object.hasOwn(c,'token'))throw Error('Invalid wallet funding snapshot.');seen.add(key);if(c.height>0)confirmed+=BigInt(c.sats);else pending+=BigInt(c.sats);}
 if(confirmed!==snapshot.confirmedSats||pending!==snapshot.pendingSats||confirmed+pending>2100000000000000n)throw Error('Wallet totals do not match the funding outputs.');
 const coins=confirmedInputs(snapshot.coins);
 if(!coins.length)throw Error('Wait for confirmed BCH, then refresh this wallet.');
 const totalInputSats=coins.reduce((sum,c)=>sum+BigInt(c.sats),0n);
 const remainingConfirmedSats=confirmed-totalInputSats;
 const pub=secp256k1.derivePublicKeyCompressed(hexToBin(w.privateKey));if(typeof pub==='string')throw Error('Could not open the wallet signing key.');
 const transaction={version:2,locktime:0,inputs:coins.map(c=>({outpointTransactionHash:hexToBin(c.txid),outpointIndex:c.index,sequenceNumber:0xffffffff,unlockingBytecode:new Uint8Array(100)})),outputs:[{lockingBytecode:hexToBin(recipient.scriptHex),valueSatoshis:1000n}]};
 const bytes=encodeTransaction(transaction).length,feeSats=BigInt(bytes*feeRate),receiveSats=totalInputSats-feeSats;if(receiveSats<1000n)throw Error('The confirmed balance cannot cover the network fee and minimum receiving amount.');transaction.outputs[0].valueSatoshis=receiveSats;
 const sourceOutputs=coins.map(c=>({lockingBytecode:hexToBin(c.scriptHex),valueSatoshis:BigInt(c.sats)}));
 for(let index=0;index<coins.length;index++){const preimage=generateSigningSerializationBCH({transaction,sourceOutputs,inputIndex:index},{coveredBytecode:sourceOutputs[index].lockingBytecode,signingSerializationType:Uint8Array.of(0x61)}),signature=secp256k1.signMessageHashSchnorr(hexToBin(w.privateKey),sha256.hash(sha256.hash(preimage)));if(typeof signature==='string')throw Error('Wallet signing failed.');transaction.inputs[index].unlockingBytecode=Uint8Array.from([...encodeDataPush(Uint8Array.from([...signature,0x61])),...encodeDataPush(pub)]);}
 if(encodeTransaction(transaction).length!==bytes||createVirtualMachineBCH().verify({transaction,sourceOutputs})!==true)throw Error('Wallet transaction could not be verified locally.');
 const hex=binToHex(encodeTransaction(transaction));return{hex,txid:hashTransaction(hexToBin(hex)),destination:recipient.address,receiveSats,feeSats,feeRate,totalInputSats,remainingConfirmedSats,address:w.address,snapshot,bytes};
}

export async function broadcastDeviceWalletSend({wallet,plan,rpc,signal,authorise=false,beforeSubmit}){
 if(authorise!==true)throw Error('Confirm the receiving address and amount before sending.');
 const w=validateDeviceWallet(wallet);if(!plan)throw Error('Review this wallet payment first.');
 const rebuilt=prepareDeviceWalletSend({wallet:w,snapshot:plan.snapshot,destination:plan.destination,feeRate:plan.feeRate,now:plan.snapshot.checkedAt});
 if(rebuilt.txid!==plan.txid||rebuilt.hex!==plan.hex||rebuilt.receiveSats!==plan.receiveSats||rebuilt.feeSats!==plan.feeSats||rebuilt.address!==plan.address)throw Error('The wallet payment changed. Review it again.');
 const existing=await checkPublishedTransaction({hex:plan.hex,rpc,signal});if(existing.status!=='unknown')return existing;
 const fresh=await lookupDeviceWallet({wallet:w,rpc,signal});
 const available=new Map(fresh.coins.filter(coin=>coin.height>0).map(coin=>[coin.txid+':'+coin.index,coin.sats]));
 if(confirmedInputs(plan.snapshot.coins).some(coin=>available.get(coin.txid+':'+coin.index)!==coin.sats))throw Error('The confirmed balance changed. Refresh and review the payment again.');
 check(signal);
 if(typeof beforeSubmit!=='function')throw Error('Save a transaction receipt before sending.');await beforeSubmit({txid:plan.txid,hex:plan.hex,kind:'wallet-send',envelopeTxid:null,walletAddress:w.address,status:'unknown',height:0,createdAt:Date.now(),checkedAt:Date.now()});check(signal);
 try{const result=await rpc.call('blockchain.transaction.broadcast',[plan.hex]);return{txid:plan.txid,status:result===plan.txid?'submitted':'unknown',height:0,checkedAt:Date.now()};}catch{return{txid:plan.txid,status:'unknown',height:0,checkedAt:Date.now()};}
}
