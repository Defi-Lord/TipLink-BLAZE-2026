// Presentation accounting only: no key handling, signing or network requests.
import {parseBch,normalizeBchInput} from '../src/split.mjs';
import {formatBch} from './preview-core.mjs';
const MAX=2100000000000000n;
export function validateSendAmount(value){const amount=parseBch(normalizeBchInput(value));if(amount<10000n||amount>MAX)throw Error('Enter at least 0.0001 BCH, within the supported amount.');return amount;}
export function summariseEnvelopeReview(plan){
 const values=['amountSats','feeSats','claimFeeEstimateSats','claimNetEstimateSats','totalInputSats','changeSats'];
 if(!plan||values.some(k=>typeof plan[k]!=='bigint'||plan[k]<0n||plan[k]>MAX))throw Error('Payment review amounts could not be verified.');
 if(plan.amountSats<10000n||plan.claimNetEstimateSats<1000n||plan.feeSats===0n||plan.claimFeeEstimateSats===0n||plan.claimNetEstimateSats+plan.claimFeeEstimateSats!==plan.amountSats||plan.totalInputSats!==plan.amountSats+plan.feeSats+plan.changeSats)throw Error('Payment review totals do not match.');
 const recipientSats=plan.claimNetEstimateSats,networkFeesSats=plan.feeSats+plan.claimFeeEstimateSats,totalFromWalletSats=plan.amountSats+plan.feeSats;
 if(totalFromWalletSats>MAX||recipientSats+networkFeesSats!==totalFromWalletSats)throw Error('Payment review totals do not match.');
 return{recipientSats,networkFeesSats,totalFromWalletSats,recipientBch:formatBch(recipientSats),networkFeesBch:formatBch(networkFeesSats),totalFromWalletBch:formatBch(totalFromWalletSats)};
}
export function explainSendError(error){const message=error?.message||'';if(/No confirmed/.test(message))return'We could not find spendable BCH in the part of your wallet we checked. No money has moved.';if(/cannot cover|Insufficient funding/.test(message))return'Your checked wallet funds cannot cover this amount and the network fees. Try a smaller amount.';if(/snapshot expired|review expired|15 minutes ahead/i.test(message))return'This transfer needs a fresh check. Start again or check the total again before continuing.';if(/passphrase/.test(message))return'Choose a password of 12–256 characters for your recovery file.';if(/declined/.test(message))return'Your wallet did not approve this request. You can try again when you are ready.';if(/cancelled/i.test(message))return'The check was cancelled. You can try again.';if(/amount|at least/.test(message))return message;if(/Connect a wallet/.test(message))return'Connect your wallet to continue.';return'We could not finish this step. Try again. If it continues, reconnect your wallet.';}
