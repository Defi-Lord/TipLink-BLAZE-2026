import {CashOutPreview} from './CashOutPreview.jsx';
import {DeviceWalletProvider,DeviceWalletPanel} from './DeviceWallet.jsx';
import {TransactionHistory} from './TransactionAction.jsx';
import React,{useEffect,useRef,useState} from 'react';
import {useWizardConnect} from '@wizardconnect/react';
import {WalletChooser} from './WalletChooser.jsx';
import {BusinessWorkspace,InvoiceCheckout} from './BusinessWorkspace.jsx';
import {INVOICE_ID} from './business-core.mjs';
import {MobileDashboard} from './MobileDashboard.jsx';
import {StatusMark} from './StatusReaction.jsx';
import {HomeScreen,LinkArtwork} from './HomeScreen.jsx';
import {EnvelopeFunding} from './EnvelopeFunding.jsx';
import {decodeClaimTransfer} from './envelope-handoff.mjs';
import {ClaimTransfer} from './ClaimTransfer.jsx';
import {RecipientJourney} from './RecipientJourney.jsx';
import {Brand,AppPreferences,useAppExperience} from './app-experience.jsx';
import {createLinkRecord,validateLinkRecord,decodePublicDemoLink,encodeLink,linkUrl,isExpired,exportRecords} from './links-core.mjs';
import {formatBch} from './preview-core.mjs';
import {openFundingRpc} from './funding-rpc.mjs';
import {discoverWalletFunding} from './live-funding-core.mjs';
const WalletAddresses=React.lazy(()=>import('./WalletAddresses.jsx').then(m=>({default:m.WalletAddresses}))); 
const RecipientPreview=React.lazy(()=>import('./RecipientPreview.jsx').then(m=>({default:m.RecipientPreview}))); 
const STORE='tiplink.public-links.v1';
const primaryPages = [
 ['home','home','Home','Home'],
 ['send','send','Send money','Send'],
 ['request','links','Request payment','Request'],
 ['activity','activity','Activity','Activity'],
];
const workspacePages = [
 ['wallet','wallet','Wallet'],
 ['business','cash','Business'],
 ['cash','cash','Cash in & out'],
];
function load(){try{const rows=JSON.parse(localStorage.getItem(STORE)||'[]');if(!Array.isArray(rows)||rows.length>100)return[];return rows.map(validateLinkRecord);}catch{return[];}}
const pagePaths={home:'/',send:'/send',request:'/request',activity:'/activity',wallet:'/wallet',business:'/business',cash:'/cash',tools:'/tools'};
function currentPage(){return Object.keys(pagePaths).find(page=>pagePaths[page]===location.pathname.replace(/\/$/,'')||pagePaths[page]===location.pathname)||'home';}
function incoming(){try{if(!location.hash)return{};if(location.hash.startsWith('#invoice=')){const id=location.hash.slice(9);if(!INVOICE_ID.test(id))throw Error('Invalid business request link.');return{invoiceId:id};}if(location.hash.startsWith('#claim='))return{transfer:decodeClaimTransfer(location.hash.slice(7))};if(!location.hash.startsWith('#tl='))throw Error('Unrecognised link format.');return{record:decodePublicDemoLink(location.hash.slice(4))};}catch(e){return{error:e.message};}}
function Icon({name,size=20}){const d={home:'M3 10l9-7 9 7v11h-7v-7h-4v7H3z',activity:'M21 12a9 9 0 11-18 0 9 9 0 0118 0 M12 7v5l3 2',send:'M3 3l19 9-19 9 4-9z M7 12h15',request:'M12 3v13 M7 11l5 5 5-5 M4 20h16',links:'M10 13a5 5 0 007 0l4-4a5 5 0 00-7-7l-2 2 M14 11a5 5 0 00-7 0l-4 4a5 5 0 007 7l2-2',wallet:'M3 6h17v15H3z M3 6V3h13v3 M15 12h7v5h-7z',arrow:'M4 12h16 M14 6l6 6-6 6',check:'M5 12l4 4L20 5',copy:'M8 8h12v13H8z M16 8V3H3v13h5',shield:'M12 3l8 3v6c0 6-8 9-8 9s-8-3-8-9V6z M8 12l3 3 5-6',code:'M8 5l-6 7 6 7 M16 5l6 7-6 7',cash:'M3 6h18v13H3z M8 6a5 5 0 01-5 5 M21 14a5 5 0 00-5 5 M14 12a2 2 0 11-4 0 2 2 0 014 0',close:'M5 5l14 14 M19 5L5 19'};return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={d[name]||d.links}/></svg>;}
export function LinkApp(){return <DeviceWalletProvider><LinkAppContent/></DeviceWalletProvider>;}
function LinkAppContent(){
 const wc=useWizardConnect({dappName:'TipLink',persistSession:false});const [tab,setTab]=useState(currentPage);const [received,setReceived]=useState(incoming);
 const [records,setRecords]=useState(load);const [created,setCreated]=useState(null);const [toast,setToast]=useState('');const [error,setError]=useState('');const [now,setNow]=useState(Date.now());
 const [sendMode,setSendMode]=useState('wallet');const [amount,setAmount]=useState('0.001');const [name,setName]=useState('');const [memo,setMemo]=useState('');const [hours,setHours]=useState('24');
 const [snapshot,setSnapshot]=useState(null);const [busy,setBusy]=useState(false);const active=useRef(null);
 const experience=useAppExperience();const errorRef=useRef(null);
 const [walletScreen,setWalletScreen]=useState(null);
 const [pairingError,setPairingError]=useState('');
 const pairingAttempt=useRef(0);
 useEffect(()=>{if(error)errorRef.current?.focus();},[error]);
 useEffect(()=>{if(!experience.moreOpen)Array.from(document.querySelectorAll('#content h1')).find(heading=>heading.getClientRects().length)?.focus({preventScroll:true});},[tab,received.record?.id]);
 const connected=wc.state==='connected';const pairing=['connecting','reconnecting'].includes(wc.state);
 useEffect(()=>{if(connected)setWalletScreen(null);},[connected]);
 useEffect(()=>{if(received.transfer)history.replaceState(null,'',location.pathname+location.search);},[received.transfer]);
 useEffect(()=>{const update=()=>{setReceived(incoming());setTab(currentPage());setCreated(null);setError('');};addEventListener('hashchange',update);addEventListener('popstate',update);const timer=setInterval(()=>setNow(Date.now()),1000);return()=>{removeEventListener('hashchange',update);removeEventListener('popstate',update);clearInterval(timer);};},[]);
 useEffect(()=>{try{localStorage.setItem(STORE,JSON.stringify(records));}catch{setError('This browser could not save link history. Copy any request you want to keep.');}},[records]);
 useEffect(()=>{setSnapshot(null);active.current?.abort();active.current=null;setBusy(false);return()=>active.current?.abort();},[wc.manager,wc.state]);
 useEffect(()=>{if(!toast)return;const id=setTimeout(()=>setToast(''),3200);return()=>clearTimeout(id);},[toast]);
 function navigate(next){experience.closeMore();if(next==='send'&&tab!=='send')setSendMode('wallet');if(location.pathname!==pagePaths[next]||location.hash)history.pushState(null,'',pagePaths[next]);setReceived({});setTab(next);setCreated(null);setError('');window.scrollTo({top:0,behavior:!experience.motionEnabled||matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});}
 async function copy(text){try{await navigator.clipboard.writeText(text);setToast('Copied to clipboard');}catch{setError('Clipboard unavailable. Select and copy the text shown below.');}}
 function openWalletChoices(){setPairingError('');setWalletScreen('choose');}
 function openExternalWallet(fromChooser=false){
  setWalletScreen(fromChooser===true?'external':'external-only');
  void startPairing();
 }
 function closeWalletChooser(){
  pairingAttempt.current++;
  setWalletScreen(null);
  if(pairing)void disconnect();
 }
 async function startPairing(){
  if(pairing||connected)return;
  const attempt=++pairingAttempt.current;
  setPairingError('');
  try{
   if(wc.state==='disconnected')await wc.disconnect();
   if(attempt!==pairingAttempt.current)return;
   if(wc.connect()===false)throw Error('Could not start wallet pairing. Try again.');
  }catch(e){if(attempt===pairingAttempt.current)setPairingError(e.message);}
 }
 async function disconnect(){active.current?.abort();setSnapshot(null);try{await wc.disconnect();}catch{setError('Disconnect TipLink inside your wallet too if the connection remains visible.');}}
 async function refresh(){setError('');if(!connected)return openExternalWallet();const controller=new AbortController();active.current?.abort();active.current=controller;setBusy(true);setSnapshot(null);let rpc;const deadline=setTimeout(()=>controller.abort(),90000);try{rpc=await openFundingRpc({signal:controller.signal});const {value:result}=await discoverWalletFunding({rpc,manager:wc.manager,state:wc.state,signal:controller.signal});if(active.current===controller&&!controller.signal.aborted)setSnapshot(result);}catch(e){if(active.current===controller)setError(e.message);}finally{clearTimeout(deadline);rpc?.close();if(active.current===controller){active.current=null;setBusy(false);}}}
 function create(e){e.preventDefault();setError('');try{const r=createLinkRecord({kind:'demo-send',amountBch:amount,name,memo,hours:Number(hours)});setRecords(old=>[r,...old].slice(0,100));setCreated(r);}catch(e){setError(e.message);}}
 function exportCsv(){const url=URL.createObjectURL(new Blob([exportRecords(records)],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='tiplink-activity.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 function exploreReceiving(){setError('');const demo=createLinkRecord({kind:'demo-send',amountBch:'0.001',name:'TipLink demo',memo:'A little something for you'});location.hash=`tl=${encodeLink(demo)}`;}

 const r=received.record;const publicView=!!r||!!received.invoiceId||!!received.transfer||!!received.error;const expired=r?isExpired(r,now):false;const title=tab==='home'?'Home':tab==='business'?'Business':tab==='request'?'Request payment':tab==='activity'?'Your links':tab==='wallet'?'Your wallet':tab==='cash'?'Cash in & out':tab==='tools'?'Developer tools':'Send money';
 const localHost=['localhost','127.0.0.1','[::1]'].includes(location.hostname);
 function resultCard(record){
  const url=linkUrl(record,location.href);
  return <section className="panel result-panel"><span className="tag">DEMO LINK READY</span><div className="result-icon"><StatusMark tone="success"/></div><h2>An envelope, ready to explore.</h2><p>No BCH has been funded. Open this link to walk through the recipient experience.</p><div className="result-amount">{formatBch(BigInt(record.sats))}<span>BCH</span></div><label>TipLink URL<textarea readOnly value={url} rows={3} onFocus={e=>e.target.select()}/></label>{localHost&&<div className="notice">This local preview opens on this computer only.</div>}<div className="button-row"><button className="primary" onClick={()=>copy(url)}><Icon name="copy" size={17}/>Copy link</button><a className="secondary" href={url}>Open claim demo<Icon name="arrow" size={16}/></a></div>{experience.canShare&&<button className="secondary full share-button" onClick={()=>experience.shareLink(url,'TipLink demo envelope').catch(()=>setError('Sharing could not open. Copy the link instead.'))}>Share using your apps<Icon name="send" size={17}/></button>}<button className="text-button" onClick={()=>setCreated(null)}>Create another link</button></section>;
 }
 return <div className={`tl-app ${publicView?'public-view':''}`} data-route={publicView?'checkout':tab} data-theme={experience.resolvedTheme} data-keyboard={experience.keyboardOpen?'open':'closed'} data-motion={experience.motionEnabled?'on':'off'}><a href="#content" className="skip" onClick={e=>{e.preventDefault();document.getElementById('content')?.focus();}}>Skip to content</a>
 {!publicView&&<aside className="rail">
   <button className="wordmark" onClick={()=>navigate('home')} aria-label="TipLink home"><Brand/></button>
   <nav aria-label="Main navigation">
     {[['Payments',primaryPages],['Workspace',workspacePages]].map(([group,pages])=><div className="rail-section" key={group}>
       <p>{group}</p>
       {pages.map(([key,icon,label])=><button title={label} aria-label={label} key={key} className={tab===key?'active':''} aria-current={tab===key?'page':undefined} onClick={()=>navigate(key)}><Icon name={icon}/><span>{label}</span></button>)}
     </div>)}
   </nav>
   <div className="rail-bottom"><button className="tools-button" title="Settings & tools" aria-label="Settings & tools" aria-haspopup="dialog" onClick={experience.openSettings}><Icon name="code"/><span>Settings & tools</span></button></div>
 </aside>}
 <div className="app-body"><header className="topbar">{publicView?<button className="wordmark" onClick={()=>navigate('home')}><Brand/></button>:<><div className="mobile-brand"><button className="wordmark" onClick={()=>navigate('home')} aria-label="TipLink home"><Brand/></button></div><div className="crumb"><button className="breadcrumb-home" onClick={()=>navigate('home')}>Home</button>{tab!=='home'&&<b aria-current="page"> / {title}</b>}</div></>}<div className="top-actions"><span className="network"><i/>Bitcoin Cash</span>{!publicView&&<button className="wallet-connect" aria-haspopup={connected?undefined:'dialog'} disabled={pairing} onClick={connected?()=>navigate('wallet'):openWalletChoices}><Icon name="wallet" size={17}/>{connected?(wc.walletName||'Connected'):pairing?'Pairing…':'Connect wallet'}</button>}{publicView&&<span className="tag">{received.transfer?'CLAIM LINK':r?.kind==='demo-send'?'DEMO EXPERIENCE':'PAYMENT REQUEST'}</span>}{!publicView&&<button className="mobile-wallet-button" disabled={pairing} aria-haspopup={connected?undefined:'dialog'} onClick={connected?()=>navigate('wallet'):openWalletChoices}><Icon name="wallet" size={17}/>Wallet</button>}{!publicView&&<button className="profile-button" onClick={experience.openMore} aria-label="Open app menu" aria-haspopup="dialog">T<span/></button>}</div></header>
 <main id="content" key={`${tab}-${received.record?.id||'workspace'}`} tabIndex={-1} className="content route-enter">{(error||wc.error)&&<div className="error" role="alert" ref={errorRef} tabIndex={-1}>{error||'Wallet connection reported an error. Open Your wallet and reset the connection.'}</div>}
 {received.error&&<section className="panel invalid"><span className="tag">LINK UNAVAILABLE</span><h1 tabIndex={-1}>Let’s check<br/>that link.</h1><p>{received.error}</p><button className="primary" onClick={()=>navigate('home')}>Open TipLink<Icon name="arrow"/></button></section>}
 {received.invoiceId&&<InvoiceCheckout key={received.invoiceId} id={received.invoiceId} now={now}/>}
 {received.transfer&&<ClaimTransfer transfer={received.transfer} onOpenWallet={()=>navigate('wallet')}/>}
 {r&&<div className="public-checkout">
  <div className="checkout-story"><h1 tabIndex={-1}>Try receiving a TipLink</h1><p>This is a demo. No money is attached.</p></div>
  <section className="panel checkout-card">
   <span className="tag">DEMO ENVELOPE</span>
   <div className="checkout-value">{formatBch(BigInt(r.sats))}<span>BCH · example amount</span></div>
   {expired?<div className="notice">This demo has expired.</div>:<RecipientJourney key={r.id} record={r} onExploreSending={()=>navigate('send')}/>}
  </section>
 </div>}
 {!publicView&&tab==='business'&&<BusinessWorkspace/>}
 {!publicView&&tab==='request'&&<section className="panel"><h1 tabIndex={-1}>Request payment</h1><p>Create a BCH payment request in Business and share its checkout link with your customer.</p><button className="primary" onClick={()=>navigate('business')}>Open Business <Icon name="arrow"/></button></section>}
 {!publicView&&tab==='home'&&<><MobileDashboard records={records} now={now} navigate={navigate} Icon={Icon}/><div className="desktop-home"><HomeScreen amount={amount} setAmount={setAmount} memo={memo} setMemo={setMemo} name={name} setName={setName} hours={hours} setHours={setHours} onSubmit={create} onSend={()=>navigate('send')} onRequest={()=>navigate('request')} onReceive={exploreReceiving} created={created} renderResult={resultCard}/></div></>}
 {!publicView&&tab==='send'&&<><div className="send-mode" role="group" aria-label="Send money mode"><button className={sendMode==='wallet'?'active':''} aria-pressed={sendMode==='wallet'} onClick={()=>setSendMode('wallet')}>Send money</button><button className={sendMode==='demo'?'active':''} aria-pressed={sendMode==='demo'} onClick={()=>setSendMode('demo')}>Try the demo</button></div>{sendMode==='wallet'&&<EnvelopeFunding manager={wc.manager} state={wc.state} walletName={wc.walletName} onConnect={openExternalWallet} onDone={()=>navigate('home')} initialAmount={amount}/>}</>}
 {!publicView&&tab==='send'&&sendMode==='demo'&&<><div className="page-heading"><div><span className="eyebrow">{tab==='send'?'A LITTLE SUPPORT. A WORLD OF POSSIBILITY.':'FOR YOUR WORK. FOR YOUR BUSINESS.'}</span><h1 tabIndex={-1}>{tab==='send'?<>Send something <em>good.</em></>:<>Get paid. <em>Simply.</em></>}</h1><p>{tab==='send'?'An amount, a note, a link. From your world to theirs.':'Create a clear payment request and share it in your next conversation.'}</p></div><span className="release"><i/>{tab==='send'?'Send / claim demo':'Request builder'}</span></div><div className="create-grid"><section className="story-panel flow-visual"><span className="flow-eyebrow">{tab==='send'?'A LITTLE SOMETHING. A LONG WAY.':'YOUR WORK. YOUR WAY.'}</span><h2>{tab==='send'?<>From your world<br/>to <i>theirs.</i></>:<>Less chasing.<br/><i>More possibility.</i></>}</h2><LinkArtwork/><div className="flow-caption"><Icon name={tab==='send'?'send':'links'} size={20}/><span>{tab==='send'?'Send an amount. Share a moment.':'One exact amount. One clear link.'}</span></div></section>
 {created?resultCard(created):<form className="panel create-form" onSubmit={create}><div className="form-heading"><span className="tag">{tab==='send'?'CREATE A DEMO ENVELOPE':'CREATE PAYMENT REQUEST'}</span><Icon name={tab==='send'?'send':'request'} size={23}/></div><h2>{tab==='send'?'Create your envelope':'Create a payment request'}</h2><p>{tab==='send'?'Walk through sending and receiving before live funding is enabled.':'Share a fixed BCH amount with a customer or client.'}</p><label htmlFor="amount">{tab==='send'?'Amount to send':'Amount to request'}</label><div className="amount-input"><input id="amount" value={amount} onChange={e=>setAmount(e.target.value)} inputMode="decimal" required/><span>BCH</span></div><div className="presets">{['0.0001','0.001','0.005'].map(v=><button type="button" key={v} className={amount===v?'selected':''} onClick={()=>setAmount(v)}>{v}</button>)}</div><label>Your name or business<input value={name} maxLength={60} onChange={e=>setName(e.target.value)} placeholder="Your name or business" autoComplete="organization"/></label><label>A little note <span>Optional</span><input value={memo} maxLength={160} onChange={e=>setMemo(e.target.value)} placeholder={tab==='send'?'A little something for your next chapter':'e.g. Website design · final payment'}/></label><label>Link lifetime<select value={hours} onChange={e=>setHours(e.target.value)}><option value="1">1 hour</option><option value="24">24 hours</option><option value="168">7 days</option><option value="720">30 days</option></select></label>{tab==='send'?<div className="protection"><Icon name="shield" size={19}/><div><b>Protected claims are planned</b><p>Optional claim codes and sender review will apply to sending money, separately from invoices.</p></div></div>:<div className="notice">This creates a BCH payment request. It does not automatically mark invoices paid or guarantee settlement.</div>}<button className="primary full" type="submit">{tab==='send'?'Create demo link':'Create payment request'}<Icon name="arrow"/></button><p className="secured"><Icon name="shield" size={14}/>{tab==='send'?'No funds leave your wallet in this demo':'Payment goes to the receiving address you enter'}</p></form>}</div><div className="steps-strip">{(tab==='send'?[['01','Enter an amount','A gift, support, or just because.'],['02','Send the link','Through the conversation you already have.'],['03','They claim it','No existing TipLink account needed.']]:[['01','Set the exact amount','Add your note and receiving address.'],['02','Share your request','A checkout link and payment QR.'],['03','Get paid in BCH','The customer confirms in their wallet.']]).map(([n,title,body])=><div key={n}><span>{n}</span><div><b>{title}</b><p>{body}</p></div></div>)}</div></>}
 {!publicView&&tab==='activity'&&<><div className="page-heading"><div><span className="eyebrow">EVERY LINK HAS A STORY.</span><h1 tabIndex={-1}>Your links. <em>In one place.</em></h1><p>Your local links and public transaction receipts, in one place.</p></div><button className="secondary" disabled={!records.length} onClick={exportCsv}>Export CSV<Icon name="request" size={16}/></button></div><div className="stats"><div><small>PAYMENT REQUESTS</small><b>{records.filter(r=>r.kind==='request').length}</b></div><div><small>DEMO ENVELOPES</small><b>{records.filter(r=>r.kind==='demo-send').length}</b></div><div><small>TRANSACTION RECEIPTS</small><strong>Check on demand</strong></div></div><section className="panel activity-panel"><div className="section-heading"><h2>Your links</h2><span className="tag">THIS DEVICE</span></div>{!records.length?<div className="empty"><Icon name="links" size={35}/><h3>Your first link starts here.</h3><p>Create an envelope demo or a payment request to see it here.</p><button className="primary" onClick={()=>navigate('send')}>Create a link<Icon name="arrow"/></button></div>:<div className="table-wrap"><table><thead><tr><th>Link</th><th>Amount</th><th>Created</th><th>Status</th><th>View</th></tr></thead><tbody>{records.map(item=><tr key={item.id}><td><b>{item.memo||item.name||'Untitled link'}</b><small>{item.kind==='demo-send'?'Demo envelope':'Payment request'}</small></td><td>{formatBch(BigInt(item.sats))}<small>BCH</small></td><td>{new Date(item.createdAt).toLocaleDateString()}</td><td><span className={`status ${item.kind==='demo-send'?'demo':''}`}>{isExpired(item,now)?'Expired':item.kind==='demo-send'?'Demo · no funds':'Payment not checked'}</span></td><td>{item.kind==='demo-send'?<a className="table-open" href={linkUrl(item,location.href)} aria-label={`Open ${item.memo||'link'}`}><Icon name="arrow" size={17}/></a>:<small>Legacy request</small>}</td></tr>)}</tbody></table></div>}</section><TransactionHistory/></>}
 {!publicView&&tab==='wallet'&&<><div className="page-heading"><div><span className="eyebrow">YOUR KEYS. YOUR CONTROL.</span><h1 tabIndex={-1}>Your wallet. <em>Your control.</em></h1><p>Use your TipLink wallet to hold BCH on this device, or connect an external wallet to fund a send link.</p></div></div><DeviceWalletPanel/><div className="wallet-grid"><section className="panel"><span className="tag">{connected?'CONNECTED':'NOT CONNECTED'}</span><h2>{connected?(wc.walletName||'Your BCH wallet'):'Bring your own wallet.'}</h2><p>Connect a compatible BCH wallet to check funding for a send link.</p><div className="button-row"><button className="primary" disabled={pairing||busy} onClick={connected?refresh:openExternalWallet}>{busy?'Checking funding…':connected?'Refresh funding':'Connect external wallet'}<Icon name="wallet" size={18}/></button>{(connected||pairing||wc.error)&&<button className="secondary" onClick={disconnect}>{pairing?'Cancel pairing':'Reset / disconnect'}</button>}</div><p className="fine">Refresh checks receive and change paths until 20 unused addresses in a row. Network providers can see the queried script hashes and your IP.</p>{busy&&<button className="text-button" onClick={()=>active.current?.abort()}>Cancel lookup</button>}</section><section className="balance-panel"><small>CHECKED CANDIDATE FUNDING</small><strong>{snapshot?formatBch(snapshot.totalSats):'—'}<span>BCH</span></strong><p>{snapshot?`${snapshot.candidates.length} outputs · ${snapshot.scannedScripts} funding scripts checked`:'Refresh to look for BCH funding.'}</p><Icon name="wallet" size={45}/></section></div>{snapshot&&<section className="panel funding"><h3>{snapshot.candidates.length?'Funding candidates found':'You can explore without adding funds.'}</h3><p>Checked {snapshot.checkedAt}. BCH checkpoint matched. Raw transaction IDs, values and scripts checked locally; confirmation and unspent status are provider-reported. Checks use network providers and raw transactions without SPV verification.</p><p className="fine">The Send screen can request wallet approval for a reviewed transaction. Sending requires a separate confirmation after wallet approval and saving the recovery file.</p></section>}</>}
 {!publicView&&tab==='cash'&&<CashOutPreview onOpenBusiness={()=>navigate('business')} onOpenWallet={()=>navigate('wallet')}/>}
 {!publicView&&tab==='tools'&&<React.Suspense fallback={<section className="panel" role="status">Loading developer tools…</section>}><section className="panel diagnostics"><span className="eyebrow">THE FOUNDATION STAYS.</span><h1 tabIndex={-1}>Under the hood.</h1><p>The earlier split-tip tools remain here. They are optional diagnostics, separate from sending money through a link.</p><details><summary>Wallet addresses & read-only funding inspector</summary><WalletAddresses manager={wc.manager} state={wc.state}/></details><details><summary>Split-tip & unsigned transaction lab</summary><RecipientPreview/></details><div className="notice">The new envelope engine is tested offline for recipient claim and sender recovery after a timeout. Wallet funding review and sign-only approval are available in Send. Broadcasting and live claims are not connected yet. A timeout permits recovery; it does not automatically return funds or disable the claim branch.</div></section></React.Suspense>}
 <footer><span>tiplink<span>.</span><small>Money, made shareable.</small></span><span>BUILT BY NAZZITECH <i/> BITCOIN CASH</span></footer>
 </main></div>{!publicView&&<nav className="mobile-dock" aria-label="App navigation">
   {primaryPages.map(([key,icon,label,shortLabel])=><button key={key} className={tab===key?'active':''} aria-current={tab===key?'page':undefined} onClick={()=>navigate(key)}><span><Icon name={icon} size={21}/></span><b>{shortLabel}</b></button>)}
   <button className={experience.moreOpen||['wallet','business','cash','tools'].includes(tab)?'active':''} aria-haspopup="dialog" aria-expanded={experience.moreOpen} onClick={experience.openMore}><span aria-hidden="true" className="dock-more-icon">•••</span><b>More</b></button>
 </nav>}{!publicView&&<AppPreferences experience={experience} onNavigate={navigate} activePage={tab}/>}{toast&&<div className="toast" role="status"><Icon name="check" size={18}/>{toast}</div>}{!publicView&&<WalletChooser screen={walletScreen==='external-only'?'external':walletScreen} wallet={wc}
   error={pairingError} onClose={closeWalletChooser}
   onExternal={()=>openExternalWallet(true)} onBack={walletScreen==='external'?openWalletChoices:undefined}
   onTipLink={()=>{closeWalletChooser();navigate('wallet');}} onPair={startPairing}/>}</div>;
}
