// Explicit, bounded mainnet submission. No retries, account registration or key storage.
import {binToHex,hexToBin,decodeTransaction,encodeTransaction,hashTransaction,sha256} from '@bitauth/libauth';
import {planFromProof,validateClaimTransfer,encodeClaimTransfer} from './envelope-handoff.mjs';
import {verifySignedEnvelopeFunding} from './envelope-funding.mjs';
import {lookupClaimFunding} from './claim-lookup.mjs';
import {validateEnvelopeDraft} from './envelope-draft.mjs';
import {buildEnvelopeSpend} from './envelope-core.mjs';
import {CHECKPOINT,verifyProviderIdentity,validateUnspentList} from './live-funding-core.mjs';
export const hashScript=script=>binToHex(sha256.hash(hexToBin(script)).reverse());
const checkSignal=signal=>{if(signal?.aborted)throw Error('Transaction check cancelled before submission.');};
export function parsePublicTransaction(hex){
 if(typeof hex!=='string'||hex.length>40000||!/^(?:[a-f0-9]{2})+$/.test(hex))throw Error('Invalid reviewed transaction.');
 const tx=decodeTransaction(hexToBin(hex));if(typeof tx==='string'||binToHex(encodeTransaction(tx))!==hex||!tx.inputs.length||!tx.outputs.length)throw Error('Invalid reviewed transaction.');
 return{tx,txid:hashTransaction(hexToBin(hex)),hex};
}
export async function checkNetwork(rpc,signal){checkSignal(signal);await rpc.call('server.version',['TipLink explicit transaction','1.4.3']);checkSignal(signal);const features=await rpc.call('server.features',[]);checkSignal(signal);const header=await rpc.call('blockchain.block.header',[CHECKPOINT.height]);checkSignal(signal);verifyProviderIdentity(features,header);}
function historyRows(value){if(!Array.isArray(value)||value.length>200)throw Error('Transaction history exceeds supported limits.');const seen=new Set();return value.map(row=>{if(!row||typeof row.tx_hash!=='string'||!/^[a-f0-9]{64}$/.test(row.tx_hash)||!Number.isSafeInteger(row.height)||row.height< -1||seen.has(row.tx_hash))throw Error('Invalid transaction history.');seen.add(row.tx_hash);return row;});}
async function published({hex,rpc,signal}){
 const{tx,txid}=parsePublicTransaction(hex);checkSignal(signal);
 const history=historyRows(await rpc.call('blockchain.scripthash.get_history',[hashScript(binToHex(tx.outputs[0].lockingBytecode))]));checkSignal(signal);
 const row=history.find(r=>r.tx_hash===txid);if(!row)return{txid,status:'unknown',height:0,checkedAt:Date.now()};
 const raw=await rpc.call('blockchain.transaction.get',[txid,false]);checkSignal(signal);
 if(typeof raw!=='string'||raw.toLowerCase()!==hex||hashTransaction(hexToBin(raw))!==txid)throw Error('Network transaction does not match the reviewed bytes.');
 return{txid,status:row.height>0?'confirmed':'seen',height:Math.max(0,row.height),checkedAt:Date.now()};
}
export async function checkPublishedTransaction({hex,rpc,signal}){parsePublicTransaction(hex);await checkNetwork(rpc,signal);return published({hex,rpc,signal});}
export function reviewFunding(handoff){
 const transfer=validateClaimTransfer(handoff?.transfer),backup=handoff?.backup;
 if(!backup||backup.type!=='tiplink-approved-transfer'||backup.version!==1)throw Error('Open the approved recovery file first.');
 const plan=planFromProof(backup.proof),verified=verifySignedEnvelopeFunding(backup.signedFundingHex,plan),out=plan.transaction.outputs[0];
 if(verified.txid!==transfer.utxo.txid||out.valueSatoshis!==BigInt(transfer.utxo.sats)||binToHex(out.lockingBytecode)!==transfer.contract.scriptHex)throw Error('Approved transaction and envelope do not match.');
 return{transfer,plan,verified};
}
async function freshSources({plan,rpc,signal}){
 const lists=new Map(),seen=new Set();
 for(let index=0;index<plan.transaction.inputs.length;index++){
  checkSignal(signal);const input=plan.transaction.inputs[index],source=plan.sourceOutputs[index],txid=binToHex(input.outpointTransactionHash),script=binToHex(source.lockingBytecode),hash=hashScript(script);
  if(!lists.has(hash))lists.set(hash,validateUnspentList(await rpc.call('blockchain.scripthash.listunspent',[hash,'include_tokens'])));
  const key=txid+':'+input.outpointIndex;if(seen.has(key))throw Error('Duplicate wallet funding input.');seen.add(key);
  const row=lists.get(hash).find(r=>r.txid===txid&&r.index===input.outpointIndex);
  if(!row||row.height<=0||BigInt(row.sats)!==source.valueSatoshis)throw Error('Wallet funding is no longer confirmed and unspent. Do not create a second transfer until you check the first transaction.');
  const raw=await rpc.call('blockchain.transaction.get',[txid,false]);checkSignal(signal);
  if(typeof raw!=='string'||raw.length>2000000||!/^(?:[a-fA-F0-9]{2})+$/.test(raw))throw Error('Invalid source transaction.');
  const bytes=hexToBin(raw),tx=decodeTransaction(bytes);if(typeof tx==='string'||binToHex(encodeTransaction(tx))!==raw.toLowerCase()||hashTransaction(bytes)!==txid)throw Error('Source transaction ID mismatch.');
  const output=tx.outputs[input.outpointIndex];if(!output||output.token!==undefined||output.valueSatoshis!==source.valueSatoshis||binToHex(output.lockingBytecode)!==script||(tx.inputs.length===1&&tx.inputs[0].outpointIndex===0xffffffff&&tx.inputs[0].outpointTransactionHash.every(v=>v===0)))throw Error('Funding source does not match the reviewed transaction.');
 }
 for(const [hash,list]of lists){checkSignal(signal);const fresh=validateUnspentList(await rpc.call('blockchain.scripthash.listunspent',[hash,'include_tokens']));const fingerprint=rows=>rows.map(r=>`${r.key}:${r.sats}:${r.height}`).sort().join('|');if(fingerprint(fresh)!==fingerprint(list))throw Error('Wallet funding changed. Check transaction status before trying again.');}
}
async function submit({hex,rpc,signal,beforeSubmit,kind,envelopeTxid}){
 const{txid}=parsePublicTransaction(hex);checkSignal(signal);
 if(typeof beforeSubmit!=='function')throw Error('Save a transaction receipt before sending.');
 await beforeSubmit({txid,hex,kind,envelopeTxid,status:'unknown',height:0,createdAt:Date.now(),checkedAt:Date.now()});
 checkSignal(signal);
 // Once this call starts, an error cannot prove that the network did not receive it.
 try{const returned=await rpc.call('blockchain.transaction.broadcast',[hex]);return{txid,status:returned===txid?'submitted':'unknown',height:0,checkedAt:Date.now()};}catch{return{txid,status:'unknown',height:0,checkedAt:Date.now()};}
}
export async function broadcastFunding({handoff,rpc,signal,authorise=false,beforeSubmit,now=Date.now()}){
 if(authorise!==true)throw Error('Confirm sending this exact transaction first.');
 const{transfer,plan,verified}=reviewFunding(handoff);await checkNetwork(rpc,signal);
 const existing=await published({hex:verified.signedHex,rpc,signal});if(existing.status!=='unknown')return existing;
 if(transfer.contract.reclaimAfter*1000-now<900000)throw Error('Recovery time is too close or has passed. Do not fund this envelope. Create a new transfer only after checking this transaction’s status.');
 await freshSources({plan,rpc,signal});
 return submit({hex:verified.signedHex,rpc,signal,beforeSubmit,kind:'funding',envelopeTxid:verified.txid});
}
export async function readMedianTimePast({rpc,signal}){
 const tip=await rpc.call('blockchain.headers.subscribe',[]);checkSignal(signal);
 if(!tip||!Number.isSafeInteger(tip.height)||tip.height<CHECKPOINT.height||tip.height>10000000||typeof tip.hex!=='string'||!/^[a-fA-F0-9]{160}$/.test(tip.hex))throw Error('Could not check network recovery time.');
 let previous;const times=[];
 for(let height=tip.height-10;height<=tip.height;height++){
  const raw=await rpc.call('blockchain.block.header',[height]);checkSignal(signal);if(typeof raw!=='string'||!/^[a-fA-F0-9]{160}$/.test(raw))throw Error('Invalid recovery-time header.');const bytes=hexToBin(raw);
  if(previous&&binToHex(bytes.slice(4,36).reverse())!==previous)throw Error('Recovery-time headers are inconsistent.');
  previous=binToHex(sha256.hash(sha256.hash(bytes)).reverse());times.push(new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength).getUint32(68,true));
  if(height===tip.height&&raw.toLowerCase()!==tip.hex.toLowerCase())throw Error('Chain tip changed. Check recovery time again.');
 }
 return times.sort((a,b)=>a-b)[5];
}
export function prepareRecovery({handoff,snapshot,destination,feeRate=1,now=Date.now()}){
 const{transfer}=reviewFunding(handoff);const draft=validateEnvelopeDraft(handoff.draft);
 if(draft.contract.address!==transfer.contract.address||draft.amountSats!==transfer.utxo.sats||draft.claimPrivateKey!==transfer.claimPrivateKey)throw Error('Recovery file does not match this envelope.');
 if(!snapshot||snapshot.status!=='confirmed'||snapshot.identity!==encodeClaimTransfer(transfer)||now<snapshot.checkedAt||now-snapshot.checkedAt>=30000)throw Error('Check confirmed envelope funding before preparing recovery.');
 return buildEnvelopeSpend({contract:transfer.contract,utxo:transfer.utxo,destination,privateKeyHex:draft.recoveryPrivateKey,branch:'reclaim',feeRate});
}
export async function broadcastEnvelopeSpend({transfer,handoff,plan,rpc,signal,authorise=false,beforeSubmit}){
 if(authorise!==true)throw Error('Confirm the receiving address and amount first.');
 const t=validateClaimTransfer(transfer);if(!plan||!['claim','reclaim'].includes(plan.branch))throw Error('Prepare this transaction for review first.');
 let key=t.claimPrivateKey;
 if(plan.branch==='reclaim'){const d=validateEnvelopeDraft(handoff?.draft);if(d.contract.address!==t.contract.address||d.claimPrivateKey!==t.claimPrivateKey||d.amountSats!==t.utxo.sats)throw Error('Wrong recovery file.');key=d.recoveryPrivateKey;}
 const rebuilt=buildEnvelopeSpend({contract:t.contract,utxo:t.utxo,destination:plan.destination,privateKeyHex:key,branch:plan.branch,feeRate:plan.feeRate??1});
 if(rebuilt.hex!==plan.hex||rebuilt.receiveSats!==plan.receiveSats||rebuilt.feeSats!==plan.feeSats)throw Error('The reviewed receiving transaction changed. Prepare it again.');
 await checkNetwork(rpc,signal);const existing=await published({hex:rebuilt.hex,rpc,signal});if(existing.status!=='unknown')return existing;
 const snapshot=await lookupClaimFunding({transfer:t,rpc,signal});if(snapshot.status!=='confirmed')throw Error('The envelope is not confirmed and unspent. Check transaction status before trying again.');
 if(plan.branch==='reclaim'){if((await readMedianTimePast({rpc,signal}))<=t.contract.reclaimAfter)throw Error('Network recovery time has not been reached. Check again later.');const latest=await lookupClaimFunding({transfer:t,rpc,signal});if(latest.status!=='confirmed')throw Error('Envelope changed while checking recovery time. Check transaction status.');}
 checkSignal(signal);return submit({hex:rebuilt.hex,rpc,signal,beforeSubmit,kind:plan.branch==='reclaim'?'recovery':'claim',envelopeTxid:t.utxo.txid});
}
