import React from 'react';

const marks = {
  pending: 'M12 7v5l3 2',
  success: 'm6 12 4 4 8-8',
  warning: 'M12 7v6m0 3v.25',
  error: 'm8 8 8 8m0-8-8 8',
};

export function StatusMark({tone, className = ''}) {
  return <span className={`status-mark status-mark--${tone} ${className}`} aria-hidden="true">
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
      {tone === 'pending' && <circle cx="12" cy="12" r="9"/>}
      <path d={marks[tone]}/>
    </svg>
  </span>;
}
