import {parseBch,normalizeBchInput} from '../src/split.mjs';
import {validateRecipient,formatBch} from './preview-core.mjs';
export const INVOICE_ID=/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
export function validateSavedInvoice(value){
 const keys=['id','merchantName','amountSats','address','memo','state','version','createdAt','expiresAt','paymentStatus','monitoringConnected'];
 const allowed=[...keys,'receipt','receiptEligible'];
 if(!value||typeof value!=='object'||Object.keys(value).some(k=>!allowed.includes(k))||keys.some(k=>!Object.hasOwn(value,k))||!INVOICE_ID.test(value.id))throw Error('Unexpected saved payment request.');
 if(Object.hasOwn(value,'receiptEligible')&&typeof value.receiptEligible!=='boolean')throw Error('Invalid receipt eligibility.');
 if(typeof value.merchantName!=='string'||value.merchantName.length>80||typeof value.memo!=='string'||value.memo.length>160||/[\u0000-\u001f\u007f]/.test(value.merchantName+value.memo))throw Error('Invalid payment request details.');
 if(typeof value.amountSats!=='string'||! /^[1-9]\d{0,15}$/.test(value.amountSats)||BigInt(value.amountSats)<1000n||BigInt(value.amountSats)>2100000000000000n)throw Error('Invalid payment request amount.');
 if(!['open','cancelled','expired'].includes(value.state)||!Number.isSafeInteger(value.version)||value.version<1)throw Error('Unsupported payment request status.');
 if(value.receipt){validateReceipt(value.receipt);if(value.paymentStatus!==value.receipt.status||value.monitoringConnected!==true)throw Error('Invalid receipt status.');}else if(value.paymentStatus!=='not_checked'||value.monitoringConnected!==false)throw Error('Unsupported payment request status.');
 const start=Date.parse(value.createdAt),end=Date.parse(value.expiresAt);if(!Number.isFinite(start)||!Number.isFinite(end)||end<=start||end-start>30*86400000)throw Error('Invalid payment request lifetime.');
 return{...value,merchantName:value.merchantName.normalize('NFKC').replace(/\p{Cf}/gu,'').slice(0,80),memo:value.memo.normalize('NFKC').replace(/\p{Cf}/gu,'').slice(0,160),address:validateRecipient(value.address).address};
}
export function invoiceActive(value,now=Date.now()){const r=validateSavedInvoice(value);return r.state==='open'&&now>=Date.parse(r.createdAt)&&now<Date.parse(r.expiresAt);}
export function savedInvoiceUrl(value,base){const r=validateSavedInvoice(value),url=new URL(base);if(!['https:','http:'].includes(url.protocol)||url.username||url.password)throw Error('Invalid link origin.');if(url.protocol!=='https:'&&!['localhost','127.0.0.1','[::1]'].includes(url.hostname))throw Error('Public checkout links require HTTPS.');url.pathname='/';url.search='';url.hash='invoice='+r.id;return url.href;}
export function savedInvoiceUri(value,now=Date.now()){const r=validateSavedInvoice(value);if(!invoiceActive(r,now))throw Error('This payment request is not active.');const params=new URLSearchParams({amount:formatBch(BigInt(r.amountSats)),label:r.merchantName});if(r.memo)params.set('message',r.memo);return r.address+'?'+params.toString();}

export async function fetchInvoiceCheckout(id,{signal,fetcher=globalThis.fetch}={}){
 if(!INVOICE_ID.test(id))throw Error('Invalid payment request link.');
 const response=await fetcher('/api/v1/public/invoices/'+id,{signal,cache:'no-store',credentials:'omit',referrerPolicy:'no-referrer'});
 if(!response.ok)throw Error(response.status===404?'This payment request could not be found.':'Could not load this payment request. Try again.');
 const invoice=validateSavedInvoice(await response.json());
 if(invoice.id!==id)throw Error('The returned payment request does not match this link.');
 return invoice;
}
export function createMerchantClient({fetcher=globalThis.fetch,signal}={}){
 let csrf='';
 async function request(path,{method='GET',body}={}){
  if(!/^\/(?:auth\/(?:login|register|session|logout|wallet\/(?:config|challenge|verify))|profile|invoices(?:\/[a-f0-9-]+\/(?:cancel|receipt))?|pricing|quotes)$/.test(path))throw Error('Unsupported business request.');
  const headers={};if(path==='/invoices'&&method==='GET')headers['X-TipLink-Receipt-Binding']='1';if(body!==undefined)headers['Content-Type']='application/json';if(csrf&&method!=='GET')headers['X-CSRF-Token']=csrf;
  let response,data;try{response=await fetcher('/api/v1/merchant'+path,{method,credentials:'same-origin',headers,body:body===undefined?undefined:JSON.stringify(body),signal,referrerPolicy:'no-referrer'});data=await response.json();}catch(error){if(error.name==='AbortError')throw error;throw Error('Could not reach the business backend. Keep the server on port 4100 running. If saving failed, refresh your list before creating another request.');}
  if(!response.ok){const error=Error(typeof data.error==='string'?data.error:'Business request failed.');error.status=response.status;throw error;}
  if(path==='/auth/login'||path==='/auth/session'||path==='/auth/wallet/verify')csrf=data.csrfToken;
  if(path==='/auth/logout')csrf='';return data;
 }
 return{request};
}

export function parseBusinessAmount(value,allowZero=false){if(allowZero&&typeof value==='string'&&/^0(?:\.0{1,8})?$/.test(value))return 0n;return parseBch(normalizeBchInput(value));}

export function validateReceipt(r){
 const keys=['txid','outputIndex','status','lastStatus','height','checkedAt','source'];
 if(!r||typeof r!=='object'||Object.keys(r).length!==keys.length||Object.keys(r).some(k=>!keys.includes(k))||!/^[a-f0-9]{64}$/.test(r.txid)||!Number.isSafeInteger(r.outputIndex)||r.outputIndex<0||!['seen','confirmed','not_found','unavailable','stale'].includes(r.status)||!['seen','confirmed','not_found','unavailable'].includes(r.lastStatus)||!Number.isSafeInteger(r.height)||r.height<0||(r.lastStatus==='confirmed')!==(r.height>0)||(r.status!=='stale'&&r.status!==r.lastStatus)||!Number.isFinite(Date.parse(r.checkedAt))||r.source!=='rostrum.riften.net')throw Error('Invalid payment receipt.');
 return r;
}
export function receiptLabel(r,now=Date.now()){
 if(!r)return 'Not checked';validateReceipt(r);
 const status=now-Date.parse(r.checkedAt)>60000?'stale':r.status;
 return {seen:'Seen · awaiting confirmation',confirmed:'Confirmed · provider reported',not_found:'No longer found · review',unavailable:'Provider unavailable · recheck',stale:'Needs a fresh check'}[status];
}
function csvCell(value){let s=String(value??'');if(/^[\s]*[=+@-]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';}
export function invoiceCsv(items,now=Date.now()){
 const rows=[['Request ID','Note','Amount BCH','Receiving address','Request status','Receipt status','Transaction ID','Output index','Checked at','Provider','Created at','Expires at','Merchant name','Amount satoshis','Exported at UTC']];
 for(const item of items){const r=validateSavedInvoice(item);rows.push([r.id,r.memo,formatBch(BigInt(r.amountSats)),r.address,r.state==='open'&&now>=Date.parse(r.expiresAt)?'expired':r.state,receiptLabel(r.receipt,now),r.receipt?.txid,r.receipt?.outputIndex,r.receipt?.checkedAt,r.receipt?.source,r.createdAt,r.expiresAt,r.merchantName,r.amountSats,new Date(now).toISOString()]);}
 return '\uFEFF'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n')+'\r\n';
}
