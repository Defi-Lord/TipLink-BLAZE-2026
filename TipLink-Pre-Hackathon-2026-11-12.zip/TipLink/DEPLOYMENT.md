# TipLink public pilot source export

This folder contains source for review and deployment, not a live deployment. No credentials or local database were intentionally copied. Review source for any credentials you may have hard-coded before pushing it anywhere.

Frontend: Vercel project root frontend, build npm run build:wallet, output wallet-lab/dist. Backend: separate Node/Docker service with project root backend, verified-TLS PostgreSQL, and HTTPS. The Dockerfile is supplied but has not been built in this environment. Existing local data/accounts are not automatically transferred.

The initial frontend configuration has NO API rewrites. Once both stable public HTTPS URLs are known, run Configure-Public-Urls.ps1 in this folder. It writes only public origins, selected customer API rewrites and a production environment TEMPLATE. It does not publish, connect to databases or set secrets. Configure DATABASE_URL privately in the backend hosting settings; never paste it into chat or put it in Vercel frontend variables. Use a dedicated TipLink database, not the MySureGas or Sharpally databases.

Backend settings: NODE_ENV=production, HOST=0.0.0.0, host-provided PORT, APP_ORIGIN=backend HTTPS origin, CUSTOMER_APP_ORIGIN=frontend HTTPS origin, DATABASE_URL=private PostgreSQL URL. Set the public WALLETCONNECT_PROJECT_ID and allow the new customer origin in that Reown project. TLS certificate verification stays enabled; provide the provider CA using DATABASE_CA_FILE if required. Plaintext-only PostgreSQL is not supported by this backend.

Before the FIRST backend service start, run node dist/migrate-cli.js as a reviewed pre-deploy command against the dedicated TipLink database. This changes that hosted database; do not run it against another project. Startup is node dist/server.js; healthcheck path is /api/v1/health. Create the first hosted administrator with the private-input bootstrap after the target service is explicitly selected. Your local administrator account is not included.

Only customer merchant/auth/invoice/quote/pricing and public invoice routes are proxied from the customer origin. Administrator routes are never proxied. Secure merchant cookies must round-trip through the customer-domain proxy; verify this after deployment. Do not enable CDN caching for API/session data. Preview-domain writes stay blocked unless the configured customer origin matches.

Frontend CSP is REPORT-ONLY until browser wallet/relay flows are tested. This is not enforced XSS protection or a security sign-off. There is no external report collector. The no-referrer and no-store/API headers and no-index pilot header are configured separately. Browser network/CSP checks are required before enforcing the CSP or opening a public launch. Do not enable third-party analytics/session replay that could capture wallet passwords or private links.

One backend instance only for the initial pilot. In-memory rate limiting has not been hardened for a multi-proxy/multi-instance deployment; shared proxy IPs may produce overly strict throttling. Hosted PostgreSQL, provider CA, hosted cookies, Docker image execution and phone/device flows remain unverified. No production data copy, migration, external Git push or publication was performed by exporting.

Use a stable customer origin: changing domains changes browser-local wallet storage. Keep encrypted wallet backups and their passwords before moving to another origin. Private claim keys remain in URL fragments and browser memory; never paste private claim links into hosting dashboards or logs.

After HTTPS is live, test both domains and API isolation, wallet sign-in, a harmless payment request, encrypted guest-wallet creation/backup/unlock/restore, then an explicitly reviewed small BCH send > claim > onward-payment round trip. No real funded round trip has been verified yet. Backend automatic settlement tracking, fiat ramps, protected phone identity and app-store releases remain pending.
