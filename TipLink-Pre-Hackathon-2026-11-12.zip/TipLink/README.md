> Pre-hackathon source snapshot for BCH BLAZE 2026. Original commit `5bc094c40ccacbd3f6fb25165558004d2b832131`, deployed November 12, 2026. The original README below describes the project at that point in time.

# TipLink

### Send a little. Mean a lot.

Bitcoin Cash payments made shareable. TipLink lets a sender fund a claimable link and share it with a recipient. Businesses can also request an exact BCH payment through a link or invoice.

**Built by [Nazzitech](https://nazzitech.vercel.app) · Developer: [Defi-Lord](https://github.com/Defi-Lord) · BCH BLAZE project**

**Stage: early pilot.** `tip-link.xyz` is the intended customer domain; deployment and a real funded end-to-end payment test are still pending. This repository is proof of work, not a claim of production readiness or an independent security audit.

![TipLink brand illustration](frontend/wallet-lab/public/midnight/link-sculpture.webp)

*Brand artwork from the app; not a screenshot of a completed payment.*

## What TipLink does

- **Send by link:** choose a BCH amount, save the encrypted transfer recovery file, review wallet approval, then explicitly submit the funding transaction. Share the private claim link after the app verifies confirmed, unspent funding with its provider.
- **Receive without an existing TipLink account:** open the link, use an existing BCH address or create an encrypted browser wallet, save its backup, review the claim and explicitly submit it.
- **Business payments:** merchant accounts, wallet sign-in, exact-amount requests, memos, expiration, public checkout, QR payment details, cancellation and CSV export.
- **Payment receipt checks:** merchants can attach and check a transaction ID on demand. This is not automatic invoice settlement monitoring.
- **Operations:** protected admin access, actual account/request counts, versioned proposed pricing and audit history.
- **Business calculator:** exact BCH arithmetic and estimates with platform policy shown separately from network fees.
- **Responsive interface:** a midnight navy, glass and lime visual system designed for mobile, tablet and desktop layouts. App-store builds are planned.

## Engineering demonstrated

React interface engineering; TypeScript/Express APIs; PostgreSQL schema migrations; wallet signature verification; Bitcoin Cash transaction preparation and local script verification; encrypted browser storage and recovery; deterministic monetary arithmetic; explicit transaction approval; authentication, authorization and CSRF protections; regression tests; and deployment configuration.

The customer app and backend/admin have separate origins. Customer API requests are narrowly proxied to the backend; administrator routes are excluded from that proxy. Private claim material is carried in URL fragments and handled by the client rather than intentionally placed in API request paths.

## Stack and structure

| Area | Implementation |
| --- | --- |
| Customer app | React, Vite, JavaScript modules and CSS |
| BCH integration | libauth, WizardConnect, WalletConnect message signing and a Rostrum provider |
| Backend | Node.js, Express and TypeScript |
| Database | PostgreSQL; local development uses PGlite |
| Checks | Node test runner, TypeScript and Vite builds |
| Hosting preparation | Static frontend configuration and a separate backend Dockerfile |

```text
frontend/
  wallet-lab/       Customer app and BCH transaction flows
  src/             Exact amount/splitting utilities
  test/            Frontend/core regression tests
backend/
  src/             API, authentication, pricing and receipt checks
  migrations/      Required PostgreSQL schema migrations
  public/          Admin interface
  test/            Backend and deployment-tool tests
  tools/           Diagnostics and pilot export tools
tools/             Export-specific public URL configuration
```

## Run locally

Use Node.js 22.23.2 or later and npm. Install dependencies separately in each folder.

```powershell
# Terminal 1, starting at the repository root
Set-Location backend
npm ci
npm run build
npm run db:migrate
npm run dev
```

The migration command above initializes the default **local development database** when no `DATABASE_URL` is configured. If an environment file points to a hosted database, verify that target before running any migration. Never commit `.env` files or database credentials.

```powershell
# Terminal 2, starting at the repository root
Set-Location frontend
npm ci
npm run dev
```

Customer app: `http://127.0.0.1:5173/`. Backend/admin: `http://127.0.0.1:4100/`. Administrative access requires a separately created administrator; there are no bundled administrator credentials. Wallet sign-in requires your public Reown project ID configured on the backend. Email-based merchant registration is also available.

## Validate

```powershell
# From frontend/
npm test
npm run build:wallet

# From backend/
npm test
npm run test:pilot
```

The uploaded source review passed **176 frontend checks, 74 backend checks and 16 pilot/export checks**, plus TypeScript and Vite builds. These runs used existing installed dependencies in the review environment. Clean lockfile installation, Docker image execution, hosted PostgreSQL/TLS, hosted cookies and device/browser interaction still require deployment validation. The frontend build currently warns about a JavaScript chunk over 500 kB.

Tests include synthetic keys, addresses and passwords. They are public fixtures, not usable accounts or funded payment destinations. Do not send BCH to fixture addresses.

## Payment and wallet boundaries

- BCH is Bitcoin Cash, distinct from BTC. The explicit transfer flows target BCH mainnet.
- A private claim link is a bearer secret: someone with the link may claim it. Never publish it, include it in screenshots or send it to analytics.
- Browser wallets are encrypted locally. Keep the encrypted backup and its password; losing the password cannot be fixed by an administrator. Changing the app domain changes browser storage.
- The sender's recovery delay enables a recovery spend; it does not automatically refund money or disable a recipient claim. Conflicting claim and recovery transactions compete for the same funds.
- Network status is provider-reported, not independently SPV-verified. A submitted transaction is not the same as a confirmed payment.
- Proposed pricing is personal 0%, merchant 1%; platform fee collection is disabled. Network fees are separate.
- The guest wallet currently supports one address and sending all confirmed funds, less the network fee. It does not yet replace every external wallet flow.
- No real funded send → guest claim → onward payment round trip has been verified. Use only a deliberately reviewed small amount for the first live test.

## Deployment and roadmap

See [DEPLOYMENT.md](DEPLOYMENT.md). Intended customer origin: `https://tip-link.xyz`; intended backend/admin origin: `https://api.tip-link.xyz`. These addresses describe the deployment plan, not verified live services. The export initially has no hosted API forwarding; configure the public URLs before hosting the connected business app.

Next milestones are public HTTPS hosting, hosted database and cookie verification, cross-device testing and the small funded payment round trip. Automatic payment reconciliation, fiat on/off ramps, phone identity, optional recipient questions and native app-store releases remain future work.

## Ownership

Created by Nazzitech. No open-source license is granted by this repository at this stage. Public visibility supports inspection of the proof of work; choose and add an explicit license before inviting reuse under open-source terms.
