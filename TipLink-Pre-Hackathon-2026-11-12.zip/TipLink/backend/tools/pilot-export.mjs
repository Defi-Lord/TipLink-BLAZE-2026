import {mkdir,readdir,readFile,writeFile,copyFile,lstat,realpath} from 'node:fs/promises';
import {resolve,join,extname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {homedir} from 'node:os';
import {randomUUID,createHash} from 'node:crypto';
import {createVercelConfig} from './pilot-config.mjs';
const deniedDirs=new Set(['node_modules','dist','data','backups','.git','.vite','.vercel','.railway','.next','upload','uploads']);
const allowedExtensions=new Set(['.mjs','.js','.jsx','.ts','.tsx','.css','.html','.json','.webmanifest','.svg','.png','.webp','.jpg','.jpeg','.ico','.woff','.woff2','.ttf']);
export const requiredMigrations=Object.freeze(['001_foundation.sql','002_merchant_requests.sql','003_wallet_accounts.sql','004_payment_receipts.sql']);
const walletTypes=new Set(['tiplink-encrypted-wallet','tiplink-private-draft','tiplink-approved-transfer','tiplink-claim','tiplink-encrypted-draft','tiplink-device-wallet','tiplink-device-wallet-slot']);
export function exportableName(name){return !name.startsWith('.')&&!/\.env(?:\.|$)/i.test(name)&&allowedExtensions.has(extname(name).toLowerCase());}
async function safeCopy(source,target,manifest,logical){const stat=await lstat(source);if(!stat.isFile()||stat.isSymbolicLink())return;const bytes=await readFile(source);if(extname(source)==='.json'){let value;try{value=JSON.parse(bytes.toString('utf8'));}catch{throw Error('Invalid JSON source in export.');}if(walletTypes.has(value?.type))return;}
 await mkdir(resolve(target,'..'),{recursive:true});await writeFile(target,bytes);manifest.push({file:logical,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}
async function tree(source,target,manifest,prefix){const stat=await lstat(source);if(!stat.isDirectory()||stat.isSymbolicLink())throw Error('Source folder must be a normal directory.');await mkdir(target,{recursive:true});for(const entry of await readdir(source,{withFileTypes:true})){if(entry.isSymbolicLink())continue;if(entry.isDirectory()){if(entry.name.startsWith('.')||deniedDirs.has(entry.name.toLowerCase()))continue;await tree(join(source,entry.name),join(target,entry.name),manifest,prefix+'/'+entry.name);}else if(exportableName(entry.name))await safeCopy(join(source,entry.name),join(target,entry.name),manifest,prefix+'/'+entry.name);}}
const dockerfile=`FROM node:22-bookworm-slim AS build
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci --ignore-scripts --no-fund
COPY tsconfig.json ./
COPY src ./src
RUN npm run build && npm prune --omit=dev --ignore-scripts --no-fund

FROM node:22-bookworm-slim
WORKDIR /app
ENV NODE_ENV=production HOST=0.0.0.0
COPY --from=build --chown=node:node /app/node_modules ./node_modules
COPY --from=build --chown=node:node /app/dist ./dist
COPY --chown=node:node package.json package-lock.json ./
COPY --chown=node:node public ./public
COPY --chown=node:node migrations ./migrations
COPY --chown=node:node tools ./tools
USER node
EXPOSE 4100
CMD ["node", "dist/server.js"]
`;
export async function exportPilot({backendRoot,frontendRoot,outputParent}){
 const backend=await realpath(resolve(backendRoot)),frontend=await realpath(resolve(frontendRoot)),parent=await realpath(resolve(outputParent));
 const normal=s=>process.platform==='win32'?s.toLowerCase():s;
 if([backend,frontend].some(folder=>normal(parent)===normal(folder)||normal(parent).startsWith(normal(folder+sep))))throw Error('Export outside both source projects.');
 for(const folder of [backend,frontend]){const p=JSON.parse(await readFile(join(folder,'package.json'),'utf8'));await readFile(join(folder,'package-lock.json'));if(folder===frontend&&typeof p.scripts?.['build:wallet']!=='string')throw Error('Frontend build:wallet script is missing.');}
 const migrationFolder=join(backend,'migrations');const migrationStat=await lstat(migrationFolder);if(!migrationStat.isDirectory()||migrationStat.isSymbolicLink())throw Error('Migration folder must be a normal directory.');
 for(const file of requiredMigrations){const stat=await lstat(join(migrationFolder,file));if(!stat.isFile()||stat.isSymbolicLink())throw Error('Required migration must be a normal file.');}
 const output=join(parent,'TipLink-Pilot-Export-'+new Date().toISOString().replace(/[:.]/g,'-')+'-'+randomUUID().slice(0,8));await mkdir(output,{recursive:false});const manifest=[];
 for(const [name,folder,trees]of [['frontend',frontend,['src','test','wallet-lab']],['backend',backend,['src','test','public','migrations']]]){
  const target=join(output,name);await mkdir(target);for(const file of ['package.json','package-lock.json',...(name==='backend'?['tsconfig.json']:[])])await safeCopy(join(folder,file),join(target,file),manifest,name+'/'+file);
  for(const sub of trees)await tree(join(folder,sub),join(target,sub),manifest,name+'/'+sub);
 }
 for(const file of requiredMigrations)await safeCopy(join(migrationFolder,file),join(output,'backend','migrations',file),manifest,'backend/migrations/'+file);
 await mkdir(join(output,'backend','tools'));for(const file of ['backend-doctor.mjs','pilot-config.mjs','configure-public.mjs','pilot-export.mjs'])await copyFile(fileURLToPath(new URL('./'+file,import.meta.url)),join(output,'backend','tools',file));
 await mkdir(join(output,'tools'));for(const file of ['pilot-config.mjs','configure-public.mjs'])await copyFile(fileURLToPath(new URL('./'+file,import.meta.url)),join(output,'tools',file));
 await writeFile(join(output,'frontend','vercel.json'),JSON.stringify(createVercelConfig(),null,2)+'\n');
 await writeFile(join(output,'backend','Dockerfile'),dockerfile);
 await writeFile(join(output,'backend','.dockerignore'),'.env\n.env.*\n*.env\n*.env.*\n**/.env\n**/.env.*\n**/*.env\n**/*.env.*\nnode_modules\ndata\nbackups\n.git\n*.tiplink*\n*.pem\n*.key\n');
 await writeFile(join(output,'.gitignore'),'.env\n.env.*\n*.env\n*.env.*\n!*.env.example\n**/node_modules/\n**/dist/\n**/.vite/\n**/data/\n**/backups/\n*.tiplink*\n*.pem\n*.key\n*.log\n');
 await writeFile(join(output,'pilot-export.json'),JSON.stringify({type:'tiplink-pilot-export',version:1,configured:false,backendOrigin:null,customerOrigin:null,published:false},null,2)+'\n');
 await writeFile(join(output,'SOURCE-MANIFEST.json'),JSON.stringify(manifest,null,2)+'\n');
 await writeFile(join(output,'Configure-Public-Urls.ps1'),`$ErrorActionPreference = 'Stop'
$backendOrigin = Read-Host 'Public HTTPS backend/admin origin (no path)'
$customerOrigin = Read-Host 'Public HTTPS customer origin (a different host, no path)'
$inputJson = @{backendOrigin=$backendOrigin;customerOrigin=$customerOrigin} | ConvertTo-Json -Compress
$inputJson | & node (Join-Path $PSScriptRoot 'tools\\configure-public.mjs')
if ($LASTEXITCODE -ne 0) { throw 'Public URL configuration stopped. No publication was attempted.' }
`);
 await writeFile(join(output,'DEPLOYMENT.md'),`# TipLink public pilot source export

This folder contains source for review and deployment, not a live deployment. No credentials or local database were intentionally copied. Review source for any credentials you may have hard-coded before pushing it anywhere.

Frontend: Vercel project root frontend, build npm run build:wallet, output wallet-lab/dist. Backend: separate Node/Docker service with project root backend, verified-TLS PostgreSQL, and HTTPS. The Dockerfile is supplied but has not been built in this environment. Existing local data/accounts are not automatically transferred.

The initial frontend configuration has NO API rewrites. Once both stable public HTTPS URLs are known, run Configure-Public-Urls.ps1 in this folder. It writes only public origins, selected customer API rewrites and a production environment TEMPLATE. It does not publish, connect to databases or set secrets. Configure DATABASE_URL privately in the backend hosting settings; never paste it into chat or put it in Vercel frontend variables. Use a dedicated TipLink database, not the MySureGas or Sharpally databases.

Backend settings: NODE_ENV=production, HOST=0.0.0.0, host-provided PORT, APP_ORIGIN=backend HTTPS origin, CUSTOMER_APP_ORIGIN=frontend HTTPS origin, DATABASE_URL=private PostgreSQL URL. Set the public WALLETCONNECT_PROJECT_ID and allow the new customer origin in that Reown project. TLS certificate verification stays enabled; provide the provider CA using DATABASE_CA_FILE if required. Plaintext-only PostgreSQL is not supported by this backend.

Before the FIRST backend service start, run node dist/migrate-cli.js as a reviewed pre-deploy command against the dedicated TipLink database. This changes that hosted database; do not run it against another project. Startup is node dist/server.js; healthcheck path is /api/v1/health. Create the first hosted administrator with the private-input bootstrap after the target service is explicitly selected. Your local administrator account is not included.

Only customer merchant/auth/invoice/quote/pricing and public invoice routes are proxied from the customer origin. Administrator routes are never proxied. Secure merchant cookies must round-trip through the customer-domain proxy; verify this after deployment. Do not enable CDN caching for API/session data. Preview-domain writes stay blocked unless the configured customer origin matches.

Frontend CSP is REPORT-ONLY until browser wallet/relay flows are tested. This is not enforced XSS protection or a security sign-off. There is no external report collector. The no-referrer and no-store/API headers and no-index pilot header are configured separately. Browser network/CSP checks are required before enforcing the CSP or opening a public launch. Do not enable third-party analytics/session replay that could capture wallet passwords or private links.

One backend instance only for the initial pilot. In-memory rate limiting has not been hardened for a multi-proxy/multi-instance deployment; shared proxy IPs may produce overly strict throttling. Hosted PostgreSQL, provider CA, hosted cookies, Docker image execution and phone/device flows remain unverified. No production data copy, migration, external Git push or publication was performed by exporting.

Use a stable customer origin: changing domains changes browser-local wallet storage. Keep encrypted wallet backups and their passwords before moving to another origin. Private claim keys remain in URL fragments and browser memory; never paste private claim links into hosting dashboards or logs.

After HTTPS is live, test both domains and API isolation, wallet sign-in, a harmless payment request, encrypted guest-wallet creation/backup/unlock/restore, then an explicitly reviewed small BCH send > claim > onward-payment round trip. No real funded round trip has been verified yet. Backend automatic settlement tracking, fiat ramps, protected phone identity and app-store releases remain pending.
`);
 return{exportFolder:output,copiedSourceFiles:manifest.length,configured:false,published:false};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{if(process.argv.length>2)throw Error('Unsupported arguments.');console.log(JSON.stringify(await exportPilot({backendRoot:fileURLToPath(new URL('../',import.meta.url)),frontendRoot:process.env.TIPLINK_FRONTEND_PATH||join(homedir(),'Documents','tiplink-starter'),outputParent:join(homedir(),'Documents')}),null,2));}catch{console.error('Pilot export stopped. Check source folders, package/lock files and write permissions. No publication was attempted.');process.exitCode=1;}
}
