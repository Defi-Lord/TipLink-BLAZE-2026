import {randomUUID} from 'node:crypto';
import type {Database,Sql,Row} from './database.js';
import {Problem,email,name,password,hashPassword,verifyPassword,randomToken,tokenHash} from './security.js';
import {validatePolicyChange,type Policy} from './pricing.js';
export type Account={id:string;email:string|null;displayName:string;role:'merchant'|'admin';walletAddress:string|null;profileComplete:boolean};
export type Session={account:Account;csrfToken:string;tokenHash:string};
type AccountRow=Row&{id:string;email:string|null;display_name:string;role:'merchant'|'admin';password_hash:string|null;active:boolean;wallet_address:string|null;profile_completed:boolean};
const publicAccount=(r:AccountRow):Account=>({id:r.id,email:r.email,displayName:r.display_name,role:r.role,walletAddress:r.wallet_address??null,profileComplete:r.profile_completed!==false});
const time=(v:unknown)=>new Date(v as string).toISOString();
function policyRow(r:Row):Policy{return{version:Number(r.version),personalBps:Number(r.personal_bps),merchantBps:Number(r.merchant_bps),merchantCapSats:r.merchant_cap_sats===null?null:String(r.merchant_cap_sats),collectionEnabled:false,createdAt:time(r.created_at)};}
export async function audit(sql:Sql,actorId:string,action:string,entityId:string,details:object={}){await sql.query('INSERT INTO audit_events(id,actor_id,action,entity_id,details) VALUES($1,$2,$3,$4,$5)',[randomUUID(),actorId,action,entityId,JSON.stringify(details)]);}
export class Store {
 constructor(public db:Database){}
 async register(input:{email:unknown;displayName:unknown;password:unknown},role:'merchant'|'admin'='merchant'){
  const address=email(input.email),displayName=name(input.displayName),hash=await hashPassword(password(input.password));const id=randomUUID();
  try{return await this.db.transaction(async sql=>{
   if(role==='admin'){await sql.query('SELECT id FROM bootstrap_lock WHERE id=1 FOR UPDATE');const admins=await sql.query('SELECT id FROM accounts WHERE role=$1 LIMIT 1',['admin']);if(admins.rows.length)throw new Problem(409,'An administrator already exists. Bootstrap creation is closed.');}
   const result=await sql.query<AccountRow>('INSERT INTO accounts(id,email,display_name,role,password_hash) VALUES($1,$2,$3,$4,$5) RETURNING *',[id,address,displayName,role,hash]);
   await audit(sql,id,role==='admin'?'admin.bootstrapped':'merchant.registered',id);
   return publicAccount(result.rows[0]!);
  });}catch(error){if((error as {code?:string}).code==='23505')throw new Problem(409,'An account with that email already exists.');throw error;}
 }
 async login(address:unknown,secret:unknown,requiredRole?:'merchant'|'admin'){const normalized=email(address);const pass=password(secret);const result=await this.db.query<AccountRow>('SELECT * FROM accounts WHERE email=$1',[normalized]);const user=result.rows[0];
  // Perform the same KDF work when the email is unknown.
  const dummy='scrypt1$'+'0'.repeat(32)+'$'+'0'.repeat(128);const valid=await verifyPassword(pass,user?.password_hash||dummy);
  if(!user||!user.active||!valid)throw new Problem(401,'Email or password is incorrect.');
  if(requiredRole&&user.role!==requiredRole)throw new Problem(403,'Use the workspace for your account type.');
  const token=randomToken(),csrfToken=randomToken();await this.db.transaction(async sql=>{await sql.query('DELETE FROM sessions WHERE expires_at<=now()');await sql.query("INSERT INTO sessions(token_hash,account_id,csrf_token,expires_at) VALUES($1,$2,$3,now()+interval '24 hours')",[tokenHash(token),user.id,csrfToken]);await audit(sql,user.id,'session.started',user.id);});
  return{token,csrfToken,account:publicAccount(user)};
 }
 async session(token:string|undefined):Promise<Session|null>{if(!token||!/^[a-f0-9]{64}$/.test(token))return null;const hash=tokenHash(token);const result=await this.db.query<AccountRow&{csrf_token:string}>('SELECT a.*,s.csrf_token FROM sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token_hash=$1 AND s.expires_at>now() AND a.active=true',[hash]);const user=result.rows[0];return user?{account:publicAccount(user),csrfToken:user.csrf_token,tokenHash:hash}:null;}
 async logout(session:Session){await this.db.transaction(async sql=>{await sql.query('DELETE FROM sessions WHERE token_hash=$1',[session.tokenHash]);await audit(sql,session.account.id,'session.ended',session.account.id);});}
 async policy(){const result=await this.db.query('SELECT p.* FROM pricing_versions p JOIN pricing_head h ON h.version=p.version WHERE h.id=1');if(!result.rows[0])throw Error('Pricing schema is missing.');return policyRow(result.rows[0]);}
 async updatePolicy(actor:Account,input:unknown){if(actor.role!=='admin')throw new Problem(403,'Administrator access is required.');const change=validatePolicyChange(input);return this.db.transaction(async sql=>{
  const head=await sql.query('SELECT version FROM pricing_head WHERE id=1 FOR UPDATE');const version=Number(head.rows[0]?.version);if(version!==change.expectedVersion)throw new Problem(409,'Pricing changed in another session. Reload before saving.');
  const next=version+1;const result=await sql.query('INSERT INTO pricing_versions(version,personal_bps,merchant_bps,merchant_cap_sats,changed_by,reason) VALUES($1,$2,$3,$4,$5,$6) RETURNING *',[next,change.personalBps,change.merchantBps,change.merchantCapSats,actor.id,change.reason]);await sql.query('UPDATE pricing_head SET version=$1 WHERE id=1',[next]);await audit(sql,actor.id,'pricing.changed',String(next),{previousVersion:version,personalBps:change.personalBps,merchantBps:change.merchantBps,merchantCapSats:change.merchantCapSats,collectionEnabled:false,reason:change.reason});return policyRow(result.rows[0]!);
 });}
 async overview(){const result=await this.db.query("SELECT count(*) FILTER(WHERE role='merchant')::integer AS merchants,count(*) FILTER(WHERE role='admin')::integer AS admins FROM accounts");return{merchants:Number(result.rows[0]?.merchants),admins:Number(result.rows[0]?.admins),paymentMonitoring:'not_connected',transactionVolumeSats:null,revenueSats:null,feeCollectionEnabled:false,databaseMode:this.db.mode};}
 async merchants(){const result=await this.db.query<AccountRow>("SELECT id,email,display_name,role,created_at,active,wallet_address,profile_completed FROM accounts WHERE role='merchant' ORDER BY created_at DESC,id LIMIT 100");return result.rows.map(r=>({...publicAccount(r),active:r.active,createdAt:time(r.created_at)}));}
 async events(){const result=await this.db.query('SELECT e.id,e.action,e.entity_id,e.details,e.created_at,a.display_name AS actor FROM audit_events e LEFT JOIN accounts a ON a.id=e.actor_id ORDER BY e.created_at DESC,e.id LIMIT 100');return result.rows.map(r=>({id:r.id,action:r.action,entityId:r.entity_id,details:r.details,createdAt:time(r.created_at),actor:r.actor}));}
}
