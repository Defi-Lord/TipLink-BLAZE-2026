import express,{type Request,type Response,type NextFunction} from 'express';
import {fileURLToPath} from 'node:url';
import type {Config} from './config.js';
import {Store,type Session} from './store.js';
import {Problem,exact,equalToken} from './security.js';
import {InvoiceStore} from './invoices.js';
import {merchantRoutes} from './merchant-routes.js';
import {PaymentReceipts,type Lookup} from './payment-receipts.js';
import {BreetBanks} from './breet-banks.js';
import {quote} from './pricing.js';
function cookie(req:Request){const matches=(req.headers.cookie||'').split(';').map(s=>s.trim()).filter(s=>s.startsWith('tiplink_session='));return matches.length===1?matches[0]!.slice('tiplink_session='.length):undefined;}
export function createApp(store:Store,config:Config,paymentLookup?:Lookup,receipts=new PaymentReceipts(store.db,paymentLookup),invoices=new InvoiceStore(store.db)){
 const breetBanks=new BreetBanks(config);const customerOrigin=config.customerOrigin||(config.production?config.origin:'http://127.0.0.1:5173');
 const app=express();app.disable('x-powered-by');app.disable('etag');app.set('trust proxy',false);
 app.use((_req,res,next)=>{res.set({'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",'Permissions-Policy':'camera=(), microphone=(), geolocation=()'});if(config.production)res.set('Strict-Transport-Security','max-age=31536000');next();});
 app.use('/api',(_req,res,next)=>{res.set('Cache-Control','no-store');next();});
 const limits=new Map<string,{count:number;until:number}>();
 app.use('/api/v1',(req,_res,next)=>{const key=req.ip||'unknown',now=Date.now();const path=req.path.toLowerCase();const auth=path.startsWith('/auth/')||path.startsWith('/merchant/auth/');const limitKey=(auth?'auth:':'api:')+key;let item=limits.get(limitKey);if(!item||now>=item.until){if(limits.size>=10000){for(const [key,value]of limits)if(now>=value.until)limits.delete(key);if(limits.size>=10000)return next(new Problem(503,'Server is busy. Try again shortly.'));}item={count:0,until:now+(auth?600000:60000)};limits.set(limitKey,item);}if(++item.count>(auth?30:300))return next(new Problem(429,'Too many requests. Try again later.'));next();});
 app.use('/api/v1',(req,_res,next)=>{if(!['GET','HEAD','OPTIONS'].includes(req.method)){if(req.headers.origin!==config.origin&&!(req.path.toLowerCase().startsWith('/merchant/')&&req.headers.origin===customerOrigin))return next(new Problem(403,'Request origin is not allowed.'));if(!req.is('application/json'))return next(new Problem(415,'Use an application/json request.'));}next();});
 app.use(express.json({limit:'12kb',strict:true}));
 const setCookie=(res:Response,value:string,clear=false)=>res.cookie('tiplink_session',value,{httpOnly:true,secure:config.production,sameSite:'strict',path:'/',maxAge:clear?0:86400000});
 async function requireSession(req:Request,res:Response,next:NextFunction){try{const session=await store.session(cookie(req));if(!session)throw new Problem(401,'Sign in to continue.');res.locals.session=session;if(!['GET','HEAD'].includes(req.method)&&!equalToken(req.headers['x-csrf-token'],session.csrfToken))throw new Problem(403,'Your security token is missing or expired. Reload and try again.');next();}catch(error){next(error);}}
 function requireAdmin(_req:Request,res:Response,next:NextFunction){if((res.locals.session as Session).account.role!=='admin')return next(new Problem(403,'Administrator access is required.'));next();}
 app.use('/api/v1/merchant',merchantRoutes(store,invoices,config,receipts));
 app.get('/api/v1/public/invoices/:id',async(req,res)=>res.json(await invoices.publicInvoice(String(req.params.id))));
 app.get('/api/v1/health',async(_req,res)=>{await store.db.query('SELECT 1');res.json({status:'ok',service:'tiplink-backend',paymentMonitoring:'merchant_txid_checks',backgroundReceiptChecks:config.receiptWorkerEnabled===true});});
 app.get('/api/v1/pricing',async(_req,res)=>res.json(await store.policy()));
 app.post('/api/v1/quotes',async(req,res)=>res.json(quote(req.body,await store.policy())));
 app.post('/api/v1/auth/register',async(req,res)=>{exact(req.body,['email','displayName','password']);const account=await store.register({email:req.body.email,displayName:req.body.displayName,password:req.body.password});res.status(201).json({account});});
 app.post('/api/v1/auth/login',async(req,res)=>{exact(req.body,['email','password']);const result=await store.login(req.body.email,req.body.password);setCookie(res,result.token);res.json({account:result.account,csrfToken:result.csrfToken});});
 app.get('/api/v1/auth/session',requireSession,(_req,res)=>{const session=res.locals.session as Session;res.json({account:session.account,csrfToken:session.csrfToken});});
 app.post('/api/v1/auth/logout',requireSession,async(req,res)=>{exact(req.body,[]);await store.logout(res.locals.session as Session);setCookie(res,'',true);res.json({ok:true});});
 app.use('/api/v1/admin',requireSession,requireAdmin);
 app.get('/api/v1/admin/breet/withdrawals',async(_req,res)=>res.json(await breetBanks.withdrawals()));
 app.get('/api/v1/admin/overview',async(_req,res)=>res.json({...await store.overview(),invoices:await invoices.summary()}));
 app.get('/api/v1/admin/invoices',async(_req,res)=>res.json({items:await invoices.adminList()}));
 app.get('/api/v1/admin/merchants',async(_req,res)=>res.json({items:await store.merchants()}));
 app.get('/api/v1/admin/audit',async(_req,res)=>res.json({items:await store.events()}));
 app.put('/api/v1/admin/pricing',async(req,res)=>res.json(await store.updatePolicy((res.locals.session as Session).account,req.body)));
 app.use('/api',(_req,res)=>res.status(404).json({error:'Endpoint not found.'}));
 app.use(express.static(fileURLToPath(new URL('../public',import.meta.url)),{index:'index.html',maxAge:0}));
 app.use((_req,res)=>res.status(404).send('Page not found.'));
 app.use((error:unknown,_req:Request,res:Response,_next:NextFunction)=>{if(error instanceof Problem)return void res.status(error.status).json({error:error.message});const status=(error as {status?:number})?.status;if(status===400||status===413)return void res.status(status).json({error:status===413?'Request is too large.':'Invalid JSON request.'});console.error('Request failed. Check database availability and application configuration.');res.status(500).json({error:'The request could not be completed. Try again later.'});});
 return app;
}
