import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {once} from 'node:events';
import {encodeCashAddress,encodeTransaction,binToHex,hexToBin,hashTransaction} from '@bitauth/libauth';
import {inspectNewInvoiceAddress,inspectPayment,lookupPayment} from '../dist/payment-network.js';
import {PaymentReceipts,presentReceipt} from '../dist/payment-receipts.js';
import {openDatabase} from '../dist/database.js';import {migrate} from '../dist/migrate.js';import {Store} from '../dist/store.js';import {InvoiceStore} from '../dist/invoices.js';import {createApp} from '../dist/app.js';
const header='0040312bdba9b08737140488c02ee43532296d9763fa36feabd23c0100000000000000000eaa975763bf54a0e37dfc1a25f2e447fcf2ed2eef4f51ce2d7b96adaf8dec8470e5256829740218ba0d6201';
const features={genesis_hash:'000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f',hash_function:'sha256'};
const address=encodeCashAddress({prefix:'bitcoincash',type:'p2pkh',payload:new Uint8Array(20).fill(83)}).address;
const script='76a914'+'53'.repeat(20)+'88ac';
function fixture({token,amount=100000n,scriptHex=script,duplicate=false,coinbase=false}={}){const output={valueSatoshis:amount,lockingBytecode:hexToBin(scriptHex),...(token?{token}:{})};const bytes=encodeTransaction({version:2,locktime:0,inputs:[{outpointTransactionHash:new Uint8Array(32).fill(coinbase?0:9),outpointIndex:coinbase?0xffffffff:0,sequenceNumber:0xffffffff,unlockingBytecode:new Uint8Array()}],outputs:duplicate?[output,output]:[output]});return{raw:binToHex(bytes),txid:hashTransaction(bytes)};}
function rpc(options={}){const fund=options.fund||fixture();let calls=0;return{async call(method){if(method==='server.version')return['fixture','1.4.3'];if(method==='server.features')return options.features||features;if(method==='blockchain.block.header')return options.header||header;if(method==='blockchain.headers.subscribe')return {height:899999,hex:header};if(method==='blockchain.scripthash.get_history'){calls++;return options.history??(options.changed&&calls>1?[]:[{tx_hash:fund.txid,height:options.height??900000}]);}if(method==='blockchain.transaction.get')return options.raw??fund.raw;throw Error('Unexpected RPC');}};}
const inspect=options=>{const f=options?.fund||fixture();return inspectPayment(rpc(options),f.txid,address,'100000');};
test('raw exact BCH payment is matched and height is provider-reported',async()=>{assert.deepEqual(await inspect(),{status:'confirmed',height:900000,outputIndex:0});assert.equal((await inspect({height:0})).status,'seen');assert.equal((await inspect({height:-1})).status,'seen');});
test('network/genesis/hash function/checkpoint mismatch fails before attribution',async()=>{for(const options of [{features:{...features,genesis_hash:'bad'}},{features:{...features,hash_function:'other'}},{header:'00'.repeat(80)}])await assert.rejects(inspect(options),/network checkpoint/);});
test('missing transaction in history is not payment evidence',async()=>{assert.deepEqual(await inspect({history:[]}),{status:'not_found',height:0,outputIndex:null});});
test('raw txid, encoding and changing history fail closed',async()=>{await assert.rejects(inspect({raw:fixture().raw.replace(/^02/,'03')}),/ID or encoding/);await assert.rejects(inspect({raw:'zz'}),/Malformed/);await assert.rejects(inspect({changed:true}),/changed/);});
test('partial amount, another address, tokens, coinbase and ambiguous identical outputs are rejected',async()=>{for(const options of [{amount:99999n},{scriptHex:'76a914'+'01'.repeat(20)+'88ac'},{token:{category:new Uint8Array(32).fill(8),amount:1n}},{coinbase:true},{duplicate:true}])await assert.rejects(inspect({fund:fixture(options)}),e=>e.status===400);});
test('malformed, duplicate and excessive history is never truncated into success',async()=>{const row={tx_hash:fixture().txid,height:1};for(const history of [[row,row],[{...row,height:1.1}],[{...row,height:-2}],Array(201).fill(row),{}])await assert.rejects(inspect({history}),/history|History/);});
let db,store,invoices,a,b,admin,server,base,login;let nextLookup={status:'confirmed',height:900000,outputIndex:0};let lookupCalls=0;
const fake=async()=>{lookupCalls++;if(nextLookup instanceof Error)throw nextLookup;return nextLookup;};
const input=(txid=randomUUID().replaceAll('-','').repeat(2))=>({txid,acknowledgeAssignment:true});
async function make(owner=a){return(await invoices.create(owner,{requestKey:randomUUID(),amountBch:'0.001',address:encodeCashAddress({prefix:'bitcoincash',type:'p2pkh',payload:new TextEncoder().encode(randomUUID().slice(0,20))}).address,memo:'Receipt fixture',hours:24})).invoice;}
async function age(id){await db.query("UPDATE invoice_receipts SET checked_at=now()-interval '2 minutes' WHERE invoice_id=$1",[id]);}
before(async()=>{db=await openDatabase({production:false,localPath:'memory://'});await migrate(db);store=new Store(db);invoices=new InvoiceStore(db,async()=>899999);a=await store.register({email:'receipt-a@example.com',displayName:'Receipt A',password:'fixture only password 1234'});b=await store.register({email:'receipt-b@example.com',displayName:'Receipt B',password:'fixture only password 1234'});admin=await store.register({email:'receipt-admin@example.com',displayName:'Receipt Admin',password:'fixture only password 1234'},'admin');server=createApp(store,{production:false,origin:'http://127.0.0.1:4100',customerOrigin:'http://127.0.0.1:5173'},fake,undefined,invoices).listen(0,'127.0.0.1');await once(server,'listening');base='http://127.0.0.1:'+server.address().port;const r=await fetch(base+'/api/v1/merchant/auth/login',{method:'POST',headers:{Origin:'http://127.0.0.1:5173','Content-Type':'application/json'},body:JSON.stringify({email:a.email,password:'fixture only password 1234'})});login={cookie:r.headers.get('set-cookie').split(';')[0],csrf:(await r.json()).csrfToken};});
after(async()=>{await new Promise(resolve=>server.close(resolve));await db.close();});
test('receipt persists atomically with audit, appears to owner/admin and remains private on public checkout',async()=>{nextLookup={status:'confirmed',height:900000,outputIndex:0};const invoice=await make(),body=input();const r=await new PaymentReceipts(db,fake).check(a,invoice.id,body);assert.equal(r.txid,body.txid);assert.equal(r.status,'confirmed');const listed=(await invoices.list(a)).find(i=>i.id===invoice.id);assert.equal(listed.receipt.txid,body.txid);assert.equal(listed.paymentStatus,'confirmed');assert.equal((await invoices.adminList()).find(i=>i.id===invoice.id).receipt.txid,body.txid);const publicItem=await invoices.publicInvoice(invoice.id);assert.equal(publicItem.paymentStatus,'not_checked');assert.ok(!('receipt'in publicItem));assert.ok((await store.events()).some(e=>e.action==='invoice.receipt_attached'&&e.entityId===invoice.id));});
test('only owner can check; admin, other merchant, extra fields and unacknowledged assignment fail before network',async()=>{const invoice=await make(),receipts=new PaymentReceipts(db,fake),before=lookupCalls;for(const [account,body]of [[b,input()],[admin,input()],[a,{...input(),status:'confirmed'}],[a,{...input(),acknowledgeAssignment:false}],[a,{txid:'abc',acknowledgeAssignment:true}]])await assert.rejects(receipts.check(account,invoice.id,body));assert.equal(lookupCalls,before);});
test('one outpoint cannot credit two requests, including another merchant',async()=>{nextLookup={status:'confirmed',height:900000,outputIndex:0};const first=await make(),second=await make(b),body=input(),receipts=new PaymentReceipts(db,fake);await receipts.check(a,first.id,body);await assert.rejects(receipts.check(b,second.id,body),e=>e.status===409);assert.equal((await db.query('SELECT * FROM invoice_receipts WHERE invoice_id=$1',[second.id])).rows.length,0);});
test('rechecks are throttled, cannot replace an attached transaction, and stale evidence is explicit',async()=>{const invoice=await make(),body=input(),receipts=new PaymentReceipts(db,fake);await receipts.check(a,invoice.id,body);await assert.rejects(receipts.check(a,invoice.id,body),e=>e.status===429);await assert.rejects(receipts.check(a,invoice.id,input()),e=>e.status===409);await age(invoice.id);assert.equal((await invoices.list(a)).find(i=>i.id===invoice.id).receipt.status,'stale');});
test('provider outage on fresh check never creates a receipt; outage on recheck invalidates current confirmation',async()=>{const receipts=new PaymentReceipts(db,fake),invoice=await make();nextLookup=Error('offline');await assert.rejects(receipts.check(a,invoice.id,input()),e=>e.status===502);assert.equal((await db.query('SELECT * FROM invoice_receipts WHERE invoice_id=$1',[invoice.id])).rows.length,0);nextLookup={status:'confirmed',height:900000,outputIndex:0};const body=input();await receipts.check(a,invoice.id,body);await age(invoice.id);nextLookup=Error('offline');assert.equal((await receipts.check(a,invoice.id,body)).status,'unavailable');nextLookup={status:'confirmed',height:900000,outputIndex:0};});
test('lost/reorganized transaction can move confirmed to missing and seen, then confirmed again',async()=>{const receipts=new PaymentReceipts(db,fake),invoice=await make(),body=input();await receipts.check(a,invoice.id,body);for(const next of [{status:'not_found',height:0,outputIndex:null},{status:'seen',height:0,outputIndex:0},{status:'confirmed',height:900001,outputIndex:0}]){await age(invoice.id);nextLookup=next;assert.equal((await receipts.check(a,invoice.id,body)).status,next.status);}});
test('cancelled or expired request status remains distinct from receipt evidence',async()=>{const invoice=await make();await invoices.cancel(a,invoice.id,{expectedVersion:1});nextLookup={status:'confirmed',height:900000,outputIndex:0};await new PaymentReceipts(db,fake).check(a,invoice.id,input());assert.equal((await invoices.list(a)).find(i=>i.id===invoice.id).state,'cancelled');});
test('network lookup overlap for one invoice is bounded',async()=>{const invoice=await make();let release;const gate=new Promise(resolve=>release=resolve);const receipts=new PaymentReceipts(db,async()=>{await gate;return{status:'confirmed',height:900000,outputIndex:0};});const first=receipts.check(a,invoice.id,input());await new Promise(resolve=>setTimeout(resolve,15));await assert.rejects(receipts.check(a,invoice.id,input()),e=>e.status===429);release();await first;});
test('audit failure rolls back receipt insertion',async()=>{const invoice=await make();const broken={...db,transaction:work=>db.transaction(sql=>work({...sql,query:(text,params)=>{if(text.startsWith('INSERT INTO audit_events'))throw Error('audit failed');return sql.query(text,params);}}))};await assert.rejects(new PaymentReceipts(broken,async()=>({status:'confirmed',height:900000,outputIndex:0})).check(a,invoice.id,input()),/audit failed/);assert.equal((await db.query('SELECT * FROM invoice_receipts WHERE invoice_id=$1',[invoice.id])).rows.length,0);});
test('HTTP receipt route requires merchant cookie, CSRF and allowed origin; returns no credential',async()=>{const invoice=await make(),path=base+'/api/v1/merchant/invoices/'+invoice.id+'/receipt';const headers={Origin:'http://127.0.0.1:5173','Content-Type':'application/json',Cookie:login.cookie,'X-CSRF-Token':login.csrf};for(const patch of [{Cookie:''},{'X-CSRF-Token':''},{Origin:'https://evil.example'}]){const r=await fetch(path,{method:'POST',headers:{...headers,...patch},body:JSON.stringify(input())});assert.ok([401,403].includes(r.status));}nextLookup={status:'confirmed',height:900000,outputIndex:0};const r=await fetch(path,{method:'POST',headers,body:JSON.stringify(input())});assert.equal(r.status,200);const data=await r.json();assert.equal(data.status,'confirmed');assert.ok(!('token'in data));});
test('repeat migration preserves receipts and existing merchant session',async()=>{const count=(await db.query('SELECT count(*) AS n FROM invoice_receipts')).rows[0].n;await migrate(db);assert.equal((await db.query('SELECT count(*) AS n FROM invoice_receipts')).rows[0].n,count);assert.equal((await fetch(base+'/api/v1/merchant/auth/session',{headers:{Cookie:login.cookie}})).status,200);});

test('background checker rechecks only aged, already linked receipts without a session',async()=>{
 await db.query('UPDATE invoice_receipts SET checked_at=now()');
 const pendingInvoice=await make(),unlinked=await make();
 const receipts=new PaymentReceipts(db,fake);
 nextLookup={status:'confirmed',height:900000,outputIndex:0};
 const body=input();
 await receipts.check(a,pendingInvoice.id,body);
 assert.equal(await receipts.recheckNext(),false);
 await age(pendingInvoice.id);
 nextLookup={status:'confirmed',height:900001,outputIndex:0};
 assert.equal(await receipts.recheckNext(),true);
 const saved=(await invoices.list(a)).find(i=>i.id===pendingInvoice.id);
 assert.equal(saved.receipt.status,'confirmed');
 assert.equal(saved.receipt.txid,body.txid);
 assert.equal(saved.receipt.height,900001);
 assert.equal((await db.query('SELECT * FROM invoice_receipts WHERE invoice_id=$1',[unlinked.id])).rows.length,0);
 assert.equal(await receipts.recheckNext(),false);
 assert.ok((await store.events()).some(e=>e.action==='invoice.receipt_auto_checked'&&e.entityId===pendingInvoice.id));
});

test('background checks exclude inactive merchant accounts',async()=>{
 await db.query('UPDATE invoice_receipts SET checked_at=now()');
 const item=await make(b),receipts=new PaymentReceipts(db,fake);
 await receipts.check(b,item.id,input());await age(item.id);
 await db.query('UPDATE accounts SET active=false WHERE id=$1',[b.id]);
 try{const before=lookupCalls;assert.equal(await receipts.recheckNext(),false);assert.equal(lookupCalls,before);}
 finally{await db.query('UPDATE accounts SET active=true WHERE id=$1',[b.id]);}
});

test('background outage invalidates old confirmation and later recovers without replacing the outpoint',async()=>{
 await db.query('UPDATE invoice_receipts SET checked_at=now()');
 const item=await make(),receipts=new PaymentReceipts(db,fake);
 nextLookup={status:'confirmed',height:900001,outputIndex:0};
 await receipts.check(a,item.id,input());await invoices.cancel(a,item.id,{expectedVersion:1});await age(item.id);
 nextLookup=Error('provider offline');
 assert.equal(await receipts.recheckNext(),true);
 let saved=(await invoices.list(a)).find(i=>i.id===item.id);
 assert.equal(saved.receipt.status,'unavailable');assert.equal(saved.receipt.height,0);assert.equal(saved.state,'cancelled');
 await age(item.id);nextLookup={status:'confirmed',height:900002,outputIndex:0};
 assert.equal(await receipts.recheckNext(),true);
 saved=(await invoices.list(a)).find(i=>i.id===item.id);
 assert.equal(saved.receipt.status,'confirmed');assert.equal(saved.receipt.outputIndex,0);
});

test('rechecks cannot change a previously assigned output index',async()=>{
 await db.query('UPDATE invoice_receipts SET checked_at=now()');
 const item=await make(),receipts=new PaymentReceipts(db,fake),body=input();
 nextLookup={status:'confirmed',height:900000,outputIndex:0};await receipts.check(a,item.id,body);await age(item.id);
 nextLookup={status:'confirmed',height:900001,outputIndex:1};
 await assert.rejects(receipts.check(a,item.id,body),e=>e.status===409);
 assert.equal(await receipts.recheckNext(),true);
 const saved=(await invoices.list(a)).find(i=>i.id===item.id);
 assert.equal(saved.receipt.outputIndex,0);assert.equal(saved.receipt.status,'unavailable');
 nextLookup={status:'confirmed',height:900001,outputIndex:0};
});

test('automatic audit failure rolls back the receipt refresh',async()=>{
 await db.query('UPDATE invoice_receipts SET checked_at=now()');
 const item=await make(),receipts=new PaymentReceipts(db,fake);
 await receipts.check(a,item.id,input());await age(item.id);
 const before=(await db.query('SELECT * FROM invoice_receipts WHERE invoice_id=$1',[item.id])).rows[0];
 const broken={...db,transaction:work=>db.transaction(sql=>work({...sql,query:(text,params)=>{
  if(text.startsWith('INSERT INTO audit_events'))throw Error('audit unavailable');
  return sql.query(text,params);
 }}))};
 await assert.rejects(new PaymentReceipts(broken,fake).recheckNext(),/audit unavailable/);
 const after=(await db.query('SELECT * FROM invoice_receipts WHERE invoice_id=$1',[item.id])).rows[0];
 assert.deepEqual(after,before);
});

test('manual checker maps database lock contention to a retryable response',async()=>{
 const fakeDb={transaction:async()=>{throw Object.assign(Error('locked'),{code:'55P03'});}};
 const receipts=new PaymentReceipts(fakeDb,async()=>{throw Error('must not look up');});
 await assert.rejects(receipts.check(a,randomUUID(),input()),e=>e.status===429);
});

test('worker configuration accepts explicit booleans and defaults to disabled',async()=>{
 const {readConfig}=await import('../dist/config.js');
 assert.equal(readConfig({}).receiptWorkerEnabled,false);
 assert.equal(readConfig({RECEIPT_WORKER_ENABLED:'true'}).receiptWorkerEnabled,true);
 assert.equal(readConfig({RECEIPT_WORKER_ENABLED:'false'}).receiptWorkerEnabled,false);
 assert.throws(()=>readConfig({RECEIPT_WORKER_ENABLED:'yes'}));
});

test('worker stops without scheduling another lookup after an in-flight check',async(t)=>{
 const {startReceiptWorker}=await import('../dist/receipt-worker.js');
 t.mock.timers.enable({apis:['setTimeout']});
 let finish,calls=0,errors=0;
 const stop=startReceiptWorker({recheckNext:()=>{calls++;return new Promise(resolve=>{finish=resolve;});}},()=>errors++);
 t.mock.timers.tick(15000);
 assert.equal(calls,1);
 const stopped=stop();finish(true);await stopped;
 t.mock.timers.tick(120000);
 assert.equal(calls,1);assert.equal(errors,0);
});

test('worker serializes lookups and backs off after database errors',async(t)=>{
 const {startReceiptWorker}=await import('../dist/receipt-worker.js');
 t.mock.timers.enable({apis:['setTimeout']});
 let calls=0,errors=0;
 const stop=startReceiptWorker({recheckNext:async()=>{calls++;throw Error('offline');}},()=>errors++);
 t.mock.timers.tick(15000);await Promise.resolve();await Promise.resolve();
 assert.equal(calls,1);assert.equal(errors,1);
 t.mock.timers.tick(29999);assert.equal(calls,1);
 t.mock.timers.tick(1);await Promise.resolve();await Promise.resolve();
 assert.equal(calls,2);assert.equal(errors,2);
 await stop();
});

test('invoice address must have no history and a valid provider checkpoint',async()=>{
 assert.equal(await inspectNewInvoiceAddress(rpc({history:[]}),address),899999);
 await assert.rejects(inspectNewInvoiceAddress(rpc(),address),{status:409});
 await assert.rejects(inspectNewInvoiceAddress(rpc({history:[],header:'00'.repeat(80)}),address),/checkpoint/);
});

test('old, unconfirmed and legacy matches cannot reserve a payment output',async()=>{
 const invoice=await make(),legacy=await make(),body=input();
 const receipts=new PaymentReceipts(db,fake);
 for(const payment of [{status:'confirmed',height:899999,outputIndex:0},{status:'seen',height:0,outputIndex:0}]){
  nextLookup=payment;
  await assert.rejects(receipts.check(a,invoice.id,body),{status:409});
 }
 assert.equal((await db.query('SELECT * FROM invoice_receipts WHERE invoice_id=$1',[invoice.id])).rows.length,0);
 nextLookup={status:'confirmed',height:900000,outputIndex:0};
 assert.equal((await receipts.check(a,invoice.id,body)).status,'confirmed');
 await receipts.check(a,legacy.id,input());
 await db.query('UPDATE merchant_invoices SET payment_start_height=NULL WHERE id=$1',[legacy.id]);
 await age(legacy.id);
 await assert.rejects(receipts.check(a,legacy.id,input()),{status:409});
 const item=(await invoices.list(a,true)).find(r=>r.id===legacy.id);
 assert.equal(item.receiptEligible,false);
 assert.equal(item.paymentStatus,'not_checked');
 assert.equal(item.receipt,undefined);
 assert.equal((await invoices.publicInvoice(legacy.id)).state,'open');
 assert.equal((await db.query('SELECT * FROM invoice_receipts WHERE invoice_id=$1',[legacy.id])).rows.length,1);
});
