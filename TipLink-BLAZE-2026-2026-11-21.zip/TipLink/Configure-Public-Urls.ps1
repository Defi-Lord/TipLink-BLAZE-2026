$ErrorActionPreference = 'Stop'
$backendOrigin = Read-Host 'Public HTTPS backend/admin origin (no path)'
$customerOrigin = Read-Host 'Public HTTPS customer origin (a different host, no path)'
$inputJson = @{backendOrigin=$backendOrigin;customerOrigin=$customerOrigin} | ConvertTo-Json -Compress
$inputJson | & node (Join-Path $PSScriptRoot 'tools\configure-public.mjs')
if ($LASTEXITCODE -ne 0) { throw 'Public URL configuration stopped. No publication was attempted.' }
