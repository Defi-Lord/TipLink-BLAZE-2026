import {existsSync,lstatSync,unlinkSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createConnection} from 'node:net';
import {readFileSync} from 'node:fs';
const SAFE_MESSAGES=new Set(['Invalid PORT.','Invalid WalletConnect project ID.','APP_ORIGIN must be an HTTP origin without a path.','CUSTOMER_APP_ORIGIN must be a supported origin.','DATABASE_URL must use PostgreSQL.','Production requires HTTPS APP_ORIGIN and DATABASE_URL.']);
export function ownerState(pid,kill=process.kill){if(!Number.isSafeInteger(pid)||pid<=0)return'unknown';try{kill(pid,0);return'running';}catch(e){return e.code==='ESRCH'?'not_running':'unknown';}}
export function probePort(port,connector=createConnection){return new Promise(resolve=>{let done=false;const socket=connector({host:'127.0.0.1',port});const finish=value=>{if(done)return;done=true;socket.destroy();resolve(value);};socket.setTimeout(1500,()=>finish('unknown'));socket.once('connect',()=>finish(true));socket.once('error',e=>finish(e.code==='ECONNREFUSED'?false:'unknown'));});}
function lockInfo(path){const stat=lstatSync(path);if(!stat.isFile()||stat.isSymbolicLink()||stat.size>32)throw Error('Lock cannot be verified safely.');const raw=readFileSync(path,'utf8');if(!/^[1-9]\d{0,9}\s*$/.test(raw))throw Error('Lock owner is invalid.');return{raw,stat,pid:Number(raw.trim())};}
export function removeVerifiedStaleLock({lockPath,original,portFree,kill=process.kill}){
 if(portFree!==true||ownerState(original.pid,kill)!=='not_running')throw Error('Owner or port is active or uncertain. Nothing removed.');
 const current=lockInfo(lockPath);if(current.raw!==original.raw||current.stat.ino!==original.stat.ino||current.stat.dev!==original.stat.dev||current.stat.mtimeMs!==original.stat.mtimeMs||current.stat.size!==original.stat.size)throw Error('Lock changed. Nothing removed.');
 if(ownerState(original.pid,kill)!=='not_running')throw Error('Owner state changed. Nothing removed.');unlinkSync(lockPath);
}
export async function diagnose({root,env=process.env,recover=false,kill=process.kill,probe=probePort}={}){
 const folder=resolve(root||fileURLToPath(new URL('../',import.meta.url)));const report={configuration:'not_checked',database:'unknown',serverBuildPresent:existsSync(resolve(folder,'dist/server.js')),lockRemoved:false};let config;
 try{const {readConfig}=await import(pathToFileURL(resolve(folder,'dist/config.js')).href);config=readConfig(env);report.configuration='ok';}catch(e){report.configuration='failed';report.errorCode=/^[A-Z0-9_]+$/.test(e.code||'')?e.code:'UNKNOWN';report.reason=SAFE_MESSAGES.has(e.message)?e.message:'Configuration or compiled files could not be loaded. Credentials were not printed.';return report;}
 report.database=config.databaseUrl?'postgres':'local';report.backendPort=config.port;report.portListening=await probe(config.port);
 if(!config.databaseUrl&&config.localPath!=='memory://'){
  const dataPath=resolve(folder,config.localPath),lockPath=dataPath+'.process-lock';report.databaseFolderPresent=existsSync(dataPath);report.lockPresent=existsSync(lockPath);
  if(report.lockPresent){let original;try{original=lockInfo(lockPath);report.lockPid=original.pid;report.lockOwner=ownerState(original.pid,kill);}catch{report.lockOwner='unreadable_or_invalid';}
   if(recover){if(config.production)throw Error('Local recovery is disabled in production.');if(!original)throw Error('Lock cannot be verified. Nothing removed.');removeVerifiedStaleLock({lockPath,original,portFree:report.portListening===false,kill});report.lockRemoved=true;report.lockPresent=false;}
  }
 }
 report.next=!report.serverBuildPresent?'Run npm run build before starting the backend.':report.portListening===true?'Backend port is already in use.':report.lockPresent?(report.lockOwner==='not_running'?'Run npm run doctor:recover to recheck and remove only the stale lock.':'Stop the verified owner normally; do not remove its lock.'):'Start with npm run dev. If startup still fails, share this report.';
 if(report.database==='postgres')report.next='Local lock recovery does not apply. Check hosted database availability privately; no database credentials were printed.';
 return report;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{const args=process.argv.slice(2);if(args.some(arg=>arg!=='--recover-stale-lock'))throw Error('Unsupported diagnostic option.');const report=await diagnose({recover:args.includes('--recover-stale-lock')});console.log(JSON.stringify(report,null,2));if(report.configuration!=='ok')process.exitCode=1;}catch{console.error('Diagnostic stopped: lock ownership, file identity, configuration or port could not be verified. Nothing else was removed.');process.exitCode=1;}
}
