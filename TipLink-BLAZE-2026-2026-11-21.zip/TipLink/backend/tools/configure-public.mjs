import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {deploymentOrigins,createVercelConfig,productionTemplate} from './pilot-config.mjs';
export async function configurePublic({root,backendOrigin,customerOrigin}){
 const folder=resolve(root),marker=JSON.parse(await readFile(resolve(folder,'pilot-export.json'),'utf8'));
 if(marker.type!=='tiplink-pilot-export'||marker.version!==1)throw Error('Choose the generated TipLink pilot export folder.');
 const origins=deploymentOrigins(backendOrigin,customerOrigin),configPath=resolve(folder,'frontend/vercel.json');
 await copyFile(configPath,configPath+'.backup-'+Date.now());
 await writeFile(configPath,JSON.stringify(createVercelConfig(origins.backendOrigin),null,2)+'\n');
 await writeFile(resolve(folder,'backend/PRODUCTION.env.example'),productionTemplate(origins));
 await writeFile(resolve(folder,'pilot-export.json'),JSON.stringify({...marker,...origins,configured:true},null,2)+'\n');
 return{configured:true,...origins,published:false};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 let raw='';try{for await(const chunk of process.stdin){raw+=chunk;if(Buffer.byteLength(raw)>2000)throw Error('Input too large.');}const value=JSON.parse(raw);if(!value||Object.keys(value).length!==2||!Object.keys(value).every(k=>['backendOrigin','customerOrigin'].includes(k)))throw Error('Use the public backend and customer origins only.');const root=fileURLToPath(new URL('../',import.meta.url));console.log(JSON.stringify(await configurePublic({root,...value}),null,2));}catch{console.error('Public URL configuration stopped. Use two different public HTTPS origins without paths, credentials, query strings or fragments.');process.exitCode=1;}
}
