export function publicOrigin(value){
 if(typeof value!=='string'||value.length>250||value!==value.trim())throw Error('Use a public HTTPS origin.');let url;try{url=new URL(value);}catch{throw Error('Use a public HTTPS origin.');}
 if(url.protocol!=='https:'||url.username||url.password||url.pathname!=='/'||url.search||url.hash||url.port||!url.hostname.includes('.')||url.hostname.endsWith('.invalid')||url.hostname==='localhost'||url.hostname.endsWith('.localhost')||/^\d[\d.]*$/.test(url.hostname)||url.hostname.includes(':'))throw Error('Use a public HTTPS origin without credentials, a port, path, query or fragment.');
 return url.origin;
}
const merchantPaths=['auth/register','auth/login','auth/session','auth/logout','auth/wallet/config','auth/wallet/challenge','auth/wallet/verify','profile','invoices','pricing','quotes'];
export function pilotHeaders(){return[
 {key:'X-Content-Type-Options',value:'nosniff'},
 {key:'Referrer-Policy',value:'no-referrer'},
 {key:'X-Frame-Options',value:'DENY'},
 {key:'Permissions-Policy',value:'camera=(), microphone=(), geolocation=()'},
 {key:'X-Robots-Tag',value:'noindex, nofollow, noarchive'},
 {key:'Content-Security-Policy-Report-Only',value:"default-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob: https:; connect-src 'self' wss://rostrum.riften.net:443 wss://relay.riften.net:443 https://*.walletconnect.com https://*.walletconnect.org wss://*.walletconnect.com wss://*.walletconnect.org https://*.web3modal.com https://*.web3modal.org; frame-src https://verify.walletconnect.com https://verify.walletconnect.org; worker-src 'self' blob:; form-action 'self'"}
];}
export function createVercelConfig(backendOrigin){
 const config={$schema:'https://openapi.vercel.sh/vercel.json',framework:null,buildCommand:'npm run build:wallet',outputDirectory:'wallet-lab/dist',headers:[{source:'/(.*)',headers:pilotHeaders()},{source:'/api/(.*)',headers:[{key:'Cache-Control',value:'no-store'},{key:'CDN-Cache-Control',value:'no-store'},{key:'Vercel-CDN-Cache-Control',value:'no-store'}]},{source:'/',headers:[{key:'Cache-Control',value:'no-store'}]},{source:'/index.html',headers:[{key:'Cache-Control',value:'no-store'}]}]};
 if(backendOrigin){const base=publicOrigin(backendOrigin);const paths=merchantPaths.map(path=>'/api/v1/merchant/'+path);paths.push('/api/v1/merchant/invoices/:id([a-f0-9-]{36})/cancel','/api/v1/merchant/invoices/:id([a-f0-9-]{36})/receipt','/api/v1/public/invoices/:id([a-f0-9-]{36})');config.rewrites=paths.map(source=>({source,destination:base+source.replace(':id([a-f0-9-]{36})',':id')}));}
 return config;
}
export function deploymentOrigins(backend,customer){const backendOrigin=publicOrigin(backend),customerOrigin=publicOrigin(customer);if(backendOrigin===customerOrigin)throw Error('Use separate origins for the customer app and administrator backend.');return{backendOrigin,customerOrigin};}
export function productionTemplate({backendOrigin,customerOrigin}){const origins=deploymentOrigins(backendOrigin,customerOrigin);return ['# TEMPLATE ONLY. Enter actual values in the hosting service settings.','NODE_ENV=production','HOST=0.0.0.0','# Let the hosting service supply PORT.','APP_ORIGIN='+origins.backendOrigin,'CUSTOMER_APP_ORIGIN='+origins.customerOrigin,'# Set DATABASE_URL privately. Production requires PostgreSQL and verified TLS.','# DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DATABASE','# Mount a provider CA when needed; never disable TLS verification.','# DATABASE_CA_FILE=/run/secrets/postgres-ca.pem','# WALLETCONNECT_PROJECT_ID=YOUR_PUBLIC_32_HEX_PROJECT_ID',''].join('\n');}
