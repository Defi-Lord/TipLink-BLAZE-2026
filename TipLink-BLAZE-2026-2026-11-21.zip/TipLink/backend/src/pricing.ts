import {Problem,exact} from './security.js';
export type Policy={version:number;personalBps:number;merchantBps:number;merchantCapSats:string|null;collectionEnabled:false;createdAt:string};
const MAX=2100000000000000n;
function sats(value:unknown,zero=false){if(typeof value!=='string'||! /^(0|[1-9]\d{0,15})$/.test(value)||BigInt(value)>MAX||(!zero&&value==='0'))throw new Problem(400,'Amounts must be exact satoshi strings within the supported supply.');return BigInt(value);}
export function validatePolicyChange(value:unknown){exact(value,['expectedVersion','personalBps','merchantBps','merchantCapSats','reason']);if(!Number.isSafeInteger(value.expectedVersion)||(value.expectedVersion as number)<1)throw new Problem(400,'A valid policy version is required.');for(const key of ['personalBps','merchantBps'])if(!Number.isInteger(value[key])||(value[key] as number)<0||(value[key] as number)>300)throw new Problem(400,'Rates must be whole basis points from 0 to 300.');if(value.merchantCapSats!==null)sats(value.merchantCapSats);if(typeof value.reason!=='string'||value.reason.trim().length<8||value.reason.length>200||/[\u0000-\u001f\u007f]/.test(value.reason))throw new Problem(400,'Give a change reason of 8–200 characters.');return{expectedVersion:value.expectedVersion as number,personalBps:value.personalBps as number,merchantBps:value.merchantBps as number,merchantCapSats:value.merchantCapSats as string|null,reason:value.reason.trim()};}
export function quote(value:unknown,policy:Policy){
 exact(value,['kind','recipientSats','fundingFeeSats','claimFeeSats']);if(!['personal','merchant'].includes(String(value.kind)))throw new Problem(400,'Choose personal or merchant.');
 const recipient=sats(value.recipientSats),funding=sats(value.fundingFeeSats,true),claim=sats(value.claimFeeSats,true);
 const bps=value.kind==='personal'?policy.personalBps:policy.merchantBps;let proposed=(recipient*BigInt(bps)+9999n)/10000n;
 if(value.kind==='merchant'&&policy.merchantCapSats!==null&&proposed>BigInt(policy.merchantCapSats))proposed=BigInt(policy.merchantCapSats);
 const network=funding+claim,pilotTotal=recipient+network,proposedTotal=pilotTotal+proposed;
 if(proposedTotal>MAX)throw new Problem(400,'Total exceeds the supported supply.');
 return{policyVersion:policy.version,kind:value.kind,recipientSats:recipient.toString(),networkFeeEstimateSats:network.toString(),proposedPlatformFeeSats:proposed.toString(),platformFeeCollectedSats:'0',pilotTotalEstimateSats:pilotTotal.toString(),proposedTotalEstimateSats:proposedTotal.toString(),collectionEnabled:false,networkFeeSource:'user-entered estimate',note:'Planning estimate only. No payment or fee is collected. No exchange rate is quoted.'};
}
