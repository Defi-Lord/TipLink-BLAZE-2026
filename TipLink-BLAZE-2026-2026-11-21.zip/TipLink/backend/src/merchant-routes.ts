import {Router,type Request,type Response,type NextFunction} from 'express';
import type {Config} from './config.js';
import {Store,type Session} from './store.js';
import {InvoiceStore} from './invoices.js';
import {Problem,exact,equalToken} from './security.js';
import {WalletAuth} from './wallet-auth.js';
import {PaymentReceipts} from './payment-receipts.js';
import {BreetBanks} from './breet-banks.js';
import {BreetDeposits} from './breet-deposits.js';
import {createBreetSandbox} from './breet-sandbox.js';
import {quote} from './pricing.js';
export function namedCookie(req:Request,name:string){const matches=(req.headers.cookie||'').split(';').map(s=>s.trim()).filter(s=>s.startsWith(name+'='));return matches.length===1?matches[0]!.slice(name.length+1):undefined;}
export function merchantRoutes(store:Store,invoices:InvoiceStore,config:Config,receipts=new PaymentReceipts(store.db)){
 const router=Router();const wallets=new WalletAuth(store.db,store);const cookieName='tiplink_merchant_session';
 const cookie=(res:Response,value:string,clear=false)=>res.cookie(cookieName,value,{httpOnly:true,secure:config.production,sameSite:'strict',path:'/api/v1/merchant',maxAge:clear?0:86400000});
 async function auth(req:Request,res:Response,next:NextFunction){try{const session=await store.session(namedCookie(req,cookieName));if(!session)throw new Problem(401,'Sign in to your business workspace.');if(session.account.role!=='merchant')throw new Problem(403,'Merchant access is required.');if(req.method!=='GET'&&!equalToken(req.headers['x-csrf-token'],session.csrfToken))throw new Problem(403,'Reload your business workspace and try again.');res.locals.merchant=session;next();}catch(error){next(error);}}
 if(!config.production){
  const banks=new BreetBanks(config);const breetStatus=createBreetSandbox(config);const deposits=new BreetDeposits(store.db,config);
  router.get('/cash-out/banks',auth,async(_req,res)=>res.json({environment:'sandbox',payoutVerified:false,items:await banks.banks()}));
  router.post('/cash-out/banks/verify',auth,async(req,res)=>{exact(req.body,['bankId','accountNumber']);res.json(await banks.verify((res.locals.merchant as Session).account.id,{bankId:req.body.bankId,accountNumber:req.body.accountNumber}));});
  router.get('/cash-out/wallet',auth,async(_req,res)=>res.json(await deposits.wallet((res.locals.merchant as Session).account)));
  router.post('/cash-out/wallet',auth,async(req,res)=>{exact(req.body,['acknowledgeSandbox']);if(req.body.acknowledgeSandbox!==true)throw new Problem(400,'Acknowledge that this is a sandbox test.');res.json(await deposits.create((res.locals.merchant as Session).account));});
  router.post('/cash-out/estimate',auth,async(req,res)=>{exact(req.body,['amountUsd']);res.json(await deposits.estimate((res.locals.merchant as Session).account,req.body.amountUsd));});
  router.get('/cash-out/ledger',auth,async(_req,res)=>res.json(await deposits.ledger((res.locals.merchant as Session).account)));
  router.get('/cash-out/transactions',auth,async(_req,res)=>res.json(await deposits.transactions((res.locals.merchant as Session).account)));
  router.get('/cash-out/status',async(_req,res)=>res.json(await breetStatus()));
 }
 router.get('/auth/wallet/config',(_req,res)=>res.json({projectId:config.walletConnectProjectId||null,chainId:'bch:bitcoincash',requiresSetup:!config.walletConnectProjectId}));
 async function linkAccount(req:Request){const session=await store.session(namedCookie(req,cookieName));if(!session||session.account.role!=='merchant'||!equalToken(req.headers['x-csrf-token'],session.csrfToken))throw new Problem(403,'Sign in to your business and reload before adding a wallet.');return session.account;}
 router.post('/auth/wallet/challenge',async(req,res)=>{exact(req.body,['address','intent']);const intent=req.body.intent;if(intent!=='signin'&&intent!=='link')throw new Problem(400,'Unsupported wallet sign-in intent.');const account=intent==='link'?await linkAccount(req):undefined;const c=await wallets.challenge({address:req.body.address,intent,origin:String(req.headers.origin),account});res.cookie('tiplink_wallet_challenge',c.binding,{httpOnly:true,secure:config.production,sameSite:'strict',path:'/api/v1/merchant',maxAge:300000});const {binding,...publicChallenge}=c;res.json(publicChallenge);});
 router.post('/auth/wallet/verify',async(req,res)=>{exact(req.body,['id','signature']);const current=await store.session(namedCookie(req,cookieName));const account=current&&equalToken(req.headers['x-csrf-token'],current.csrfToken)?current.account:undefined;const login=await wallets.verify({id:req.body.id,signature:req.body.signature,binding:namedCookie(req,'tiplink_wallet_challenge'),origin:String(req.headers.origin),account});cookie(res,login.token);res.clearCookie('tiplink_wallet_challenge',{httpOnly:true,secure:config.production,sameSite:'strict',path:'/api/v1/merchant'});res.json({account:login.account,csrfToken:login.csrfToken});});
 router.patch('/profile',auth,async(req,res)=>{exact(req.body,['displayName']);res.json({account:await wallets.profile((res.locals.merchant as Session).account,req.body.displayName)});});
 router.post('/auth/register',async(req,res)=>{exact(req.body,['email','displayName','password']);const account=await store.register({email:req.body.email,displayName:req.body.displayName,password:req.body.password});res.status(201).json({account});});
 router.post('/auth/login',async(req,res)=>{exact(req.body,['email','password']);const login=await store.login(req.body.email,req.body.password,'merchant');cookie(res,login.token);res.json({account:login.account,csrfToken:login.csrfToken});});
 router.get('/auth/session',auth,(_req,res)=>{const s=res.locals.merchant as Session;res.json({account:s.account,csrfToken:s.csrfToken});});
 router.post('/auth/logout',auth,async(req,res)=>{exact(req.body,[]);await store.logout(res.locals.merchant as Session);cookie(res,'',true);res.json({ok:true});});
 router.get('/invoices',auth,async(req,res)=>res.json({items:await invoices.list((res.locals.merchant as Session).account,req.get('x-tiplink-receipt-binding')==='1'),backgroundChecks:config.receiptWorkerEnabled===true}));
 router.post('/invoices',auth,async(req,res)=>{const result=await invoices.create((res.locals.merchant as Session).account,req.body);res.status(result.replayed?200:201).json(result);});
 router.post('/invoices/:id/cancel',auth,async(req,res)=>res.json(await invoices.cancel((res.locals.merchant as Session).account,String(req.params.id),req.body)));
 router.post('/invoices/:id/receipt',auth,async(req,res)=>res.json(await receipts.check((res.locals.merchant as Session).account,String(req.params.id),req.body)));
 router.get('/pricing',auth,async(_req,res)=>res.json(await store.policy()));
 router.post('/quotes',auth,async(req,res)=>res.json(quote(req.body,await store.policy())));
 return router;
}
