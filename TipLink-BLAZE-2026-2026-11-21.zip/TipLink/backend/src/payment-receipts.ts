import type {Database,Row,Sql} from './database.js';
import type {Account} from './store.js';
import {audit} from './store.js';
import {Problem,exact} from './security.js';
import {UUID} from './invoices.js';
import {lookupPayment,PAYMENT_SOURCE,type PaymentLookup} from './payment-network.js';
export type Lookup=(txid:string,address:string,amount:string)=>Promise<PaymentLookup>;
export function presentReceipt(row:Row,now=Date.now()){
 const checkedAt=new Date(row.checked_at as string).toISOString();
 return{txid:String(row.txid),outputIndex:Number(row.output_index),status:now-Date.parse(checkedAt)>60000?'stale':String(row.status),lastStatus:String(row.status),height:Number(row.height),checkedAt,source:PAYMENT_SOURCE};
}
export class PaymentReceipts {
 private active=new Set<string>();
 constructor(public db:Database,private lookup:Lookup=lookupPayment){}
 async check(account:Account,id:string,input:unknown){
  if(account.role!=='merchant')throw new Problem(403,'Merchant access is required.');
  if(!UUID.test(id))throw new Problem(404,'Payment request not found.');
  exact(input,['txid','acknowledgeAssignment']);
  if(input.acknowledgeAssignment!==true)throw new Problem(400,'Confirm that the customer supplied this transaction for this request.');
  if(typeof input.txid!=='string'||!/^[a-fA-F0-9]{64}$/.test(input.txid))throw new Problem(400,'Paste the 64-character BCH transaction ID from the customer’s wallet.');
  const txid=input.txid.toLowerCase();
  return this.runCheck(id,txid,account.id);
 }

 async syncFromCheckout(id:string,input:unknown){
  if(!UUID.test(id))throw new Problem(404,'Payment request not found.');
  exact(input,['txid']);
  if(typeof input.txid!=='string'||! /^[a-f0-9]{64}$/.test(input.txid))throw new Problem(400,'Invalid BCH transaction ID.');
  return this.runCheck(id,input.txid);
 }

 private async runCheck(id:string,txid:string,merchantId?:string){
  if(this.active.has(id)||this.active.size>=4)throw new Problem(429,'A payment check is already running. Try again shortly.');
  this.active.add(id);
  try{
   return await this.db.transaction(async sql=>{
    // All manual and background checks lock the invoice before reading its receipt.
    const result=merchantId
     ?await sql.query('SELECT * FROM merchant_invoices WHERE id=$1 AND merchant_id=$2 FOR UPDATE NOWAIT',[id,merchantId])
     :await sql.query(`SELECT i.* FROM merchant_invoices i JOIN accounts a ON a.id=i.merchant_id
       WHERE i.id=$1 AND a.active=true AND a.role='merchant' AND i.payment_start_height IS NOT NULL
       AND NOT EXISTS(SELECT 1 FROM merchant_invoices other WHERE other.address=i.address AND other.id<>i.id)
       FOR UPDATE OF i NOWAIT`,[id]);
    const invoice=result.rows[0];
    if(!invoice)throw new Problem(404,'Payment request not found.');
    if(invoice.payment_start_height==null)throw new Problem(409,'Receipt checks are unavailable for this older request. Verify payment directly in your wallet.');
    return this.checkLocked(sql,invoice,txid,merchantId?'merchant':'checkout');
   });
  }catch(error){
   const code=(error as {code?:string}).code;
   if(code==='55P03')throw new Problem(429,'A payment check is already running. Try again shortly.');
   if(code==='23505')throw new Problem(409,'This payment output is already attached to another request.');
   throw error;
  }finally{this.active.delete(id);}
 }

 async recheckNext(){
  return this.db.transaction(async sql=>{
   const result=await sql.query(
    "SELECT i.* FROM merchant_invoices i JOIN invoice_receipts r ON r.invoice_id=i.id JOIN accounts a ON a.id=i.merchant_id WHERE i.payment_start_height IS NOT NULL AND a.active=true AND a.role='merchant' AND r.checked_at<=now()-interval '60 seconds' ORDER BY r.checked_at,i.id LIMIT 1 FOR UPDATE OF i SKIP LOCKED"
   );
   const invoice=result.rows[0];
   if(!invoice)return false;
   const old=(await sql.query('SELECT * FROM invoice_receipts WHERE invoice_id=$1',[invoice.id])).rows[0];
   if(!old)return false;
   // A concurrent manual check may have committed while the candidate was selected.
   if(Date.now()-new Date(old.checked_at as string).getTime()<60000)return false;
   await this.checkLocked(sql,invoice,String(old.txid),'worker');
   return true;
  });
 }

 private async checkLocked(sql:Sql,invoice:Row,txid:string,source:'merchant'|'checkout'|'worker'){
  const id=String(invoice.id);
  const old=(await sql.query('SELECT * FROM invoice_receipts WHERE invoice_id=$1',[id])).rows[0];
  if(old&&old.txid!==txid)throw new Problem(409,'A receipt is already attached to this request. Refresh it using the same transaction ID.');
  if(old&&Date.now()-new Date(old.checked_at as string).getTime()<10000){
   if(source==='checkout')return presentReceipt(old);
   throw new Problem(429,'Wait ten seconds before checking this receipt again.');
  }
  let payment:PaymentLookup;
  let unavailable=false;
  try{
   payment=await this.lookup(txid,String(invoice.address),String(invoice.amount_sats));
   if(payment.status==='confirmed'&&payment.height<=Number(invoice.payment_start_height))throw new Problem(409,'This payment predates the request.');
   if(old&&payment.outputIndex!==null&&payment.outputIndex!==Number(old.output_index)){
    throw new Problem(409,'The payment output changed. This receipt needs manual review.');
   }
  }catch(error){
   if(error instanceof Problem&&source!=='worker')throw error;
   if(!old)throw new Problem(502,'The BCH provider could not verify this payment. Nothing was marked as received. Try again shortly.');
   unavailable=true;
   payment={status:'not_found',height:0,outputIndex:Number(old.output_index)};
  }
  if(payment.status==='not_found'&&!old&&!unavailable)throw new Problem(400,'The provider cannot find this transaction for the receiving address. Check the ID and try again.');
  if(payment.status==='seen'&&!old&&source==='merchant')throw new Problem(409,'Wait for a network confirmation before attaching this receipt.');
  const index=payment.outputIndex??(old?Number(old.output_index):null);
  if(index===null)throw new Problem(409,'Payment evidence is unavailable.');
  const status=unavailable?'unavailable':payment.status;
  const saved=await sql.query(
   'INSERT INTO invoice_receipts(invoice_id,txid,output_index,status,height,checked_at) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(invoice_id) DO UPDATE SET status=EXCLUDED.status,height=EXCLUDED.height,checked_at=EXCLUDED.checked_at RETURNING *',
   [id,txid,index,status,payment.height,new Date()]
  );
  const action=source==='worker'?'invoice.receipt_auto_checked':old?'invoice.receipt_checked':'invoice.receipt_attached';
  await audit(sql,String(invoice.merchant_id),action,id,{txid,outputIndex:index,status,height:payment.height});
  return presentReceipt(saved.rows[0]!);
 }
}
