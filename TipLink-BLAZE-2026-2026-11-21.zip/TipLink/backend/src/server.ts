import {PaymentReceipts} from './payment-receipts.js';
import {startReceiptWorker} from './receipt-worker.js';
import {readConfig} from './config.js';import {openDatabase} from './database.js';import {Store} from './store.js';import {createApp} from './app.js';
async function start(){
const config=readConfig();const db=await openDatabase(config);
try{const result=await db.query('SELECT version FROM tiplink_schema_version WHERE version=8');if(!result.rows.length)throw Error();}catch{console.error('Database migration 008 is required. Run npm run db:migrate before starting the backend.');await db.close();process.exitCode=1;return;}
const receipts=new PaymentReceipts(db);
let stopWorker:(()=>Promise<void>)|undefined;
const server=createApp(new Store(db),config,undefined,receipts).listen(config.port,config.host,()=>{
 console.log(`TipLink admin: ${config.origin} · ${db.mode} · fee collection disabled`);
 if(config.receiptWorkerEnabled){
  stopWorker=startReceiptWorker(receipts);
  console.log('Background receipt checks enabled.');
 }
});
server.on('error',()=>{console.error('Server could not start. Check HOST, PORT and whether another server is running.');void stopWorker?.().finally(()=>db.close());if(!stopWorker)void db.close();process.exitCode=1;});
let stopping=false;
async function stop(){
 if(stopping)return;
 stopping=true;
 const deadline=setTimeout(()=>process.exit(1),30000);
 deadline.unref();
 try{
  await Promise.all([stopWorker?.(),new Promise<void>(resolve=>server.close(()=>resolve()))]);
  await db.close();
  clearTimeout(deadline);
  process.exit(0);
 }catch{
  console.error('Backend shutdown could not finish cleanly.');
  process.exit(1);
 }
}
process.on('SIGINT',stop);process.on('SIGTERM',stop);

}
start().catch(()=>{console.error('Backend startup failed. Check application and database configuration. Keep credentials private.');process.exitCode=1;});
