import {randomUUID} from 'node:crypto';
import type {Database,Row} from './database.js';
import {Store,audit,type Account} from './store.js';
import {Problem,randomToken,tokenHash,equalToken,name} from './security.js';
import {walletAddress,verifyWalletMessage} from './wallet-proof.js';
import {UUID} from './invoices.js';
export class WalletAuth {
 constructor(public db:Database,public store:Store){}
 async challenge({address:raw,origin,intent,account,now=Date.now()}:{address:unknown;origin:string;intent:'signin'|'link';account?:Account;now?:number}){
  const address=walletAddress(raw);if(!['signin','link'].includes(intent))throw new Problem(400,'Unsupported wallet sign-in intent.');if(intent==='link'&&(!account||account.role!=='merchant'))throw new Problem(401,'Sign in before adding a wallet.');
  const id=randomUUID(),binding=randomToken(),nonce=randomToken(),expiresAt=now+300000;
  const purpose=intent==='link'?`Add wallet sign-in to merchant account ${account!.id}.`:'Sign in or create a TipLink merchant account.';
  const message=`TipLink Business\n\nOrigin: ${origin}\nAddress: ${address}\nNetwork: Bitcoin Cash mainnet\nPurpose: ${purpose}\nChallenge ID: ${id}\nNonce: ${nonce}\nIssued at: ${new Date(now).toISOString()}\nExpires at: ${new Date(expiresAt).toISOString()}\n\nThis is a sign-in message, not a payment. It does not authorise transactions or access to private keys.`;
  await this.db.transaction(async sql=>{await sql.query("DELETE FROM wallet_login_challenges WHERE expires_at<now()-interval '1 day'");await sql.query('INSERT INTO wallet_login_challenges(id,address,origin,message,binding_hash,intent,account_id,created_at,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)',[id,address,origin,message,tokenHash(binding),intent,intent==='link'?account!.id:null,new Date(now),new Date(expiresAt)]);});
  return{id,address,message,expiresAt:new Date(expiresAt).toISOString(),binding};
 }
 async verify({id,signature,binding,origin,account,now=Date.now()}:{id:unknown;signature:unknown;binding:string|undefined;origin:string;account?:Account;now?:number}){
  if(typeof id!=='string'||!UUID.test(id)||!binding||!/^[a-f0-9]{64}$/.test(binding))throw new Problem(401,'Wallet challenge expired or belongs to another browser. Start again.');
  const result=await this.db.transaction(async sql=>{
   const found=await sql.query('SELECT * FROM wallet_login_challenges WHERE id=$1 FOR UPDATE',[id]);const c=found.rows[0];
   const invalid=!c||c.used_at!==null||Number(c.attempts)>=5||origin!==c.origin||new Date(c.created_at as string).getTime()>now||new Date(c.expires_at as string).getTime()<=now||!equalToken(tokenHash(binding),String(c.binding_hash));
   if(invalid)return{error:new Problem(401,'Wallet challenge expired, used or invalid. Start again.')};
   if(c.intent==='link'&&(!account||account.id!==c.account_id||account.role!=='merchant'))return{error:new Problem(403,'Sign in to the original merchant account before adding this wallet.')};
   await sql.query('UPDATE wallet_login_challenges SET attempts=attempts+1 WHERE id=$1',[id]);
   if(!verifyWalletMessage({message:String(c.message),address:String(c.address),signature}))return{error:new Problem(401,'Wallet signature could not be verified. No account was signed in.')};
   await sql.query('UPDATE wallet_login_challenges SET used_at=$1 WHERE id=$2',[new Date(now),id]);
   let rows=await sql.query('SELECT id,role,active FROM accounts WHERE wallet_address=$1',[c.address]);let accountId:string;
   if(c.intent==='link'){
    if(rows.rows[0]&&rows.rows[0].id!==account!.id)return{error:new Problem(409,'This wallet belongs to another account. Accounts are not merged automatically.')};
    const target=await sql.query('SELECT wallet_address,active FROM accounts WHERE id=$1 AND role=$2 FOR UPDATE',[account!.id,'merchant']);
    if(!target.rows[0]?.active)return{error:new Problem(401,'This merchant account is not active.')};
    if(target.rows[0].wallet_address&&target.rows[0].wallet_address!==c.address)return{error:new Problem(409,'This account already has a different sign-in wallet.')};
    await sql.query('UPDATE accounts SET wallet_address=$1 WHERE id=$2',[c.address,account!.id]);accountId=account!.id;await audit(sql,accountId,'wallet.linked',accountId);
   }else if(rows.rows[0]){
    if(rows.rows[0].role!=='merchant'||rows.rows[0].active!==true)return{error:new Problem(401,'Wallet account is not available.')};accountId=String(rows.rows[0].id);
   }else{
    // Only merchant accounts can ever be created through wallet proof.
    const candidate=randomUUID();await sql.query("INSERT INTO accounts(id,email,display_name,role,password_hash,wallet_address,profile_completed) VALUES($1,NULL,'My business','merchant',NULL,$2,false) ON CONFLICT(wallet_address) DO NOTHING",[candidate,c.address]);rows=await sql.query('SELECT id,role,active FROM accounts WHERE wallet_address=$1',[c.address]);if(!rows.rows[0]||rows.rows[0].role!=='merchant'||rows.rows[0].active!==true)return{error:new Problem(401,'Wallet account is not available.')};accountId=String(rows.rows[0].id);if(accountId===candidate)await audit(sql,accountId,'merchant.wallet_registered',accountId);
   }
   const token=randomToken(),csrfToken=randomToken();await sql.query('DELETE FROM sessions WHERE expires_at<=now()');await sql.query("INSERT INTO sessions(token_hash,account_id,csrf_token,expires_at) VALUES($1,$2,$3,now()+interval '24 hours')",[tokenHash(token),accountId,csrfToken]);await audit(sql,accountId,'wallet.session_started',accountId);return{token,csrfToken};
  });
  if(result.error)throw result.error;
  const session=await this.store.session(result.token);if(!session)throw new Problem(401,'Wallet account is not available.');return{token:result.token!,csrfToken:result.csrfToken!,account:session.account};
 }
 async profile(account:Account,displayName:unknown){if(account.role!=='merchant')throw new Problem(403,'Merchant access is required.');const label=name(displayName);await this.db.transaction(async sql=>{await sql.query('UPDATE accounts SET display_name=$1,profile_completed=true WHERE id=$2',[label,account.id]);await audit(sql,account.id,'merchant.profile_updated',account.id);});return{...account,displayName:label,profileComplete:true};}
}
