import {randomUUID,createHash} from 'node:crypto';
import {decodeCashAddress,encodeCashAddress} from '@bitauth/libauth';
import {exact,Problem} from './security.js';
import type {Database,Row} from './database.js';
import type {Account} from './store.js';
import {audit} from './store.js';
import {checkNewInvoiceAddress} from './payment-network.js';
import {presentReceipt} from './payment-receipts.js';
export const UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
export function validateInvoiceInput(value:unknown){
 exact(value,['requestKey','amountBch','address','memo','hours']);
 if(typeof value.requestKey!=='string'||!UUID.test(value.requestKey))throw new Problem(400,'A valid request key is required.');
 if(typeof value.amountBch!=='string'||! /^(0|[1-9]\d{0,8})(\.\d{1,8})?$/.test(value.amountBch))throw new Problem(400,'Enter an exact BCH amount with up to 8 decimals.');
 const[whole,fraction='']=value.amountBch.split('.');const amount=BigInt(whole!)*100000000n+BigInt(fraction.padEnd(8,'0'));if(amount<1000n||amount>2100000000000000n)throw new Problem(400,'Request at least 0.00001 BCH, within the supported supply.');
 if(typeof value.address!=='string'||value.address.length>120)throw new Problem(400,'Enter a BCH mainnet receiving address.');
 const address=value.address.trim();if(address!==address.toLowerCase()&&address!==address.toUpperCase())throw new Problem(400,'Mixed-case receiving addresses are invalid.');
 const decoded=decodeCashAddress(address.toLowerCase());if(typeof decoded==='string'||decoded.prefix!=='bitcoincash'||decoded.type!=='p2pkh'||decoded.payload.length!==20)throw new Problem(400,'Use a standard BCH mainnet CashAddr with the bitcoincash:q prefix.');
 const normalized=encodeCashAddress({prefix:'bitcoincash',type:'p2pkh',payload:decoded.payload}).address;
 const memo=typeof value.memo==='string'?value.memo.normalize('NFKC').replace(/\p{Cf}/gu,'').trim():null;
 if(memo===null||memo.length>160||/[\u0000-\u001f\u007f]/.test(memo))throw new Problem(400,'Use a note of up to 160 characters.');
 if(!Number.isInteger(value.hours)||(value.hours as number)<1||(value.hours as number)>720)throw new Problem(400,'Choose a lifetime from 1 to 720 hours.');
 return{requestKey:value.requestKey,amountSats:amount.toString(),address:normalized,memo,hours:value.hours as number};
}
function present(row:Row,now=Date.now(),includeReceiptEligibility=false){
 const expiresAt=new Date(row.expires_at as string).toISOString();
 const receiptEligible=row.payment_start_height!=null;
 const receipt=receiptEligible&&row.txid?presentReceipt(row,now):null;
 return{...(receipt?{receipt}:{}),id:String(row.id),merchantName:String(row.merchant_name),amountSats:String(row.amount_sats),address:String(row.address),memo:String(row.memo),state:row.state==='cancelled'?'cancelled':now>=Date.parse(expiresAt)?'expired':'open',version:Number(row.version),createdAt:new Date(row.created_at as string).toISOString(),expiresAt,paymentStatus:receipt?receipt.status:'not_checked',monitoringConnected:!!receipt,...(includeReceiptEligibility?{receiptEligible}:{})};
}
function merchant(account:Account){if(account.role!=='merchant')throw new Problem(403,'Merchant access is required.');}
export class InvoiceStore {
 constructor(public db:Database,private checkAddress=checkNewInvoiceAddress){}
 async create(account:Account,input:unknown,now=Date.now()){
  merchant(account);if(account.profileComplete===false)throw new Problem(409,'Set your business name before creating a request.');const value=validateInvoiceInput(input);const fingerprint=createHash('sha256').update(JSON.stringify({amountSats:value.amountSats,address:value.address,memo:value.memo,hours:value.hours})).digest('hex');const id=randomUUID();
  const replay=(row:Row)=>{
   if(row.fingerprint!==fingerprint)throw new Problem(409,'This request key was used for different details. Start a new request.');
   return {invoice:present(row,now),replayed:true};
  };
  const existing=await this.db.query('SELECT * FROM merchant_invoices WHERE merchant_id=$1 AND request_key=$2',[account.id,value.requestKey]);
  if(existing.rows[0])return replay(existing.rows[0]);
  const used=await this.db.query('SELECT * FROM merchant_invoices WHERE address=$1 ORDER BY (merchant_id=$2 AND request_key=$3) DESC LIMIT 1',[value.address,account.id,value.requestKey]);
  if(used.rows[0]){
   if(used.rows[0].merchant_id===account.id&&used.rows[0].request_key===value.requestKey)return replay(used.rows[0]);
   throw new Problem(409,'Use a new BCH receiving address for each payment request.');
  }
  let startHeight:number;
  try{startHeight=await this.checkAddress(value.address);}
  catch(error){if(error instanceof Problem)throw error;throw new Problem(502,'Could not check the new BCH address. Try again before sharing a payment request.');}
  return this.db.transaction(async sql=>{
   const inserted=await sql.query('INSERT INTO merchant_invoices(id,merchant_id,request_key,fingerprint,merchant_name,amount_sats,address,memo,created_at,expires_at,payment_start_height) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) ON CONFLICT DO NOTHING RETURNING *',[id,account.id,value.requestKey,fingerprint,account.displayName,value.amountSats,value.address,value.memo,new Date(now),new Date(now+value.hours*3600000),startHeight]);
   if(inserted.rows[0]){await audit(sql,account.id,'invoice.created',id,{amountSats:value.amountSats});return{invoice:present(inserted.rows[0],now),replayed:false};}
   const found=await sql.query('SELECT * FROM merchant_invoices WHERE merchant_id=$1 AND request_key=$2',[account.id,value.requestKey]);
   if(found.rows[0])return replay(found.rows[0]);
   throw new Problem(409,'Use a new BCH receiving address for each payment request.');
  });
 }
 async list(account:Account,includeReceiptEligibility=false){merchant(account);const result=await this.db.query('SELECT i.*,r.txid,r.output_index,r.status,r.height,r.checked_at FROM merchant_invoices i LEFT JOIN invoice_receipts r ON r.invoice_id=i.id WHERE i.merchant_id=$1 ORDER BY i.created_at DESC,i.id LIMIT 100',[account.id]);return result.rows.map(row=>present(row,Date.now(),includeReceiptEligibility));}
 async publicInvoice(id:string,includeReceiptEligibility=false){
  if(!UUID.test(id))throw new Problem(404,'Payment request not found.');
  const result=await this.db.query(includeReceiptEligibility?`SELECT i.*,
   (i.payment_start_height IS NOT NULL AND a.active=true AND a.role='merchant'
    AND NOT EXISTS(SELECT 1 FROM merchant_invoices other WHERE other.address=i.address AND other.id<>i.id)) AS checkout_receipt_eligible
   FROM merchant_invoices i JOIN accounts a ON a.id=i.merchant_id WHERE i.id=$1`:'SELECT * FROM merchant_invoices WHERE id=$1',[id]);
  const row=result.rows[0];
  if(!row)throw new Problem(404,'Payment request not found.');
  return {...present(row),...(includeReceiptEligibility?{receiptEligible:row.checkout_receipt_eligible===true}:{})};
 }
 async cancel(account:Account,id:string,input:unknown,now=Date.now()){
  merchant(account);exact(input,['expectedVersion']);if(!Number.isSafeInteger(input.expectedVersion)||(input.expectedVersion as number)<1)throw new Problem(400,'A valid request version is required.');if(!UUID.test(id))throw new Problem(404,'Payment request not found.');
  return this.db.transaction(async sql=>{const result=await sql.query('SELECT * FROM merchant_invoices WHERE id=$1 AND merchant_id=$2 FOR UPDATE',[id,account.id]);const row=result.rows[0];if(!row)throw new Problem(404,'Payment request not found.');if(row.state==='cancelled')return present(row,now);if(Number(row.version)!==input.expectedVersion)throw new Problem(409,'The request changed. Refresh your list.');if(now>=new Date(row.expires_at as string).getTime())throw new Problem(409,'This payment request has expired.');const changed=await sql.query("UPDATE merchant_invoices SET state='cancelled',version=version+1 WHERE id=$1 RETURNING *",[id]);await audit(sql,account.id,'invoice.cancelled',id);return present(changed.rows[0]!,now);});
 }
 async adminList(){const result=await this.db.query('SELECT i.*,r.txid,r.output_index,r.status,r.height,r.checked_at FROM merchant_invoices i LEFT JOIN invoice_receipts r ON r.invoice_id=i.id ORDER BY i.created_at DESC,i.id LIMIT 100');return result.rows.map(row=>present(row));}
 async adminPage(search:string,filter:'all'|'attention',page:number){
  const now=Date.now();
  const size=20;
  const result=await this.db.query(`
   SELECT i.*,r.txid,r.output_index,r.status,r.height,r.checked_at
   FROM merchant_invoices i LEFT JOIN invoice_receipts r ON r.invoice_id=i.id
   WHERE ($1='' OR strpos(lower(i.merchant_name),lower($1))>0
    OR i.id::text=lower($1)
    OR (i.payment_start_height IS NOT NULL AND r.txid=lower($1)))
    AND ($2='all' OR (i.payment_start_height IS NOT NULL AND r.txid IS NOT NULL
      AND (r.status IN ('not_found','unavailable') OR r.checked_at < $4::timestamptz - interval '60 seconds')))
   ORDER BY i.created_at DESC,i.id
   LIMIT 21 OFFSET $3`,[search,filter,(page-1)*size,new Date(now).toISOString()]);
  return {items:result.rows.slice(0,size).map(row=>present(row,now)),page,hasNext:result.rows.length>size,checkedAt:new Date(now).toISOString()};
 }
 async summary(){const result=await this.db.query("SELECT count(*)::integer AS total,count(*) FILTER(WHERE state='open' AND expires_at>now())::integer AS open,count(*) FILTER(WHERE state='cancelled')::integer AS cancelled FROM merchant_invoices");return result.rows[0];}
}
