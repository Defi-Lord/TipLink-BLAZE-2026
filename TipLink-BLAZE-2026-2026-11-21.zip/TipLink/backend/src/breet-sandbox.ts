import type {Config} from './config.js';
// This adapter deliberately has no transaction or production operations.
export function createBreetSandbox(config:Pick<Config,'breetAppId'|'breetAppSecret'>,request:typeof fetch=fetch){
 type Status={provider:'Breet';environment:'sandbox';state:'not_configured'|'listed'|'disabled'|'missing'|'unavailable';activity:'unknown'|'active'|'inactive';payoutVerified:false;checkedAt:string|null};
 let cached:Status|undefined;let until=0;let pending:Promise<Status>|undefined;
 const base={provider:'Breet' as const,environment:'sandbox' as const,payoutVerified:false as const};
 async function lookup():Promise<Status>{
  const checkedAt=new Date().toISOString();
  try{
   const response=await request('https://api.breet.io/v1/trades/assets',{method:'GET',redirect:'error',signal:AbortSignal.timeout(10000),headers:{'x-app-id':config.breetAppId!,'x-app-secret':config.breetAppSecret!,'X-Breet-Env':'sandbox',Accept:'application/json'}});
   if(!response.ok)throw Error('Provider unavailable');
   const raw=await response.text();if(raw.length>1000000)throw Error('Response too large');
   const body=JSON.parse(raw);
   if(body.success!==true||!Array.isArray(body.data)||body.data.length>1000)throw Error('Invalid provider response');
   const matches=body.data.filter((a:unknown)=>a!==null&&typeof a==='object'&&(a as {identifier?:unknown}).identifier==='BCH_TEST');
   if(matches.length===0)return {...base,state:'missing',activity:'unknown',checkedAt};
   if(matches.length!==1)throw Error('Ambiguous asset');
   const asset=matches[0];
   if(asset.symbol!=='BCH'||asset.network!=='Bitcoin_Cash'||(asset.isActive!==undefined&&asset.isActive!==null&&typeof asset.isActive!=='boolean'))throw Error('Invalid asset');
   return {...base,state:asset.isActive===false?'disabled':'listed',activity:asset.isActive===true?'active':asset.isActive===false?'inactive':'unknown',checkedAt};
  }catch{return {...base,state:'unavailable',activity:'unknown',checkedAt};}
 }
 return async():Promise<Status>=>{
  if(!config.breetAppId||!config.breetAppSecret)return {...base,state:'not_configured',activity:'unknown',checkedAt:null};
  if(cached&&Date.now()<until)return cached;
  if(!pending)pending=lookup().then(value=>{cached=value;until=Date.now()+60000;return value;}).finally(()=>{pending=undefined;});
  return pending;
 };
}
