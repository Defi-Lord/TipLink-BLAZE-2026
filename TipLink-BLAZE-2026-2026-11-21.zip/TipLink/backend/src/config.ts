import {decodeAdminTotpSecret} from './admin-totp.js';
import {readFileSync} from 'node:fs';
export type Config={adminTotpSecret?:Buffer;breetAppId?:string;breetAppSecret?:string;receiptWorkerEnabled?:boolean;production:boolean;host:string;port:number;origin:string;customerOrigin?:string;walletConnectProjectId?:string;databaseUrl?:string;databaseCa?:string;localPath:string};
export function readConfig(env:NodeJS.ProcessEnv=process.env):Config {
 if(env.RECEIPT_WORKER_ENABLED!==undefined&&!['true','false'].includes(env.RECEIPT_WORKER_ENABLED))throw Error('Invalid RECEIPT_WORKER_ENABLED.');
 if(env.BREET_ENV!==undefined&&env.BREET_ENV!=='sandbox')throw Error('Only Breet sandbox is supported.');
 if(Boolean(env.BREET_APP_ID)!==Boolean(env.BREET_APP_SECRET))throw Error('Configure both Breet credentials.');
 if(env.BREET_APP_ID&&(!/^[a-zA-Z0-9-]{1,128}$/.test(env.BREET_APP_ID)||!env.BREET_APP_SECRET||!/^[\x21-\x7e]{1,512}$/.test(env.BREET_APP_SECRET)))throw Error('Invalid Breet credentials.');
 const production=env.NODE_ENV==='production';const port=Number(env.PORT||4100);
 if(!Number.isInteger(port)||port<1||port>65535)throw Error('Invalid PORT.');
 if(env.WALLETCONNECT_PROJECT_ID&&!/^[a-fA-F0-9]{32}$/.test(env.WALLETCONNECT_PROJECT_ID))throw Error('Invalid WalletConnect project ID.');
 const origin=new URL(env.APP_ORIGIN||`http://127.0.0.1:${port}`);
 if(origin.pathname!=='/'||origin.search||origin.hash||origin.username||origin.password||!['https:','http:'].includes(origin.protocol))throw Error('APP_ORIGIN must be an HTTP origin without a path.');
 if(production&&(origin.protocol!=='https:'||!env.DATABASE_URL))throw Error('Production requires HTTPS APP_ORIGIN and DATABASE_URL.');
 const customer=new URL(env.CUSTOMER_APP_ORIGIN||(production?origin.origin:'http://127.0.0.1:5173'));
 if(customer.pathname!=='/'||customer.search||customer.hash||customer.username||customer.password||!['http:','https:'].includes(customer.protocol)||(production&&customer.protocol!=='https:'))throw Error('CUSTOMER_APP_ORIGIN must be a supported origin.');
 if(env.DATABASE_URL){const db=new URL(env.DATABASE_URL);if(!['postgres:','postgresql:'].includes(db.protocol))throw Error('DATABASE_URL must use PostgreSQL.');}
 return{adminTotpSecret:env.ADMIN_TOTP_SECRET===undefined?undefined:decodeAdminTotpSecret(env.ADMIN_TOTP_SECRET),breetAppId:env.BREET_APP_ID,breetAppSecret:env.BREET_APP_SECRET,receiptWorkerEnabled:env.RECEIPT_WORKER_ENABLED==='true',production,host:env.HOST||(production?'0.0.0.0':'127.0.0.1'),port,origin:origin.origin,customerOrigin:customer.origin,walletConnectProjectId:env.WALLETCONNECT_PROJECT_ID?.toLowerCase(),databaseUrl:env.DATABASE_URL,databaseCa:env.DATABASE_CA_FILE?readFileSync(env.DATABASE_CA_FILE,'utf8'):undefined,localPath:env.LOCAL_DATABASE_PATH||'./data/tiplink'};
}
