import {createHash} from 'node:crypto';
import type {Config} from './config.js';
import {Problem} from './security.js';
type Bank={id:string;name:string};
const normalize=(value:string)=>value.normalize('NFKC').trim().replace(/\s+/gu,' ').toLocaleUpperCase('en');
const text=(value:unknown,max=120):value is string=>typeof value==='string'&&value.trim().length>0&&value.length<=max&&!/[\x00-\x1f\x7f]/.test(value);
/** Sandbox checks only. Never saves a beneficiary or submits a withdrawal. */
export class BreetBanks {
 private bankCache?:{until:number;value:Promise<Bank[]>};
 private withdrawalCache?:{until:number;value:Promise<object>};
 private attempts=new Map<string,{until:number;count:number}>();
 private lookups=new Map<string,{until:number;value:Promise<object>}>();
 constructor(private config:Pick<Config,'breetAppId'|'breetAppSecret'>,private request:typeof fetch=fetch){}
 private async call(path:string,body?:object){
  if(!this.config.breetAppId||!this.config.breetAppSecret)throw new Problem(503,'Breet sandbox is not configured.');
  try {
   const response=await this.request('https://api.breet.io/v1/'+path,{method:body?'POST':'GET',redirect:'error',signal:AbortSignal.timeout(10000),headers:{'x-app-id':this.config.breetAppId,'x-app-secret':this.config.breetAppSecret,'X-Breet-Env':'sandbox',Accept:'application/json',...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});
   if(!response.ok||!response.body)throw Error();
   const reader=response.body.getReader();let size=0;const chunks:Uint8Array[]=[];
   try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>1048576)throw Error();chunks.push(value);}}finally{await reader.cancel().catch(()=>{});}
   const result=JSON.parse(Buffer.concat(chunks).toString('utf8'));if(result?.success!==true||result.data===undefined)throw Error();return result;
  }catch{throw new Problem(502,'Breet sandbox check unavailable. No payout was submitted.');}
 }
 async banks():Promise<Bank[]>{
  if(this.bankCache&&Date.now()<this.bankCache.until)return this.bankCache.value;
  const value=(async()=>{const result=await this.call('payments/banks?currency=ngn');if(!Array.isArray(result.data)||result.data.length>1000)throw new Problem(502,'Breet returned an unexpected bank list.');const seen=new Set<string>();const banks:Bank[]=[];for(const row of result.data){if(row?.currency!=='NGN'||row?.country!=='Nigeria'||row?.type!=='nuban')continue;if(!text(row.id,16)||!/^\d{1,16}$/.test(row.id)||!text(row.name)||seen.has(row.id))throw new Problem(502,'Breet returned an unexpected bank list.');seen.add(row.id);banks.push({id:row.id,name:row.name.trim()});}if(!banks.length)throw new Problem(502,'No Nigerian banks were returned.');return banks.sort((a,b)=>a.name.localeCompare(b.name));})();
  this.bankCache={until:Date.now()+300000,value};try{return await value;}catch(error){this.bankCache=undefined;throw error;}
 }
 async verify(owner:string,input:{bankId:unknown;accountNumber:unknown}){
  const {bankId,accountNumber}=input;
  if(typeof bankId!=='string'||!/^\d{1,16}$/.test(bankId)||typeof accountNumber!=='string'||!/^\d{10}$/.test(accountNumber))throw new Problem(400,'Select a bank and enter a ten-digit account number.');
  const bank=(await this.banks()).find(row=>row.id===bankId);if(!bank)throw new Problem(400,'Choose a bank from the current Nigerian bank list.');
  const now=Date.now();for(const [id,item]of this.attempts)if(item.until<=now)this.attempts.delete(id);for(const [key,item]of this.lookups)if(item.until<=now)this.lookups.delete(key);
  const key=createHash('sha256').update(JSON.stringify([owner,bankId,accountNumber])).digest('hex');
  const cached=this.lookups.get(key);if(cached)return cached.value;
  let attempt=this.attempts.get(owner);if(!attempt){if(this.attempts.size>=10000)throw new Problem(503,'Bank lookups are busy. Try again shortly.');attempt={until:now+60000,count:0};this.attempts.set(owner,attempt);}
  if(attempt.count>=10)throw new Problem(429,'Too many bank lookups. Wait a minute and try again.');
  if(this.lookups.size>=10000)throw new Problem(503,'Bank lookups are busy. Try again shortly.');attempt.count++;
  const value=(async()=>{
   const {data}=await this.call('payments/banks/validate',{id:bank.id,accountNumber,currency:'ngn'});
   const detailsMatch=data?.accountNumber===accountNumber&&data?.type==='nuban'&&text(data?.bankName)&&normalize(data.bankName)===normalize(bank.name)&&(data.id===undefined||data.id===bank.id);
   const resolved=detailsMatch&&text(data?.accountName)&&normalize(data.accountName).length>=2;
   const checkedAt=Date.now();
   return {environment:'sandbox',payoutVerified:false,payoutEnabled:false,state:resolved?'resolved':'details_mismatch',bankId:bank.id,bankName:bank.name,accountLast4:accountNumber.slice(-4),accountName:resolved?data.accountName.trim():null,checkedAt:new Date(checkedAt).toISOString(),expiresAt:new Date(checkedAt+300000).toISOString()};
  })();
  this.lookups.set(key,{until:now+60000,value});try{return await value;}catch(error){this.lookups.delete(key);throw error;}
 }
 async withdrawals():Promise<object>{
  if(this.withdrawalCache&&Date.now()<this.withdrawalCache.until)return this.withdrawalCache.value;
  const value=this.readWithdrawals();this.withdrawalCache={until:Date.now()+30000,value};try{return await value;}catch(error){this.withdrawalCache=undefined;throw error;}
 }
 private async readWithdrawals(){
  const items:object[]=[];const seen=new Set<string>();let complete=false;
  for(let page=1;page<=5;page++){
   const result=await this.call(`payments/withdrawals?page=${page}&size=25`);
   if(!Array.isArray(result.data)||result.data.length>25||typeof result.meta?.hasNextPage!=='boolean'||(result.meta.page!==undefined&&result.meta.page!==page))throw new Problem(502,'Withdrawal history is incomplete or unexpected. Payout remains unverified.');
   for(const row of result.data){if(!row||typeof row.id!=='string'||!/^[a-f\d]{24}$/i.test(row.id)||seen.has(row.id)||!text(row.status,32)||!['NGN','USD','GHS'].includes(String(row.currency).toUpperCase())||!['number','string'].includes(typeof row.amount)||!/^\d{1,13}(\.\d{1,8})?$/.test(String(row.amount))||Number(row.amount)<=0||!Number.isFinite(Date.parse(row.createdAt))||Date.parse(row.createdAt)>Date.now()+300000)throw new Problem(502,'Withdrawal history is incomplete or unexpected. Payout remains unverified.');seen.add(row.id);items.push({id:row.id,status:row.status,currency:String(row.currency).toUpperCase(),amount:String(row.amount),createdAt:new Date(row.createdAt).toISOString()});}
   if(!result.meta.hasNextPage){complete=true;break;}if(result.data.length===0)throw new Problem(502,'Withdrawal pagination is inconsistent. Payout remains unverified.');
  }
  return {environment:'sandbox',readOnly:true,payoutVerified:false,complete,checkedAt:new Date().toISOString(),items};
 }
}
