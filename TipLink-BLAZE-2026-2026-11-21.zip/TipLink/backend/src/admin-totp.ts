import {createHash, createHmac, timingSafeEqual} from 'node:crypto';

const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export function decodeAdminTotpSecret(value: string): Buffer {
  if (!/^[A-Z2-7]{32}$/.test(value)) {
    throw new Error('ADMIN_TOTP_SECRET must be a 32-character uppercase Base32 secret.');
  }
  const bytes: number[] = [];
  let bits = 0;
  let buffer = 0;
  for (const char of value) {
    buffer = (buffer << 5) | alphabet.indexOf(char);
    bits += 5;
    if (bits >= 8) {
      bits -= 8;
      bytes.push((buffer >>> bits) & 255);
    }
  }
  return Buffer.from(bytes);
}

export function adminTotpVersion(secret: Buffer): string {
  return createHash('sha256').update(secret).digest('hex');
}

export function matchAdminTotp(secret: Buffer, code: unknown, now = Date.now()): number | null {
  if (typeof code !== 'string' || !/^\d{6}$/.test(code)) return null;
  const step = Math.floor(now / 30_000);
  const input = Buffer.alloc(8);
  for (const candidate of [step, step - 1]) {
    input.writeBigUInt64BE(BigInt(candidate));
    const digest = createHmac('sha1', secret).update(input).digest();
    const offset = digest[digest.length - 1]! & 15;
    const expected = ((digest.readUInt32BE(offset) & 0x7fffffff) % 1_000_000).toString().padStart(6, '0');
    if (timingSafeEqual(Buffer.from(expected), Buffer.from(code))) return candidate;
  }
  return null;
}
