import {secp256k1,sha256,ripemd160,decodeCashAddress,encodeCashAddress,bigIntToCompactUint,utf8ToBin,binToHex} from '@bitauth/libauth';
import {Problem} from './security.js';
export function walletAddress(value:unknown){
 if(typeof value!=='string'||value.length>120)throw new Problem(400,'Use a standard BCH mainnet wallet address.');
 const address=value.trim();if(address!==address.toLowerCase()&&address!==address.toUpperCase())throw new Problem(400,'Mixed-case wallet address.');
 const decoded=decodeCashAddress(address.toLowerCase());if(typeof decoded==='string'||decoded.prefix!=='bitcoincash'||decoded.type!=='p2pkh'||decoded.payload.length!==20)throw new Problem(400,'Wallet sign-in requires a standard BCH mainnet P2PKH address.');
 return encodeCashAddress({prefix:'bitcoincash',type:'p2pkh',payload:decoded.payload}).address;
}
export function bitcoinMessageHash(message:string){const bytes=utf8ToBin(message);return sha256.hash(sha256.hash(Uint8Array.from([...utf8ToBin('\x18Bitcoin Signed Message:\n'),...bigIntToCompactUint(BigInt(bytes.length)),...bytes])));}
export function verifyWalletMessage({message,address,signature}:{message:string;address:string;signature:unknown}){
 // Selene's bch_signMessage format: one compressed-key recovery header + 64-byte compact ECDSA.
 if(typeof signature!=='string'||signature.length!==88||!/^[A-Za-z0-9+/]{87}=$/.test(signature))return false;
 const bytes=Buffer.from(signature,'base64');if(bytes.length!==65||bytes.toString('base64')!==signature)return false;
 const header=bytes[0]!;if(header<31||header>34)return false;
 const hash=bitcoinMessageHash(message),compact=bytes.subarray(1),publicKey=secp256k1.recoverPublicKeyCompressed(compact,(header-31) as 0|1|2|3,hash);
 if(typeof publicKey==='string'||!secp256k1.verifySignatureCompactLowS(compact,publicKey,hash))return false;
 const decoded=decodeCashAddress(walletAddress(address));if(typeof decoded==='string')return false;
 return binToHex(ripemd160.hash(sha256.hash(publicKey)))===binToHex(decoded.payload);
}
