import type {PaymentReceipts} from './payment-receipts.js';

export function startReceiptWorker(
 receipts:Pick<PaymentReceipts,'recheckNext'>,
 onError:()=>void=()=>console.error('Background receipt check failed. Retrying later.')
){
 let stopped=false;
 let delay=15000;
 let timer:ReturnType<typeof setTimeout>;
 let pending:Promise<void>|undefined;
 function schedule(){
  timer=setTimeout(()=>{
   pending=tick();
  },delay);
  timer.unref();
 }
 async function tick(){
  try{
   await receipts.recheckNext();
   delay=15000;
  }catch{
   delay=Math.min(delay*2,120000);
   onError();
  }finally{
   if(!stopped)schedule();
  }
 }
 schedule();
 return async()=>{
  stopped=true;
  clearTimeout(timer);
  await pending;
 };
}
