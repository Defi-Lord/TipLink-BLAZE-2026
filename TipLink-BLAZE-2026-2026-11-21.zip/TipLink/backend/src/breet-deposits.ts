import {createHash,randomUUID} from 'node:crypto';
import {decodeCashAddress} from '@bitauth/libauth';
import type {Config} from './config.js';
import type {Database,Row} from './database.js';
import {Problem} from './security.js';
import {BreetLedger,depositSnapshot} from './breet-ledger.js';
import {audit,type Account} from './store.js';

type WalletRow=Row&{state:string;label:string;asset_id:string;wallet_id:string|null;address:string|null};
const id=(v:unknown):v is string=>typeof v==='string'&&/^[a-f0-9]{24}$/.test(v);
function testAddress(value:unknown):value is string {
 if(typeof value!=='string'||value.length>120||!value.startsWith('bchtest:'))return false;
 const decoded=decodeCashAddress(value);
 return typeof decoded!=='string'&&decoded.prefix==='bchtest'&&decoded.type==='p2pkh'&&decoded.payload.length===20;
}
const unavailable=()=>new Problem(503,'Breet sandbox is unavailable. No bank payout has been made.');
export class BreetDeposits {
 private scope:string;
 private cache=new Map<string,{until:number;value:Promise<object>}>();
 constructor(private db:Database,private config:Pick<Config,'breetAppId'|'breetAppSecret'>,private request:typeof fetch=fetch){
  this.scope=createHash('sha256').update(config.breetAppId||'unconfigured').digest('hex');
 }
 private async owner(account:Account){
  const result=await this.db.query('SELECT id FROM accounts WHERE id=$1 AND active=true AND role=$2',[account.id,'merchant']);
  if(!result.rows.length)throw new Problem(403,'Sign in to your business workspace.');
 }
 private async call(path:string,body?:object):Promise<any>{
  if(!this.config.breetAppId||!this.config.breetAppSecret)throw new Problem(503,'Breet sandbox credentials are not configured.');
  const response=await this.request('https://api.breet.io/v1/'+path,{method:body?'POST':'GET',redirect:'error',signal:AbortSignal.timeout(10000),headers:{'x-app-id':this.config.breetAppId,'x-app-secret':this.config.breetAppSecret,'X-Breet-Env':'sandbox',Accept:'application/json',...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});
  if(!response.ok||!response.body)throw unavailable();
  const reader=response.body.getReader(),parts:Uint8Array[]=[];let length=0;
  try{for(;;){const r=await reader.read();if(r.done)break;length+=r.value.length;if(length>1000000)throw unavailable();parts.push(r.value);}}finally{await reader.cancel().catch(()=>{});}
  const result=JSON.parse(Buffer.concat(parts).toString('utf8'));
  if(!result||result.success!==true||result.data===undefined)throw unavailable();
  return result;
 }
 private async row(account:Account){return (await this.db.query<WalletRow>('SELECT * FROM breet_sandbox_wallets WHERE account_id=$1 AND app_scope=$2',[account.id,this.scope])).rows[0];}
 private publicWallet(row:WalletRow|undefined){return {environment:'sandbox',asset:'BCH_TEST',payoutVerified:false,state:row?.state==='ready'?'ready':row?'uncertain':'not_created',address:row?.state==='ready'?row.address:null,label:row?.label??null};}
 async wallet(account:Account){await this.owner(account);return this.publicWallet(await this.row(account));}
 async create(account:Account){
  await this.owner(account);const existing=await this.row(account);if(existing)return this.publicWallet(existing);
  let asset:any;
  try{const result=await this.call('trades/assets');if(!Array.isArray(result.data)||result.data.length>1000)throw unavailable();const matches=result.data.filter((a:any)=>a&&a.identifier==='BCH_TEST');if(matches.length!==1)throw unavailable();asset=matches[0];if(!id(asset.id)||asset.network!=='Bitcoin_Cash'||asset.isActive===false||(asset.isActive!=null&&typeof asset.isActive!=='boolean'))throw unavailable();}catch{throw unavailable();}
  const label='tiplink-sandbox-'+randomUUID();
  const claimed=await this.db.transaction(async sql=>{
   const r=await sql.query('INSERT INTO breet_sandbox_wallets(account_id,app_scope,label,asset_id,state) VALUES($1,$2,$3,$4,$5) ON CONFLICT(account_id,app_scope) DO NOTHING RETURNING label',[account.id,this.scope,label,asset.id,'creating']);
   if(!r.rows.length)return false;
   await audit(sql,account.id,'cashout.sandbox.address_requested',label);return true;
  });
  if(!claimed)return this.publicWallet(await this.row(account));
  try{
   const result=await this.call('trades/sell/assets/'+asset.id+'/generate-address',{label,autoSettlement:false});
   if(!id(result.data?.id)||!testAddress(result.data?.address))throw unavailable();
   await this.db.transaction(async sql=>{
    await sql.query('UPDATE breet_sandbox_wallets SET state=$1,wallet_id=$2,address=$3 WHERE account_id=$4 AND app_scope=$5 AND label=$6 AND state=$7',['ready',result.data.id,result.data.address,account.id,this.scope,label,'creating']);
    await audit(sql,account.id,'cashout.sandbox.address_saved',label);
   });
  }catch{
   await this.db.query('UPDATE breet_sandbox_wallets SET state=$1 WHERE account_id=$2 AND app_scope=$3 AND state=$4',['uncertain',account.id,this.scope,'creating']);
  }
  return this.publicWallet(await this.row(account));
 }
 async estimate(account:Account,input:unknown){
  await this.owner(account);
  if(typeof input!=='string'||!/^(?:[1-9]\d{0,3}|10000)(?:\.\d{1,2})?$/.test(input))throw new Problem(400,'Enter a USD amount from 1 to 10,000 with at most two decimal places.');
  const usd=Number(input);if(usd<1||usd>10000)throw new Problem(400,'Use an amount from 1 to 10,000 USD.');
  const row=await this.row(account);if(!row||row.state!=='ready')throw new Problem(409,'Create your sandbox deposit address first.');
  const key='quote:'+account.id+':'+usd.toFixed(2),previous=this.cache.get(key);
  if(previous&&previous.until>Date.now())return previous.value;
  for(const [k,v]of this.cache)if(v.until<=Date.now())this.cache.delete(k);
  if(this.cache.size>=1000)throw unavailable();
  const value=this.lookupEstimate(row,usd);this.cache.set(key,{until:Date.now()+30000,value});return value;
 }
 private async lookupEstimate(row:WalletRow,usd:number){
  try{
   const result=await this.call('trades/pbc/sell/rate-calculator/'+row.asset_id,{amountInUSD:usd,currency:'ngn'});
   const d=result.data;
   if(!d||typeof d.NGNAmount!=='number'||!Number.isFinite(d.NGNAmount)||d.NGNAmount<=0||d.NGNAmount>1e12||Number(d.NGNAmount.toFixed(2))<=0||typeof d.rate!=='number'||!Number.isFinite(d.rate)||d.rate<=0||d.rate>1e8||Number(d.rate.toFixed(4))<=0||typeof d.cryptoAmount!=='number'||!Number.isFinite(d.cryptoAmount)||d.cryptoAmount<=0||d.cryptoAmount>21000000||Number(d.cryptoAmount.toFixed(8))<=0)throw unavailable();
   // Display estimates only; no conversion, balance mutation or payout is exposed.
   const checkedAt=new Date().toISOString();
   return {environment:'sandbox',provider:'Breet',asset:'BCH_TEST',currency:'NGN',amountUsd:usd.toFixed(2),estimatedNgn:d.NGNAmount.toFixed(2),approximateBch:d.cryptoAmount.toFixed(8),rateNgnPerUsd:d.rate.toFixed(4),feesQuoted:false,payoutVerified:false,checkedAt,refreshAfter:new Date(Date.parse(checkedAt)+60000).toISOString()};
  }catch{throw new Problem(503,'Breet could not provide a sandbox estimate. No conversion or bank payout was submitted.');}
 }
 async transactions(account:Account){
  await this.owner(account);const row=await this.row(account);
  if(!row||row.state!=='ready')throw new Problem(409,'Create your sandbox address first. An uncertain creation must be reconciled before continuing.');
  const key=account.id;const previous=this.cache.get(key);if(previous&&previous.until>Date.now())return previous.value;
  for(const [k,v]of this.cache)if(v.until<=Date.now())this.cache.delete(k);
  if(this.cache.size>=1000)throw unavailable();
  const value=this.lookupTransactions(account.id,row);this.cache.set(key,{until:Date.now()+30000,value});return value;
 }
 async ledger(account:Account){await this.owner(account);return new BreetLedger(this.db).read(account.id,this.scope);}
 private async lookupTransactions(accountId:string,row:WalletRow){
  const checkedAt=new Date().toISOString();
  try{
   const params=new URLSearchParams({address:row.address!,assetId:row.asset_id,page:'1',size:'25'});
   const result=await this.call('trades/transactions?'+params);
   if(!Array.isArray(result.data)||result.data.length>25||typeof result.meta?.hasNextPage!=='boolean')throw unavailable();
   const seen=new Set<string>();
   const snapshots:ReturnType<typeof depositSnapshot>[]=[];
   const items=result.data.map((t:any)=>{
    if(!t||!id(t.id)||seen.has(t.id)||t.wallet!==row.wallet_id||t.address!==row.address||t.asset!==row.asset_id)throw unavailable();
    seen.add(t.id);
    const amount=String(t.cryptoReceived);
    if(!/^(?:0|[1-9]\d{0,7})(?:\.\d{1,8})?$/.test(amount)||!Number.isFinite(Date.parse(t.createdAt)))throw unavailable();
    const snapshot=depositSnapshot(t);snapshots.push(snapshot);
    const status=snapshot.status;
    return {id:t.id,amountBch:amount,status,createdAt:new Date(t.createdAt).toISOString()};
   });
   await new BreetLedger(this.db).observe(accountId,this.scope,row.wallet_id!,snapshots,checkedAt);
   return {environment:'sandbox',payoutVerified:false,state:'checked',items,hasMore:result.meta.hasNextPage,checkedAt};
  }catch{return {environment:'sandbox',payoutVerified:false,state:'unavailable',items:[],hasMore:null,checkedAt};}
 }
}
