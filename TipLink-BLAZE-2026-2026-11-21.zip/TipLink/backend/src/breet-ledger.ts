import type {Database,Row} from './database.js';
import {audit} from './store.js';
import {Problem} from './security.js';
export type DepositSnapshot={id:string;amountSats:string;status:string;walletCredited:boolean|null;reportedCurrency:string|null;reportedAmount:string|null;createdAt:string};
export function depositSnapshot(t:any):DepositSnapshot{
 const amount=String(t.cryptoReceived);
 if(!/^[a-f0-9]{24}$/.test(t.id)||!/^(?:0|[1-9]\d{0,7})(?:\.\d{1,8})?$/.test(amount))throw Error('Invalid deposit.');
 const [whole,fraction='']=amount.split('.');const sats=BigInt(whole!)*100000000n+BigInt(fraction.padEnd(8,'0'));
 const createdAt=Date.parse(t.createdAt);
 if(sats<=0n||sats>2100000000000000n||!Number.isFinite(createdAt)||createdAt>Date.now()+300000)throw Error('Invalid deposit.');
 const status=['pending','completed','flagged','deleted','failed'].includes(t.status)?t.status:'unknown';
 const currency=typeof t.currency==='string'?t.currency.toUpperCase():null;
 const reported=typeof t.amount==='number'||typeof t.amount==='string'?String(t.amount):'';
 const validReported=/^(?:0|[1-9]\d{0,12})(?:\.\d{1,18})?$/.test(reported);
 // Preserve provider-reported figures without assuming they are net, spendable proceeds.
 return {id:t.id,amountSats:String(sats),status,walletCredited:typeof t.walletCredited==='boolean'?t.walletCredited:null,reportedCurrency:currency&&['USD','NGN','GHS'].includes(currency)?currency:null,reportedAmount:validReported?reported:null,createdAt:new Date(createdAt).toISOString()};
}
export class BreetLedger{
 constructor(private db:Database){}
 async observe(accountId:string,scope:string,walletId:string,items:DepositSnapshot[],checkedAt:string){
  await this.db.transaction(async sql=>{
   const owner=await sql.query('SELECT w.account_id FROM breet_sandbox_wallets w JOIN accounts a ON a.id=w.account_id WHERE w.account_id=$1 AND w.app_scope=$2 AND w.wallet_id=$3 AND w.state=$4 AND a.active=true AND a.role=$5 FOR UPDATE OF w',[accountId,scope,walletId,'ready','merchant']);
   if(!owner.rows.length)throw new Problem(403,'Merchant deposit ownership could not be verified.');
   for(const item of items){
    const existing=(await sql.query('SELECT * FROM breet_sandbox_deposits WHERE app_scope=$1 AND trade_id=$2 FOR UPDATE',[scope,item.id])).rows[0];
    if(existing&&(existing.account_id!==accountId||existing.wallet_id!==walletId))throw Error('Conflicting deposit owner.');
    if(existing&&new Date(existing.checked_at as string).getTime()>Date.parse(checkedAt))continue;
    const changed=!!existing&&((existing.recorded_at!=null&&(item.status!=='completed'||(existing.wallet_credited===true&&item.walletCredited!==true)))||String(existing.amount_sats)!==item.amountSats||new Date(existing.provider_created_at as string).toISOString()!==item.createdAt||
     (existing.recorded_at!=null&&(existing.reported_currency!==item.reportedCurrency||existing.reported_amount!==item.reportedAmount)));
    const review=changed||existing?.review_required===true;
    if(existing){
     await sql.query('UPDATE breet_sandbox_deposits SET provider_status=$1,wallet_credited=$2,reported_currency=$3,reported_amount=$4,review_required=$5,checked_at=$6 WHERE app_scope=$7 AND trade_id=$8',[item.status,item.walletCredited,review?existing.reported_currency:item.reportedCurrency,review?existing.reported_amount:item.reportedAmount,review,checkedAt,scope,item.id]);
    }else{
     await sql.query('INSERT INTO breet_sandbox_deposits(app_scope,trade_id,account_id,wallet_id,amount_sats,provider_status,wallet_credited,reported_currency,reported_amount,provider_created_at,checked_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)',[scope,item.id,accountId,walletId,item.amountSats,item.status,item.walletCredited,item.reportedCurrency,item.reportedAmount,item.createdAt,checkedAt]);
    }
    if(item.status==='completed'&&!review){
     const recorded=await sql.query('UPDATE breet_sandbox_deposits SET recorded_at=$1 WHERE app_scope=$2 AND trade_id=$3 AND recorded_at IS NULL RETURNING trade_id',[checkedAt,scope,item.id]);
     if(recorded.rows.length)await audit(sql,accountId,'cashout.sandbox.deposit_recorded',item.id,{amountSats:item.amountSats});
    }
   }
  });
 }
 async read(accountId:string,scope:string){
  const totals=(await this.db.query(`WITH deposits AS MATERIALIZED (SELECT * FROM breet_sandbox_deposits WHERE account_id=$1 AND app_scope=$2)
   SELECT count(*)::int AS observed_count,count(*) FILTER(WHERE recorded_at IS NOT NULL)::int AS recorded_count,COALESCE(sum(amount_sats) FILTER(WHERE recorded_at IS NOT NULL),0)::text AS recorded_sats,count(*) FILTER(WHERE review_required OR (recorded_at IS NOT NULL AND provider_status<>'completed'))::int AS review_count,
   (SELECT COALESCE(jsonb_agg(recent),'[]'::jsonb) FROM (SELECT * FROM deposits ORDER BY provider_created_at DESC,trade_id DESC LIMIT 25) recent) AS items FROM deposits`,[accountId,scope])).rows[0]!;
  const rows=totals.items as Row[];
  const items=rows.map((r:Row)=>({id:r.trade_id,amountSats:String(r.amount_sats),status:r.provider_status,walletCredited:r.wallet_credited,reportedCurrency:r.reported_currency,reportedAmount:r.reported_amount,reviewRequired:r.review_required,checkedAt:new Date(r.checked_at as string).toISOString(),recordedAt:r.recorded_at?new Date(r.recorded_at as string).toISOString():null}));
  return {environment:'sandbox',payoutVerified:false,spendingEnabled:false,recordedSats:String(totals.recorded_sats),recordedCount:totals.recorded_count,reviewCount:totals.review_count,hasMore:Number(totals.observed_count)>items.length,items};
 }
}
