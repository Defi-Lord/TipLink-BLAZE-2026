import {randomBytes,scrypt as scryptCallback,timingSafeEqual,createHash} from 'node:crypto';
export class Problem extends Error {constructor(public status:number,message:string){super(message);}}
export function exact(value:unknown,keys:string[]):asserts value is Record<string,unknown>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||Object.keys(value).some(k=>!keys.includes(k)))throw new Problem(400,'Unexpected or missing fields.');}
export function email(value:unknown){if(typeof value!=='string'||value.length>254||! /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/.test(value.trim()))throw new Problem(400,'Enter a valid email address.');return value.trim().toLowerCase();}
export function name(value:unknown){const normalized=typeof value==='string'?value.normalize('NFKC').replace(/\p{Cf}/gu,'').trim():'';if(normalized.length<2||normalized.length>80||/[\u0000-\u001f\u007f]/.test(normalized))throw new Problem(400,'Use a name of 2–80 characters.');return normalized;}
export function password(value:unknown):string {if(typeof value!=='string'||value.length<14||value.length>128||Buffer.byteLength(value)>512)throw new Problem(400,'Use a password of 14–128 characters.');return value;}
export const randomToken=()=>randomBytes(32).toString('hex');
export const tokenHash=(value:string)=>createHash('sha256').update(value).digest('hex');
export function equalToken(a:unknown,b:string){return typeof a==='string'&&/^[a-f0-9]{64}$/.test(a)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));}
let running=0;
async function derive(value:string,salt:string){if(running>=8)throw new Problem(503,'Authentication is busy. Try again shortly.');running++;try{return await new Promise<Buffer>((resolve,reject)=>scryptCallback(value,salt,64,{N:32768,r:8,p:1,maxmem:64*1024*1024},(error,key)=>error?reject(error):resolve(key)));}finally{running--;}}
export async function hashPassword(value:string){password(value);const salt=randomBytes(16).toString('hex');return `scrypt1$${salt}$${(await derive(value,salt)).toString('hex')}`;}
export async function verifyPassword(value:string,stored:string){const parts=stored.split('$');if(parts.length!==3||parts[0]!=='scrypt1'||!/^[a-f0-9]{32}$/.test(parts[1]||'')||!/^[a-f0-9]{128}$/.test(parts[2]||''))return false;const result=await derive(value,parts[1]!);return timingSafeEqual(result,Buffer.from(parts[2]!,'hex'));}
