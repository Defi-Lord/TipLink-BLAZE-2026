import {createHash} from 'node:crypto';
import {decodeCashAddress,decodeTransaction,encodeTransaction,binToHex,hexToBin,hashTransaction} from '@bitauth/libauth';
import {Problem} from './security.js';
export const PAYMENT_SOURCE='rostrum.riften.net';
const GENESIS='000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f';
const CHECKPOINT={height:898374,hash:'00000000000000000157a0a3dcdc80f1acd809648d238c1e893b26247091b3b4'};
export interface PaymentLookup {status:'seen'|'confirmed'|'not_found';outputIndex:number|null;height:number;}
export interface Rpc {call(method:string,params:unknown[]):Promise<unknown>;}
const hash=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest();
async function checkNetwork(rpc:Rpc){
 await rpc.call('server.version',['TipLink receipt check','1.4.3']);
 const features=await rpc.call('server.features',[]) as Record<string,unknown>|null;
 const header=await rpc.call('blockchain.block.header',[CHECKPOINT.height]);
 if(features?.genesis_hash!==GENESIS||features.hash_function!=='sha256'||typeof header!=='string'||!/^[a-fA-F0-9]{160}$/.test(header)||hash(hash(hexToBin(header))).reverse().toString('hex')!==CHECKPOINT.hash)throw Error('Wrong network checkpoint.');
}
function paymentScript(address:string){
 const decoded=decodeCashAddress(address);if(typeof decoded==='string'||decoded.prefix!=='bitcoincash'||decoded.type!=='p2pkh'||decoded.payload.length!==20)throw Error('Unsupported receiving address.');
 const script='76a914'+binToHex(decoded.payload)+'88ac';
 return {script,scriptHash:hash(hexToBin(script)).reverse().toString('hex')};
}
export async function inspectNewInvoiceAddress(rpc:Rpc,address:string):Promise<number>{
 await checkNetwork(rpc);
 const tip=await rpc.call('blockchain.headers.subscribe',[]) as {height?:number;hex?:string}|null;
 if(!tip||typeof tip.height!=='number'||!Number.isSafeInteger(tip.height)||tip.height<CHECKPOINT.height||tip.height>10000000||typeof tip.hex!=='string'||!/^[a-fA-F0-9]{160}$/.test(tip.hex))throw Error('Invalid network tip.');
 const {scriptHash}=paymentScript(address);
 const history=await rpc.call('blockchain.scripthash.get_history',[scriptHash]);
 if(!Array.isArray(history))throw Error('Invalid address history.');
 if(history.length)throw new Problem(409,'Use a fresh BCH receiving address with no transaction history for this request.');
 return tip.height;
}
export async function inspectPayment(rpc:Rpc,txid:string,address:string,amount:string):Promise<PaymentLookup>{
 await checkNetwork(rpc);
 const {script,scriptHash}=paymentScript(address);
 const history=await rpc.call('blockchain.scripthash.get_history',[scriptHash]);
 if(!Array.isArray(history)||history.length>200)throw Error('History outside bounded limit.');
 const seen=new Set<string>();let height:number|undefined;
 for(const entry of history){if(!entry||typeof entry!=='object'||typeof entry.tx_hash!=='string'||!/^[a-f0-9]{64}$/.test(entry.tx_hash)||!Number.isSafeInteger(entry.height)||entry.height< -1||seen.has(entry.tx_hash))throw Error('Malformed history.');seen.add(entry.tx_hash);if(entry.tx_hash===txid)height=entry.height;}
 if(height===undefined)return{status:'not_found',outputIndex:null,height:0};
 const raw=await rpc.call('blockchain.transaction.get',[txid,false]);
 if(typeof raw!=='string'||raw.length>2000000||!/^(?:[a-fA-F0-9]{2})+$/.test(raw))throw Error('Malformed transaction.');
 const bytes=hexToBin(raw),tx=decodeTransaction(bytes);
 if(typeof tx==='string'||hashTransaction(bytes)!==txid||binToHex(encodeTransaction(tx))!==raw.toLowerCase())throw Error('Transaction ID or encoding mismatch.');
 if(tx.inputs.length===0||tx.outputs.length===0||(tx.inputs.length===1&&tx.inputs[0]!.outpointIndex===0xffffffff&&tx.inputs[0]!.outpointTransactionHash.every(n=>n===0)))throw new Problem(400,'This is not a supported customer payment.');
 const matches=tx.outputs.map((output,index)=>({output,index})).filter(({output})=>output.token===undefined&&binToHex(output.lockingBytecode)===script&&output.valueSatoshis===BigInt(amount));
 if(matches.length!==1)throw new Problem(400,matches.length?'This transaction has multiple identical payment outputs. It needs manual review.':'This transaction does not contain one exact BCH payment to this request’s address. Partial, combined and token payments need manual review.');
 // Re-read history to avoid accepting a result that changed during the lookup.
 const fresh=await rpc.call('blockchain.scripthash.get_history',[scriptHash]);
 if(JSON.stringify(fresh)!==JSON.stringify(history))throw Error('History changed during lookup.');
 return{status:height>0?'confirmed':'seen',outputIndex:matches[0]!.index,height:Math.max(height,0)};
}
const METHODS=new Set(['server.version','server.features','blockchain.block.header','blockchain.scripthash.get_history','blockchain.transaction.get','blockchain.headers.subscribe']);
const PAYMENT_PROVIDERS=['wss://rostrum.riften.net:443','wss://electroncash.dk:50004','wss://bch.loping.net:50004'];
async function withPaymentRpc<T>(url:string,work:(rpc:Rpc)=>Promise<T>):Promise<T>{
 const ws=new WebSocket(url);let next=0,total=0,closed=false;
 const pending=new Map<number,{resolve:(value:unknown)=>void;reject:(error:Error)=>void}>();
 let failOpen:(error:Error)=>void=()=>{};
 const fail=()=>{if(closed)return;const error=Error('Payment provider unavailable.');closed=true;failOpen(error);for(const p of pending.values())p.reject(error);pending.clear();ws.close();};
 const timer=setTimeout(fail,15000);
 try{
  const opened=new Promise<void>((resolve,reject)=>{failOpen=reject;ws.addEventListener('open',()=>resolve(),{once:true});});
  ws.addEventListener('error',fail);ws.addEventListener('close',()=>{if(!closed)fail();});
  ws.addEventListener('message',event=>{try{if(typeof event.data!=='string'||(total+=Buffer.byteLength(event.data))>2500000)throw Error();for(const line of event.data.trim().split('\n')){const msg=JSON.parse(line);if(!Number.isSafeInteger(msg.id)||!pending.has(msg.id))continue;const p=pending.get(msg.id)!;pending.delete(msg.id);if(msg.error||!Object.hasOwn(msg,'result'))p.reject(Error('Provider lookup rejected.'));else p.resolve(msg.result);}}catch{fail();}});
  await opened;
  return await work({call:(method,params)=>{if(closed||!METHODS.has(method))return Promise.reject(Error('Unsupported payment lookup.'));return new Promise((resolve,reject)=>{const id=++next;pending.set(id,{resolve,reject});ws.send(JSON.stringify({jsonrpc:'2.0',id,method,params})+'\n');});}});
 }finally{closed=true;clearTimeout(timer);ws.close();}
}

export async function lookupPayment(txid:string,address:string,amount:string){
 const results=await Promise.allSettled(PAYMENT_PROVIDERS.map(url=>withPaymentRpc(url,rpc=>inspectPayment(rpc,txid,address,amount))));
 const votes=new Map<string,PaymentLookup>();
 const errors=new Map<string,Problem>();
 for(const result of results){
  if(result.status==='fulfilled'){
   const key=JSON.stringify(result.value);
   if(votes.has(key))return result.value;
   votes.set(key,result.value);
  }else if(result.reason instanceof Problem){
   const key=result.reason.message;
   if(errors.has(key))throw result.reason;
   errors.set(key,result.reason);
  }
 }
 throw Error('BCH providers did not agree on the payment.');
}
export async function checkNewInvoiceAddress(address:string){
 const results=await Promise.allSettled(PAYMENT_PROVIDERS.map(url=>withPaymentRpc(url,rpc=>inspectNewInvoiceAddress(rpc,address))));
 const used=results.find(result=>result.status==='rejected'&&result.reason instanceof Problem);
 if(used?.status==='rejected')throw used.reason;
 const heights=results.flatMap(result=>result.status==='fulfilled'?[result.value]:[]);
 if(heights.length<2||Math.max(...heights)-Math.min(...heights)>2)throw Error('BCH providers did not agree on the network tip.');
 return Math.max(...heights);
}
