import {readFile} from 'node:fs/promises';
import type {Database} from './database.js';
export async function migrate(db:Database){const scripts=await Promise.all(['001_foundation.sql','002_merchant_requests.sql','003_wallet_accounts.sql','004_payment_receipts.sql','005_breet_sandbox.sql','006_breet_deposit_ledger.sql','007_invoice_payment_binding.sql','008_admin_totp.sql'].map(file=>readFile(new URL('../migrations/'+file,import.meta.url),'utf8')));await db.transaction(async tx=>{for(const sql of scripts)await tx.exec(sql);});}
