import {PGlite} from '@electric-sql/pglite';
import pg from 'pg';
import {mkdir,open,unlink,type FileHandle} from 'node:fs/promises';
import {resolve} from 'node:path';
import type {Config} from './config.js';
export type Row=Record<string,unknown>;
export interface Sql { exec(text:string):Promise<void>; query<T extends Row=Row>(text:string,params?:unknown[]):Promise<{rows:T[]}>; }
export interface Database extends Sql {transaction<T>(work:(sql:Sql)=>Promise<T>):Promise<T>;close():Promise<void>;mode:'postgres'|'local-postgres';}
export async function openDatabase(config:Config):Promise<Database>{
 if(config.databaseUrl){
  const url=new URL(config.databaseUrl);
  // URL SSL options must not silently weaken certificate verification.
  for(const key of ['sslmode','sslcert','sslkey','sslrootcert'])url.searchParams.delete(key);
  const local=['localhost','127.0.0.1','[::1]'].includes(url.hostname);
  const pool=new pg.Pool({connectionString:url.href,max:5,connectionTimeoutMillis:10000,idleTimeoutMillis:30000,ssl:!config.production&&local?false:{rejectUnauthorized:true,...(config.databaseCa?{ca:config.databaseCa}:{})}});
  pool.on('error',()=>console.error('PostgreSQL pool connection failed.'));
  return{mode:'postgres',exec:async text=>{await pool.query(text);},query:async<T extends Row>(text:string,params:unknown[]=[])=>({rows:(await pool.query<T>(text,params)).rows}),async transaction(work){const client=await pool.connect();try{await client.query('BEGIN');const value=await work({exec:async text=>{await client.query(text);},query:async<T extends Row>(text:string,params:unknown[]=[])=>({rows:(await client.query<T>(text,params)).rows})});await client.query('COMMIT');return value;}catch(error){await client.query('ROLLBACK');throw error;}finally{client.release();}},close:()=>pool.end()};
 }
 if(config.production)throw Error('Local database is disabled in production.');
 let lock:FileHandle|undefined;let lockPath='';
 if(config.localPath!=='memory://'){await mkdir(resolve(config.localPath),{recursive:true,mode:0o700});lockPath=resolve(config.localPath)+'.process-lock';try{lock=await open(lockPath,'wx',0o600);await lock.writeFile(String(process.pid));}catch{throw Error('Local database is already open or its lock cannot be created. Stop the other backend process first.');}}
 const release=async()=>{await lock?.close();if(lockPath)await unlink(lockPath);};
 const database=new PGlite(config.localPath);try{await database.waitReady;}catch(error){await database.close().catch(()=>{});await release();throw error;}let closed=false;
 return{mode:'local-postgres',exec:async text=>{await database.exec(text);},query:async<T extends Row>(text:string,params:unknown[]=[])=>({rows:(await database.query<T>(text,params)).rows}),transaction:work=>database.transaction(tx=>work({exec:async text=>{await tx.exec(text);},query:async<T extends Row>(text:string,params:unknown[]=[])=>({rows:(await tx.query<T>(text,params)).rows})})),async close(){if(closed)return;closed=true;try{await database.close();}finally{await release();}}};
}
