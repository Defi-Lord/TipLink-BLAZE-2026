CREATE TABLE IF NOT EXISTS invoice_receipts (
 invoice_id uuid PRIMARY KEY REFERENCES merchant_invoices(id),
 txid text NOT NULL CHECK(txid ~ '^[a-f0-9]{64}$'),
 output_index integer NOT NULL CHECK(output_index>=0),
 status text NOT NULL CHECK(status IN ('seen','confirmed','not_found','unavailable')),
 height integer NOT NULL CHECK(height>=0),
 checked_at timestamptz NOT NULL,
 UNIQUE(txid,output_index),
 CHECK((status='confirmed' AND height>0) OR (status<>'confirmed' AND height=0))
);
INSERT INTO tiplink_schema_version(version) VALUES(4) ON CONFLICT DO NOTHING;
