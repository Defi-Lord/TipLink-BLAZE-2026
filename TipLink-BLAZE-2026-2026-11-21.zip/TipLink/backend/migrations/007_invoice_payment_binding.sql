ALTER TABLE merchant_invoices ADD COLUMN IF NOT EXISTS payment_start_height integer
 CHECK(payment_start_height BETWEEN 898374 AND 10000000);
CREATE INDEX IF NOT EXISTS merchant_invoices_address ON merchant_invoices(address);
CREATE UNIQUE INDEX IF NOT EXISTS merchant_invoices_receipt_address ON merchant_invoices(address)
 WHERE payment_start_height IS NOT NULL;
INSERT INTO tiplink_schema_version(version) VALUES(7) ON CONFLICT DO NOTHING;
