CREATE TABLE IF NOT EXISTS breet_sandbox_wallets (
 account_id uuid NOT NULL REFERENCES accounts(id),
 app_scope text NOT NULL CHECK(length(app_scope)=64),
 label text NOT NULL UNIQUE,
 asset_id text NOT NULL,
 state text NOT NULL CHECK(state IN ('creating','uncertain','ready')),
 wallet_id text,
 address text,
 created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(account_id,app_scope),
 UNIQUE(app_scope,wallet_id),
 UNIQUE(app_scope,address),
 CHECK((state='ready' AND wallet_id IS NOT NULL AND address IS NOT NULL) OR (state<>'ready' AND wallet_id IS NULL AND address IS NULL))
);
INSERT INTO tiplink_schema_version(version) VALUES(5) ON CONFLICT DO NOTHING;
