CREATE TABLE IF NOT EXISTS merchant_invoices (
 id uuid PRIMARY KEY, merchant_id uuid NOT NULL REFERENCES accounts(id), request_key uuid NOT NULL,
 fingerprint text NOT NULL CHECK(length(fingerprint)=64), merchant_name text NOT NULL,
 amount_sats bigint NOT NULL CHECK(amount_sats BETWEEN 1000 AND 2100000000000000),
 address text NOT NULL, memo text NOT NULL CHECK(length(memo)<=160),
 state text NOT NULL DEFAULT 'open' CHECK(state IN ('open','cancelled')), version integer NOT NULL DEFAULT 1 CHECK(version>0),
 created_at timestamptz NOT NULL, expires_at timestamptz NOT NULL CHECK(expires_at>created_at),
 UNIQUE(merchant_id,request_key)
);
CREATE INDEX IF NOT EXISTS merchant_invoices_owner_created ON merchant_invoices(merchant_id,created_at DESC);
INSERT INTO tiplink_schema_version(version) VALUES(2) ON CONFLICT DO NOTHING;
