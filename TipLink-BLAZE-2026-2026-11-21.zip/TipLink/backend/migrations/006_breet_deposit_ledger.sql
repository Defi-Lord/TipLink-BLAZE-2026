CREATE TABLE IF NOT EXISTS breet_sandbox_deposits (
 app_scope text NOT NULL,
 trade_id text NOT NULL CHECK(trade_id ~ '^[a-f0-9]{24}$'),
 account_id uuid NOT NULL,
 wallet_id text NOT NULL,
 amount_sats bigint NOT NULL CHECK(amount_sats>0 AND amount_sats<=2100000000000000),
 provider_status text NOT NULL CHECK(provider_status IN ('pending','completed','flagged','deleted','failed','unknown')),
 wallet_credited boolean,
 reported_currency text CHECK(reported_currency IN ('USD','NGN','GHS')),
 reported_amount text,
 review_required boolean NOT NULL DEFAULT false,
 provider_created_at timestamptz NOT NULL,
 first_seen_at timestamptz NOT NULL DEFAULT now(),
 checked_at timestamptz NOT NULL,
 recorded_at timestamptz,
 PRIMARY KEY(app_scope,trade_id),
 FOREIGN KEY(account_id,app_scope) REFERENCES breet_sandbox_wallets(account_id,app_scope)
);
CREATE INDEX IF NOT EXISTS breet_sandbox_deposits_owner ON breet_sandbox_deposits(account_id,app_scope);
INSERT INTO tiplink_schema_version(version) VALUES(6) ON CONFLICT DO NOTHING;
