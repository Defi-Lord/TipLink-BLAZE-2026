ALTER TABLE accounts ALTER COLUMN email DROP NOT NULL;
ALTER TABLE accounts ALTER COLUMN password_hash DROP NOT NULL;
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS wallet_address text UNIQUE;
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS profile_completed boolean NOT NULL DEFAULT true;
DO $$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM pg_constraint WHERE conname='accounts_authentication_required') THEN
  ALTER TABLE accounts ADD CONSTRAINT accounts_authentication_required CHECK ((email IS NOT NULL AND password_hash IS NOT NULL) OR wallet_address IS NOT NULL);
 END IF;
 IF NOT EXISTS(SELECT 1 FROM pg_constraint WHERE conname='accounts_admin_email_only') THEN
  ALTER TABLE accounts ADD CONSTRAINT accounts_admin_email_only CHECK(role<>'admin' OR (email IS NOT NULL AND password_hash IS NOT NULL AND wallet_address IS NULL));
 END IF;
END $$;
CREATE TABLE IF NOT EXISTS wallet_login_challenges (
 id uuid PRIMARY KEY, address text NOT NULL, origin text NOT NULL, message text NOT NULL,
 binding_hash text NOT NULL, intent text NOT NULL CHECK(intent IN ('signin','link')),
 account_id uuid REFERENCES accounts(id), created_at timestamptz NOT NULL, expires_at timestamptz NOT NULL,
 attempts integer NOT NULL DEFAULT 0 CHECK(attempts BETWEEN 0 AND 5), used_at timestamptz,
 CHECK((intent='link' AND account_id IS NOT NULL) OR (intent='signin' AND account_id IS NULL))
);
CREATE INDEX IF NOT EXISTS wallet_challenges_expiry ON wallet_login_challenges(expires_at);
INSERT INTO tiplink_schema_version(version) VALUES(3) ON CONFLICT DO NOTHING;
