CREATE TABLE IF NOT EXISTS tiplink_schema_version (version integer PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS accounts (
 id uuid PRIMARY KEY, email text NOT NULL UNIQUE CHECK (email=lower(email)), display_name text NOT NULL,
 role text NOT NULL CHECK (role IN ('merchant','admin')), password_hash text NOT NULL,
 active boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash text PRIMARY KEY CHECK (length(token_hash)=64), account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
 csrf_token text NOT NULL CHECK (length(csrf_token)=64), expires_at timestamptz NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions(expires_at);
CREATE TABLE IF NOT EXISTS pricing_versions (
 version integer PRIMARY KEY CHECK (version>0), personal_bps integer NOT NULL CHECK (personal_bps BETWEEN 0 AND 300),
 merchant_bps integer NOT NULL CHECK (merchant_bps BETWEEN 0 AND 300), merchant_cap_sats bigint CHECK (merchant_cap_sats BETWEEN 1 AND 2100000000000000),
 collection_enabled boolean NOT NULL DEFAULT false CHECK (collection_enabled=false),
 changed_by uuid REFERENCES accounts(id), reason text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS pricing_head (id integer PRIMARY KEY CHECK(id=1), version integer NOT NULL REFERENCES pricing_versions(version));
CREATE TABLE IF NOT EXISTS audit_events (
 id uuid PRIMARY KEY, actor_id uuid REFERENCES accounts(id), action text NOT NULL,
 entity_id text NOT NULL, details jsonb NOT NULL DEFAULT '{}', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_created ON audit_events(created_at DESC);
CREATE TABLE IF NOT EXISTS bootstrap_lock (id integer PRIMARY KEY CHECK(id=1));
INSERT INTO bootstrap_lock(id) VALUES(1) ON CONFLICT DO NOTHING;
INSERT INTO pricing_versions(version,personal_bps,merchant_bps,reason) VALUES(1,0,100,'Initial pilot: personal free; merchant 1% proposal. Fee collection disabled.') ON CONFLICT DO NOTHING;
INSERT INTO pricing_head(id,version) VALUES(1,1) ON CONFLICT DO NOTHING;
INSERT INTO tiplink_schema_version(version) VALUES(1) ON CONFLICT DO NOTHING;
