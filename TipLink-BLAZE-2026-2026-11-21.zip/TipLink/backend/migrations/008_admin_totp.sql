ALTER TABLE accounts ADD COLUMN IF NOT EXISTS admin_totp_step bigint;
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS admin_totp_version text;

CREATE INDEX IF NOT EXISTS merchant_invoices_admin_created
 ON merchant_invoices(created_at DESC, id);

INSERT INTO tiplink_schema_version(version) VALUES(8) ON CONFLICT DO NOTHING;
