import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createBreetSandbox} from '../dist/breet-sandbox.js';
import {readConfig} from '../dist/config.js';
const config={breetAppId:'app-id',breetAppSecret:'private-example'};
const asset={identifier:'BCH_TEST',symbol:'BCH',network:'Bitcoin_Cash'};
const reply=data=>new Response(JSON.stringify({success:true,data}));
test('unconfigured Breet makes no request',async()=>{assert.equal((await createBreetSandbox({},()=>{throw Error();})()).state,'not_configured');});
test('sandbox-only GET, hidden credentials and coalesced cached reads',async()=>{
 let calls=0;
 const status=createBreetSandbox(config,async(url,options)=>{calls++;assert.equal(url,'https://api.breet.io/v1/trades/assets');assert.equal(options.method,'GET');assert.equal(options.redirect,'error');assert.equal(options.headers['X-Breet-Env'],'sandbox');assert.equal(options.headers['x-app-secret'],config.breetAppSecret);return reply([asset]);});
 const values=await Promise.all([status(),status(),status()]);await status();assert.equal(calls,1);assert.equal(values[0].state,'listed');assert.equal(values[0].activity,'unknown');assert.equal(values[0].payoutVerified,false);assert.ok(!JSON.stringify(values).includes(config.breetAppSecret));
});
test('explicit active, disabled and missing assets stay distinct',async()=>{
 for(const [data,state,activity]of [[[ {...asset,isActive:true}],'listed','active'],[[{...asset,isActive:false}],'disabled','inactive'],[[],'missing','unknown']]){
 const value=await createBreetSandbox(config,async()=>reply(data))();assert.equal(value.state,state);assert.equal(value.activity,activity);assert.equal(value.payoutVerified,false);
 }
});
test('invalid and unavailable responses never imply readiness',async()=>{
 for(const request of [async()=>reply([asset,asset]),async()=>reply([{...asset,network:'Bitcoin'}]),async()=>reply([{...asset,isActive:'true'}]),async()=>new Response('bad'),async()=>new Response('private-example',{status:403}),async()=>{throw Error('private-example');}]){
 const value=await createBreetSandbox(config,request)();assert.equal(value.state,'unavailable');assert.equal(value.activity,'unknown');assert.ok(!JSON.stringify(value).includes('private-example'));
 }
});
test('configuration refuses production, incomplete keys and header injection',()=>{
 for(const env of [{BREET_ENV:'production'},{BREET_APP_ID:'id'},{BREET_APP_ID:'id',BREET_APP_SECRET:'secret\nvalue'}])assert.throws(()=>readConfig(env));
 const value=readConfig({BREET_ENV:'sandbox',BREET_APP_ID:'id',BREET_APP_SECRET:'secret'});assert.equal(value.breetAppId,'id');
});
