import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {openDatabase} from '../dist/database.js';
import {migrate} from '../dist/migrate.js';
import {BreetLedger,depositSnapshot} from '../dist/breet-ledger.js';
import {BreetDeposits} from '../dist/breet-deposits.js';
let db;const scope=createHash('sha256').update('ledger-fixture').digest('hex');
const id=()=>randomUUID().replaceAll('-','').slice(0,24);
async function owner(){
 const a={id:randomUUID(),wallet:id(),address:'bchtest:fixture-'+id(),asset:id()};
 await db.query('INSERT INTO accounts(id,email,display_name,role,password_hash) VALUES($1,$2,$3,$4,$5)',[a.id,a.id+'@example.com','Ledger fixture','merchant','unusable-fixture']);
 await db.query('INSERT INTO breet_sandbox_wallets(account_id,app_scope,label,asset_id,state,wallet_id,address) VALUES($1,$2,$3,$4,$5,$6,$7)',[a.id,scope,id(),a.asset,'ready',a.wallet,a.address]);return a;
}
const trade=(patch={})=>({id:id(),cryptoReceived:'0.05',status:'completed',walletCredited:true,currency:'usd',amount:19.9,createdAt:'2026-11-10T00:00:00Z',...patch});
const snapshot=p=>depositSnapshot(trade(p));
const checked=()=>new Date().toISOString();
before(async()=>{db=await openDatabase({production:false,localPath:'memory://'});await migrate(db);});
after(async()=>{await db.close();});
test('concurrent refresh and service restart record one deposit and one audit event, migration preserves it',async()=>{
 const a=await owner(),t=snapshot(),l=new BreetLedger(db),now=checked();
 await Promise.all([l.observe(a.id,scope,a.wallet,[t],now),l.observe(a.id,scope,a.wallet,[t],now)]);
 await new BreetLedger(db).observe(a.id,scope,a.wallet,[t],now);await migrate(db);
 const value=await l.read(a.id,scope);assert.equal(value.recordedSats,'5000000');assert.equal(value.recordedCount,1);assert.equal(value.items[0].reportedAmount,'19.9');assert.equal(value.spendingEnabled,false);assert.equal(value.payoutVerified,false);
 assert.equal((await db.query('SELECT count(*)::int AS n FROM audit_events WHERE action=$1 AND entity_id=$2',['cashout.sandbox.deposit_recorded',t.id])).rows[0].n,1);
});
test('pending and flagged observations do not count as completed deposits; completion records exactly once',async()=>{
 const a=await owner(),l=new BreetLedger(db),t=snapshot({status:'pending',walletCredited:false}),now=checked();
 await l.observe(a.id,scope,a.wallet,[t],now);assert.equal((await l.read(a.id,scope)).recordedCount,0);
 await l.observe(a.id,scope,a.wallet,[{...t,status:'flagged'}],now);assert.equal((await l.read(a.id,scope)).recordedSats,'0');
 await l.observe(a.id,scope,a.wallet,[{...t,status:'completed',walletCredited:true}],now);assert.equal((await l.read(a.id,scope)).recordedCount,1);
});
test('owner isolation and globally unique provider trade prevent attribution to a second merchant',async()=>{
 const a=await owner(),b=await owner(),l=new BreetLedger(db),t=snapshot();await l.observe(a.id,scope,a.wallet,[t],checked());
 assert.equal((await l.read(b.id,scope)).recordedCount,0);
 await assert.rejects(l.observe(b.id,scope,b.wallet,[t],checked()));assert.equal((await l.read(b.id,scope)).recordedCount,0);
 await assert.rejects(l.observe(a.id,scope,b.wallet,[snapshot()],checked()),e=>e.status===403);
});
test('changed amounts or provider reversal hold records for review and retain original amount',async()=>{
 for(const patch of [{amountSats:'6000000'},{status:'deleted'},{reportedAmount:'30'},{walletCredited:false}]){
  const a=await owner(),l=new BreetLedger(db),t=snapshot(),now=checked();await l.observe(a.id,scope,a.wallet,[t],now);
  await l.observe(a.id,scope,a.wallet,[{...t,...patch}],now);const r=await l.read(a.id,scope);assert.equal(r.reviewCount,1);assert.equal(r.recordedSats,'5000000');assert.equal(r.items[0].amountSats,'5000000');
 }
});
test('a delayed older response cannot replace newer provider evidence',async()=>{
 const a=await owner(),l=new BreetLedger(db),t=snapshot(),now=checked();await l.observe(a.id,scope,a.wallet,[t],now);
 await l.observe(a.id,scope,a.wallet,[{...t,status:'pending'}],new Date(Date.parse(now)-1000).toISOString());
 const r=await l.read(a.id,scope);assert.equal(r.items[0].status,'completed');assert.equal(r.reviewCount,0);
});
test('audit failure rolls back the deposit insert and recorded marker atomically',async()=>{
 const a=await owner(),t=snapshot();const broken={transaction:work=>db.transaction(sql=>work({...sql,query:async(text,params)=>{if(text.startsWith('INSERT INTO audit_events'))throw Error('fixture audit failure');return sql.query(text,params);}}))};
 await assert.rejects(new BreetLedger(broken).observe(a.id,scope,a.wallet,[t],checked()));assert.equal((await new BreetLedger(db).read(a.id,scope)).recordedCount,0);
});
test('provider outage does not erase saved records or substitute zero',async()=>{
 const a=await owner(),t=snapshot();await new BreetLedger(db).observe(a.id,scope,a.wallet,[t],checked());
 const s=new BreetDeposits(db,{breetAppId:'ledger-fixture',breetAppSecret:'fixture-private'},async()=>{throw Error('secret fixture');});
 assert.equal((await s.transactions(a)).state,'unavailable');const saved=await s.ledger(a);assert.equal(saved.recordedCount,1);assert.equal(saved.recordedSats,'5000000');assert.equal(saved.spendingEnabled,false);
});
test('fractional satoshis, excessive BCH and future times reject; raw provider private fields never enter snapshots',()=>{
 for(const change of [{cryptoReceived:'0.000000001'},{cryptoReceived:'-1'},{cryptoReceived:'0'},{cryptoReceived:'21000001'},{createdAt:'2099-01-01T00:00:00Z'}])assert.throws(()=>snapshot(change));
 const result=snapshot({secret:'private fixture',accountNumber:'1234567890',currency:'secret',amount:'private fixture'});assert.equal(result.reportedCurrency,null);assert.equal(result.reportedAmount,null);assert.ok(!JSON.stringify(result).includes('private fixture'));
});
