import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {once} from 'node:events';
import {encodeCashAddress} from '@bitauth/libauth';
import {BreetDeposits} from '../dist/breet-deposits.js';
import {openDatabase} from '../dist/database.js';
import {migrate} from '../dist/migrate.js';
import {Store} from '../dist/store.js';
import {createApp} from '../dist/app.js';
let db;
const config={breetAppId:'fixture-app',breetAppSecret:'fixture-private-secret'};
const assetId='67063f653b4a1f6c7a60ec51';
const walletId='6af0e35c43d1620a7d79cfed';
const address=encodeCashAddress({prefix:'bchtest',type:'p2pkh',payload:new Uint8Array(20).fill(7)}).address;
const asset={id:assetId,identifier:'BCH_TEST',network:'Bitcoin_Cash'};
const response=(data,meta={hasNextPage:false})=>new Response(JSON.stringify({success:true,data,meta}));
async function owner(role='merchant'){
 const a={id:randomUUID(),role};
 await db.query('INSERT INTO accounts(id,email,display_name,role,password_hash) VALUES($1,$2,$3,$4,$5)',[a.id,a.id+'@example.com','Fixture',role,'unusable-test-fixture-hash']);return a;
}
function provider({wallet={id:walletId,address},transactions=[],assetValue=asset,failPost=false,meta={hasNextPage:false}}={}){
 const calls=[];
 return {calls,fetch:async(url,options)=>{
  calls.push({url,options});assert.equal(options.redirect,'error');assert.equal(options.headers['X-Breet-Env'],'sandbox');
  if(url.endsWith('/trades/assets'))return response([assetValue]);
  if(options.method==='POST'){assert.ok(url.endsWith('/'+assetId+'/generate-address'));const body=JSON.parse(options.body);assert.equal(body.autoSettlement,false);assert.deepEqual(Object.keys(body).sort(),['autoSettlement','label']);if(failPost)throw Error(config.breetAppSecret);return response(wallet);}
  assert.ok(url.includes('/trades/transactions?'));const parsed=new URL(url);assert.equal(parsed.searchParams.get('address'),address);assert.equal(parsed.searchParams.get('assetId'),assetId);return response(transactions,meta);
 }};
}
before(async()=>{db=await openDatabase({production:false,localPath:'memory://'});await migrate(db);});
after(async()=>{await db.close();});
test('one durable address per owner: concurrent requests, refresh and service restart never create duplicates',async()=>{
 const a=await owner(),p=provider(),service=new BreetDeposits(db,config,p.fetch);
 assert.equal((await service.wallet(a)).state,'not_created');
 await Promise.all([service.create(a),service.create(a)]);
 const saved=await service.wallet(a);assert.equal(saved.state,'ready');assert.equal(saved.address,address);assert.equal(saved.payoutVerified,false);
 assert.equal((await new BreetDeposits(db,config,p.fetch).create(a)).address,address);
 assert.equal(p.calls.filter(c=>c.options.method==='POST').length,1);
 assert.ok(!JSON.stringify(saved).includes(config.breetAppSecret));
 await migrate(db);assert.equal((await service.wallet(a)).address,address);
});
test('lost create response stays uncertain across restarts and explicit retries do not resubmit',async()=>{
 const a=await owner(),p=provider({failPost:true}),s=new BreetDeposits(db,config,p.fetch);
 const value=await s.create(a);assert.equal(value.state,'uncertain');assert.equal(value.address,null);assert.match(value.label,/tiplink-sandbox-/);
 await new BreetDeposits(db,config,p.fetch).create(a);assert.equal(p.calls.filter(c=>c.options.method==='POST').length,1);
 await assert.rejects(s.transactions(a),e=>e.status===409);
});
test('mainnet or malformed provider address is withheld and cannot be retried as a new creation',async()=>{
 for(const bad of ['bitcoincash:'+address.split(':')[1],address.slice(0,-1)+'z']){
  const a=await owner(),p=provider({wallet:{id:walletId,address:bad}}),s=new BreetDeposits(db,config,p.fetch);
  assert.equal((await s.create(a)).state,'uncertain');assert.equal((await s.wallet(a)).address,null);
 }
});
test('database intent failure blocks provider POST entirely',async()=>{
 const a=await owner(),p=provider();const broken={query:db.query.bind(db),transaction:async()=>{throw Error('storage failure');}};
 await assert.rejects(new BreetDeposits(broken,config,p.fetch).create(a));assert.equal(p.calls.filter(c=>c.options.method==='POST').length,0);
});
test('disabled/wrong-network assets fail before address creation; missing keys never make provider requests',async()=>{
 for(const change of [{isActive:false},{network:'Bitcoin'},{isActive:'true'}]){
  const p=provider({assetValue:{...asset,...change}});await assert.rejects(new BreetDeposits(db,config,p.fetch).create(await owner()),e=>e.status===503);assert.equal(p.calls.length,1);
 }
 let calls=0;await assert.rejects(new BreetDeposits(db,{},async()=>{calls++;throw Error();}).create(await owner()));assert.equal(calls,0);
});
test('another merchant sees no address, admins and disabled merchants cannot use sandbox',async()=>{
 const p=provider(),s=new BreetDeposits(db,{...config,breetAppId:randomUUID()},p.fetch),a=await owner(),b=await owner();
 assert.equal((await s.create(a)).state,'ready');assert.equal((await s.wallet(b)).state,'not_created');await assert.rejects(s.transactions(b),e=>e.status===409);
 await assert.rejects(s.create(await owner('admin')),e=>e.status===403);
 await db.query('UPDATE accounts SET active=false WHERE id=$1',[a.id]);await assert.rejects(s.wallet(a),e=>e.status===403);
});
test('transaction snapshots are owner-bound, coalesced, bounded and never mean bank payout',async()=>{
 const a=await owner(),t={id:'692f91aa729255932afe9078',wallet:walletId,address,asset:assetId,cryptoReceived:'0.05',status:'completed',createdAt:'2026-11-08T22:00:00Z',accountNumber:'private-bank-field'};
 const p=provider({transactions:[t],meta:{hasNextPage:true}}),s=new BreetDeposits(db,{...config,breetAppId:'transactions-fixture'},p.fetch);
 await s.create(a);const values=await Promise.all([s.transactions(a),s.transactions(a)]);
 assert.equal(values[0].state,'checked');assert.equal(values[0].items[0].amountBch,'0.05');assert.equal(values[0].payoutVerified,false);assert.equal(values[0].hasMore,true);assert.ok(!JSON.stringify(values).includes('private-bank-field'));assert.equal(p.calls.filter(c=>c.url.includes('transactions?')).length,1);
});
test('wrong owner, wrong asset, duplicates and incomplete pagination never become empty successful history',async()=>{
 for(const change of [{wallet:'692f91aa729255932afe9078'},{asset:'692f91aa729255932afe9078'},{address:'different'},{cryptoReceived:'NaN'}]){
  const a=await owner(),t={id:'692f91aa729255932afe9078',wallet:walletId,address,asset:assetId,cryptoReceived:'0.05',status:'completed',createdAt:'2026-11-08T22:00:00Z',...change};
  const p=provider({transactions:[t]}),s=new BreetDeposits(db,{...config,breetAppId:randomUUID()},p.fetch);await s.create(a);assert.equal((await s.transactions(a)).state,'unavailable');
 }
 const a=await owner(),p=provider({meta:{}}),s=new BreetDeposits(db,{...config,breetAppId:randomUUID()},p.fetch);await s.create(a);assert.equal((await s.transactions(a)).state,'unavailable');
 const t={id:'692f91aa729255932afe9078',wallet:walletId,address,asset:assetId,cryptoReceived:'0.05',status:'completed',createdAt:'2026-11-08T22:00:00Z'};
 const duplicate=provider({transactions:[t,t]}),dupService=new BreetDeposits(db,{...config,breetAppId:randomUUID()},duplicate.fetch),dupOwner=await owner();await dupService.create(dupOwner);assert.equal((await dupService.transactions(dupOwner)).state,'unavailable');
});
test('HTTP wallet creation requires merchant authentication, allowed origin, CSRF and exact acknowledgement',async()=>{
 const store=new Store(db),origin='http://127.0.0.1:4100',customerOrigin='http://127.0.0.1:5173';
 const a=await store.register({email:randomUUID()+'@example.com',displayName:'Test merchant',password:'fixture-password-12345'});
 const login=await store.login(a.email,'fixture-password-12345','merchant');
 const server=createApp(store,{production:false,origin,customerOrigin}).listen(0,'127.0.0.1');await once(server,'listening');
 try{
  const url='http://127.0.0.1:'+server.address().port+'/api/v1/merchant/cash-out/wallet';
  const cookie='tiplink_merchant_session='+login.token;
  for(const headers of [{},{Cookie:cookie},{Cookie:cookie,'X-CSRF-Token':login.csrfToken,Origin:'https://evil.example'}]){
   const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json',Origin:customerOrigin,...headers},body:JSON.stringify({acknowledgeSandbox:true})});assert.ok([401,403].includes(r.status));
  }
  const headers={'Content-Type':'application/json',Origin:customerOrigin,Cookie:cookie,'X-CSRF-Token':login.csrfToken};
  for(const body of [{acknowledgeSandbox:false},{acknowledgeSandbox:true,asset:'BCH'}]){const r=await fetch(url,{method:'POST',headers,body:JSON.stringify(body)});assert.equal(r.status,400);}
  const r=await fetch(url,{headers:{Cookie:cookie}});assert.equal(r.status,200);assert.equal(r.headers.get('Cache-Control'),'no-store');assert.equal((await r.json()).state,'not_created');
 }finally{await new Promise(resolve=>server.close(resolve));}
});
