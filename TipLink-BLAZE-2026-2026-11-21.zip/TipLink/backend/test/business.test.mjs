import {createHmac} from 'node:crypto';
import {test,before,after} from 'node:test';import assert from 'node:assert/strict';import {once} from 'node:events';import {randomUUID} from 'node:crypto';
import {encodeCashAddress} from '@bitauth/libauth';import {openDatabase} from '../dist/database.js';import {migrate} from '../dist/migrate.js';import {Store} from '../dist/store.js';import {InvoiceStore,validateInvoiceInput} from '../dist/invoices.js';import {createApp} from '../dist/app.js';
let db,store,invoices,server,base,a,b,admin,la,lb,ladmin;
const customerOrigin='http://127.0.0.1:5173',origin='http://127.0.0.1:4100',password='public fixture password 1234';
const address=encodeCashAddress({prefix:'bitcoincash',type:'p2pkh',payload:new Uint8Array(20).fill(83)}).address;
const body=patch=>({requestKey:randomUUID(),amountBch:'0.001',address:encodeCashAddress({prefix:'bitcoincash',type:'p2pkh',payload:new TextEncoder().encode(randomUUID().slice(0,20))}).address,memo:'Design work',hours:24,...patch});
async function request(path,{method='GET',data,cookie,csrf,from=customerOrigin}={}){const headers={};if(data!==undefined)headers['Content-Type']='application/json';if(method!=='GET')headers.Origin=from;if(cookie)headers.Cookie=cookie;if(csrf)headers['X-CSRF-Token']=csrf;const r=await fetch(base+'/api/v1'+path,{method,headers,body:data===undefined?undefined:JSON.stringify(data)});return{status:r.status,headers:r.headers,data:await r.json()};}
async function login(email,admin=false){const r=await request(admin?'/auth/login':'/merchant/auth/login',{method:'POST',from:admin?origin:customerOrigin,data:{email,password}});assert.equal(r.status,200);return{cookie:r.headers.get('set-cookie').split(';')[0],csrf:r.data.csrfToken};}
before(async()=>{db=await openDatabase({production:false,localPath:'memory://'});await migrate(db);store=new Store(db);invoices=new InvoiceStore(db,async()=>899999);admin=await store.register({email:'admin@example.com',displayName:'Administrator',password},'admin');a=await store.register({email:'a@example.com',displayName:'Merchant A',password});b=await store.register({email:'b@example.com',displayName:'Merchant B',password});server=createApp(store,{production:false,origin,customerOrigin},undefined,undefined,invoices).listen(0,'127.0.0.1');await once(server,'listening');base='http://127.0.0.1:'+server.address().port;la=await login(a.email);lb=await login(b.email);ladmin=await login(admin.email,true);});
after(async()=>{await new Promise(resolve=>server.close(resolve));await db.close();});
test('merchant registration from customer origin cannot choose admin role',async()=>{const r=await request('/merchant/auth/register',{method:'POST',data:{email:'new@example.com',displayName:'New business',password}});assert.equal(r.status,201);assert.equal(r.data.account.role,'merchant');const bad=await request('/merchant/auth/register',{method:'POST',data:{email:'bad@example.com',displayName:'Bad actor',password,role:'admin'}});assert.equal(bad.status,400);});
test('separate path-scoped merchant cookie keeps admin and business sessions independent',async()=>{const r=await request('/merchant/auth/login',{method:'POST',data:{email:a.email,password}});assert.match(r.headers.get('set-cookie'),/tiplink_merchant_session=/);assert.match(r.headers.get('set-cookie'),/Path=\/api\/v1\/merchant/);assert.equal((await request('/merchant/auth/session',{cookie:ladmin.cookie})).status,401);const renamed=ladmin.cookie.replace('tiplink_session=','tiplink_merchant_session=');assert.equal((await request('/merchant/auth/session',{cookie:renamed})).status,403);assert.equal((await request('/merchant/auth/login',{method:'POST',data:{email:admin.email,password}})).status,403);assert.equal((await request('/admin/overview',{cookie:ladmin.cookie})).status,200);});
test('customer origin cannot mutate administrator settings',async()=>{const r=await request('/admin/pricing',{method:'PUT',cookie:ladmin.cookie,csrf:ladmin.csrf,data:{expectedVersion:1,personalBps:0,merchantBps:100,merchantCapSats:null,reason:'Must not be accepted'}});assert.equal(r.status,403);});
test('invoices require merchant auth, correct origin and CSRF',async()=>{for(const options of [{},{cookie:la.cookie},{cookie:la.cookie,csrf:la.csrf,from:'https://evil.example'}]){const r=await request('/merchant/invoices',{method:'POST',data:body(),...options});assert.ok([401,403].includes(r.status));}});
test('create persists a fixed amount, public details and invoice.created audit atomically',async()=>{const r=await request('/merchant/invoices',{method:'POST',cookie:la.cookie,csrf:la.csrf,data:body()});assert.equal(r.status,201);assert.equal(r.data.invoice.amountSats,'100000');assert.equal(r.data.invoice.paymentStatus,'not_checked');assert.equal(r.data.invoice.merchantName,'Merchant A');const events=await store.events();assert.ok(events.some(e=>e.action==='invoice.created'&&e.entityId===r.data.invoice.id));});
test('same request key replays the saved result and changed payload conflicts',async()=>{const input=body();const first=await invoices.create(a,input);const replay=await invoices.create(a,{...input,amountBch:'0.00100000',address:input.address.toUpperCase()});assert.equal(replay.replayed,true);assert.equal(first.invoice.id,replay.invoice.id);await assert.rejects(invoices.create(a,{...input,memo:'Different details'}),e=>e.status===409);});
test('concurrent save retries create exactly one invoice and one audit event',async()=>{const input=body();const results=await Promise.all([invoices.create(a,input),invoices.create(a,input)]);assert.equal(results[0].invoice.id,results[1].invoice.id);const events=await store.events();assert.equal(events.filter(e=>e.entityId===results[0].invoice.id&&e.action==='invoice.created').length,1);});
test('owner isolation applies to list and cancellation, even when id is known',async()=>{const r=await invoices.create(a,body());assert.ok(!(await invoices.list(b)).some(i=>i.id===r.invoice.id));const response=await request('/merchant/invoices/'+r.invoice.id+'/cancel',{method:'POST',cookie:lb.cookie,csrf:lb.csrf,data:{expectedVersion:1}});assert.equal(response.status,404);assert.equal((await invoices.publicInvoice(r.invoice.id)).state,'open');});
test('public checkout reveals no account email, merchant id, request key or credential',async()=>{const created=await invoices.create(a,body());const r=await request('/public/invoices/'+created.invoice.id);assert.equal(r.status,200);assert.equal(r.data.address,created.invoice.address);for(const field of ['email','merchant_id','merchantId','requestKey','fingerprint','password','claimPrivateKey'])assert.ok(!(field in r.data));assert.equal(r.headers.get('cache-control'),'no-store');});
test('cancel closes saved checkout and repeat cancellation has no duplicate audit',async()=>{const r=await invoices.create(a,body());const first=await invoices.cancel(a,r.invoice.id,{expectedVersion:1});assert.equal(first.state,'cancelled');assert.equal(first.version,2);assert.equal((await invoices.cancel(a,r.invoice.id,{expectedVersion:1})).version,2);assert.equal((await invoices.publicInvoice(r.invoice.id)).state,'cancelled');assert.equal((await store.events()).filter(e=>e.entityId===r.invoice.id&&e.action==='invoice.cancelled').length,1);});
test('expired request is distinct from paid and cancellation checks version',async()=>{const r=await invoices.create(a,body({hours:1}),Date.now()-7200000);assert.equal((await invoices.publicInvoice(r.invoice.id)).state,'expired');assert.equal((await invoices.publicInvoice(r.invoice.id)).paymentStatus,'not_checked');await assert.rejects(invoices.cancel(a,r.invoice.id,{expectedVersion:1}),e=>e.status===409);const active=await invoices.create(a,body());await assert.rejects(invoices.cancel(a,active.invoice.id,{expectedVersion:2}),e=>e.status===409);});
test('server validation rejects wrong network, dust, exponents, extra fields and fake paid status',()=>{const testnet=encodeCashAddress({prefix:'bchtest',type:'p2pkh',payload:new Uint8Array(20).fill(83)}).address;for(const patch of [{address:testnet},{amountBch:'0.00000001'},{amountBch:'1e3'},{amountBch:'21000001'},{amountBch:1},{hours:0},{hours:721},{memo:'a'.repeat(161)},{state:'paid'},{claimPrivateKey:'secret'},{requestKey:'bad'}])assert.throws(()=>validateInvoiceInput(body(patch)));});
test('invoice insert rolls back if audit logging fails',async()=>{const input=body();const broken={...db,transaction:work=>db.transaction(sql=>work({...sql,query:(text,params)=>{if(text.startsWith('INSERT INTO audit_events'))throw Error('audit failed');return sql.query(text,params);}}))};await assert.rejects(new InvoiceStore(broken,async()=>899999).create(a,input),/audit failed/);const result=await db.query('SELECT id FROM merchant_invoices WHERE request_key=$1',[input.requestKey]);assert.equal(result.rows.length,0);});
test('admin sees saved invoice metadata and actual counts, never a fabricated paid status',async()=>{const r=await request('/admin/invoices',{cookie:ladmin.cookie});assert.equal(r.status,200);assert.ok(r.data.items.length>0);assert.ok(r.data.items.every(i=>i.paymentStatus==='not_checked'));const overview=await request('/admin/overview',{cookie:ladmin.cookie});assert.ok(overview.data.invoices.total>0);assert.equal(overview.data.transactionVolumeSats,null);assert.equal((await request('/admin/invoices',{cookie:la.cookie})).status,401);});
test('calculator uses backend policy through the merchant session and does not collect fees',async()=>{const r=await request('/merchant/quotes',{method:'POST',cookie:la.cookie,csrf:la.csrf,data:{kind:'merchant',recipientSats:'100000',fundingFeeSats:'300',claimFeeSats:'200'}});assert.equal(r.status,200);assert.equal(r.data.proposedPlatformFeeSats,'1000');assert.equal(r.data.pilotTotalEstimateSats,'100500');assert.equal(r.data.platformFeeCollectedSats,'0');});
test('business logout revokes only that session; the admin session still works',async()=>{assert.equal((await request('/merchant/auth/logout',{method:'POST',cookie:la.cookie,csrf:la.csrf,data:{}})).status,200);assert.equal((await request('/merchant/auth/session',{cookie:la.cookie})).status,401);assert.equal((await request('/auth/session',{cookie:ladmin.cookie})).status,200);});

test('upgrade from foundation schema preserves accounts, sessions and edited pricing',async()=>{const {readFile}=await import('node:fs/promises');const upgrade=await openDatabase({production:false,localPath:'memory://'});try{await upgrade.exec(await readFile(new URL('../migrations/001_foundation.sql',import.meta.url),'utf8'));const before=new Store(upgrade);const actor=await before.register({email:'upgrade@example.com',displayName:'Upgrade admin',password},'admin');const login=await before.login(actor.email,password);await before.updatePolicy(actor,{expectedVersion:1,personalBps:0,merchantBps:75,merchantCapSats:null,reason:'Preserve edited proposal'});await migrate(upgrade);assert.equal((await before.policy()).merchantBps,75);assert.equal((await before.policy()).version,2);assert.equal((await before.session(login.token)).account.id,actor.id);assert.deepEqual(await new InvoiceStore(upgrade).adminList(),[]);}finally{await upgrade.close();}});

test('one fresh receiving address can be reserved by only one request across merchants',async()=>{
 const input=body();
 const outcomes=await Promise.allSettled([invoices.create(a,input),invoices.create(b,body({address:input.address}))]);
 assert.equal(outcomes.filter(result=>result.status==='fulfilled').length,1);
 assert.equal(outcomes.find(result=>result.status==='rejected').reason.status,409);
 const rows=await db.query('SELECT payment_start_height FROM merchant_invoices WHERE address=$1',[input.address]);
 assert.equal(rows.rows.length,1);
 assert.equal(rows.rows[0].payment_start_height,899999);
});

test('admin searches beyond the first page and can inspect a receipt without exposing it publicly', async()=>{
 const target=(await invoices.create(a,body(),Date.now()-120_000)).invoice;
 const stale=(await invoices.create(a,body(),Date.now()-90_000)).invoice;
 const missing=(await invoices.create(b,body())).invoice;
 const txid='ab'.repeat(32);
 for(const [invoice,hash,status,height,age] of [
  [target,txid,'confirmed',900000,0],
  [stale,'cd'.repeat(32),'confirmed',900000,90_000],
  [missing,'ef'.repeat(32),'not_found',0,0]
 ]){
  await db.query('INSERT INTO invoice_receipts(invoice_id,txid,output_index,status,height,checked_at) VALUES($1,$2,0,$3,$4,$5)',[invoice.id,hash,status,height,new Date(Date.now()-age)]);
 }
 for(let i=0;i<21;i++)await invoices.create(a,body());
 const path='/admin/invoices?filter=all&page=1';
 const options={cookie:ladmin.cookie};
 assert.equal((await request(path)).status,401);
 const merchant=await request('/auth/login',{method:'POST',from:origin,data:{email:a.email,password}});
 assert.equal((await request(path,{cookie:merchant.headers.get('set-cookie').split(';')[0]})).status,403);
 const page1=await request(path,options);
 assert.equal(page1.data.items.length,20);
 assert.equal(page1.data.hasNext,true);
 assert.ok(!page1.data.items.some(item=>item.id===target.id));
 const page2=await request('/admin/invoices?page=2',options);
 assert.ok(page2.data.items.some(item=>item.id===target.id));
 assert.ok(page2.data.items.every(item=>!page1.data.items.some(previous=>previous.id===item.id)));
 for(const search of [target.id,txid.toUpperCase()]){
  const result=await request('/admin/invoices?search='+search,options);
  assert.equal(result.status,200);
  assert.equal(result.data.items.length,1);
  assert.equal(result.data.items[0].id,target.id);
  assert.equal(result.data.items[0].receipt.txid,txid);
  assert.equal(result.data.items[0].receipt.status,'confirmed');
 }
 const byMerchant=await request('/admin/invoices?search=merchant+b',options);
 assert.ok(byMerchant.data.items.length>0);
 assert.ok(byMerchant.data.items.every(item=>item.merchantName==='Merchant B'));
 const attention=await request('/admin/invoices?filter=attention',options);
 assert.deepEqual(attention.data.items.map(item=>item.id).sort(),[stale.id,missing.id].sort());
 assert.equal((await request('/admin/invoices?search=%25',options)).data.items.length,0);
 for(const query of ['page=0','page=1&page=2','filter=unknown']){
  assert.equal((await request('/admin/invoices?'+query,options)).status,400);
 }
 const publicResponse=await request('/public/invoices/'+target.id);
 assert.equal(publicResponse.data.receipt,undefined);
});

test('admin authenticator blocks old sessions and allows one concurrent use of each code', async()=>{
 const secret=Buffer.from('12345678901234567890','ascii');
 const secureServer=createApp(store,{production:false,origin,customerOrigin,adminTotpSecret:secret},undefined,undefined,invoices).listen(0,'127.0.0.1');
 await once(secureServer,'listening');
 const endpoint='http://127.0.0.1:'+secureServer.address().port+'/api/v1';
 const login=details=>fetch(endpoint+'/auth/login',{
  method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},
  body:JSON.stringify({email:admin.email,password,...details})
 });
 try{
  assert.equal((await fetch(endpoint+'/auth/options').then(r=>r.json())).adminAuthenticatorRequired,true);
  assert.equal((await fetch(endpoint+'/admin/overview',{headers:{Cookie:ladmin.cookie}})).status,401);
  assert.equal((await login({})).status,401);
  assert.equal((await login({code:'bad'})).status,401);
  const counter=Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(Math.floor(Date.now()/30_000)));
  const digest=createHmac('sha1',secret).update(counter).digest();
  const code=String((digest.readUInt32BE(digest[19]&15)&0x7fffffff)%1_000_000).padStart(6,'0');
  const results=await Promise.all([login({code}),login({code})]);
  assert.deepEqual(results.map(result=>result.status).sort(),[200,401]);
  const cookie=results.find(result=>result.ok).headers.get('set-cookie').split(';')[0];
  const restored=await fetch(endpoint+'/auth/session',{headers:{Cookie:cookie}});
  assert.equal(restored.status,200);
  assert.equal((await restored.json()).account.role,'admin');
  assert.equal((await fetch(endpoint+'/admin/overview',{headers:{Cookie:cookie}})).status,200);
  assert.equal((await fetch(endpoint+'/merchant/auth/session',{headers:{Cookie:lb.cookie}})).status,200);
  assert.equal((await request('/admin/overview',{cookie:ladmin.cookie})).status,401);
  assert.equal((await request('/auth/login',{method:'POST',from:origin,data:{email:admin.email,password}})).status,503);
 }finally{
  await new Promise(resolve=>secureServer.close(resolve));
 }
});
