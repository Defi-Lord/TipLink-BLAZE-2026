import {test} from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {BreetBanks} from '../dist/breet-banks.js';
import {openDatabase} from '../dist/database.js';
import {migrate} from '../dist/migrate.js';
import {Store} from '../dist/store.js';
import {createApp} from '../dist/app.js';
const config={breetAppId:'bank-fixture',breetAppSecret:'private-fixture-secret'};
const list=[{id:'25',name:'OPay - Paycom',country:'Nigeria',currency:'NGN',type:'nuban',avatar:'private-avatar'}];
const input={bankId:'25',accountNumber:'1234567890'};
const valid={accountNumber:input.accountNumber,accountName:'FIXTURE PERSON',bankName:'OPay - Paycom',type:'nuban',privateField:'never-return'};
const reply=(data,meta)=>new Response(JSON.stringify({success:true,data,meta}));
function provider(data=valid){const calls=[];return {calls,fetch:async(url,options)=>{calls.push({url,options});if(url.endsWith('/payments/banks'))return new Response(JSON.stringify({success:false,message:'currency required'}),{status:422});return reply(url.endsWith('/payments/banks?currency=ngn')?list:data);}};}
test('bank verification uses fixed sandbox endpoints, exact provider payload and a redacted result',async()=>{
 const p=provider(),s=new BreetBanks(config,p.fetch);
 const [a,b]=await Promise.all([s.banks(),s.banks()]);assert.deepEqual(a,[{id:'25',name:'OPay - Paycom'}]);assert.deepEqual(a,b);assert.equal(p.calls.length,1);assert.equal(p.calls[0].url,'https://api.breet.io/v1/payments/banks?currency=ngn');assert.equal(p.calls[0].options.method,'GET');
 const result=await s.verify('owner',input);assert.equal(result.state,'resolved');assert.equal(result.accountName,'FIXTURE PERSON');assert.equal(result.accountLast4,'7890');assert.equal(result.payoutEnabled,false);assert.equal(result.payoutVerified,false);
 for(const call of p.calls){assert.equal(call.options.headers['X-Breet-Env'],'sandbox');assert.equal(call.options.redirect,'error');assert.ok(call.options.signal);}
 assert.equal(p.calls[1].url,'https://api.breet.io/v1/payments/banks/validate');assert.deepEqual(JSON.parse(p.calls[1].options.body),{id:'25',accountNumber:input.accountNumber,currency:'ngn'});
 for(const secret of [input.accountNumber,'never-return',config.breetAppSecret])assert.ok(!JSON.stringify(result).includes(secret));
 assert.deepEqual(await s.verify('owner',input),result);assert.equal(p.calls.length,2);
});
test('masked/substituted account, wrong bank/type and missing names never reveal a name',async()=>{
 for(const [change,state]of [[{accountNumber:'123456XXXX'},'details_mismatch'],[{accountNumber:'0987654321'},'details_mismatch'],[{bankName:'Different Bank'},'details_mismatch'],[{type:'mobile_money'},'details_mismatch'],[{id:'39'},'details_mismatch'],[{accountName:null},'details_mismatch'],[{accountName:'bad\r\nname'},'details_mismatch']]){
  const p=provider({...valid,...change});const value=await new BreetBanks(config,p.fetch).verify('owner',input);assert.equal(value.state,state);assert.equal(value.accountName,null);assert.equal(value.payoutVerified,false);
 }
});
test('invalid details and unknown bank cannot initiate validation; non-NGN and duplicate bank rows are handled',async()=>{
 const p=provider(),s=new BreetBanks(config,p.fetch);
 for(const change of [{bankId:'../withdrawals'},{accountNumber:'1234'},{accountNumber:1234567890},{accountNumber:'12345678901'},{bankId:25}])await assert.rejects(s.verify('owner',{...input,...change}),e=>e.status===400);
 assert.equal(p.calls.length,0);await assert.rejects(s.verify('owner',{...input,bankId:'999'}),e=>e.status===400);assert.equal(p.calls.length,1);
 const filtered=new BreetBanks(config,async()=>reply([...list,{id:'9',name:'Foreign bank',currency:'GHS',country:'Ghana',type:'mobile_money'}]));assert.equal((await filtered.banks()).length,1);
 await assert.rejects(new BreetBanks(config,async()=>reply([...list,...list])).banks(),e=>e.status===502);
});
test('provider errors, oversized bodies and absent configuration reveal no secrets and never submit withdrawals',async()=>{
 for(const stub of [async()=>{throw Error(config.breetAppSecret);},async()=>new Response(config.breetAppSecret,{status:500}),async()=>new Response('x'.repeat(1048577)),async()=>reply(null)])await assert.rejects(new BreetBanks(config,stub).banks(),e=>[502,503].includes(e.status)&&!e.message.includes(config.breetAppSecret));
 let calls=0;await assert.rejects(new BreetBanks({},async()=>{calls++;throw Error();}).banks(),e=>e.status===503);assert.equal(calls,0);
});
test('different account numbers resolve immediately, same lookup coalesces per owner and new lookups are bounded',async()=>{
 const calls=[];const s=new BreetBanks(config,async(url,options)=>{calls.push(url);if(url.endsWith('?currency=ngn'))return reply(list);const body=JSON.parse(options.body);return reply({...valid,accountNumber:body.accountNumber});});
 const first=await Promise.all([s.verify('a',input),s.verify('a',input)]);assert.equal(first[0].state,'resolved');assert.equal(calls.length,2);
 for(let i=1;i<10;i++)assert.equal((await s.verify('a',{...input,accountNumber:String(1234567890+i)})).state,'resolved');
 await assert.rejects(s.verify('a',{...input,accountNumber:'9999999999'}),e=>e.status===429);
 assert.equal((await s.verify('b',input)).state,'resolved');assert.equal(calls.length,12);
});
const withdrawal={id:'692f91aa729255932afe9078',status:'pending',currency:'ngn',amount:27600,createdAt:new Date().toISOString(),meta:{accountNumber:'private-account',accountName:'private-name'}};
test('withdrawal lookup is GET-only, coalesced, paginated and excludes beneficiary information',async()=>{
 const calls=[];const s=new BreetBanks(config,async(url,options)=>{calls.push(url);assert.equal(options.method,'GET');assert.equal(options.headers['X-Breet-Env'],'sandbox');return reply(url.includes('page=1')?[withdrawal]:[],{hasNextPage:url.includes('page=1'),page:url.includes('page=1')?1:2});});
 const values=await Promise.all([s.withdrawals(),s.withdrawals()]);assert.equal(calls.length,2);assert.deepEqual(calls,['https://api.breet.io/v1/payments/withdrawals?page=1&size=25','https://api.breet.io/v1/payments/withdrawals?page=2&size=25']);assert.equal(values[0].complete,true);assert.equal(values[0].items.length,1);assert.equal(values[0].payoutVerified,false);assert.ok(!JSON.stringify(values).includes('private-'));
});
test('missing pagination, duplicate records and malformed amounts cannot become an empty successful history',async()=>{
 for(const [data,meta]of [[[],{}],[[withdrawal,withdrawal],{hasNextPage:false}],[[{...withdrawal,amount:'1e5'}],{hasNextPage:false}],[[{...withdrawal,amount:null}],{hasNextPage:false}],[[],{hasNextPage:true}]])await assert.rejects(new BreetBanks(config,async()=>reply(data,meta)).withdrawals(),e=>e.status===502);
 const empty=await new BreetBanks(config,async()=>reply([],{hasNextPage:false})).withdrawals();assert.equal(empty.complete,true);assert.deepEqual(empty.items,[]);assert.equal(empty.payoutVerified,false);
 let page=0;const capped=await new BreetBanks(config,async()=>reply([{...withdrawal,id:(++page).toString(16).padStart(24,'0')}],{hasNextPage:true,page})).withdrawals();assert.equal(capped.complete,false);assert.equal(capped.items.length,5);
});
test('HTTP bank checks require merchant session, CSRF and origin; account-wide withdrawal lookup requires administrator',async()=>{
 const db=await openDatabase({production:false,localPath:'memory://'});await migrate(db);const store=new Store(db),password='bank fixture password 12345';
 const merchant=await store.register({email:'bank-merchant@example.com',displayName:'Bank merchant',password});const admin=await store.register({email:'bank-admin@example.com',displayName:'Bank admin',password},'admin');
 const login=await store.login(merchant.email,password,'merchant'),administrator=await store.login(admin.email,password);
 const server=createApp(store,{production:false,origin:'http://127.0.0.1:4100',customerOrigin:'http://127.0.0.1:5173'}).listen(0,'127.0.0.1');await once(server,'listening');const base='http://127.0.0.1:'+server.address().port+'/api/v1';
 try{
  for(const headers of [{},{Cookie:'tiplink_merchant_session='+login.token},{Cookie:'tiplink_merchant_session='+login.token,'X-CSRF-Token':login.csrfToken,Origin:'https://foreign.example'}]){const r=await fetch(base+'/merchant/cash-out/banks/verify',{method:'POST',headers:{'Content-Type':'application/json',Origin:'http://127.0.0.1:5173',...headers},body:JSON.stringify(input)});assert.ok([401,403].includes(r.status));}
  const headers={'Content-Type':'application/json',Origin:'http://127.0.0.1:5173',Cookie:'tiplink_merchant_session='+login.token,'X-CSRF-Token':login.csrfToken};
  for(const extra of [{pin:'1234'},{accountName:'FORGED NAME'},{expectedName:'MANUAL NAME'}])assert.equal((await fetch(base+'/merchant/cash-out/banks/verify',{method:'POST',headers,body:JSON.stringify({...input,...extra})})).status,400);
  assert.equal((await fetch(base+'/merchant/cash-out/banks',{headers:{Cookie:headers.Cookie}})).status,503);
  for(const cookie of ['',headers.Cookie,'tiplink_session='+login.token])assert.ok([401,403].includes((await fetch(base+'/admin/breet/withdrawals',{headers:{Cookie:cookie}})).status));
  const r=await fetch(base+'/admin/breet/withdrawals',{headers:{Cookie:'tiplink_session='+administrator.token}});assert.equal(r.status,503);assert.equal(r.headers.get('cache-control'),'no-store');
  await db.query('UPDATE accounts SET active=false WHERE id=$1',[merchant.id]);assert.equal((await fetch(base+'/merchant/cash-out/banks',{headers:{Cookie:headers.Cookie}})).status,401);
 }finally{await new Promise(resolve=>server.close(resolve));await db.close();}
});
