import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {openDatabase} from '../dist/database.js';
import {migrate} from '../dist/migrate.js';
import {BreetDeposits} from '../dist/breet-deposits.js';
let db;
const config={breetAppId:'estimate-fixture',breetAppSecret:'private-fixture-secret'};
const assetId='67063f653b4a1f6c7a60ec51';
const scope=createHash('sha256').update(config.breetAppId).digest('hex');
async function owner(ready=true,role='merchant'){
 const account={id:randomUUID(),role};
 await db.query('INSERT INTO accounts(id,email,display_name,role,password_hash) VALUES($1,$2,$3,$4,$5)',[account.id,account.id+'@example.com','Estimate fixture',role,'unusable-fixture']);
 if(ready)await db.query('INSERT INTO breet_sandbox_wallets(account_id,app_scope,label,asset_id,state,wallet_id,address) VALUES($1,$2,$3,$4,$5,$6,$7)',[account.id,scope,randomUUID(),assetId,'ready',randomUUID().replaceAll('-','').slice(0,24),'bchtest:fixture-'+account.id]);
 return account;
}
const valid={NGNAmount:27800,rate:1390,cryptoAmount:0.05};
const reply=d=>new Response(JSON.stringify({success:true,data:d}));
before(async()=>{db=await openDatabase({production:false,localPath:'memory://'});await migrate(db);});
after(async()=>{await db.close();});
test('fixed sandbox calculator path/body, coalesced reads, redaction and explicit fee/payout uncertainty',async()=>{
 const calls=[];const service=new BreetDeposits(db,config,async(url,options)=>{
  calls.push(url);assert.equal(url,'https://api.breet.io/v1/trades/pbc/sell/rate-calculator/'+assetId);assert.equal(options.method,'POST');assert.equal(options.redirect,'error');assert.equal(options.headers['X-Breet-Env'],'sandbox');assert.deepEqual(JSON.parse(options.body),{amountInUSD:20,currency:'ngn'});return reply({...valid,bank:'private-bank-field'});
 });
 const account=await owner();const values=await Promise.all([service.estimate(account,'20'),service.estimate(account,'20.00')]);
 assert.equal(calls.length,1);const q=values[0];assert.equal(q.estimatedNgn,'27800.00');assert.equal(q.amountUsd,'20.00');assert.equal(q.approximateBch,'0.05000000');assert.equal(q.rateNgnPerUsd,'1390.0000');assert.equal(q.feesQuoted,false);assert.equal(q.payoutVerified,false);assert.equal(Date.parse(q.refreshAfter)-Date.parse(q.checkedAt),60000);assert.ok(!JSON.stringify(q).includes('private-'));
});
test('invalid USD amounts and caller-selected currency fail before any provider request',async()=>{
 let calls=0;const s=new BreetDeposits(db,config,async()=>{calls++;return reply(valid);}),a=await owner();
 for(const amount of [20,'0','0.5','-5','20.001','1e2','10000.01','10001',' 20','20\r\n','01',{amountUsd:'20',currency:'ghs'}])await assert.rejects(s.estimate(a,amount),e=>e.status===400);
 assert.equal(calls,0);
});
test('missing address, disabled account and administrator cannot request estimates',async()=>{
 let calls=0;const s=new BreetDeposits(db,config,async()=>{calls++;return reply(valid);});
 await assert.rejects(s.estimate(await owner(false),'20'),e=>e.status===409);
 await assert.rejects(s.estimate(await owner(false,'admin'),'20'),e=>e.status===403);
 const a=await owner();await db.query('UPDATE accounts SET active=false WHERE id=$1',[a.id]);await assert.rejects(s.estimate(a,'20'),e=>e.status===403);assert.equal(calls,0);
});
test('invalid/missing provider numbers reject rather than returning invented values',async()=>{
 for(const data of [{...valid,NGNAmount:0},{...valid,NGNAmount:0.001},{...valid,rate:0.000001},{...valid,NGNAmount:'27800'},{...valid,NGNAmount:null},{...valid,rate:-1},{...valid,cryptoAmount:1e-12},{...valid,cryptoAmount:NaN},{rate:1390,GHSAmount:20}]){
  const s=new BreetDeposits(db,config,async()=>reply(data));await assert.rejects(s.estimate(await owner(),'20'),e=>e.status===503&&!e.message.includes(config.breetAppSecret));
 }
});
test('provider failures are redacted, cached briefly and cannot fall back to example quotes',async()=>{
 let calls=0;const s=new BreetDeposits(db,config,async()=>{calls++;throw Error(config.breetAppSecret);}),a=await owner();
 for(let i=0;i<2;i++)await assert.rejects(s.estimate(a,'20'),e=>e.status===503&&!e.message.includes(config.breetAppSecret));assert.equal(calls,1);
});
test('cache separates amounts and owners without changing wallet rows or creating audit/balance mutations',async()=>{
 let calls=0;const s=new BreetDeposits(db,config,async()=>{calls++;return reply(valid);}),a=await owner(),b=await owner();
 const before=JSON.stringify((await db.query('SELECT * FROM breet_sandbox_wallets ORDER BY account_id')).rows);
 const count=(await db.query('SELECT count(*)::int AS n FROM audit_events')).rows[0].n;
 await s.estimate(a,'20');await s.estimate(a,'21');await s.estimate(b,'20');assert.equal(calls,3);
 assert.equal((await db.query('SELECT count(*)::int AS n FROM audit_events')).rows[0].n,count);
 assert.equal(JSON.stringify((await db.query('SELECT * FROM breet_sandbox_wallets ORDER BY account_id')).rows),before);
});
