const $=selector=>document.querySelector(selector);
let csrf='',policy=null,currentPage='overview',receiptRows=[];
function receiptText(item){const status=item.receipt&&Date.now()-Date.parse(item.receipt.checkedAt)>60000?'stale':item.paymentStatus;return ({seen:'Seen · unconfirmed',confirmed:'Confirmed · provider reported',not_found:'No longer found',unavailable:'Provider unavailable',stale:'Needs recheck',not_checked:'Not checked'})[status]||'Unknown';}
setInterval(()=>{for(const {cell,item}of receiptRows)cell.textContent=receiptText(item)+' · Request '+item.state;},5000);
const formatBch=value=>{const n=BigInt(value);return `${n/100000000n}.${(n%100000000n).toString().padStart(8,'0')}`;};
function parseBch(value){if(typeof value!=='string'||! /^(0|[1-9]\d*)(\.\d{1,8})?$/.test(value))throw Error('Use an exact BCH amount with up to 8 decimal places.');const [whole,fraction='']=value.split('.');return (BigInt(whole)*100000000n+BigInt(fraction.padEnd(8,'0'))).toString();}
function showError(message,login=false){const element=$(login?'#login-error':'#app-error');element.textContent=message;element.hidden=false;}
function clearMessages(){$('#app-error').hidden=true;$('#app-status').hidden=true;}
async function api(path,{method='GET',body}={}){const headers={};if(body!==undefined)headers['Content-Type']='application/json';if(csrf&&method!=='GET')headers['X-CSRF-Token']=csrf;const response=await fetch('/api/v1'+path,{method,headers,credentials:'same-origin',body:body===undefined?undefined:JSON.stringify(body)});const data=await response.json();if(!response.ok){if(response.status===401&&path!=='/health'&&!$('#workspace').hidden)closeWorkspace();throw Error(data.error||'The request could not be completed.');}return data;}
function nav(page){currentPage=page;$('#admin-more').open=false;clearMessages();for(const el of document.querySelectorAll('[data-panel]'))el.hidden=el.dataset.panel!==page;for(const el of document.querySelectorAll('[data-page]')){el.classList.toggle('active',el.dataset.page===page);if(el.dataset.page===page)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current');}const names={overview:['Overview','Your business. In focus.','Accounts, policies and operational readiness in one place.'],merchants:['Merchants','The people behind the payments.','Merchant accounts registered in this backend.'],invoices:['Requests','Every request. A clear record.','Merchant requests and their manually associated payment receipts.'],pricing:['Pricing','Simple fees. Clearly shown.','Versioned planning settings with a record of every change.'],calculator:['Calculator','A little maths. A lot of clarity.','Know what reaches them, and what it could cost.'],audit:['Audit history','Every change. On record.','A backend record of account and policy activity.']};const [crumb,title,description]=names[page];$('#breadcrumb').textContent=crumb;$('#page-title').textContent=title;$('#page-description').textContent=description;$('#workspace-main').focus({preventScroll:true});if(matchMedia('(max-width:760px)').matches)window.scrollTo(0,0);}
function cell(row,text){const td=document.createElement('td');td.textContent=text;row.append(td);return td;}
const invoiceSearch=$('#invoice-search');
let invoiceCriteria={search:'',filter:'all'},invoiceHasNext=false,invoicePage=1,invoiceRequest=0,workspaceGeneration=0;

function labelUpdate(id,text){
 const element=$(id);
 element.textContent=text;
}

async function updateSection(id,fetchData,render){
 const generation=workspaceGeneration;
 try{
  const value=await fetchData();
  if(generation!==workspaceGeneration||$('#workspace').hidden)return;
  render(value);
  labelUpdate(id,'Updated '+new Date().toLocaleTimeString());
 }catch{
  if(generation!==workspaceGeneration||$('#workspace').hidden)return;
  labelUpdate(id,'Could not refresh. Any data shown is from the last successful check.');
 }
}

async function refreshHealth(){
 const generation=workspaceGeneration;
 const badge=$('#api-status');
 try{
  const result=await api('/health');
  if(generation!==workspaceGeneration||$('#workspace').hidden)return;
  if(result.status!=='ok')throw Error('Health check failed.');
  badge.textContent='API healthy';
  badge.dataset.state='healthy';
  labelUpdate('#database-mode','Database reachable · checked '+new Date().toLocaleTimeString());
  labelUpdate('#worker-status',result.backgroundReceiptChecks
   ?'Background rechecks enabled for linked receipts.'
   :'Background rechecks disabled. Merchants can check a transaction ID.');
 }catch{
  if(generation!==workspaceGeneration||$('#workspace').hidden)return;
  badge.textContent='API check unavailable';
  badge.dataset.state='unavailable';
  labelUpdate('#database-mode','Could not confirm current database health.');
  labelUpdate('#worker-status','Receipt worker configuration unavailable.');
 }
}

function invoiceDetail(list,label,value,copy=false){
 const field=document.createElement('div'),name=document.createElement('dt'),description=document.createElement('dd');
 name.textContent=label;
 description.textContent=value;
 field.append(name,description);
 if(copy){
  const button=document.createElement('button');
  button.type='button';
  button.className='secondary';
  button.textContent='Copy '+label.toLowerCase();
  button.addEventListener('click',async()=>{
   try{
    await navigator.clipboard.writeText(value);
    button.textContent='Copied';
   }catch{
    button.textContent='Select the ID to copy it';
   }
  });
  field.append(button);
 }
 list.append(field);
}

function renderInvoice(item){
 const row=document.createElement('li'),details=document.createElement('details'),summary=document.createElement('summary');
 const title=document.createElement('span'),merchant=document.createElement('strong'),status=document.createElement('small');
 merchant.textContent=item.merchantName;
 status.textContent=receiptText(item)+' · Request '+item.state;
 title.className='invoice-title';
 title.append(merchant,status);
 receiptRows.push({cell:status,item});
 const amount=document.createElement('strong');
 amount.className='invoice-amount';
 amount.textContent=formatBch(item.amountSats)+' BCH';
 summary.append(title,amount);
 const fields=document.createElement('dl');
 fields.className='invoice-details';
 invoiceDetail(fields,'Request ID',item.id,true);
 if(item.memo)invoiceDetail(fields,'Note',item.memo);
 if(item.receipt){
  invoiceDetail(fields,'BCH transaction ID',item.receipt.txid,true);
  invoiceDetail(fields,'Last checked',new Date(item.receipt.checkedAt).toLocaleString());
  invoiceDetail(fields,'Last provider result',receiptText({paymentStatus:item.receipt.lastStatus}));
  invoiceDetail(fields,'Output index',String(item.receipt.outputIndex));
 }
 details.append(summary,fields);
 row.append(details);
 return row;
}

async function refreshInvoices(page=invoicePage){
 const request=++invoiceRequest;
 const params=new URLSearchParams({...invoiceCriteria,page:String(page)});
 $('#invoice-prev').disabled=true;
 $('#invoice-next').disabled=true;
 labelUpdate('#invoice-update','Loading requests…');
 try{
  const result=await api('/admin/invoices?'+params);
  if(request!==invoiceRequest||$('#workspace').hidden)return;
  invoicePage=result.page;
  invoiceHasNext=result.hasNext;
  receiptRows=[];
  $('#invoices-body').replaceChildren(...result.items.map(renderInvoice));
  $('#invoices-empty').hidden=result.items.length>0;
  $('#invoice-pagination').hidden=result.page===1&&!result.hasNext;
  $('#invoice-prev').disabled=result.page===1;
  $('#invoice-next').disabled=!result.hasNext;
  labelUpdate('#invoice-page','Page '+result.page);
  labelUpdate('#invoice-update','Checked '+new Date(result.checkedAt).toLocaleTimeString());
 }catch{
  if(request!==invoiceRequest||$('#workspace').hidden)return;
  $('#invoice-prev').disabled=invoicePage===1;
  $('#invoice-next').disabled=!invoiceHasNext;
  labelUpdate('#invoice-update','Could not load requests. Any results shown are from the previous search.');
 }
}

async function refresh(){
 clearMessages();
 const button=$('#refresh');
 button.disabled=true;
 try{
  await Promise.all([
   refreshHealth(),
   updateSection('#overview-update',()=>api('/admin/overview'),overview=>{
    labelUpdate('#invoice-count',String(overview.invoices.total));
    labelUpdate('#merchant-count',String(overview.merchants));
   }),
   updateSection('#pricing-update',()=>api('/pricing'),newPolicy=>{
    policy=newPolicy;
    labelUpdate('#personal-rate',(policy.personalBps/100)+'%');
    labelUpdate('#merchant-rate',(policy.merchantBps/100)+'%');
    const form=$('#pricing-form');
    form.elements.personalBps.value=policy.personalBps;
    form.elements.merchantBps.value=policy.merchantBps;
    form.elements.merchantCapSats.value=policy.merchantCapSats||'';
    form.elements.reason.value='';
    labelUpdate('#policy-version','Policy version '+policy.version+' · '+new Date(policy.createdAt).toLocaleString()+' · collection disabled');
   }),
   updateSection('#merchants-update',()=>api('/admin/merchants'),merchants=>{
    const body=$('#merchants-body');
    body.replaceChildren();
    $('#merchants-empty').hidden=merchants.items.length>0;
    for(const item of merchants.items){
     const row=document.createElement('tr');
     cell(row,item.displayName);cell(row,item.email||'Wallet sign-in');cell(row,new Date(item.createdAt).toLocaleDateString());cell(row,item.active?'Active':'Inactive');
     body.append(row);
    }
   }),
   updateSection('#audit-update',()=>api('/admin/audit'),audit=>{
    const events=$('#audit-body');
    events.replaceChildren();
    for(const item of audit.items){
     const row=document.createElement('tr');
     cell(row,item.action);cell(row,item.actor||'System');cell(row,new Date(item.createdAt).toLocaleString());
     const td=cell(row,''),details=document.createElement('details'),summary=document.createElement('summary'),pre=document.createElement('pre');
     summary.textContent='View details';pre.textContent=JSON.stringify(item.details,null,2);
     details.append(summary,pre);td.append(details);events.append(row);
    }
   }),
   refreshInvoices()
  ]);
 }finally{
  button.disabled=false;
 }
}

function closeWorkspace(){
 workspaceGeneration++;
 invoiceRequest++;
 labelUpdate('#api-status','Checking API…');
 $('#api-status').removeAttribute('data-state');
 labelUpdate('#database-mode','Checking database status…');
 labelUpdate('#worker-status','Checking receipt worker status…');
 invoicePage=1;
 invoiceHasNext=false;
 csrf='';
 policy=null;
 receiptRows=[];
 invoiceSearch.reset();
 invoiceCriteria={search:'',filter:'all'};
 $('#invoices-empty').hidden=true;
 $('#invoice-pagination').hidden=true;
 $('#merchants-empty').hidden=true;
 $('#quote-result').hidden=true;
 $('#quote-empty').hidden=false;
 for(const selector of ['#invoices-body','#merchants-body','#audit-body','#quote-lines'])$(selector).replaceChildren();
 for(const selector of ['#merchant-count','#invoice-count','#personal-rate','#merchant-rate'])labelUpdate(selector,'—');
 for(const selector of ['#overview-update','#pricing-update','#merchants-update','#audit-update','#invoice-update','#policy-version'])labelUpdate(selector,'');
 $('#pricing-form').reset();
 $('#workspace').hidden=true;
 $('#login-view').hidden=false;
}

function searchInvoices(){
 invoiceCriteria={search:invoiceSearch.elements.search.value.trim(),filter:invoiceSearch.elements.filter.value};
 refreshInvoices(1);
}
invoiceSearch.addEventListener('submit',event=>{event.preventDefault();searchInvoices();});
invoiceSearch.elements.filter.addEventListener('change',searchInvoices);
$('#invoice-prev').addEventListener('click',()=>refreshInvoices(Math.max(1,invoicePage-1)));
$('#invoice-next').addEventListener('click',()=>refreshInvoices(invoicePage+1));
$('#open-attention').addEventListener('click',()=>{
 invoiceSearch.reset();
 invoiceSearch.elements.filter.value='attention';
 nav('invoices');
 searchInvoices();
});

function showAuthenticator(required){
 const field=$('#authenticator-field'),input=field.querySelector('input');
 field.hidden=!required;
 input.disabled=!required;
 input.required=required;
}
async function openWorkspace(session){if(session.account.role!=='admin'){await api('/auth/logout',{method:'POST',body:{}}).catch(()=>{});csrf='';throw Error('This workspace is for administrators. Merchant access will be connected in the customer app.');}$('#admin-name').textContent=session.account.displayName;$('#login-view').hidden=true;$('#workspace').hidden=false;nav('overview');await refresh();}
$('#login-form').addEventListener('submit',async event=>{event.preventDefault();const form=event.currentTarget,button=form.querySelector('button');button.disabled=true;$('#login-error').hidden=true;try{const result=await api('/auth/login',{method:'POST',body:{email:form.elements.email.value,password:form.elements.password.value,...(form.elements.code.disabled?{}:{code:form.elements.code.value})}});form.elements.password.value='';csrf=result.csrfToken;await openWorkspace(result);}catch(error){form.elements.password.value='';showError(error.message,true);}finally{form.elements.code.value='';button.disabled=false;}});
for(const button of document.querySelectorAll('[data-page],[data-go]'))button.addEventListener('click',()=>nav(button.dataset.page||button.dataset.go));
$('#refresh').addEventListener('click',refresh);
async function logout(){try{await api('/auth/logout',{method:'POST',body:{}});closeWorkspace();$('#login-form input').focus();}catch(error){showError(error.message);}}
$('#logout').addEventListener('click',logout);
$('#mobile-logout').addEventListener('click',()=>{$('#admin-more').open=false;logout();});
// Desktop header sign-out shares the same handler as the mobile menu.
const mobileLogout=document.createElement('button');mobileLogout.className='secondary header-logout';mobileLogout.textContent='Sign out';mobileLogout.addEventListener('click',logout);$('header>div').append(mobileLogout);
$('#pricing-form').addEventListener('submit',async event=>{event.preventDefault();if(!policy)return;clearMessages();const form=event.currentTarget,button=form.querySelector('button');button.disabled=true;try{const cap=form.elements.merchantCapSats.value.trim();if(cap&&!/^[1-9]\d{0,15}$/.test(cap))throw Error('Enter a whole satoshi cap or leave it blank.');await api('/admin/pricing',{method:'PUT',body:{expectedVersion:policy.version,personalBps:Number(form.elements.personalBps.value),merchantBps:Number(form.elements.merchantBps.value),merchantCapSats:cap||null,reason:form.elements.reason.value}});await refresh();$('#app-status').textContent='Proposed pricing saved and recorded. Fee collection remains disabled.';$('#app-status').hidden=false;}catch(error){showError(error.message);}finally{button.disabled=false;}});
$('#quote-form').addEventListener('submit',async event=>{event.preventDefault();clearMessages();const form=event.currentTarget,button=form.querySelector('button');button.disabled=true;try{const result=await api('/quotes',{method:'POST',body:{kind:form.elements.kind.value,recipientSats:parseBch(form.elements.recipientBch.value),fundingFeeSats:parseBch(form.elements.fundingBch.value),claimFeeSats:parseBch(form.elements.claimBch.value)}});const lines=$('#quote-lines');lines.replaceChildren();for(const [label,value,total]of [['Recipient receives',result.recipientSats],['Network fees · your estimate',result.networkFeeEstimateSats],['Proposed platform fee',result.proposedPlatformFeeSats],['Pilot total · no platform fee',result.pilotTotalEstimateSats,true],['Total with proposed fee',result.proposedTotalEstimateSats]]){const div=document.createElement('div'),dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=label;dd.textContent=formatBch(value)+' BCH';if(total)div.className='total';div.append(dt,dd);lines.append(div);}$('#quote-empty').hidden=true;$('#quote-result').hidden=false;}catch(error){showError(error.message);}finally{button.disabled=false;}});
api('/auth/options').then(result=>showAuthenticator(result.adminAuthenticatorRequired)).catch(()=>showAuthenticator(true));
api('/auth/session').then(async session=>{csrf=session.csrfToken;await openWorkspace(session);}).catch(error=>{if(error.message!=='Sign in to continue.')showError(error.message,true);});
