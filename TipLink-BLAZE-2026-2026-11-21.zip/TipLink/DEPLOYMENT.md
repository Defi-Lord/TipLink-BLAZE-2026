# TipLink deployment

TipLink runs as a BCH mainnet pilot. The [customer app](https://tip-link.xyz/) is hosted on Vercel and the [backend health endpoint](https://api.tip-link.xyz/api/v1/health) is served by Railway. Staging and production use separate backends, databases, and admin authenticator secrets.

## Frontend

| Setting | Value |
| --- | --- |
| Vercel project root | `frontend` |
| Build command | `npm run build:wallet` |
| Output directory | `wallet-lab/dist` |
| Customer origin | `https://tip-link.xyz` |

[vercel.json](frontend/vercel.json) defines the security headers and selected merchant and public request API rewrites. Keep session and checkout API responses out of CDN caches. Verify a merchant session through the same origin that serves the frontend. Preview deployments need an explicitly configured origin to exercise writes. For another installation, update the rewrite destinations and both origins.

The customer domain scopes browser-local wallets. Preserve encrypted backups and their passwords before changing domains. Keep private claim links, wallet credentials, and recovery material out of logs, screenshots, and analytics.

## Backend configuration

Deploy [backend/Dockerfile](backend/Dockerfile) with `backend` as the project root. Set the variables below in the backend environment.

| Variable | Purpose |
| --- | --- |
| `NODE_ENV` | Set to `production` on the live service. |
| `HOST` | Set to `0.0.0.0` for container hosting. The platform supplies `PORT`. |
| `APP_ORIGIN` | Backend HTTPS origin. Production uses `https://api.tip-link.xyz`. |
| `CUSTOMER_APP_ORIGIN` | Customer HTTPS origin. Production uses `https://tip-link.xyz`. |
| `DATABASE_URL` | Private connection string for the dedicated TipLink PostgreSQL database. |
| `DATABASE_CA_FILE` | Path to the provider's CA file when needed. The migration and runtime containers both need access to it. Certificate verification stays enabled. |
| `WALLETCONNECT_PROJECT_ID` | Reown project ID for merchant wallet sign-in. Allow the customer origin in the Reown project. |
| `ADMIN_TOTP_SECRET` | Environment-specific backend secret for admin sign-in. Follow [the admin runbook](backend/ADMIN-OPERATIONS.md). |
| `RECEIPT_WORKER_ENABLED` | Set to `true` to recheck existing linked payment receipts. The production service currently enables it. |

Railway runs `node dist/migrate-cli.js` as its pre-deploy command against the service database. The backend starts with `node dist/server.js` and requires migration 008. Use `/api/v1/health` to check the deployed service.

## Release checks

1. Verify the environment and database targets, then verify that deployment logs show the migration succeeded.
2. Open the API health endpoint and confirm `status` is `ok`.
3. Sign in through the admin origin with a fresh authenticator code and open **Review payments**. Keep any synthetic verification records in staging.
4. Verify the customer app, business sign-in, public checkout, and wallet pairing on the customer origin.
5. For mainnet payment verification, record the funding and claim transaction IDs after verifying the recipient output. Keep the private claim link and recovery material private.

Use the [local setup guide](README.md#run-locally) for development.
