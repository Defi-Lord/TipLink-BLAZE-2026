> Judging source snapshot for BCH BLAZE 2026. Original commit `b9df4304f3914c2506b0eb1d4a84257040c44de9`, captured November 21, 2026. Compare it with the [pre-hackathon snapshot](https://github.com/Defi-Lord/TipLink-BLAZE-2026/blob/main/TipLink-Pre-Hackathon-2026-11-12.zip). [Live app and presentation](https://www.tip-link.xyz/).

BLAZE work includes payment tracking and synchronized merchant receipts for eligible requests, pay-by-link wallet handoff improvements, and the dashboard and in-app help refresh. The Selene invoice receipt sync was verified on mainnet. A complete funded send, claim, and onward withdrawal still needs an end-to-end check.

# TipLink

**Send Bitcoin Cash through a link.** A sender funds a private claim link and shares it with the recipient. The recipient can claim BCH to an existing address or create a browser wallet without opening a TipLink account. Freelancers and merchants can also request an exact BCH amount from a shareable checkout.

[Open the live app](https://tip-link.xyz/) · [Run locally](#run-locally) · [Deployment guide](DEPLOYMENT.md)

Built by [Defi-Lord](https://github.com/Defi-Lord) at [Nazzitech](https://nazzitech.vercel.app) for BCH BLAZE 2026.

![TipLink brand artwork showing interlocking metal links](frontend/wallet-lab/public/midnight/link-sculpture.webp)

## Try it

| Flow | What to try |
| --- | --- |
| Send BCH | Open the send flow, connect a compatible BCH wallet through WizardConnect, enter an amount, and review the funding transaction. Signing and broadcasting are separate steps. |
| Claim BCH | Open a privately shared, funded link. Use a BCH receiving address or create an encrypted browser wallet, then review the claim. |
| Request a payment | In **Business**, create a request with an exact BCH amount, optional memo, and expiration. Open the shareable checkout to see the amount and QR code. After payment, the merchant can attach a transaction ID for verification. |

**Live mainnet pilot.** Deployment, API health, and administrator sign-in with an authenticator have been verified. An end-to-end funded send and claim on mainnet is still pending verification. The review screens let you inspect the flow before broadcasting. A broadcast uses real BCH and may incur a network fee.

## How it works

| Area | Implementation |
| --- | --- |
| Customer app | React and Vite. Sender and recipient screens are in [frontend/wallet-lab](frontend/wallet-lab). |
| BCH transactions | WizardConnect for compatible BCH wallets, libauth for transaction construction and local script checks, and a Rostrum provider for chain lookups. |
| Recipient wallet | Client-side encrypted storage with a downloadable encrypted backup. |
| Business API | Node.js, Express, TypeScript, and PostgreSQL. Payment requests support expiration, cancellation, and CSV export. Payment amounts are handled in integer satoshis. |
| Payment operations | A worker rechecks previously linked receipts. Admins can inspect requests and review receipts that need attention. The admin workspace also includes an audit history, proposed pricing, and authenticator-protected access. |

The [frontend configuration](frontend/vercel.json) forwards selected customer API routes to the backend. Admin routes use a separate origin. The private claim material stays in the URL fragment and is handled by the client.

## Run locally

Use Node.js **22.23.2 or newer** and npm. Run each block from the repository root in a separate PowerShell window.

```powershell
Set-Location backend
npm ci
npm run build
npm run db:migrate
npm run dev
```

With no `DATABASE_URL` configured, this initializes a local PGlite database. If your shell or `backend/.env` already specifies a hosted database, verify the migration target before running the command.

```powershell
Set-Location frontend
npm ci
npm run dev
```

Open the customer app at `http://127.0.0.1:5173/` and the backend at `http://127.0.0.1:4100/`. Email-based merchant registration works locally. Merchant wallet sign-in requires a compatible wallet and a Reown project ID configured on the backend. See [deployment configuration](DEPLOYMENT.md#backend-configuration).

## Validate changes

| Folder | Commands |
| --- | --- |
| `frontend/` | `npm test`, `npm run build:wallet` |
| `backend/` | `npm test`, `npm run test:pilot` |

The admin release passed **125 backend tests**. Staging verified the payment review queue with a synthetic receipt. The production release verified PostgreSQL migration, API health, and admin sign-in with an authenticator.

## Pilot limits

- A claim link is a bearer secret. Anyone with it can attempt to claim available funds. Share it privately and keep recovery files and passwords secure.
- The recovery delay allows the sender to attempt a recovery transaction after the specified time. It neither sends an automatic refund nor disables the recipient’s ability to claim.
- Receipt status is provider-reported. The receipt worker rechecks transaction IDs already linked to requests.
- Platform fee collection is disabled. Fiat on/off-ramp work is sandbox-only, and mobile app-store releases are outside the current pilot.

## Ownership

Created by Nazzitech. The repository currently has no open-source license.
