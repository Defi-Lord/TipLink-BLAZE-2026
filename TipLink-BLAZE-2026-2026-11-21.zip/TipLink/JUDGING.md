# TipLink judging source

This archive contains the November 21 snapshot. The November 12 pre-hackathon baseline is available alongside it in the public judging repository. Both snapshots come from the GitHub commits identified in their READMEs. Internal operations notes and old export-review records were omitted.

Source inspection does not grant an open-source license. See the live application at https://www.tip-link.xyz/.
