export function normalizeBchInput(value) {
  if (typeof value !== 'string') throw Error('Enter a BCH amount.');
  const normalized=value.trim().replace(',', '.').replace(/^\./,'0.');
  if (normalized.startsWith('-') || /^0(?:\.0+)?$/.test(normalized)) throw Error('Enter a BCH amount greater than zero.');
  return normalized;
}

// Exact accounting only. This module does not construct, sign or broadcast BCH transactions.
export function parseBch(value) {
  if (typeof value !== 'string' || !/^(0|[1-9]\d*)(\.\d{1,8})?$/.test(value)) {
    throw new Error('Enter a BCH amount with at most eight decimal places.');
  }
  const [whole, fraction = ''] = value.split('.');
  const sats = BigInt(whole) * 100000000n + BigInt(fraction.padEnd(8, '0'));
  if (sats <= 0n || sats > 21000000n * 100000000n) throw new Error('BCH amount outside supported range.');
  return sats;
}

export function splitTip(totalSats, members, minimumOutputSats) {
  if (typeof totalSats !== 'bigint' || totalSats <= 0n) throw new Error('Positive integer satoshis required.');
  // Supply the output floor from the selected script/network policy; do not assume a universal dust limit.
  if (typeof minimumOutputSats !== 'bigint' || minimumOutputSats <= 0n) throw new Error('Output floor required.');
  if (!Array.isArray(members) || members.length < 2 || members.length > 5) throw new Error('Choose two to five members.');
  const ids = new Set();
  for (const member of members) {
    if (typeof member.id !== 'string' || !member.id.trim() || ids.has(member.id)) throw new Error('Unique member IDs required.');
    ids.add(member.id);
    if (!Number.isInteger(member.bps) || member.bps <= 0 || member.bps > 10000) throw new Error('Invalid share in basis points.');
  }
  if (members.reduce((sum, m) => sum + m.bps, 0) !== 10000) throw new Error('Shares must total 100%.');
  const rows = members.map((member, index) => ({
    id: member.id, bps: member.bps, index,
    sats: totalSats * BigInt(member.bps) / 10000n,
    remainder: totalSats * BigInt(member.bps) % 10000n,
  }));
  let left = totalSats - rows.reduce((sum, row) => sum + row.sats, 0n);
  // Largest remainder; equal remainders resolve by the published member order.
  const ranked = [...rows].sort((a, b) => a.remainder === b.remainder ? a.index - b.index : a.remainder > b.remainder ? -1 : 1);
  for (const row of ranked) {
    if (left === 0n) break;
    row.sats += 1n;
    left -= 1n;
  }
  if (rows.some(row => row.sats < minimumOutputSats)) throw new Error('Tip too small for the configured split and output floor.');
  return rows.map(({ id, bps, sats }) => ({ id, bps, sats }));
}

export function fundingSummary(inputSats, recipientSats, minerFeeSats, minimumChangeSats) {
  for (const value of [inputSats, recipientSats, minerFeeSats, minimumChangeSats]) {
    if (typeof value !== 'bigint' || value < 0n) throw new Error('Nonnegative integer satoshis required.');
  }
  if (recipientSats === 0n || minimumChangeSats === 0n) throw new Error('Recipient value and change floor must be positive.');
  const changeSats = inputSats - recipientSats - minerFeeSats;
  if (changeSats < 0n) throw new Error('Insufficient funds, including miner fee.');
  if (changeSats > 0n && changeSats < minimumChangeSats) throw new Error('Change below policy floor; rebuild and show a new quote.');
  return { recipientSats, minerFeeSats, changeSats, platformFeeSats: 0n };
}
