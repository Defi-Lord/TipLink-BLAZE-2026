import React,{useEffect,useRef,useState} from 'react';
import {openFundingRpc} from './funding-rpc.mjs';
import {lookupWalletFunding} from './live-funding-core.mjs';
import {formatBch} from './preview-core.mjs';
export function LiveFunding({rows,prefix}) {
  const [result,setResult]=useState(null);const [issue,setIssue]=useState('');const [busy,setBusy]=useState(false);const active=useRef(null);
  useEffect(()=>{setBusy(false);setIssue('');setResult(null);return ()=>{active.current?.abort();active.current=null;};},[rows,prefix]);
  const current=result?.rows===rows?result.value:null;
  async function lookup(){
    const controller=new AbortController();active.current?.abort();active.current=controller;
    setBusy(true);setIssue('');setResult(null);let rpc;const timer=setTimeout(()=>controller.abort(),90000);
    try{rpc=await openFundingRpc({signal:controller.signal});const value=await lookupWalletFunding({rpc,rows,signal:controller.signal});if(active.current===controller&&!controller.signal.aborted)setResult({rows,value});}
    catch(e){if(active.current===controller)setIssue(e.message||'Funding lookup failed.');}
    finally{clearTimeout(timer);rpc?.close();if(active.current===controller){active.current=null;setBusy(false);}}
  }
  return <section><h3>Live funding lookup · read only</h3><p>Clicking below sends these four wallet script hashes to <strong>rostrum.riften.net</strong> to query BCH mainnet. The provider can link the queried scripts. No xpubs, private keys or recovery words are sent.</p><p className="fine">Only the displayed receive indices 0–2 and change index 0 are scanned. This is not a full-wallet balance. The wallet's own network is not automatically detected.</p><div className="actions"><button type="button" disabled={busy||prefix!=='bitcoincash'} onClick={lookup}>{busy?'Checking provider and funding…':'Check BCH mainnet funding'}</button>{busy&&<button type="button" className="secondary" onClick={()=>active.current?.abort()}>Cancel lookup</button>}</div>{prefix!=='bitcoincash'&&<p>Choose BCH mainnet address encoding to use this provider. Development-network lookup is not configured.</p>}{issue&&<p role="alert" className="error">{issue}</p>}
  {current&&<div className="preview-result" role="status"><h3>{current.candidates.length?'Funding candidates found':'No BCH-only funding found in the scanned scripts'}</h3><p>Provider BCH mainnet checkpoint matched: block {current.checkpoint}.</p><p>Candidate total: <strong>{formatBch(current.totalSats)} BCH</strong> · {current.candidates.length} outputs · {current.scannedScripts} scripts.</p><p className="fine">Checked: {current.checkedAt}. Excluded token outputs: {current.excludedTokens}; excluded coinbase outputs: {current.excludedCoinbase}.</p>{current.candidates.map(c=><div className="output-row" key={`${c.txid}:${c.index}`}><strong>{c.path} / {c.addressIndex} · {c.sats} sats</strong><code>{c.txid}:{c.index}</code><span>{c.height>0?'Provider reports confirmed':'Provider reports unconfirmed'}</span></div>)}<p className="fine">Raw transaction IDs, output amounts and scripts were checked locally. Unspent status comes from one provider, refreshed during this scan; it can change. No header-chain validation, Merkle inclusion proof or full-node verification is performed. This is not payment approval. Signing and broadcast remain disabled.</p></div>}</section>;
}
