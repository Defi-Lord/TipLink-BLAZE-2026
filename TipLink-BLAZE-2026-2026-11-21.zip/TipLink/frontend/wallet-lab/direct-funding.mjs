// External-wallet BCH funding: the sender pays a unique contract address using
// a regular wallet Send action. No WalletConnect signature and no private keys
// are ever sent to a server. Never activate a claim link without chain checks.
import {binToHex,hexToBin,sha256,decodeTransaction,encodeTransaction,hashTransaction} from '@bitauth/libauth';
import {validateEnvelopeDraft,decryptEnvelopeDraft} from './envelope-draft.mjs';
import {validateClaimTransfer,encodeClaimTransfer} from './envelope-handoff.mjs';
import {CHECKPOINT,verifyProviderIdentity,validateUnspentList} from './live-funding-core.mjs';
import {isVerifiedFundingRpc} from './funding-rpc.mjs';

const MAX_TX_HEX=40000;
const HEX=/^(?:[a-fA-F0-9]{2})+$/;
const exact=(obj,keys)=>obj&&typeof obj==='object'&&!Array.isArray(obj)&&
 Object.keys(obj).length===keys.length&&Object.keys(obj).every(key=>keys.includes(key));
const isCoinbase=tx=>tx.inputs.length===1&&tx.inputs[0].outpointIndex===0xffffffff&&
 tx.inputs[0].outpointTransactionHash.every(byte=>byte===0);
export const directFundingScriptHash=script=>binToHex(sha256.hash(hexToBin(script)).reverse());

export function validateDirectFundingTransaction({draft,rawHex,txid,index}){
 const d=validateEnvelopeDraft(draft);
 if(typeof rawHex!=='string'||rawHex.length>MAX_TX_HEX||!HEX.test(rawHex))throw Error('Invalid external funding transaction bytes.');
 if(typeof txid!=='string'||!/^[a-f0-9]{64}$/.test(txid)||!Number.isSafeInteger(index)||index<0||index>0xffffffff)
  throw Error('Invalid external funding outpoint.');
 const raw=rawHex.toLowerCase(),bytes=hexToBin(raw),tx=decodeTransaction(bytes);
 if(typeof tx==='string'||binToHex(encodeTransaction(tx))!==raw||hashTransaction(bytes)!==txid||isCoinbase(tx))
  throw Error('External funding transaction could not be verified.');
 const out=tx.outputs[index];
 if(!out||out.token!==undefined||out.valueSatoshis!==BigInt(d.amountSats)||
  binToHex(out.lockingBytecode)!==d.contract.scriptHex)
  throw Error('External payment must fund the exact BCH amount and contract address.');
 // Reject ambiguous multiple outputs to the same one-time envelope script.
 if(tx.outputs.filter(row=>binToHex(row.lockingBytecode)===d.contract.scriptHex).length!==1)
  throw Error('Multiple outputs to this envelope cannot be safely selected.');
 return validateClaimTransfer({
  type:'tiplink-claim',version:1,network:'bitcoincash',
  contract:d.contract,
  utxo:{txid,index,sats:d.amountSats,scriptHex:d.contract.scriptHex},
  claimPrivateKey:d.claimPrivateKey
 });
}

export async function lookupDirectFunding({draft,rpc,signal,now=()=>Date.now()}){
 const d=validateEnvelopeDraft(draft);
 const check=()=>{if(signal?.aborted)throw Error('External BCH funding check cancelled.');};
 check();
 // openFundingRpc already verifies two independent BCH providers' genesis
 // and fixed mainnet checkpoint. Avoid three redundant network round trips
 // on every automatic poll; injected/mock RPCs still verify from scratch.
 if(!isVerifiedFundingRpc(rpc)){
  await rpc.call('server.version',['TipLink direct BCH funding','1.4.3']);check();
  verifyProviderIdentity(await rpc.call('server.features',[]),
   await rpc.call('blockchain.block.header',[CHECKPOINT.height]));check();
 }
 const hash=directFundingScriptHash(d.contract.scriptHex);
 const entries=validateUnspentList(await rpc.call('blockchain.scripthash.listunspent',[hash,'include_tokens']),20);
 check();
 if(!entries.length)return{status:'unfunded',message:'No BCH payment to this address was found.',checkedAt:now()};
 if(entries.length!==1)return{status:'ambiguous',message:'Multiple outputs were found. Do not share a claim link; recover with support.',checkedAt:now()};
 const entry=entries[0];
 if(entry.sats!==d.amountSats)return{status:'wrong-amount',message:'The paid amount does not match this link. Do not send another payment. Keep the recovery file.',checkedAt:now()};
 const raw=await rpc.call('blockchain.transaction.get',[entry.txid,false]);check();
 const transfer=validateDirectFundingTransaction({draft:d,rawHex:raw,txid:entry.txid,index:entry.index});
 const reread=validateUnspentList(await rpc.call('blockchain.scripthash.listunspent',[hash,'include_tokens']),20);
 check();
 if(reread.length!==1||reread[0].key!==entry.key||reread[0].sats!==entry.sats||reread[0].height!==entry.height)
  throw Error('The BCH envelope changed while checking. Check again.');
 const timestamp=now();
 if(!Number.isSafeInteger(timestamp)||timestamp<0)throw Error('Invalid BCH lookup time.');
 return {
  status:entry.height>0?'confirmed':'unconfirmed',
  height:entry.height,checkedAt:timestamp,
  rawFundingHex:raw.toLowerCase(),transfer,
  identity:encodeClaimTransfer(transfer),
  message:entry.height>0
   ?'Confirmed and unspent BCH funding was cross-checked against a raw transaction by independent network providers.'
   :'Payment detected by independent BCH providers. A pending claim link can be prepared now, but receiving BCH remains locked until a block confirms the funding.'
 };
}

export function createDirectFundedHandoff({draft,encryptedDraft,snapshot,allowPending=false,now=Date.now()}){
 const d=validateEnvelopeDraft(draft);
 if(!encryptedDraft||encryptedDraft.type!=='tiplink-encrypted-draft')throw Error('Save the protected recovery file first.');
 // Pending links are allowed only for an already-seen exact transaction, never
 // for an unfunded, unavailable, stale, conflicting or incorrect payment.
 const pending=snapshot?.status==='unconfirmed'&&snapshot?.height===0;
 const confirmed=snapshot?.status==='confirmed'&&snapshot?.height>0;
 if((!confirmed&&!(allowPending===true&&pending))||!Number.isSafeInteger(snapshot.checkedAt)||
  now<snapshot.checkedAt||now-snapshot.checkedAt>=30000)
  throw Error('Refresh and verify a detected BCH payment before preparing a claim link.');
 const transfer=validateDirectFundingTransaction({
  draft:d,rawHex:snapshot.rawFundingHex,txid:snapshot.transfer?.utxo?.txid,index:snapshot.transfer?.utxo?.index
 });
 if(encodeClaimTransfer(transfer)!==snapshot.identity)
  throw Error('External funding proof changed; no claim link can be issued.');
 const backup={
  type:'tiplink-direct-funded',version:1,
  encryptedDraft:structuredClone(encryptedDraft),
  rawFundingHex:snapshot.rawFundingHex,
  outpoint:{txid:transfer.utxo.txid,index:transfer.utxo.index,sats:transfer.utxo.sats,scriptHex:transfer.utxo.scriptHex}
 };
 return{draft:d,transfer,backup,
  status:confirmed?'DIRECT BCH FUNDING CONFIRMED; NO WALLET SIGNATURE REQUIRED'
   :'DIRECT BCH FUNDING DETECTED, UNCONFIRMED; CLAIM LOCKED UNTIL BLOCK CONFIRMATION'};
}

export function verifyDirectFundedBackup({backup,draft}){
 if(!exact(backup,['type','version','encryptedDraft','rawFundingHex','outpoint'])||
  backup.type!=='tiplink-direct-funded'||backup.version!==1||
  !exact(backup.outpoint,['txid','index','sats','scriptHex']))
  throw Error('Invalid direct BCH recovery backup.');
 const t=validateDirectFundingTransaction({
  draft,rawHex:backup.rawFundingHex,txid:backup.outpoint.txid,index:backup.outpoint.index
 });
 if(JSON.stringify(t.utxo)!==JSON.stringify(backup.outpoint))
  throw Error('Saved external funding output was modified.');
 return t;
}

export async function restoreDirectFundedHandoff(backup,password){
 const d=validateEnvelopeDraft(await decryptEnvelopeDraft(backup?.encryptedDraft,password));
 return{draft:d,transfer:verifyDirectFundedBackup({backup,draft:d}),backup,
  status:'DIRECT BCH FUNDING RESTORED; NETWORK STATUS MUST BE RECHECKED'};
}
