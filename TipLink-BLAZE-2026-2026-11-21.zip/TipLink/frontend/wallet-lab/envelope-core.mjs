// Offline contract engine. No provider calls, wallet requests or broadcasting.
import {secp256k1,sha256,ripemd160,binToHex,hexToBin,encodeCashAddress,encodeDataPush,bigIntToVmNumber,encodeTransaction,generateSigningSerializationBCH,createVirtualMachineBCH} from '@bitauth/libauth';
import {validateRecipient} from './preview-core.mjs';
const concat=(...parts)=>Uint8Array.from(parts.flatMap(p=>Array.from(p)));
const op=(...bytes)=>Uint8Array.from(bytes);
const money=2100000000000000n;
function pub(value){if(typeof value!=='string'||!/^(02|03)[a-f0-9]{64}$/.test(value)||!secp256k1.validatePublicKey(hexToBin(value)))throw Error('A valid compressed public key is required.');return hexToBin(value);}
export function createEnvelopeContract({claimPublicKey,senderPublicKey,reclaimAfter}){
 const claim=pub(claimPublicKey),sender=pub(senderPublicKey);
 if(claimPublicKey===senderPublicKey)throw Error('Claim and sender keys must differ.');
 if(!Number.isSafeInteger(reclaimAfter)||reclaimAfter<500000000||reclaimAfter>0x7fffffff)throw Error('Reclaim time must be a supported Unix timestamp.');
 // IF <claim key> CHECKSIG ELSE <time> CLTV DROP <sender key> CHECKSIG ENDIF
 const redeem=concat(op(0x63),encodeDataPush(claim),op(0xac,0x67),encodeDataPush(bigIntToVmNumber(BigInt(reclaimAfter))),op(0xb1,0x75),encodeDataPush(sender),op(0xac,0x68));
 const payload=ripemd160.hash(sha256.hash(redeem));
 const locking=concat(op(0xa9),encodeDataPush(payload),op(0x87));
 return{version:1,network:'bitcoincash',claimPublicKey,senderPublicKey,reclaimAfter,redeemHex:binToHex(redeem),scriptHex:binToHex(locking),address:encodeCashAddress({prefix:'bitcoincash',type:'p2sh',payload}).address};
}
export function validateEnvelopeContract(contract){const canonical=createEnvelopeContract(contract);if(contract.redeemHex!==canonical.redeemHex||contract.scriptHex!==canonical.scriptHex||contract.address!==canonical.address||contract.network!==canonical.network||contract.version!==1)throw Error('Envelope contract was modified.');return canonical;}
export function buildEnvelopeSpend({contract,utxo,destination,privateKeyHex,branch='claim',feeRate=1}){
 const c=validateEnvelopeContract(contract);
 if(!['claim','reclaim'].includes(branch))throw Error('Unknown spending branch.');
 if(!Number.isSafeInteger(feeRate)||feeRate<1||feeRate>100)throw Error('Invalid fee rate.');
 if(typeof privateKeyHex!=='string'||!/^[a-f0-9]{64}$/.test(privateKeyHex))throw Error('Invalid claim/reclaim key.');
 const key=hexToBin(privateKeyHex);const publicKey=secp256k1.derivePublicKeyCompressed(key);
 if(typeof publicKey==='string'||binToHex(publicKey)!==(branch==='claim'?c.claimPublicKey:c.senderPublicKey))throw Error('Key does not match the chosen contract branch.');
 if(!utxo||Object.hasOwn(utxo,'token')||Object.hasOwn(utxo,'tokenData')||!/^[a-f0-9]{64}$/.test(utxo.txid)||!Number.isSafeInteger(utxo.index)||utxo.index<0||utxo.index>0xffffffff||utxo.scriptHex!==c.scriptHex||typeof utxo.sats!=='string'||!/^[1-9]\d*$/.test(utxo.sats)||BigInt(utxo.sats)>money)throw Error('Invalid BCH-only contract outpoint.');
 const recipient=validateRecipient(destination);const redeem=hexToBin(c.redeemHex);
 const sourceOutputs=[{lockingBytecode:hexToBin(c.scriptHex),valueSatoshis:BigInt(utxo.sats)}];
 const unlocking=sig=>concat(encodeDataPush(sig),op(branch==='claim'?0x51:0x00),encodeDataPush(redeem));
 const tx={version:2,locktime:branch==='reclaim'?c.reclaimAfter:0,inputs:[{outpointTransactionHash:hexToBin(utxo.txid),outpointIndex:utxo.index,sequenceNumber:branch==='reclaim'?0xfffffffe:0xffffffff,unlockingBytecode:unlocking(new Uint8Array(65))}],outputs:[{lockingBytecode:hexToBin(recipient.scriptHex),valueSatoshis:1000n}]};
 const estimatedBytes=encodeTransaction(tx).length;const feeSats=BigInt(estimatedBytes*feeRate);const receiveSats=BigInt(utxo.sats)-feeSats;
 if(receiveSats<1000n)throw Error('Envelope cannot cover the fee and minimum receiving output.');
 tx.outputs[0].valueSatoshis=receiveSats;
 const context={transaction:tx,sourceOutputs,inputIndex:0};const preimage=generateSigningSerializationBCH(context,{coveredBytecode:redeem,signingSerializationType:op(0x41)});
 const signature=secp256k1.signMessageHashSchnorr(key,sha256.hash(sha256.hash(preimage)));
 if(typeof signature==='string')throw Error('Signing failed.');
 tx.inputs[0].unlockingBytecode=unlocking(concat(signature,op(0x41)));
 const valid=createVirtualMachineBCH().verify({transaction:tx,sourceOutputs});
 if(valid!==true)throw Error(`Local contract verification failed: ${valid}`);
 const raw=encodeTransaction(tx);if(raw.length!==estimatedBytes)throw Error('Signed fee estimate changed.');
 return{branch,feeRate,transaction:tx,sourceOutputs,hex:binToHex(raw),bytes:raw.length,feeSats,receiveSats,destination:recipient.address,locktime:tx.locktime,verification:'SCRIPT VERIFIED LOCALLY; CHAIN EXISTENCE, UNSPENT STATUS AND FINALITY NOT CHECKED'};
}
