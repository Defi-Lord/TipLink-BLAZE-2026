import React, { useEffect, useState } from 'react';
import { deriveWalletAddresses, inspectFundingTransaction } from './wallet-address-core.mjs';
import { LiveFunding } from './LiveFunding.jsx';

export function WalletAddresses({ manager, state }) {
  const [prefix,setPrefix]=useState('bitcoincash');
  const [data,setData]=useState(null); const [error,setError]=useState('');
  const [raw,setRaw]=useState(''); const [txid,setTxid]=useState(''); const [index,setIndex]=useState('0');
  const [funding,setFunding]=useState(null);
  useEffect(()=>{setData(null);setError('');setFunding(null);setRaw('');setTxid('');},[manager,state]);
  const rows = state === 'connected' && data?.manager === manager && data?.prefix === prefix ? data.rows : null;
  function derive() {setError('');setFunding(null);try {setData({ manager,prefix,rows:deriveWalletAddresses(manager,state,prefix) });} catch(e){setData(null);setError(e.message);}}
  function inspect(e) {e.preventDefault();setError('');setFunding(null);try{if(!rows)throw new Error('Derive wallet addresses first.');if(!/^(0|[1-9]\d*)$/.test(index))throw new Error('Use a nonnegative integer output index.');setFunding(inspectFundingTransaction({rawHex:raw.trim(),expectedTxid:txid.trim(),outputIndex:Number(index),walletScriptHex:rows[0].scriptHex}));}catch(e){setError(e.message);}}
  return <section className="card preview-card"><div className="step">05 / WALLET ADDRESS LAB</div><h2>Your wallet. Locally derived addresses.</h2><p>Derive three receive addresses and a change-address candidate from the public paths supplied by your connected wallet. No private keys are requested.</p>
    <label className="field">Address encoding<select value={prefix} onChange={e=>{setPrefix(e.target.value);setData(null);setFunding(null);setError('');}}><option value="bitcoincash">BCH mainnet · bitcoincash:</option><option value="bchtest">Development networks · bchtest:</option></select></label>
    <p className="fine">This selects the displayed prefix only. It does not switch or detect your wallet's network. Testnet and Chipnet share bchtest:. Do not deposit funds based on this lab.</p>
    <button type="button" disabled={state!=='connected'} onClick={derive}>Derive wallet addresses</button>
    {state!=='connected' && <p role="status">Connect your wallet above to enable derivation.</p>}
    {error && <p className="error" role="alert">{error}</p>}
    {rows && <div className="preview-result" aria-live="polite">{rows.map(row=><div className="output-row" key={`${row.path}:${row.index}`}><strong>{row.path} / index {row.index}</strong><code>{row.address}</code><details><summary>Inspect locking script</summary><code>{row.scriptHex}</code></details></div>)}<p className="fine">These are fixed indices for inspection, not freshly reserved payment addresses. Confirm receive / index 0 with your wallet before using it. Change ownership and recovery still need end-to-end signing verification.</p>
    <LiveFunding rows={rows} prefix={prefix}/><details><summary>Inspect an existing raw funding transaction (optional)</summary><p>Checks one output against receive / index 0. It does not look up balances or prove an output is unspent. Leave blank if this development wallet is unfunded.</p><form onSubmit={inspect}><label className="field">Expected transaction ID<input value={txid} onChange={e=>{setTxid(e.target.value);setFunding(null);}} autoComplete="off"/></label><label className="field">Output index<input value={index} onChange={e=>{setIndex(e.target.value);setFunding(null);}} inputMode="numeric"/></label><label className="field">Raw transaction hex<textarea value={raw} onChange={e=>{setRaw(e.target.value);setFunding(null);}} rows={4} spellCheck={false}/></label><button type="submit">Inspect raw output</button></form>{funding && <p role="status">Raw output matched: {funding.sats} sats.<br/><strong>Chain existence and unspent status remain unchecked.</strong></p>}</details></div>}
    <p className="fine">Blockchain requests occur only when you click Check BCH mainnet funding. The manual inspector stays local. Funding candidates are not connected to the simulated transaction builder; no signing or broadcast is added.</p>
  </section>;
}
