// Business identity must be started on the exact customer origin authorized by
// the Railway API. Temporary Vercel preview hosts cannot authorize merchant
// writes; use the live canonical domain rather than weaken backend CSRF checks.
export const BUSINESS_CANONICAL_URL='https://www.tip-link.xyz/business';
export function previewBusinessRedirect(hostname,pathname){
 if(typeof hostname!=='string'||typeof pathname!=='string')return null;
 const preview=/^tip-link-[a-z0-9-]+\.vercel\.app$/i.test(hostname);
 return preview&&pathname.replace(/\/$/,'')==='/business'?BUSINESS_CANONICAL_URL:null;
}
export function previewBusinessNavigation(hostname,next){
 return next==='business'?previewBusinessRedirect(hostname,'/business'):null;
}
