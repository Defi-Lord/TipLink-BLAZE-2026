import React,{useEffect,useRef,useState} from 'react';
import {useDeviceWallet,DeviceWalletSetup} from './DeviceWallet.jsx';
import {lookupDeviceWallet,prepareDeviceWalletExactSend} from './device-wallet-network.mjs';
import {openFundingRpc} from './funding-rpc.mjs';
import {DIRECT_FAST_PROVIDERS} from './direct-funding-monitor.mjs';
import {TransactionAction} from './TransactionAction.jsx';
import {formatBch} from './preview-core.mjs';

// The built-in TipLink wallet is the default source of funds. A transaction is
// prepared and locally VM-verified here, but NEVER broadcast until the user
// explicitly reviews and approves it in TransactionAction.
export function TipLinkWalletFunding({draft}){
 const device=useDeviceWallet();
 const [snapshot,setSnapshot]=useState(null),[plan,setPlan]=useState(null),
  [busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const live=useRef(true),active=useRef(null);
 useEffect(()=>{live.current=true;return()=>{live.current=false;active.current?.abort();};},[]);
 useEffect(()=>{active.current?.abort();setSnapshot(null);setPlan(null);setError('');setNotice('');},[device.wallet?.address,draft.contract.address]);
 async function review(){
  if(!device.wallet)return;
  const controller=new AbortController();
  active.current?.abort();active.current=controller;
  setBusy(true);setError('');setNotice('');setPlan(null);
  let rpc;const timeout=setTimeout(()=>controller.abort(),45000);
  try{
   rpc=await openFundingRpc({signal:controller.signal,providers:[...DIRECT_FAST_PROVIDERS],timeoutMs:10000});
   const next=await lookupDeviceWallet({wallet:device.wallet,rpc,signal:controller.signal});
   if(!live.current||controller.signal.aborted||active.current!==controller)return;
   setSnapshot(next);
   const prepared=prepareDeviceWalletExactSend({
    wallet:device.wallet,snapshot:next,destination:draft.contract.address,amountSats:draft.amountSats
   });
   setPlan(prepared);
  }catch(e){
   if(live.current&&!controller.signal.aborted&&active.current===controller)
    setError(e.message||'Could not safely prepare funding from this wallet. Nothing was sent.');
  }finally{
   clearTimeout(timeout);rpc?.close();
   if(live.current&&active.current===controller){setBusy(false);active.current=null;}
  }
 }
 const enoughTime=draft.contract.reclaimAfter*1000-Date.now()>3600000;
 return <section className="tiplink-internal-funding">
  <span className="tag">YOUR TIPLINK WALLET · DEFAULT</span>
  <h3>Pay straight from the wallet you already own.</h3>
  <p>One BCH wallet for receiving, sending and Business. Your protected keys stay on this device; each payment still needs your explicit approval.</p>
  {!device.ready?<p role="status">Finding your saved wallet…</p>:!device.wallet?
   <div className="notice">
    <p>{device.slot?'Your TipLink wallet is recognized. Unlock it with your password to send BCH.':'Create your TipLink wallet once, keep its encrypted backup, and fund its receiving address. You can then use it throughout TipLink.'}</p>
    <DeviceWalletSetup/>
   </div>:
   <div className="notice">
    <p><b>Saved wallet</b></p><code>{device.wallet.address}</code>
    <p>Fund this address if your balance is low. You don't need an external wallet connection to use a funded TipLink wallet.</p>
    {snapshot&&<p className="fine">Available confirmed: {formatBch(snapshot.confirmedSats)} BCH · Unconfirmed: {formatBch(snapshot.pendingSats)} BCH. Network fees are additional to the link amount.</p>}
    <p><b>Link funding:</b> exactly {formatBch(BigInt(draft.amountSats))} BCH</p>
    {!enoughTime&&<p className="error" role="alert">The link's recovery deadline is too close. Create a new link before funding it.</p>}
    <button type="button" className="primary full" disabled={busy||!enoughTime} onClick={review}>
     {busy?'Checking balance and preparing payment…':plan?'Refresh payment review':'Review payment from my TipLink wallet'}
    </button>
    {error&&<p className="error" role="alert">{error}</p>}
    {plan&&<div className="tiplink-wallet-review">
     <h3>Review exact payment</h3>
     <dl className="recipient-summary">
      <div><dt>Into the TipLink contract</dt><dd>{formatBch(plan.receiveSats)} BCH</dd></div>
      <div><dt>Network fee</dt><dd>{formatBch(plan.feeSats)} BCH</dd></div>
      <div><dt>Change returned to your wallet</dt><dd>{formatBch(plan.changeSats)} BCH</dd></div>
     </dl>
     <p className="fine">The recipient will claim through the private link, not this funding address. You must explicitly approve broadcasting the transaction below.</p>
     <TransactionAction kind="wallet-send" hex={plan.hex} wallet={device.wallet} plan={plan}
      onResult={value=>{if(value?.status==='submitted'||value?.status==='seen'||value?.status==='confirmed'){
       setNotice('Payment submitted. TipLink is now watching the same contract automatically; do not pay again.');
      }}}/>
    </div>}
    {notice&&<p className="notice" role="status">{notice}</p>}
    <button type="button" className="text-button" onClick={device.lock}>Lock this wallet</button>
   </div>}
 </section>;
}
