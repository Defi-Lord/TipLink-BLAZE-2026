import { binToHex, hexToBin, encodeTransaction, decodeTransaction, encodeCashAddress } from '@bitauth/libauth';
import { previewTip, validateRecipient } from './preview-core.mjs';

const MAX_MONEY = 21000000n * 100000000n;
function satoshis(value) {
  if (typeof value !== 'string' || !/^[1-9]\d*$/.test(value)) throw new Error('Funding values must be positive integer satoshi strings.');
  const result = BigInt(value);
  if (result > MAX_MONEY) throw new Error('Funding amount outside supported range.');
  return result;
}
// Offline construction only. Funding data is NOT checked against a blockchain.
export function buildUnsigned({ amountBch, addresses, changeAddress, utxos, feeRate = 1 }) {
  if (!Number.isSafeInteger(feeRate) || feeRate < 1 || feeRate > 100) throw new Error('Fee rate must be an integer from 1 to 100 sats/byte.');
  if (!Array.isArray(utxos) || utxos.length < 1 || utxos.length > 20) throw new Error('Provide one to twenty funding inputs.');
  const preview = previewTip(amountBch, addresses);
  const change = validateRecipient(changeAddress);
  if (preview.outputs.some(o => o.scriptHex === change.scriptHex)) throw new Error('Use a separate change script for this lab.');
  const seen = new Set();
  const sources = utxos.map(u => {
    if (!u || typeof u !== 'object' || ('token' in u) || ('tokenData' in u)) throw new Error('Token-bearing or token-labelled inputs are unsupported.');
    if (typeof u.txid !== 'string' || !/^[0-9a-fA-F]{64}$/.test(u.txid)) throw new Error('Invalid funding transaction ID.');
    if (!Number.isSafeInteger(u.index) || u.index < 0 || u.index > 0xffffffff) throw new Error('Invalid funding output index.');
    const key = `${u.txid.toLowerCase()}:${u.index}`;
    if (seen.has(key)) throw new Error('Duplicate funding outpoint.');
    seen.add(key);
    if (typeof u.scriptHex !== 'string' || !/^76a914[0-9a-fA-F]{40}88ac$/.test(u.scriptHex)) throw new Error('Only standard P2PKH funding scripts are supported.');
    return { txid: u.txid.toLowerCase(), index: u.index, valueSatoshis: satoshis(u.sats), lockingBytecode: hexToBin(u.scriptHex) };
  });
  const totalInputSats = sources.reduce((s, u) => s + u.valueSatoshis, 0n);
  if (totalInputSats > MAX_MONEY) throw new Error('Total funding outside supported range.');
  const outputs = preview.outputs.map(o => ({ lockingBytecode: hexToBin(o.scriptHex), valueSatoshis: o.sats }));
  const inputs = sources.map(u => ({ outpointTransactionHash: hexToBin(u.txid), outpointIndex: u.index, sequenceNumber: 0xffffffff, unlockingBytecode: new Uint8Array() }));
  const make = out => ({ version: 2, locktime: 0, inputs, outputs: out });
  // 108-byte conservative P2PKH unlocking-script placeholder for fee estimation.
  // It is NOT included in the unsigned serialization and is not a signature.
  const sizeFor = out => encodeTransaction({ ...make(out), inputs: inputs.map(i => ({ ...i, unlockingBytecode: new Uint8Array(108) })) }).length;
  const bareSize = sizeFor(outputs);
  const bareFee = BigInt(bareSize * feeRate);
  let minerFeeSats = bareFee;
  let changeSats = 0n;
  let estimatedSignedBytes = bareSize;
  const excess = totalInputSats - preview.totalSats - bareFee;
  if (excess < 0n) throw new Error('Insufficient funding including estimated miner fee.');
  if (excess > 0n) {
    const withChange = [...outputs, { lockingBytecode: hexToBin(change.scriptHex), valueSatoshis: 1000n }];
    estimatedSignedBytes = sizeFor(withChange);
    minerFeeSats = BigInt(estimatedSignedBytes * feeRate);
    changeSats = totalInputSats - preview.totalSats - minerFeeSats;
    if (changeSats < 1000n) throw new Error('Change is below the lab minimum. Rebuild with different funding; excess will not silently become a fee.');
    outputs.push({ lockingBytecode: hexToBin(change.scriptHex), valueSatoshis: changeSats });
  }
  const transaction = make(outputs);
  const unsignedHex = binToHex(encodeTransaction(transaction));
  return { mode: 'OFFLINE — UNVERIFIED FUNDING', unsignedHex, unsignedBytes: unsignedHex.length / 2,
    estimatedSignedBytes, feeRate, totalInputSats, recipientSats: preview.totalSats, minerFeeSats, changeSats,
    outputs: outputs.map((o,i) => ({ role: i < 3 ? preview.outputs[i].id : 'Change', sats: o.valueSatoshis, scriptHex: binToHex(o.lockingBytecode) })),
    sourceOutputs: sources.map(u => ({ valueSatoshis: u.valueSatoshis, lockingBytecode: binToHex(u.lockingBytecode) })) };
}

// Checks a candidate unsigned serialization against an independently retained plan.
// Does not establish input existence, ownership, signatures, confirmation or spendability.
export function verifyUnsigned(candidateHex, plan) {
  if (typeof candidateHex !== 'string' || !/^(?:[0-9a-fA-F]{2})+$/.test(candidateHex)) throw new Error('Invalid transaction hex.');
  const decoded = decodeTransaction(hexToBin(candidateHex));
  if (typeof decoded === 'string') throw new Error('Transaction could not be decoded.');
  if (binToHex(encodeTransaction(decoded)) !== plan.unsignedHex) throw new Error('Transaction differs from the reviewed plan.');
  if (decoded.inputs.some(i => i.unlockingBytecode.length !== 0)) throw new Error('Expected unsigned inputs.');
  const totalOutputs = decoded.outputs.reduce((s,o) => s+o.valueSatoshis, 0n);
  if (plan.totalInputSats - totalOutputs !== plan.minerFeeSats) throw new Error('Fee does not reconcile.');
  return true;
}

export function buildSimulation(amountBch, addresses) {
  const changeAddress = encodeCashAddress({ prefix:'bitcoincash', type:'p2pkh', payload:new Uint8Array(20).fill(4) }).address;
  const plan = buildUnsigned({ amountBch, addresses, changeAddress,
    utxos: [{ txid: '11'.repeat(32), index: 0, sats: '100000000', scriptHex: `76a914${'05'.repeat(20)}88ac` }], feeRate: 1 });
  verifyUnsigned(plan.unsignedHex, plan);
  return plan;
}
