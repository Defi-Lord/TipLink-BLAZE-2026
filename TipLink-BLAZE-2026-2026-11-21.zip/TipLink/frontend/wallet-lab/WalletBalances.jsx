import React,{useCallback,useEffect,useRef,useState} from 'react';
import {lookupDeviceWallet} from './device-wallet-network.mjs';
import {openFundingRpc} from './funding-rpc.mjs';
import {DIRECT_FAST_PROVIDERS} from './direct-funding-monitor.mjs';
import {formatBch} from './preview-core.mjs';
import {TransactionReaction} from './StatusReaction.jsx';
import {binToHex} from '@bitauth/libauth';
import {parsePublicTransaction} from './broadcast-core.mjs';

async function isExternalDeposit(txid,scriptHex,rpc){
 const raw=await rpc.call('blockchain.transaction.get',[txid,false]);
 const payment=parsePublicTransaction(typeof raw==='string'?raw.toLowerCase():raw);
 if(payment.txid!==txid||payment.tx.inputs.length>16)return false;
 const parents=new Map();
 for(const input of payment.tx.inputs){
  const parentId=binToHex(input.outpointTransactionHash);
  if(!parents.has(parentId)){
   const rawParent=await rpc.call('blockchain.transaction.get',[parentId,false]);
   const parent=parsePublicTransaction(typeof rawParent==='string'?rawParent.toLowerCase():rawParent);
   if(parent.txid!==parentId)return false;
   parents.set(parentId,parent.tx);
  }
  const output=parents.get(parentId).outputs[input.outpointIndex];
  if(!output||binToHex(output.lockingBytecode)===scriptHex)return false;
 }
 return true;
}

function readBalanceCheckpoint(address){
 try{
  const saved=JSON.parse(localStorage.getItem('tiplink-balance-checkpoint:'+address));
  if(!saved||!Number.isSafeInteger(saved.at)||Date.now()-saved.at>86400000||!/^\d{1,16}$/.test(saved.total)||!Array.isArray(saved.confirmed)||saved.confirmed.length>128||saved.confirmed.some(txid=>typeof txid!=='string'||! /^[a-f0-9]{64}$/.test(txid)))return null;
  return {address,confirmedSats:BigInt(saved.total),confirmed:new Set(saved.confirmed)};
 }catch{return null;}
}

export function useWalletBalance(address){
 const [result,setResult]=useState(null);
 const request=useRef(null);
 const previous=useRef(null);

 const refresh=useCallback(async()=>{
  if(!address||request.current||document.hidden||navigator.onLine===false)return;
  const controller=new AbortController();
  request.current=controller;
  const deadline=setTimeout(()=>controller.abort(),30000);
  let rpc;
  setResult(old=>({...((old?.address===address)?old:null),address,busy:true,error:''}));
  try{
   rpc=await openFundingRpc({signal:controller.signal,providers:DIRECT_FAST_PROVIDERS,timeoutMs:8000});
   const snapshot=await lookupDeviceWallet({wallet:{address,watchOnly:true},rpc,signal:controller.signal});
   if(controller.signal.aborted)return;
   const last=previous.current;
   const known=last?.confirmed??new Set();
   const confirmed=new Set(snapshot.coins.filter(coin=>coin.height>0).map(coin=>coin.txid));
   previous.current={address,confirmed,confirmedSats:snapshot.confirmedSats};
   try{
    if(!snapshot.unscannedOutputs)localStorage.setItem('tiplink-balance-checkpoint:'+address,JSON.stringify({at:Date.now(),total:String(snapshot.confirmedSats),confirmed:[...confirmed]}));
   }catch{}
   setResult(old=>({address,snapshot,busy:false,error:'',reaction:old?.address===address?old.reaction:0}));
   if(last?.address===address&&snapshot.confirmedSats>last.confirmedSats){
    const fresh=[...new Set(snapshot.coins.filter(coin=>coin.height>0&&!known.has(coin.txid)).map(coin=>coin.txid))].slice(0,4);
    for(const txid of fresh){
     let incoming=false;
     try{incoming=await isExternalDeposit(txid,snapshot.scriptHex,rpc);}catch{}
     if(controller.signal.aborted||request.current!==controller)break;
     if(incoming){setResult(old=>({...old,reaction:Date.now()}));break;}
    }
   }
  }catch(error){
   if(request.current===controller)setResult(old=>({...old,address,busy:false,error:controller.signal.aborted?'Balance check timed out.':error.message}));
  }finally{
   clearTimeout(deadline);
   rpc?.close();
   if(request.current===controller){request.current=null;setResult(old=>old?.address===address?{...old,busy:false}:old);}
  }
 },[address]);

 useEffect(()=>{
  previous.current=address?readBalanceCheckpoint(address):null;
  if(!address)return;
  void refresh();
  const interval=setInterval(refresh,20000);
  document.addEventListener('visibilitychange',refresh);
  window.addEventListener('online',refresh);
  return()=>{
   request.current?.abort();
   request.current=null;
   clearInterval(interval);
   document.removeEventListener('visibilitychange',refresh);
   window.removeEventListener('online',refresh);
  };
 },[address,refresh]);

 const current=result?.address===address?result:null;
 const reaction=current?.reaction;
 useEffect(()=>{
  if(!reaction)return;
  const timer=setTimeout(()=>setResult(old=>old?.reaction===reaction?{...old,reaction:0}:old),4500);
  return()=>clearTimeout(timer);
 },[reaction]);
 return {snapshot:current?.snapshot??null,busy:!!current?.busy,error:current?.error||'',reaction:current?.reaction||0,refresh};
}

export function WalletBalances({balance,connected,external,busy,onRefresh}){
 const {snapshot}=balance;
 return <>
  {balance.reaction>0&&<TransactionReaction key={balance.reaction} kind="claim"/>}
  <section className="home-balances" aria-label="Wallet balances">
   <div>
    <span>TipLink balance</span>
    <strong>{snapshot?formatBch(snapshot.confirmedSats)+' BCH':balance.busy?'Checking…':'—'}</strong>
    {snapshot?.pendingSats>0n&&<small>{formatBch(snapshot.pendingSats)} BCH pending</small>}
    {snapshot?.unscannedOutputs>0&&<small>Verified portion only</small>}
    {balance.error&&<small>Balance check delayed <button className="text-button" type="button" onClick={balance.refresh}>Retry</button></small>}
   </div>
   <div>
    <span>External BCH wallet</span>
    <strong>{external?formatBch(external.totalSats)+' BCH':connected?busy?'Checking…':'—':'Disconnected'}</strong>
    {connected&&<button type="button" className="text-button" disabled={busy} onClick={onRefresh}>{external?'Refresh checked balance':'Check confirmed BCH'}</button>}
    {external&&<small>Confirmed funding found</small>}
   </div>
  </section>
 </>;
}
