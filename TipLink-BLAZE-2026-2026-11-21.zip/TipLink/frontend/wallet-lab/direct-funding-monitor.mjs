// Foreground BCH payment monitor for direct Send links.
// A verified funding check may advance the UI, but a pending payment never may.
// All scheduling is sequential, bounded and cancellable: no overlapping lookups.
import {openFundingRpc} from './funding-rpc.mjs';
import {lookupDirectFunding,createDirectFundedHandoff} from './direct-funding.mjs';
import {paymentCheckIssue} from './payment-status.mjs';

export const DIRECT_POLL_MS=Object.freeze({
 unfunded:15000,
 unconfirmed:9000,
 retry:12000,
 retryMax:60000
});
export const DIRECT_FAST_PROVIDERS=Object.freeze(['proxy:nordic','proxy:imaginary']);
export const recipientCheckDelay=status=>status==='unconfirmed'?9000:status==='confirmed'?20000:12000;
export const receiptCheckDelay=status=>['unknown','submitted','seen'].includes(status)?10000:0;
export function directNextDelay(status,failures=0){
 if(status==='unconfirmed')return DIRECT_POLL_MS.unconfirmed;
 if(status==='unfunded')return DIRECT_POLL_MS.unfunded;
 return Math.min(DIRECT_POLL_MS.retryMax,DIRECT_POLL_MS.retry*Math.pow(2,Math.min(Math.max(0,failures-1),3)));
}
export function startDirectFundingMonitor({
 draft,encryptedDraft,
 onUpdate=()=>{},onFunded=()=>{},onDetected=null,
 openRpc=openFundingRpc,lookup=lookupDirectFunding,buildHandoff=createDirectFundedHandoff,
 schedule=(callback,delay)=>setTimeout(callback,delay),
 unschedule=handle=>clearTimeout(handle),
 isVisible=()=>typeof document==='undefined'||document.visibilityState==='visible',
 isOnline=()=>typeof navigator==='undefined'||navigator.onLine!==false
}={}){
 if(!draft?.contract?.address||!encryptedDraft)throw Error('A protected BCH funding draft is required.');
 let stopped=false,done=false,busy=false,rpc=null,timer=null,failures=0,lastStatus='unfunded';
 const abort=new AbortController();
 const emit=value=>{if(!stopped&&!done)onUpdate(value);};
 function clear(){if(timer!==null){unschedule(timer);timer=null;}}
 function queue(delay){
  clear();
  if(stopped||done||!isOnline()||!isVisible())return;
  timer=schedule(()=>{timer=null;void check();},delay);
 }
 async function check(){
  clear();
  if(stopped||done||busy)return;
  if(!isVisible()||!isOnline()){
   emit({phase:'paused',status:lastStatus,message:'Monitoring pauses while this tab is hidden or offline. It resumes automatically.'});
   return;
  }
  busy=true;
  emit({phase:'checking',status:lastStatus});
  let nextDelay=DIRECT_POLL_MS.unfunded;
  try{
   if(!rpc){
    // Two independent verified BCH full nodes, avoiding a slow or blocked
    // browser WebSocket relay. No wallet keys or transaction broadcasts.
    const connected=await openRpc({signal:abort.signal,providers:[...DIRECT_FAST_PROVIDERS],timeoutMs:10000});
    if(stopped||abort.signal.aborted){connected?.close?.();return;}
    rpc=connected;
   }
   const snapshot=await lookup({draft,rpc,signal:abort.signal});
   if(stopped||abort.signal.aborted)return;
   lastStatus=snapshot.status;
   failures=0;
   if(snapshot.status==='confirmed'||(snapshot.status==='unconfirmed'&&typeof onDetected==='function')){
    // A pending verified transaction can produce a *shareable* claim link.
    // Claiming still requires a fresh confirmed, unspent BCH output.
    const pending=snapshot.status==='unconfirmed';
    const handoff=buildHandoff({draft,encryptedDraft,snapshot,...(pending?{allowPending:true}:{})});
    if(stopped)return;
    done=true;
    rpc?.close?.();rpc=null;
    if(pending)onDetected(handoff);
    else onFunded(handoff);
    return;
   }
   emit({phase: snapshot.status==='unconfirmed'?'confirming':snapshot.status==='unfunded'?'watching':'attention',
    status:snapshot.status,message:snapshot.message,checkedAt:snapshot.checkedAt});
   // Stop on unsafe/ambiguous payment: don't suggest or start another send.
   if(snapshot.status!=='unfunded'&&snapshot.status!=='unconfirmed')return;
   nextDelay=directNextDelay(snapshot.status);
  }catch(error){
   if(stopped||abort.signal.aborted)return;
   failures++;
   rpc?.close?.();rpc=null;
   nextDelay=directNextDelay('error',failures);
   const issue=paymentCheckIssue(error);
   emit({phase:'error',status:lastStatus,issue:issue.code,
    message:issue.message,retryInMs:nextDelay});
  }finally{
   busy=false;
   if(!stopped&&!done&&lastStatus!=='wrong-amount'&&lastStatus!=='ambiguous')queue(nextDelay);
  }
 }
 function stop(){
  if(stopped)return;
  stopped=true;clear();abort.abort();rpc?.close?.();rpc=null;
 }
 function refresh(){
  if(stopped||done||busy)return;
  clear();
  if(!isVisible()||!isOnline()){
   emit({phase:'paused',status:lastStatus,message:'Automatic checks resume when this tab is visible and online.'});
   return;
  }
  return check();
 }
 // Starts automatically; explicit Check now is only an optional accelerator.
 queue(0);
 return {stop,refresh,isDone:()=>done,isBusy:()=>busy};
}
