import {parseBch,normalizeBchInput} from '../src/split.mjs';
import {validateRecipient,formatBch} from './preview-core.mjs';
const MAX=2100000000000000n;const MAX_LIFETIME=30*86400000;const MAX_DEMO_SATS=1000000n;
function text(value,max,label){if(typeof value!=='string'||value.length>max||/[\u0000-\u001f\u007f]/.test(value))throw Error(`${label} is invalid.`);return value.normalize('NFKC').replace(/\p{Cf}/gu,'').trim().slice(0,max);}
function amount(value){const sats=parseBch(normalizeBchInput(value));if(sats<1000n||sats>MAX)throw Error('Enter at least 0.00001 BCH, within the supported supply.');return sats;}
function id(){return Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');}
export function createLinkRecord({kind,amountBch,memo='',name='',address='',hours=24,now=Date.now()}){
 if(!['request','demo-send'].includes(kind))throw Error('Unsupported link type.');
 if(!Number.isSafeInteger(now)||!Number.isSafeInteger(hours)||hours<1||hours>720)throw Error('Choose an expiry from 1 hour to 30 days.');
 const sats=amount(amountBch);const recipient=kind==='request'?validateRecipient(address).address:undefined;
 return validateLinkRecord({v:1,id:id(),kind,sats:sats.toString(),memo:text(memo,160,'Memo'),name:text(name,60,'Name'),createdAt:now,expiresAt:now+hours*3600000,...(recipient?{address:recipient}:{})});
}
export function validateLinkRecord(value){
 if(!value||typeof value!=='object'||Array.isArray(value))throw Error('Invalid TipLink record.');
 const allowed=['v','id','kind','sats','memo','name','createdAt','expiresAt','address'];
 if(Object.keys(value).some(k=>!allowed.includes(k)))throw Error('Unexpected link fields.');
 if(value.v!==1||!['request','demo-send'].includes(value.kind)||typeof value.id!=='string'||!/^[a-f0-9]{32}$/.test(value.id))throw Error('Unsupported or malformed link.');
 if(typeof value.sats!=='string'||!/^[1-9]\d*$/.test(value.sats)||BigInt(value.sats)<1000n||BigInt(value.sats)>MAX)throw Error('Invalid link amount.');
 if(!Number.isSafeInteger(value.createdAt)||!Number.isSafeInteger(value.expiresAt)||value.createdAt<0||value.expiresAt<=value.createdAt||value.expiresAt-value.createdAt>MAX_LIFETIME)throw Error('Invalid link lifetime.');
 const common={v:1,id:value.id,kind:value.kind,sats:value.sats,memo:text(value.memo,160,'Memo'),name:text(value.name,60,'Name'),createdAt:value.createdAt,expiresAt:value.expiresAt};
 if(value.kind==='demo-send'){if('address'in value)throw Error('Demo links cannot specify real receiving addresses.');if(BigInt(value.sats)>MAX_DEMO_SATS)throw Error('Demo links are limited to 0.01 BCH.');return common;}
 return{...common,address:validateRecipient(value.address).address};
}
export function encodeLink(record){const normalized=validateLinkRecord(record);const payload=normalized.kind==='demo-send'?{...normalized,name:'',memo:''}:normalized;const bytes=new TextEncoder().encode(JSON.stringify(payload));return btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');}
export function decodeLink(encoded,now=Date.now()){if(typeof encoded!=='string'||encoded.length>2500||!/^[A-Za-z0-9_-]+$/.test(encoded))throw Error('Invalid or oversized link.');try{const binary=atob(encoded.replaceAll('-','+').replaceAll('_','/'));const record=validateLinkRecord(JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(Uint8Array.from(binary,c=>c.charCodeAt(0)))));if(record.createdAt>now+300000)throw Error('Link creation time is too far ahead.');return record;}catch(e){throw Error(`This TipLink cannot be opened: ${e.message}`);}}
export function decodePublicDemoLink(encoded,now=Date.now()){
 const record=decodeLink(encoded,now);
 if(record.kind!=='demo-send')throw Error('This old payment link cannot verify its receiving address. Ask for a new TipLink payment request.');
 return {...record,name:'',memo:''};
}
export function linkUrl(record,base){const url=new URL(base);if(!['https:','http:'].includes(url.protocol)||url.username||url.password)throw Error('Invalid link origin.');url.pathname='/';url.search='';url.hash=`tl=${encodeLink(record)}`;return url.href;}
export function isExpired(record,now=Date.now()){return now>=validateLinkRecord(record).expiresAt;}
export function paymentUri(record,now=Date.now()){const r=validateLinkRecord(record);if(r.kind!=='request')throw Error('Only payment requests have a payment URI.');if(now<r.createdAt||isExpired(r,now))throw Error('This payment request is not active.');const params=new URLSearchParams({amount:formatBch(BigInt(r.sats))});if(r.name)params.set('label',r.name);if(r.memo)params.set('message',r.memo);return`${r.address}?${params}`;}
function csvCell(value){let s=String(value??'');if(/^[\s]*[=+@-]/.test(s))s="'"+s;return'"'+s.replaceAll('"','""')+'"';}
export function exportRecords(records,now=Date.now()){return[['id','type','BCH','name','memo','created_utc','expires_utc','status'],...records.map(item=>{const r=validateLinkRecord(item);return[r.id,r.kind,formatBch(BigInt(r.sats)),r.name,r.memo,new Date(r.createdAt).toISOString(),new Date(r.expiresAt).toISOString(),r.kind==='request'?(isExpired(r,now)?'expired; payment status not checked':'payment status not checked'):'demo; no money sent'];})].map(row=>row.map(csvCell).join(',')).join('\r\n');}
