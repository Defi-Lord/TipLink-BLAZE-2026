import React from 'react';
export {shouldCelebrateTransaction} from './transaction-reaction.mjs';

const marks = {
  pending: 'M12 7v5l3 2',
  success: 'm6 12 4 4 8-8',
  warning: 'M12 7v6m0 3v.25',
  error: 'm8 8 8 8m0-8-8 8',
};

export function StatusMark({tone, className = ''}) {
  return <span className={`status-mark status-mark--${tone} ${className}`} aria-hidden="true">
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
      {tone === 'pending' && <circle cx="12" cy="12" r="9"/>}
      <path d={marks[tone]} pathLength="1"/>
    </svg>
  </span>;
}


// Celebration only for a new, provider-confirmed BCH status transition. The
// transaction journal remains the source of truth; this animation never claims
// a transaction succeeded from a mere network broadcast.
export function TransactionReaction({kind='claim'}){
 const labels={claim:'Money received',funding:'Link funded',recovery:'Money recovered','wallet-send':'Payment confirmed',checkout:'Matching payment confirmed'};
 return <div className="transaction-celebration" role="status" aria-live="polite">
  <div className="transaction-celebration-halo" aria-hidden="true"/>
  <span className="transaction-celebration-icon" aria-hidden="true">
   <svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12l5 5 11-11"/></svg>
  </span>
  <div className="transaction-celebration-particles" aria-hidden="true">
   {Array.from({length:12},(_,i)=><span key={i} style={{'--particle-index':i}}/>)}
  </div>
  <strong>{labels[kind]||'Transaction confirmed'}</strong>
  <p>Confirmed on the Bitcoin Cash network.</p>
 </div>;
}
