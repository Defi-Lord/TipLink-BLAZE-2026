import React, {useEffect, useMemo, useRef, useState} from 'react';
import makeQr from 'qrcode-generator';
import './wallet-chooser.css';

export function WalletChooser({screen, wallet, error, onExternal, onBack, onTipLink, onPair, onClose}) {
  const dialog = useRef(null);
  const heading = useRef(null);
  const [copyMessage, setCopyMessage] = useState('');
  const pairing = wallet.state === 'connecting' || wallet.state === 'reconnecting';
  const uri = pairing && wallet.uri?.startsWith('wiz://') ? wallet.uri : '';
  const qrValue = uri ? wallet.qrUri : '';
  const qr = useMemo(() => {
    if (!qrValue) return '';
    try {
      const code = makeQr(0, 'M');
      code.addData(qrValue, 'Alphanumeric');
      code.make();
      return code.createSvgTag({cellSize: 4, margin: 16, scalable: true});
    } catch {
      return '';
    }
  }, [qrValue]);
  const pairingError = error || (wallet.state === 'disconnected' && !uri ? 'The wallet disconnected. Try pairing again.' : '');
  const title = screen === 'choose' ? 'Choose your wallet' : 'Connect an external wallet';

  useEffect(() => {
    const modal = dialog.current;
    if (screen && !modal.open) modal.showModal();
    if (!screen && modal.open) modal.close();
    if (screen) heading.current.focus();
  }, [screen]);

  useEffect(() => {
    setCopyMessage('');
  }, [uri, screen]);

  async function copyPairingCode() {
    try {
      await navigator.clipboard.writeText(uri);
      setCopyMessage('Pairing link copied.');
    } catch {
      setCopyMessage('Copy is unavailable. Use the QR code to pair.');
    }
  }

  return (
    <dialog ref={dialog} className="wallet-chooser" aria-labelledby="wallet-chooser-title"
      onCancel={event => { event.preventDefault(); onClose(); }}
      onClick={event => { if (event.target === dialog.current) onClose(); }}>
      <div className="wallet-chooser-body">
        <header className="wallet-chooser-header">
          <h2 id="wallet-chooser-title" ref={heading} tabIndex={-1}>{title}</h2>
          <button type="button" className="sheet-close" onClick={onClose} aria-label="Close wallet chooser">×</button>
        </header>
        {screen === 'choose' && <>
          <button type="button" className="wallet-choice" onClick={onTipLink}>
            <strong>Open my TipLink wallet</strong>
            <span>Create, unlock, or restore the BCH wallet on this device.</span>
          </button>
          <button type="button" className="wallet-choice" onClick={onExternal}>
            <strong>Connect an external wallet</strong>
            <span>Pair a compatible BCH wallet to fund a send link.</span>
          </button>
        </>}
        {screen === 'external' && <>
          <p>Open the WizardConnect scanner in your BCH wallet, scan this code, and approve the connection there.</p>
          {uri ? <>
            {qr ? (
              <div className="wallet-pairing-qr" role="img" aria-label="WizardConnect pairing QR code"
                dangerouslySetInnerHTML={{__html: qr}}/>
            ) : (
              <p role="alert">The QR code could not be displayed. Open your wallet app or copy the pairing link.</p>
            )}
            <p>Pairing on the same phone? Try opening your wallet app.</p>
            <a className="primary full" href={uri}>Open wallet app</a>
            <button type="button" className="secondary full" onClick={copyPairingCode}>Copy pairing link</button>
            {copyMessage && <p role="status">{copyMessage}</p>}
          </> : pairingError ? (
            <>
              <p className="error" role="alert">{pairingError}</p>
              <button type="button" className="primary full" onClick={onPair}>Retry pairing</button>
            </>
          ) : (
            <p role="status">{wallet.state === 'reconnecting' ? 'Reconnecting to your wallet…' : 'Generating your QR code…'}</p>
          )}
          {onBack && !pairing && <button type="button" className="text-button" onClick={onBack}>Back to wallet choices</button>}
        </>}
      </div>
    </dialog>
  );
}
