import React, {useState} from 'react';
import {Brand} from './app-experience.jsx';
import {LinkArtwork} from './HomeScreen.jsx';
import {readTransactionReceipts, transactionStatusLabel} from './transaction-journal.mjs';

const shortcuts = [
  {page: 'wallet', icon: 'wallet', label: 'Wallet'},
  {page: 'activity', icon: 'activity', label: 'Activity'},
  {page: 'help', icon: 'help', label: 'Help'},
];

const receiptTitles = {
  funding: 'Link funding',
  claim: 'Incoming payment',
  recovery: 'Recovery',
  'wallet-send': 'Wallet payment',
};

export function MobileDashboard({now, navigate, onHelp, Icon}) {
  const [{receipts, unavailable}] = useState(() => {
    try {
      return {receipts: readTransactionReceipts(), unavailable: false};
    } catch {
      return {receipts: [], unavailable: true};
    }
  });

  const activity = receipts.map(receipt => ({
    id: receipt.txid,
    title: receiptTitles[receipt.kind] ?? 'Transaction',
    time: receipt.createdAt,
    detail: transactionStatusLabel(receipt, now),
  })).sort((first, second) => second.time - first.time).slice(0, 3);

  return <div className="mobile-home payments-home">
    <section className="payments-welcome" aria-labelledby="dashboard-intro">
      <div className="payments-mark"><Brand markOnly/></div>
      <div className="payments-intro">
        <h1 id="dashboard-intro" tabIndex={-1}>Send a little.<br/><em>Mean a lot.</em></h1>
        <p>Send and request Bitcoin Cash with a link.</p>
      </div>
      <div className="payments-art"><LinkArtwork priority/></div>
    </section>
    <div className="payments-actions">
      <button type="button" className="primary" onClick={() => navigate('send')}><Icon name="send"/>Send money</button>
      <button type="button" className="secondary" onClick={() => navigate('request')}><Icon name="links"/>Request</button>
    </div>
    <div className="payments-network"><span><i aria-hidden="true"/>Bitcoin Cash</span><small>Mainnet</small></div>
    <section className="payments-shortcuts" aria-labelledby="payments-shortcuts-title">
      <h2 id="payments-shortcuts-title">At a glance</h2>
      <div className="payments-tiles">
        {shortcuts.map(({page, icon, label}) => <button key={page} type="button"
          aria-haspopup={page === 'help' ? 'dialog' : undefined}
          onClick={page === 'help' ? onHelp : () => navigate(page)}>
          <span className="payments-tile-icon"><Icon name={icon}/></span><span>{label}</span>
        </button>)}
      </div>
    </section>
    <section className="dashboard-activity" aria-labelledby="dashboard-activity">
      <div className="dashboard-section-heading">
        <h2 id="dashboard-activity">Recent activity</h2>
        <button type="button" onClick={() => navigate('activity')}>View all <Icon name="arrow" size={16}/></button>
      </div>
      {activity.length > 0 && <ul>
        {activity.map(item => <li key={item.id}>
          <span className="dashboard-activity-icon"><Icon name="activity"/></span>
          <div><strong>{item.title}</strong><small>{item.detail}</small></div>
        </li>)}
      </ul>}
      {(unavailable || !activity.length) && <div className="dashboard-empty">
        <span className="dashboard-activity-icon"><Icon name="activity"/></span>
        <div>
          <strong>{unavailable ? 'Receipts unavailable' : 'No transactions yet'}</strong>
          <small>{unavailable ? 'Open Activity to check your saved receipts.' : 'BCH transactions saved on this device will appear here.'}</small>
        </div>
      </div>}
    </section>
  </div>;
}
