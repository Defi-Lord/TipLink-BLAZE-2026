// Private drafts stay in caller memory. Nothing here accesses storage, network or logs.
import {generatePrivateKey,secp256k1,binToHex,hexToBin} from '@bitauth/libauth';
import {parseBch,normalizeBchInput} from '../src/split.mjs';
import {createEnvelopeContract,validateEnvelopeContract} from './envelope-core.mjs';
const MAX=2100000000000000n;const ITERATIONS=600000;
const exact=(object,keys)=>object&&typeof object==='object'&&!Array.isArray(object)&&Object.keys(object).length===keys.length&&Object.keys(object).every(k=>keys.includes(k));
function publicKey(key){if(typeof key!=='string'||!/^[a-f0-9]{64}$/.test(key))throw Error('Invalid private draft key.');const p=secp256k1.derivePublicKeyCompressed(hexToBin(key));if(typeof p==='string')throw Error('Invalid private draft key.');return binToHex(p);}
export function createEnvelopeDraft({amountBch,hours=24,now=Date.now()}){
 const sats=parseBch(normalizeBchInput(amountBch));if(sats<10000n||sats>MAX)throw Error('Wallet preparation needs at least 0.0001 BCH.');
 if(!Number.isSafeInteger(now)||now<0||!Number.isSafeInteger(hours)||hours<1||hours>720)throw Error('Choose a recovery delay from 1 hour to 30 days.');
 const claimPrivateKey=binToHex(generatePrivateKey());let recoveryPrivateKey=binToHex(generatePrivateKey());while(recoveryPrivateKey===claimPrivateKey)recoveryPrivateKey=binToHex(generatePrivateKey());
 const contract=createEnvelopeContract({claimPublicKey:publicKey(claimPrivateKey),senderPublicKey:publicKey(recoveryPrivateKey),reclaimAfter:Math.floor(now/1000)+hours*3600});
 return validateEnvelopeDraft({type:'tiplink-private-draft',version:1,network:'bitcoincash',createdAt:now,amountSats:sats.toString(),claimPrivateKey,recoveryPrivateKey,contract});
}
export function validateEnvelopeDraft(value){
 if(!exact(value,['type','version','network','createdAt','amountSats','claimPrivateKey','recoveryPrivateKey','contract'])||value.type!=='tiplink-private-draft'||value.version!==1||value.network!=='bitcoincash')throw Error('Unsupported private envelope draft.');
 if(!Number.isSafeInteger(value.createdAt)||value.createdAt<0||value.createdAt>8640000000000000||typeof value.amountSats!=='string'||!/^[1-9]\d*$/.test(value.amountSats)||BigInt(value.amountSats)<10000n||BigInt(value.amountSats)>MAX)throw Error('Invalid draft amount or creation time.');
 if(!exact(value.contract,['version','network','claimPublicKey','senderPublicKey','reclaimAfter','redeemHex','scriptHex','address']))throw Error('Unsupported contract fields.');
 const contract=validateEnvelopeContract(value.contract);
 if(publicKey(value.claimPrivateKey)!==contract.claimPublicKey||publicKey(value.recoveryPrivateKey)!==contract.senderPublicKey)throw Error('Draft key does not match its contract.');
 const interval=contract.reclaimAfter-Math.floor(value.createdAt/1000);if(interval<3600||interval>30*86400)throw Error('Invalid draft recovery interval.');
 return {...value,contract};
}
function password(value){if(typeof value!=='string'||value.length<12||value.length>256)throw Error('Use a backup passphrase of 12–256 characters.');return new TextEncoder().encode(value);}
const b64=bytes=>btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
function unb64(value,max){if(typeof value!=='string'||value.length>max||!/^[A-Za-z0-9_-]+$/.test(value))throw Error('Invalid encrypted backup encoding.');let bytes;try{bytes=Uint8Array.from(atob(value.replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0));}catch{throw Error('Invalid encrypted backup encoding.');}if(b64(bytes)!==value)throw Error('Noncanonical backup encoding.');return bytes;}
const aad=new TextEncoder().encode('TipLink encrypted private draft v1 | AES-256-GCM | PBKDF2-SHA256 | 600000');
async function encryptionKey(passphrase,salt){const material=await crypto.subtle.importKey('raw',password(passphrase),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',hash:'SHA-256',salt,iterations:ITERATIONS},material,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);}
export async function encryptEnvelopeDraft(draft,passphrase){const value=validateEnvelopeDraft(draft);const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12));const key=await encryptionKey(passphrase,salt);const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:aad},key,new TextEncoder().encode(JSON.stringify(value)));return{type:'tiplink-encrypted-draft',version:1,kdf:'PBKDF2-SHA256',iterations:ITERATIONS,cipher:'AES-256-GCM',salt:b64(salt),iv:b64(iv),ciphertext:b64(new Uint8Array(ciphertext))};}
export async function decryptEnvelopeDraft(backup,passphrase){
 if(!exact(backup,['type','version','kdf','iterations','cipher','salt','iv','ciphertext'])||backup.type!=='tiplink-encrypted-draft'||backup.version!==1||backup.kdf!=='PBKDF2-SHA256'||backup.iterations!==ITERATIONS||backup.cipher!=='AES-256-GCM')throw Error('Unsupported encrypted draft format.');
 const salt=unb64(backup.salt,24),iv=unb64(backup.iv,16),ciphertext=unb64(backup.ciphertext,12000);if(salt.length!==16||iv.length!==12||ciphertext.length<16)throw Error('Invalid encrypted draft size.');
 const key=await encryptionKey(passphrase,salt);let raw;try{raw=await crypto.subtle.decrypt({name:'AES-GCM',iv,additionalData:aad},key,ciphertext);}catch{throw Error('Backup could not be unlocked. Check the passphrase and file.');}
 let value;try{value=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(raw));}catch{throw Error('Decrypted draft is malformed.');}return validateEnvelopeDraft(value);
}
