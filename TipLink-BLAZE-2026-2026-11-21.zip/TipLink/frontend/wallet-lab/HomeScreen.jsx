import React from 'react';
function Symbol({name,size=22}){const paths={send:'M3 3l19 9-19 9 4-9z M7 12h15',link:'M10 13a5 5 0 007 0l4-4a5 5 0 00-7-7l-2 2 M14 11a5 5 0 00-7 0l-4 4a5 5 0 007 7l2-2',gift:'M3 8h18v4H3z M5 12v9h14v-9 M12 8v13 M12 8H8a3 3 0 113-4z M12 8h4a3 3 0 10-3-4z',note:'M5 3h10l4 4v14H5z M15 3v5h4 M8 12h8 M8 16h6',people:'M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2 M13 7a4 4 0 11-8 0 4 4 0 018 0 M17 4a4 4 0 010 8 M22 21v-2a4 4 0 00-3-4',arrow:'M5 12h14 M14 7l5 5-5 5',info:'M12 11v6 M12 7v.1 M21 12a9 9 0 11-18 0 9 9 0 0118 0',message:'M3 4h18v13H8l-5 4z M7 9h.1 M12 9h.1 M17 9h.1'};return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name]||paths.link}/></svg>;}
export function LinkArtwork({className='',priority=false}){return <img className={`link-artwork ${className}`} src="/midnight/link-sculpture.webp" width="1536" height="1024" alt="" aria-hidden="true" decoding="async" loading={priority?'eager':'lazy'} fetchPriority={priority?'high':'auto'}/>;}
export function HomeScreen({onSend,onRequest,onWallet,onActivity}){
 return <div className="midnight-home">
  <section className="home-hero" aria-labelledby="home-title">
   <div className="home-intro">
    <h1 id="home-title" tabIndex={-1}>Send a little.<br/>Mean <span>a lot.</span></h1>
    <p className="home-summary">Send and request Bitcoin Cash with a link.</p>
    <div className="home-actions">
     <button className="primary" onClick={onSend}><Symbol name="send" size={20}/>Send money</button>
     <button className="secondary" onClick={onRequest}><Symbol name="link" size={20}/>Request payment</button>
    </div>
   </div>
   <div className="home-visual"><LinkArtwork priority/></div>
  </section>
  <div className="home-panels">
   <section className="panel home-ways">
    <h2>Your wallet</h2>
    <p>Receive and manage BCH on this device.</p>
    <button className="secondary" onClick={onWallet}>Open wallet <Symbol name="arrow" size={17}/></button>
   </section>
   <section className="panel home-ways">
    <h2>Activity</h2>
    <p>Check your saved BCH transaction receipts.</p>
    <button className="secondary" onClick={onActivity}>View activity <Symbol name="arrow" size={17}/></button>
   </section>
  </div>
 </div>;
}
