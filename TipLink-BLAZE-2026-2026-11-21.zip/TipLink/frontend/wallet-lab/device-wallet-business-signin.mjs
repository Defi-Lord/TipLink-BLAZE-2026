// Sign *only* an explicitly approved TipLink Business login challenge with the
// unlocked non-custodial wallet. No transaction signing or wallet keys leave the app.
import {secp256k1,sha256,utf8ToBin,bigIntToCompactUint,hexToBin} from '@bitauth/libauth';
import {validateDeviceWallet} from './device-wallet-core.mjs';
export function bitcoinMessageHash(message){
 if(typeof message!=='string'||message.length>5000)throw Error('Invalid BCH message challenge.');
 const bytes=utf8ToBin(message);
 const prefix=utf8ToBin('\x18Bitcoin Signed Message:\n');
 return sha256.hash(sha256.hash(Uint8Array.from([...prefix,...bigIntToCompactUint(BigInt(bytes.length)),...bytes])));
}
export function signDeviceWalletBusinessChallenge({wallet,challenge,origin,now=Date.now()}){
 const value=validateDeviceWallet(wallet);
 if(!challenge||typeof challenge.id!=='string'||typeof challenge.message!=='string'||typeof challenge.expiresAt!=='string'||
  typeof origin!=='string'||!/^https?:\/\//.test(origin)||
  !Number.isSafeInteger(now)||Date.parse(challenge.expiresAt)<=now||
  Date.parse(challenge.expiresAt)>now+300000)throw Error('Business challenge expired or invalid. Request a new one.');
 if(challenge.address!==undefined&&challenge.address!==value.address)throw Error('Business challenge address does not match your saved wallet.');
 const message=challenge.message;
 if(!message.startsWith('TipLink Business\n\n')||
  !message.includes('\nOrigin: '+origin+'\n')||
  !message.includes('\nAddress: '+value.address+'\n')||
  !message.includes('\nNetwork: Bitcoin Cash mainnet\n')||
  !message.includes('\nPurpose: Sign in or create a TipLink merchant account.\n')&&!message.includes('\nPurpose: Add wallet sign-in to merchant account ')||
  !message.includes('\nChallenge ID: '+challenge.id+'\n')||
  !message.includes('\nExpires at: '+challenge.expiresAt+'\n')||
  !message.includes('This is a sign-in message, not a payment.'))
  throw Error('The Business sign-in challenge is not authentic for this wallet and origin.');
 const result=secp256k1.signMessageHashRecoverableCompact(hexToBin(value.privateKey),bitcoinMessageHash(message));
 if(typeof result==='string')throw Error('Could not sign the Business login challenge.');
 const packed=Uint8Array.from([31+result.recoveryId,...result.signature]);
 return btoa(String.fromCharCode(...packed));
}
