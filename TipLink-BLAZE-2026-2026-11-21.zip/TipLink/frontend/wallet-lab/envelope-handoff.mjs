// Claim secrets stay in URL fragments and caller memory. No storage, telemetry or network.
import {binToHex,hexToBin,secp256k1,decodeTransaction,encodeTransaction} from '@bitauth/libauth';
import {validateEnvelopeContract} from './envelope-core.mjs';
import {validateEnvelopeDraft,decryptEnvelopeDraft} from './envelope-draft.mjs';
import {verifySignedEnvelopeFunding} from './envelope-funding.mjs';
const MAX=2100000000000000n;
const exact=(o,keys)=>o&&typeof o==='object'&&!Array.isArray(o)&&Object.keys(o).length===keys.length&&Object.keys(o).every(k=>keys.includes(k));
const hex=(s,max)=>typeof s==='string'&&s.length<=max&&/^(?:[a-f0-9]{2})+$/.test(s);
const money=s=>typeof s==='string'&&/^[1-9]\d{0,15}$/.test(s)&&BigInt(s)<=MAX;
export function validateClaimTransfer(value){
 if(!exact(value,['type','version','network','contract','utxo','claimPrivateKey'])||value.type!=='tiplink-claim'||value.version!==1||value.network!=='bitcoincash')throw Error('Unsupported claim link.');
 if(!exact(value.contract,['version','network','claimPublicKey','senderPublicKey','reclaimAfter','redeemHex','scriptHex','address']))throw Error('Unexpected claim contract fields.');
 const contract=validateEnvelopeContract(value.contract),u=value.utxo;
 if(!exact(u,['txid','index','sats','scriptHex'])||typeof u.txid!=='string'||!/^[a-f0-9]{64}$/.test(u.txid)||!Number.isSafeInteger(u.index)||u.index<0||u.index>0xffffffff||!money(u.sats)||BigInt(u.sats)<10000n||u.scriptHex!==contract.scriptHex)throw Error('Invalid claim funding details.');
 if(typeof value.claimPrivateKey!=='string'||!/^[a-f0-9]{64}$/.test(value.claimPrivateKey))throw Error('Invalid claim key.');
 const pub=secp256k1.derivePublicKeyCompressed(hexToBin(value.claimPrivateKey));
 if(typeof pub==='string'||binToHex(pub)!==contract.claimPublicKey)throw Error('Claim key does not match this envelope.');
 return {type:'tiplink-claim',version:1,network:'bitcoincash',contract,utxo:{...u},claimPrivateKey:value.claimPrivateKey};
}
const encode=value=>btoa(String.fromCharCode(...new TextEncoder().encode(JSON.stringify(value)))).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
export function encodeClaimTransfer(value){return encode(validateClaimTransfer(value));}
export function decodeClaimTransfer(encoded){
 if(typeof encoded!=='string'||encoded.length>2400||!/^[A-Za-z0-9_-]+$/.test(encoded))throw Error('Invalid or oversized claim link.');
 let value;try{const raw=atob(encoded.replaceAll('-','+').replaceAll('_','/'));if(btoa(raw).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'')!==encoded)throw Error();value=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(Uint8Array.from(raw,c=>c.charCodeAt(0))));}catch{throw Error('Malformed claim link.');}
 return validateClaimTransfer(value);
}
export function claimTransferUrl(value,base){
 const url=new URL(base);if(!['https:','http:'].includes(url.protocol)||url.username||url.password)throw Error('Unsupported claim link origin.');
 const local=['localhost','127.0.0.1','[::1]'].includes(url.hostname);if(url.protocol!=='https:'&&!local)throw Error('Public claim links require HTTPS.');
 url.pathname='/';url.search='';url.hash='claim='+encodeClaimTransfer(value);return url.href;
}
function transferFor(draft,verified){return validateClaimTransfer({type:'tiplink-claim',version:1,network:'bitcoincash',contract:draft.contract,utxo:{txid:verified.txid,index:0,sats:draft.amountSats,scriptHex:draft.contract.scriptHex},claimPrivateKey:draft.claimPrivateKey});}
function checkEnvelopeOutput(plan,draft){const output=plan.transaction.outputs[0];if(!output||output.token!==undefined||output.valueSatoshis!==BigInt(draft.amountSats)||binToHex(output.lockingBytecode)!==draft.contract.scriptHex)throw Error('Funding output does not match the saved envelope.');}
function proofFor(plan){return{unsignedHex:plan.unsignedHex,estimatedSignedBytes:plan.estimatedSignedBytes,totalInputSats:plan.totalInputSats.toString(),feeSats:plan.feeSats.toString(),sourceOutputs:plan.sourceOutputs.map(o=>({scriptHex:binToHex(o.lockingBytecode),sats:o.valueSatoshis.toString()}))};}
export function planFromProof(p){
 if(!exact(p,['unsignedHex','estimatedSignedBytes','totalInputSats','feeSats','sourceOutputs'])||!hex(p.unsignedHex,40000)||!Number.isSafeInteger(p.estimatedSignedBytes)||p.estimatedSignedBytes<1||p.estimatedSignedBytes>20000||!money(p.totalInputSats)||!money(p.feeSats)||!Array.isArray(p.sourceOutputs)||p.sourceOutputs.length<1||p.sourceOutputs.length>20)throw Error('Invalid saved funding proof.');
 const transaction=decodeTransaction(hexToBin(p.unsignedHex));if(typeof transaction==='string'||binToHex(encodeTransaction(transaction))!==p.unsignedHex||transaction.version!==2||transaction.locktime!==0||transaction.inputs.length!==p.sourceOutputs.length||transaction.outputs.length<1||transaction.outputs.length>2||transaction.outputs.some(o=>o.token!==undefined))throw Error('Invalid saved funding transaction.');
 const sourceOutputs=p.sourceOutputs.map(o=>{if(!exact(o,['scriptHex','sats'])||!/^76a914[a-f0-9]{40}88ac$/.test(o.scriptHex)||!money(o.sats))throw Error('Invalid saved funding source.');return{lockingBytecode:hexToBin(o.scriptHex),valueSatoshis:BigInt(o.sats)};});
 if(sourceOutputs.reduce((s,o)=>s+o.valueSatoshis,0n)!==BigInt(p.totalInputSats))throw Error('Saved funding source values do not reconcile.');
 if(transaction.inputs.some(i=>i.unlockingBytecode.length||i.sequenceNumber!==0xffffffff))throw Error('Invalid unsigned funding inputs.');
 return{...p,transaction,totalInputSats:BigInt(p.totalInputSats),feeSats:BigInt(p.feeSats),sourceOutputs};
}
export function createApprovedHandoff({draft,encryptedDraft,signedHex,plan}){
 const d=validateEnvelopeDraft(draft);checkEnvelopeOutput(plan,d);
 // Recheck returned bytes rather than trusting the UI's signed status or txid.
 const verified=verifySignedEnvelopeFunding(signedHex,plan);
 const proof=proofFor(plan);planFromProof(proof);
 if(!encryptedDraft||encryptedDraft.type!=='tiplink-encrypted-draft')throw Error('Save the encrypted recovery draft first.');
 return{draft:d,transfer:transferFor(d,verified),backup:{type:'tiplink-approved-transfer',version:1,encryptedDraft:structuredClone(encryptedDraft),signedFundingHex:verified.signedHex,proof},status:'APPROVED LOCALLY; FUNDING NOT CHECKED ON CHAIN'};
}
export async function restoreApprovedHandoff(backup,password){
 if(!exact(backup,['type','version','encryptedDraft','signedFundingHex','proof'])||backup.type!=='tiplink-approved-transfer'||backup.version!==1||!hex(backup.signedFundingHex,40000))throw Error('Unsupported approved transfer file.');
 const plan=planFromProof(backup.proof);const draft=await decryptEnvelopeDraft(backup.encryptedDraft,password);checkEnvelopeOutput(plan,draft);
 const verified=verifySignedEnvelopeFunding(backup.signedFundingHex,plan);
 return{draft,transfer:transferFor(draft,verified),backup,status:'RESTORED LOCALLY; FUNDING NOT CHECKED ON CHAIN'};
}
