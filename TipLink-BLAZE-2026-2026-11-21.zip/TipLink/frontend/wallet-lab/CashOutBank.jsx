import {StatusMark} from './StatusReaction.jsx';
import React, {useEffect, useRef, useState} from 'react';
import {createBankLookup} from './cash-out-bank-client.mjs';

export function CashOutBank() {
  const [banks, setBanks] = useState([]), [bankId, setBankId] = useState(''), [number, setNumber] = useState('');
  const [lookup, setLookup] = useState({phase: 'idle', result: null, message: ''});
  const [listBusy, setListBusy] = useState(true), [listError, setListError] = useState(''), [reload, setReload] = useState(0), [now, setNow] = useState(Date.now());
  const resolver = useRef(null);
  function resolve(bank, accountNumber) {
    if (!resolver.current) resolver.current = createBankLookup({onChange: setLookup});
    resolver.current.update(bank, accountNumber);
  }
  useEffect(() => () => resolver.current?.dispose(), []);
  useEffect(() => {
    const controller = new AbortController(); setListBusy(true); setListError('');
    async function load() {
      try {
        const response = await fetch('/api/v1/merchant/cash-out/banks', {credentials: 'same-origin', cache: 'no-store', referrerPolicy: 'no-referrer', signal: controller.signal});
        const data = await response.json();
        if (!response.ok) throw Error(response.status === 401 || response.status === 403 ? 'Sign in through Business, then return here.' : typeof data.error === 'string' ? data.error : 'The bank list is unavailable.');
        if (data.environment !== 'sandbox' || data.payoutVerified !== false || !Array.isArray(data.items) || !data.items.length || data.items.length > 1000 || data.items.some(bank => typeof bank.id !== 'string' || !/^\d{1,16}$/.test(bank.id) || typeof bank.name !== 'string' || !bank.name.trim() || bank.name.length > 120) || new Set(data.items.map(bank => bank.id)).size !== data.items.length) throw Error('The bank list could not be checked.');
        if (!controller.signal.aborted) setBanks(data.items);
      } catch (error) {if (!controller.signal.aborted) setListError(error.message === 'Failed to fetch' ? 'Could not load banks. Try again.' : error.message);}
      finally {if (!controller.signal.aborted) setListBusy(false);}
    }
    load(); return () => controller.abort();
  }, [reload]);
  useEffect(() => {if (!lookup.result) return; setNow(Date.now()); const timer = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(timer);}, [lookup.result]);
  const expired = lookup.result && now >= Date.parse(lookup.result.expiresAt);
  const accountName = !expired && lookup.phase === 'resolved' ? lookup.result.accountName : '';
  const selected = banks.find(bank => bank.id === bankId);
  return <section className="cash-preview cash-bank" aria-labelledby="cash-bank-title">
    <h2 id="cash-bank-title">Look up a bank account</h2>
    <p>Select your bank and enter your account number. The account name loads automatically.</p>
    <div className="cash-bank-fields">
      <label htmlFor="cash-bank-id">Bank</label>
      <select id="cash-bank-id" value={bankId} disabled={listBusy || !banks.length} onChange={event => {const id = event.target.value; setBankId(id); resolve(banks.find(bank => bank.id === id), number);}}><option value="">{listBusy ? 'Loading banks…' : 'Choose your bank'}</option>{banks.map(bank => <option key={bank.id} value={bank.id}>{bank.name}</option>)}</select>
      <label htmlFor="cash-bank-number">Account number</label>
      <input id="cash-bank-number" value={number} onChange={event => {const value = event.target.value.replace(/\D/g, '').slice(0, 10); setNumber(value); resolve(selected, value);}} inputMode="numeric" maxLength={10} autoComplete="off" aria-describedby="cash-bank-help" />
      <small id="cash-bank-help">Enter all 10 digits to load the account name.</small>
      <label htmlFor="cash-bank-name">Account name</label>
      <input id="cash-bank-name" readOnly value={accountName} placeholder={lookup.phase === 'loading' ? 'Looking up account name…' : 'Account name appears here'} aria-busy={lookup.phase === 'loading'} />
    </div>
    {listError && <><p className="cash-preview-error" role="alert">{listError}</p><button className="cash-sandbox-secondary" type="button" onClick={() => setReload(value => value + 1)}>Retry loading banks</button></>}
    <div role="status" aria-live="polite">
      {lookup.phase === 'loading' && <p className="status-reaction"><StatusMark tone="pending" className="status-mark--compact"/>Looking up account name…</p>}
      {accountName && <p className="status-reaction"><StatusMark tone="success" className="status-mark--compact"/>Account name returned by Breet sandbox.</p>}
      {expired && <p>This lookup has expired. Refresh the account name before relying on it.</p>}
    </div>
    {lookup.message && <p className="cash-preview-error status-reaction" role="alert"><StatusMark tone="warning" className="status-mark--compact"/>{lookup.message}</p>}
    {(lookup.phase === 'error' || expired) && <button className="cash-sandbox-secondary" type="button" onClick={() => resolve(selected, number)}>Retry account lookup</button>}
    <p className="cash-preview-note">Sandbox lookup only. Account ownership and live bank payouts remain unverified.</p>
  </section>;
}
