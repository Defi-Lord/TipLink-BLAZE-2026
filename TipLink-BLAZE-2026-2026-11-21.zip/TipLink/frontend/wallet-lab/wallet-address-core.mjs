import { sha256, ripemd160, secp256k1, encodeCashAddress, binToHex, hexToBin, decodeTransaction, encodeTransaction, hashTransaction } from '@bitauth/libauth';

export function addressFromPubkey(pubkey, prefix) {
  if (!['bitcoincash','bchtest'].includes(prefix)) throw new Error('Unsupported address encoding.');
  if (!(pubkey instanceof Uint8Array) || pubkey.length !== 33 || ![2,3].includes(pubkey[0]) || !secp256k1.validatePublicKey(pubkey)) throw new Error('Wallet returned an invalid compressed public key.');
  const hash = ripemd160.hash(sha256.hash(pubkey));
  return { address: encodeCashAddress({ prefix, type:'p2pkh', payload:hash }).address, scriptHex:`76a914${binToHex(hash)}88ac` };
}

export function deriveWalletAddresses(manager, state, prefix = 'bitcoincash') {
  if (state !== 'connected' || !manager || manager.protocol !== 'hdwalletv1') throw new Error('Connect an hdwalletv1 wallet first.');
  if (!manager.hasPath(0) || !manager.hasPath(1)) throw new Error('Wallet must supply both receive and change paths.');
  const specs = [{path:'receive',child:0,index:0},{path:'receive',child:0,index:1},{path:'receive',child:0,index:2},{path:'change',child:1,index:0}];
  const rows = specs.map(s => ({ path:s.path, index:s.index, ...addressFromPubkey(manager.getPubkey(s.child,BigInt(s.index)),prefix) }));
  if (new Set(rows.map(r=>r.scriptHex)).size !== rows.length) throw new Error('Wallet derivation produced overlapping receive/change scripts.');
  return rows;
}

export function deriveWalletPath(manager,state,path,index){
 if(state!=='connected'||manager?.protocol!=='hdwalletv1')throw Error('Connect an hdwalletv1 wallet first.');
 if(!['receive','change'].includes(path)||!Number.isInteger(index)||index<0||index>=200)throw Error('Invalid wallet address path.');
 const child=path==='receive'?0:1;
 if(!manager.hasPath(child))throw Error('Wallet must supply both receive and change paths.');
 return {path,index,...addressFromPubkey(manager.getPubkey(child,BigInt(index)),'bitcoincash')};
}
export function verifyWalletScanRows(manager,state,rows){
 if(!Array.isArray(rows)||rows.length<4||rows.length>400)throw Error('Invalid wallet scan paths.');
 const seen=new Set();
 const verified=rows.map(row=>{
  const expected=deriveWalletPath(manager,state,row.path,row.index);
  if(expected.scriptHex!==row.scriptHex||seen.has(row.scriptHex))throw Error('Wallet address paths changed. Refresh funding.');
  seen.add(row.scriptHex);
  return expected;
 });
 if(!verified.some(row=>row.path==='change'&&row.index===0))throw Error('Missing wallet change path.');
 return verified;
}

// Raw transaction integrity/ownership-candidate check only: no network or spendability claim.
export function inspectFundingTransaction({ rawHex, expectedTxid, outputIndex, walletScriptHex }) {
  if (typeof rawHex !== 'string' || rawHex.length > 2000000 || !/^(?:[a-fA-F0-9]{2})+$/.test(rawHex)) throw new Error('Enter raw transaction hex (maximum 1 MB).');
  if (typeof expectedTxid !== 'string' || !/^[a-fA-F0-9]{64}$/.test(expectedTxid)) throw new Error('Expected transaction ID must contain 64 hex characters.');
  if (!Number.isSafeInteger(outputIndex) || outputIndex < 0) throw new Error('Invalid output index.');
  if (typeof walletScriptHex !== 'string' || !/^76a914[a-fA-F0-9]{40}88ac$/.test(walletScriptHex)) throw new Error('Expected wallet P2PKH script required.');
  const bytes = hexToBin(rawHex); const tx = decodeTransaction(bytes);
  if (typeof tx === 'string' || binToHex(encodeTransaction(tx)) !== rawHex.toLowerCase()) throw new Error('Invalid or noncanonical transaction encoding.');
  const txid = hashTransaction(bytes);
  if (txid !== expectedTxid.toLowerCase()) throw new Error('Raw transaction does not match the expected transaction ID.');
  const output = tx.outputs[outputIndex];
  if (!output) throw new Error('Funding output does not exist in this transaction.');
  if (output.token !== undefined) throw new Error('Token-bearing funding output excluded.');
  if (binToHex(output.lockingBytecode) !== walletScriptHex.toLowerCase()) throw new Error('Funding script does not match the selected wallet address.');
  if (output.valueSatoshis <= 0n || output.valueSatoshis > 21000000n*100000000n) throw new Error('Unsupported funding amount.');
  return { txid, index:outputIndex, sats:output.valueSatoshis.toString(), scriptHex:walletScriptHex.toLowerCase(), status:'RAW OUTPUT MATCHED — CHAIN EXISTENCE AND UNSPENT STATUS NOT CHECKED' };
}
