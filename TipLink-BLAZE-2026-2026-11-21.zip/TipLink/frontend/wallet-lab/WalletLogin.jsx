import React,{useEffect,useRef,useState} from 'react';
import makeQr from 'qrcode-generator';
import {connectLoginWallet} from './wallet-login-client.mjs';
import {useDeviceWallet,DeviceWalletSetup} from './DeviceWallet.jsx';
import {signDeviceWalletBusinessChallenge} from './device-wallet-business-signin.mjs';
import './wallet-login.css';
function PairingQR({uri}){try{const qr=makeQr(0,'M');qr.addData(uri);qr.make();return <div className="qr" role="img" aria-label="WalletConnect sign-in QR" dangerouslySetInnerHTML={{__html:qr.createSvgTag({cellSize:4,margin:2,scalable:true})}}/>;}catch{return <p>Copy the pairing URI instead.</p>;}}
export function WalletLogin({request,onSuccess,link=false,disabled=false,onBusyChange=()=>{}}){
 const device=useDeviceWallet();const[showWalletSetup,setShowWalletSetup]=useState(false),[externalSelected,setExternalSelected]=useState(false);
 const[config,setConfig]=useState(null),[error,setError]=useState(''),[phase,setPhase]=useState('idle'),[uri,setUri]=useState(''),[challenge,setChallenge]=useState(null);const live=useRef(true),active=useRef(null),requestRef=useRef(request);requestRef.current=request;
 useEffect(()=>{live.current=true;requestRef.current('/auth/wallet/config').then(result=>{if(live.current)setConfig(result);}).catch(()=>{if(live.current)setError('Wallet sign-in setup could not be loaded. Email sign-in remains available.');});return()=>{live.current=false;active.current?.abort();};},[]);
 async function signInWithTipLink(){
  if(!device.wallet){setShowWalletSetup(true);return;}
  const controller=new AbortController();active.current?.abort();active.current=controller;
  setError('');setUri('');setChallenge(null);setPhase('signing');onBusyChange(true);
  const timeout=setTimeout(()=>controller.abort(),30000);
  try{
   const c=await requestRef.current('/auth/wallet/challenge',{method:'POST',
    body:{address:device.wallet.address,intent:link?'link':'signin'}});
   if(!live.current||controller.signal.aborted)return;
   setChallenge(c);
   // The user clicked to authorize a Business message, never a BCH payment.
   const signature=signDeviceWalletBusinessChallenge({
    wallet:device.wallet,challenge:c,origin:location.origin
   });
   if(!live.current||controller.signal.aborted)return;
   setPhase('verifying');
   const result=await requestRef.current('/auth/wallet/verify',{method:'POST',body:{id:c.id,signature}});
   if(!live.current||controller.signal.aborted)return;
   setChallenge(null);setPhase('idle');await onSuccess(result);
  }catch(e){
   if(live.current){setError(controller.signal.aborted?'TipLink wallet sign-in was cancelled.':e.message);setPhase('idle');}
  }finally{
   clearTimeout(timeout);
   if(active.current===controller)active.current=null;
   if(live.current)onBusyChange(false);
  }
 }
 async function signIn(){const controller=new AbortController();active.current?.abort();active.current=controller;let wallet;setError('');setUri('');setChallenge(null);setPhase('connecting');onBusyChange(true);const timeout=setTimeout(()=>controller.abort(),180000);try{wallet=await connectLoginWallet({projectId:config?.projectId,origin:location.origin,signal:controller.signal,onUri:value=>{if(live.current&&!controller.signal.aborted)setUri(value);}});if(!live.current||controller.signal.aborted)return;setUri('');setPhase('signing');const c=await requestRef.current('/auth/wallet/challenge',{method:'POST',body:{address:wallet.address,intent:link?'link':'signin'}});if(!live.current||controller.signal.aborted)return;setChallenge(c);const signature=await wallet.signMessage(c.message);if(!live.current||controller.signal.aborted)return;setPhase('verifying');const result=await requestRef.current('/auth/wallet/verify',{method:'POST',body:{id:c.id,signature}});if(!live.current||controller.signal.aborted)return;await wallet.close();wallet=null;setChallenge(null);setPhase('idle');await onSuccess(result);}catch(e){if(live.current){setError(controller.signal.aborted?'Wallet sign-in cancelled or timed out. You can try again.':e.message);setPhase('idle');}}finally{clearTimeout(timeout);await wallet?.close();if(active.current===controller)active.current=null;if(live.current){setUri('');onBusyChange(false);}}}
 const busy=phase!=='idle';
 const saved=!!device.slot,unlocked=!!device.wallet;
 return <section className="wallet-login">
  <span className="tag">{link?'KEEP YOUR EXISTING BUSINESS':'ONE WALLET. ALL OF TIPLINK.'}</span>
  <h2>{link?'Use your TipLink wallet for Business.':'Your TipLink wallet is your way in.'}</h2>
  <p>{link?'Link your existing TipLink BCH wallet to your current Business account.':'Create or unlock one TipLink BCH wallet and use it for sending, receiving and signing in to Business. Funding is only needed to send BCH, not to create payment requests.'}</p>
  {saved&&<p className="wallet-remembered"><strong>Saved wallet recognized</strong><code>{device.slot.address}</code><small>{unlocked?'Wallet unlocked for this session':'Encrypted wallet saved. Unlock to sign in; it was not deleted.'}</small></p>}
  <button type="button" className="primary full" disabled={disabled||busy||!config||!device.ready}
   onClick={signInWithTipLink}>{busy&&!externalSelected?(phase==='verifying'?'Verifying your signature…':'Signing Business message…'):
    !saved?'Create my TipLink wallet':unlocked?link?'Link TipLink wallet':'Continue with TipLink wallet':'Unlock my TipLink wallet'}</button>
  {showWalletSetup&&!unlocked&&<div className="wallet-login-local-setup"><DeviceWalletSetup/></div>}
  {showWalletSetup&&unlocked&&<p className="notice" role="status">Wallet unlocked. Press Continue with TipLink wallet above to sign in.</p>}
  {error&&<div className="error" role="alert">{error}</div>}
  {!config&&!error&&<p role="status">Checking Business sign-in availability…</p>}
  <details className="wallet-login-external" open={externalSelected}
   onToggle={event=>setExternalSelected(event.currentTarget.open)}>
   <summary>Use an external wallet instead (optional)</summary>
   <p>Connect Selene or another compatible BCH wallet if you prefer. Your TipLink wallet remains saved.</p>
   <button type="button" className="secondary full" disabled={disabled||busy||!config?.projectId} onClick={signIn}>
    {busy&&externalSelected?(phase==='connecting'?'Connect in your external wallet…':phase==='signing'?'Approve the sign-in message…':'Checking the signature…'):
     link?'Link external wallet':'Continue with external BCH wallet'}
   </button>
   {uri&&<div className="wallet-pairing"><h3>Scan with Selene's WalletConnect scanner.</h3>
    <p>This is optional and separate from TipLink's built-in wallet.</p>
    <PairingQR uri={uri}/>
    <label>WalletConnect pairing URI<textarea readOnly rows={3} value={uri} onFocus={e=>e.target.select()}/></label>
    <button type="button" className="secondary full" onClick={async()=>{try{await navigator.clipboard.writeText(uri);}catch{setError('Select the pairing URI above and copy it.');}}}>Copy pairing URI</button>
   </div>}
  </details>
  {config?.requiresSetup&&<p className="wallet-setup-note">External wallet sign-in setup is unavailable. Email sign-in remains available.</p>}
  {challenge&&<details className="wallet-message"><summary>View the exact sign-in message</summary>
   <pre>{challenge.message}</pre><p>Only your Business sign-in message is signed, never a BCH transaction.</p>
  </details>}
  {busy&&<button type="button" className="text-button" onClick={()=>active.current?.abort()}>Cancel wallet sign-in</button>}
  <p className="fine">Your TipLink wallet is encrypted on this device. Business requires an explicit sign-in signature only when your server session expires (currently 24 hours). No BCH funding or network fee is needed for login.</p>
  {!link&&<p className="fine">Already have a Business account registered with email or another wallet? Sign in to that account first and link this wallet in Business settings to keep existing requests together.</p>}
 </section>;
}
