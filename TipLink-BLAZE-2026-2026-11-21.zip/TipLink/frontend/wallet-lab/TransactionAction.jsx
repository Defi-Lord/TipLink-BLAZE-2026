import React,{useEffect,useMemo,useRef,useState} from 'react';
import {openFundingRpc,openTransactionRpc} from './funding-rpc.mjs';
import {DIRECT_FAST_PROVIDERS,receiptCheckDelay} from './direct-funding-monitor.mjs';
import {broadcastDeviceWalletSend} from './device-wallet-network.mjs';
import {broadcastFunding,broadcastEnvelopeSpend,checkPublishedTransaction,parsePublicTransaction} from './broadcast-core.mjs';
import {readTransactionReceipts,saveTransactionReceipt,updateTransactionReceipt,removeTransactionReceipt,importTransactionReceipt,transactionStatusLabel} from './transaction-journal.mjs';
import {StatusMark,TransactionReaction,shouldCelebrateTransaction} from './StatusReaction.jsx';
import './transaction-action.css';
import {findCheckoutPayment,recordCheckoutMatch,listCheckoutPayments,saveCheckoutPayment} from './checkout-payment.mjs';
import {fetchInvoiceCheckout} from './business-core.mjs';
import {formatBch} from './preview-core.mjs';
export function TransactionHashLink({txid}){
 return <a className="transaction-hash-link" href={`https://bchexplorer.cash/tx/${txid}`}
  target="_blank" rel="noopener noreferrer"><code>{txid}</code></a>;
}
export function downloadTransactionReceipt(receipt){const blob=new Blob([JSON.stringify(receipt,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='TipLink-'+receipt.kind+'-'+receipt.txid.slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
export function TransactionAction(props){
 const txid=useMemo(()=>parsePublicTransaction(props.hex).txid,[props.hex]);
 return <TransactionControls key={txid} {...props} txid={txid}/>;
}
function TransactionControls({txid,kind,hex,transfer,handoff,plan,wallet,disabled=false,onResult}){
 const[ack,setAck]=useState(false),[busy,setBusy]=useState(''),[result,setResult]=useState(null),[error,setError]=useState(''),[now,setNow]=useState(Date.now());
 const active=useRef(null),live=useRef(true),locked=useRef(false);
 const previousStatus=useRef(null),reactionTimer=useRef(null);const[reaction,setReaction]=useState(0);
 useEffect(()=>{live.current=true;setAck(false);setResult(null);setError('');try{const stored=readTransactionReceipts().find(r=>r.txid===txid)||null;previousStatus.current=stored?.status??null;setResult(stored);setReaction(0);}catch(e){setError(e.message);}const timer=setInterval(()=>setNow(Date.now()),1000);return()=>{live.current=false;active.current?.abort();clearTimeout(reactionTimer.current);clearInterval(timer);};},[txid]);
 function remember(value){let saved=updateTransactionReceipt(txid,value);if(!saved&&value.status!=='unknown')saved=saveTransactionReceipt({...value,hex,kind,...(kind==='wallet-send'?{envelopeTxid:null,walletAddress:wallet.address}:{envelopeTxid:transfer.utxo.txid}),createdAt:value.checkedAt});return saved||value;}
 async function run(send){
  if(locked.current||send&&(!ack||disabled))return;locked.current=true;setError('');setBusy(send?'sending':'checking');const c=new AbortController();active.current=c;let rpc;const timer=setTimeout(()=>c.abort(),send?90000:30000);
  try{
   rpc=send?await openTransactionRpc({signedHex:hex,signal:c.signal}):await openFundingRpc({signal:c.signal,providers:[...DIRECT_FAST_PROVIDERS],timeoutMs:10000});
   const value=send?await(kind==='wallet-send'?broadcastDeviceWalletSend({wallet,plan,rpc,signal:c.signal,authorise:ack,beforeSubmit:saveTransactionReceipt}):kind==='funding'?broadcastFunding({handoff,rpc,signal:c.signal,authorise:ack,beforeSubmit:saveTransactionReceipt}):broadcastEnvelopeSpend({transfer,handoff,plan,rpc,signal:c.signal,authorise:ack,beforeSubmit:saveTransactionReceipt})):await checkPublishedTransaction({hex,rpc,signal:c.signal});
   let record=value;try{record=remember(value);}catch{if(live.current)setError('The network result could not be saved. Keep this transaction ID and check its status before sending anything else.');}
   if(live.current){
    const celebration=shouldCelebrateTransaction(previousStatus.current,record?.status,{initiated:send});
    previousStatus.current=record?.status??null;
    setResult(record);setNow(Date.now());
    if(celebration){
     setReaction(value=>value+1);
     clearTimeout(reactionTimer.current);
     reactionTimer.current=setTimeout(()=>{if(live.current)setReaction(0);},4200);
    }
    onResult?.(value);
   }
  }catch(e){if(live.current)setError(e.message||'The transaction check could not finish.');if(!send){const unknown={txid,status:'unknown',height:0,checkedAt:Date.now()};try{remember(unknown);}catch{}if(live.current)setResult(unknown);}}
  finally{clearTimeout(timer);rpc?.close();locked.current=false;if(active.current===c)active.current=null;if(live.current)setBusy('');}
 }
 // Once a transaction has been submitted, monitor the exact same txid
 // automatically. Never re-broadcast; even 'unknown' can mean submitted.
 useEffect(()=>{
  if(!result||result.txid!==txid||!['submitted','seen','unknown'].includes(result.status))return;
  let stopped=false,timer;
  const update=()=>{if(!stopped&&document.visibilityState==='visible'&&navigator.onLine!==false)void run(false);};
  const schedule=()=>{clearTimeout(timer);timer=setTimeout(()=>{update();if(!stopped)schedule();},receiptCheckDelay(result.status));};
  schedule();
  const resume=()=>{if(document.visibilityState==='visible'){update();schedule();}};
  document.addEventListener('visibilitychange',resume);
  window.addEventListener('online',resume);
  return()=>{stopped=true;clearTimeout(timer);document.removeEventListener('visibilitychange',resume);window.removeEventListener('online',resume);};
 },[txid,result?.status]);
 const freshResult=result?.txid===txid&&now>=result.checkedAt&&now-result.checkedAt<30000;
 const tone=!freshResult||result?.status==='unknown'?'warning':result.status==='confirmed'?'success':'pending';
 const confirmedTitle={funding:'Funding confirmed',claim:'Money received',recovery:'Money recovered','wallet-send':'Payment confirmed'}[kind];
 const submitted=!!result&&['submitted','seen','confirmed'].includes(result.status);
 return <div className="transaction-action">{reaction>0&&<TransactionReaction key={`${txid}-${reaction}`} kind={kind}/>}<span className="eyebrow">{kind==='funding'?'PUT MONEY IN THIS LINK':kind==='recovery'?'RECOVER UNCLAIMED MONEY':kind==='wallet-send'?'SEND FROM YOUR TIPLINK WALLET':'RECEIVE THIS PAYMENT'}</span>{busy?<div className="transaction-result status-reaction" role="status"><StatusMark tone="pending"/><b>{busy==='sending'?'Submitting transaction…':'Checking the network…'}</b></div>:result?.txid===txid&&<div className={'transaction-result transaction-'+result.status+' status-reaction'} role="status"><StatusMark key={tone} tone={tone}/><div><b>{tone==='success'?confirmedTitle:transactionStatusLabel(result,now)}</b><p>{tone==='success'?'Confirmation reported by the network provider.':tone==='warning'?'Check this same transaction before creating another transfer.':'Transaction broadcast detected; TipLink checks for blockchain confirmation automatically.'}</p></div></div>}{!submitted&&<><label className="backup-ack"><input type="checkbox" checked={ack} disabled={!!busy||disabled} onChange={e=>setAck(e.target.checked)}/><span>{kind==='funding'?'I reviewed the amount and fees, saved the recovery file, and want to send this BCH.':'I checked the receiving address and exact amount, and want to send this transaction.'}</span></label><button className="primary full" disabled={!ack||disabled||!!busy} onClick={()=>run(true)}>{busy==='sending'?'Checking and sending…':result?'Retry this exact transaction':kind==='funding'?'Send BCH into this link':kind==='recovery'?'Recover to this address':kind==='wallet-send'?'Send my confirmed BCH':'Receive BCH at this address'}</button></>}<button className="secondary full" disabled={!!busy} onClick={()=>run(false)}>{busy==='checking'?'Checking the network…':'Check transaction status'}</button>{busy&&<button className="text-button" onClick={()=>active.current?.abort()}>Stop waiting</button>}{error&&<div className="error status-reaction" role="alert"><StatusMark tone="warning"/><span>{error}</span></div>}<details><summary>Transaction receipt</summary><p>Transaction ID</p><code>{txid}</code>{result?.hex&&<button className="text-button" onClick={()=>downloadTransactionReceipt(result)}>Download receipt</button>}<p className="fine">A public transaction receipt is saved on this device before submission. It contains signed transaction bytes, not your private keys or claim link. Stopping or closing this screen cannot undo a transaction already sent.</p></details><p className="fine">This sends real BCH on mainnet. Confirmation and unspent status are reported by BCH network providers. No TipLink platform fee is collected.</p></div>;
}
function CheckoutHistory(){
 const [rows,setRows]=useState([]);
 const [issue,setIssue]=useState('');
 useEffect(()=>{
  let active=true,controller=null;
  async function refresh(){
   if(!active||controller||document.hidden||navigator.onLine===false)return;
   let saved;
   try{saved=listCheckoutPayments();}catch{return;}
   setRows(saved);
   const candidate=saved.filter(row=>row.receiptSyncPending||(row.status!=='confirmed'&&(row.txid||row.manualTxid||Date.now()-row.openedAt<86400000)))
    .sort((a,b)=>(a.checkedAt||a.openedAt)-(b.checkedAt||b.openedAt))[0];
   if(!candidate)return;
   const operation=new AbortController();
   controller=operation;
   const timer=setTimeout(()=>operation.abort(),18000);
   let rpc;
   try{
    const invoice=await fetchInvoiceCheckout(candidate.id,{signal:operation.signal});
    if(invoice.address!==candidate.address||invoice.amountSats!==candidate.amountSats)return;
    rpc=await openFundingRpc({signal:operation.signal,providers:DIRECT_FAST_PROVIDERS,timeoutMs:8000});
    const found=await findCheckoutPayment({invoice,rpc,baseline:candidate.baseline,txid:candidate.manualTxid||candidate.txid});
    if(!active||operation.signal.aborted)return;
    if(found.status==='seen'||found.status==='confirmed')await recordCheckoutMatch(invoice,found,{signal:operation.signal});
    else saveCheckoutPayment(invoice,{checkedAt:Date.now()});
    if(!active||operation.signal.aborted)return;
    setRows(listCheckoutPayments());
    setIssue(found.status==='ambiguous'?'Several possible payments. Open the request and verify your wallet transaction ID.':'');
   }catch{if(active)setIssue('Some payment checks are delayed.');}
   finally{clearTimeout(timer);rpc?.close();controller=null;}
  }
  void refresh();
  const interval=setInterval(refresh,15000);
  document.addEventListener('visibilitychange',refresh);
  window.addEventListener('online',refresh);
  return()=>{
   active=false;
   clearInterval(interval);
   controller?.abort();
   document.removeEventListener('visibilitychange',refresh);
   window.removeEventListener('online',refresh);
  };
 },[]);
 if(!rows.length)return null;
 return <section className="panel transaction-history" aria-label="Payment requests checked on this device">
  <h2>Payment request activity</h2>
  {issue&&<p role="status">{issue}</p>}
  <ul>{rows.map(row=><li key={row.id}>
   <details className="activity-receipt">
    <summary>
     <StatusMark tone={row.status==='confirmed'?'success':'pending'}/>
     <strong>{formatBch(BigInt(row.amountSats))} BCH</strong>
     {' · '}{row.status==='confirmed'?'Matching payment confirmed':row.status==='seen'?'Payment detected · pending confirmation':'Waiting for payment'}
    </summary>
    <dl className="recipient-summary">
     <div><dt>Receiving address</dt><dd><code>{row.address}</code></dd></div>
     {row.txid&&<div><dt>Transaction hash</dt><dd><TransactionHashLink txid={row.txid}/></dd></div>}
     {row.height>0&&<div><dt>BCH block</dt><dd>{row.height}</dd></div>}
     {row.checkedAt&&<div><dt>Last checked</dt><dd>{new Date(row.checkedAt).toLocaleString()}</dd></div>}
    </dl>
    <a href={'/#invoice='+row.id}>Open request</a>
   </details>
  </li>)}</ul>
 </section>;
}
export function TransactionHistory(){
 const[rows,setRows]=useState([]),[receiptFile,setReceiptFile]=useState(null),[exported,setExported]=useState([]),[removing,setRemoving]=useState(null),[error,setError]=useState(''),[busy,setBusy]=useState(''),[now,setNow]=useState(Date.now());const active=useRef(null),live=useRef(true),locked=useRef(false);
 function load(){try{setRows(readTransactionReceipts());}catch(e){setError(e.message);}}
 useEffect(()=>{live.current=true;load();const timer=setInterval(()=>setNow(Date.now()),1000);return()=>{live.current=false;active.current?.abort();clearInterval(timer);};},[]);
 async function restoreReceipt(e){e.preventDefault();setError('');try{if(!receiptFile||receiptFile.size>50000)throw Error('Choose a TipLink transaction receipt under 50 KB.');importTransactionReceipt(JSON.parse(await receiptFile.text()));if(live.current){load();setReceiptFile(null);}}catch{if(live.current)setError('Could not restore that transaction receipt. Use a downloaded TipLink receipt; never upload a recovery file or wallet words here.');}}
 async function check(row){if(locked.current)return;locked.current=true;setBusy(row.txid);setError('');const c=new AbortController();active.current=c;let rpc;const timer=setTimeout(()=>c.abort(),60000);try{rpc=await openFundingRpc({signal:c.signal});const status=await checkPublishedTransaction({hex:row.hex,rpc,signal:c.signal});updateTransactionReceipt(row.txid,status);if(live.current)load();}catch{try{updateTransactionReceipt(row.txid,{txid:row.txid,status:'unknown',height:0,checkedAt:Date.now()});}catch{}if(live.current){load();setError('Could not establish a fresh network result. Check this transaction before sending another.');}}finally{clearTimeout(timer);rpc?.close();active.current=null;locked.current=false;if(live.current)setBusy('');}}
 return <><CheckoutHistory/><section className="panel transaction-history"><div className="section-heading"><h2>Your transaction receipts</h2><span className="tag">THIS DEVICE</span></div><p>Funding, receiving, recovery, and wallet payment receipts saved on this device.</p>{error&&<div className="error" role="alert">{error}</div>}{!rows.length?<p className="fine">Your first submitted transaction will appear here.</p>:<div className="table-wrap"><table><thead><tr><th>Transaction</th><th>Network status</th><th>Receipt</th></tr></thead><tbody>{rows.map(row=><tr key={row.txid} className="activity-receipt-row" onClick={event=>{
  if(event.target.closest('a, button, details'))return;
  const details=event.currentTarget.querySelector('details');
  details.open=!details.open;
 }}>
  <td><details className="activity-receipt">
   <summary>{row.kind==='funding'?'Funded link':row.kind==='recovery'?'Recovery':row.kind==='wallet-send'?'Wallet payment':'Received payment'}</summary>
   <dl className="recipient-summary">
    <div><dt>Transaction hash</dt><dd><TransactionHashLink txid={row.txid}/></dd></div>
    {row.height>0&&<div><dt>BCH block</dt><dd>{row.height}</dd></div>}
    {row.walletAddress&&<div><dt>TipLink wallet address</dt><dd><code>{row.walletAddress}</code></dd></div>}
    <div><dt>First saved</dt><dd>{new Date(row.createdAt).toLocaleString()}</dd></div>
    <div><dt>Last checked</dt><dd>{new Date(row.checkedAt).toLocaleString()}</dd></div>
   </dl>
  </details></td>
  <td>{transactionStatusLabel(row,now)}<small>{row.height?'Reported block '+row.height:'No confirmed block reported'}</small></td>
  <td>
   <button className="text-button" disabled={!!busy} onClick={()=>check(row)}>{busy===row.txid?'Checking…':'Check status'}</button>
   <button className="text-button" onClick={()=>{downloadTransactionReceipt(row);setExported(value=>[...value,row.txid]);}}>Download</button>
   <button className="text-button" disabled={!!busy||!exported.includes(row.txid)} onClick={()=>setRemoving(row.txid)}>Remove saved receipt</button>
  </td>
 </tr>)}</tbody></table></div>}{removing&&<div className="notice"><p>Remove this receipt from this device? Keep the downloaded copy. Removing it cannot cancel a transaction, recover funds or prove that an uncertain payment failed.</p><div className="button-row"><button className="secondary" onClick={()=>setRemoving(null)}>Keep it here</button><button className="secondary" onClick={()=>{try{removeTransactionReceipt(removing,{exported:exported.includes(removing)});load();setRemoving(null);}catch(e){setError(e.message);}}}>Remove from this device</button></div></div>}<details className="restore-public-receipt"><summary>Restore a transaction receipt</summary><form onSubmit={restoreReceipt}><label>Downloaded transaction receipt<input type="file" accept="application/json,.json" onChange={e=>setReceiptFile(e.target.files?.[0]||null)}/></label><p className="fine">This accepts a public transaction receipt, not your encrypted recovery file. Restored status starts as uncertain until checked with the network.</p><button className="secondary" disabled={!receiptFile||!!busy}>Restore receipt</button></form></details><p className="fine">Receipts contain public transaction data and stay in this browser. Keep your downloaded recovery file separately. A missing network result does not prove a transaction failed. Clearing browser data removes this history.</p></section></>;
}
