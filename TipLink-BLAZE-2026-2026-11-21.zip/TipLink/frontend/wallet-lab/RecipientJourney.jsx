import React,{useEffect,useRef,useState} from 'react';
import {startRecipientJourney,advanceRecipientJourney} from './recipient-journey.mjs';
import {formatBch} from './preview-core.mjs';

export function RecipientJourney({record,onExploreSending}){
 const [state,setState]=useState(()=>startRecipientJourney(record));const [error,setError]=useState('');
 const heading=useRef(null);const errorRef=useRef(null);const first=useRef(true);
 useEffect(()=>{if(first.current){first.current=false;return;}heading.current?.focus();},[state.stage]);
 useEffect(()=>{if(error)errorRef.current?.focus();},[error]);
 function act(action){try{const next=advanceRecipientJourney(state,action,record);setState(next);setError('');}catch(e){setError(e.message);}}
 return <RecipientJourneyView record={record} state={state} act={act} error={error} headingRef={heading} errorRef={errorRef} onExploreSending={onExploreSending}/>;
}
export function RecipientJourneyView({record,state,act,error='',headingRef,errorRef,onExploreSending}){
 const stage=state.stage;const guest=state.mode==='guest';const number={welcome:1,destination:1,review:2,complete:3}[stage];
 return <div className="recipient-journey">
  <div className="recipient-preview-note"><span aria-hidden="true">◈</span><div><b>Demo only · no money attached</b><p>No wallet is created and no transaction is sent.</p></div></div>
  <ol className="recipient-progress" aria-label="Receiving preview progress">{['Choose','Review','Finish'].map((label,i)=><li key={label} aria-current={number===i+1?'step':undefined} className={number>=i+1?'reached':''}><span>{i+1}</span>{label}</li>)}</ol>
  {error&&<div className="error" role="alert" tabIndex={-1} ref={errorRef}>{error}</div>}
  {stage==='welcome'&&<><h2 ref={headingRef} tabIndex={-1}>A link. A little possibility.</h2><p>Try receiving BCH without signing in or moving money.</p><button className="primary full" onClick={()=>act({type:'start'})}>Explore receiving <span aria-hidden="true">→</span></button><p className="fine">Never enter wallet recovery words or private keys to receive a payment.</p></>}
  {stage==='destination'&&<><h2 ref={headingRef} tabIndex={-1}>Make it yours.</h2><p>Choose how you would receive BCH.</p><fieldset className="recipient-choices"><legend className="recipient-sr">Receiving destination</legend><label className={guest?'selected':''}><input type="radio" name="recipient-destination" checked={guest} onChange={()=>act({type:'mode',value:'guest'})}/><span><b>I’m new to BCH</b><small>Preview receiving with a TipLink wallet on this device.</small></span><em>Preview</em></label><label className={!guest?'selected':''}><input type="radio" name="recipient-destination" checked={!guest} onChange={()=>act({type:'mode',value:'existing'})}/><span><b>I already have a wallet</b><small>Check a BCH receiving address you control.</small></span></label></fieldset>
   {!guest&&<label className="recipient-address">Your BCH receiving address<textarea rows={3} maxLength={200} spellCheck={false} autoComplete="off" value={state.address} placeholder="bitcoincash:q…" onChange={e=>act({type:'address',value:e.target.value})}/><small>In Selene, open Receive and copy your BCH address. This preview supports standard bitcoincash:q… addresses.</small></label>}
   {guest&&<div className="recipient-help"><b>No setup for this preview.</b><p>On a funded claim link, choose Receive here in TipLink to set up a wallet and save your recovery information.</p></div>}
   <button className="primary full" onClick={()=>act({type:'review'})}>Review receiving preview <span aria-hidden="true">→</span></button></>}
  {stage==='review'&&<><h2 ref={headingRef} tabIndex={-1}>One last look.</h2><p>Check the destination before finishing the walkthrough.</p><dl className="recipient-summary"><div><dt>Demo envelope amount</dt><dd>{formatBch(BigInt(record.sats))} BCH</dd></div><div><dt>Receiving method</dt><dd>{guest?'Guest onboarding preview':'Your BCH wallet'}</dd></div><div><dt>Actual BCH received</dt><dd>0 BCH · demo only</dd></div><div><dt>Network fee</dt><dd>No transaction created</dd></div></dl>
   {!guest&&<div className="recipient-reviewed-address"><small>CHECK YOUR FULL ADDRESS</small><code>{state.review.address}</code><p>Address format checked. Ownership and wallet access are not verified.</p></div>}
   {guest&&<p className="recipient-help">This preview creates no wallet. With a funded claim link, you can set one up on this device without a TipLink account.</p>}
   <button className="primary full" onClick={()=>act({type:'finish'})}>Finish demo</button><button className="text-button" onClick={()=>act({type:'back'})}>Change receiving method</button></>}
  {stage==='complete'&&<div className="recipient-complete" role="status"><span className="recipient-done" aria-hidden="true">✓</span><h2 ref={headingRef} tabIndex={-1}>You’ve tried receiving.</h2><p>That’s the walkthrough. No BCH moved.</p><dl className="recipient-summary"><div><dt>Demo envelope</dt><dd>{formatBch(BigInt(record.sats))} BCH</dd></div><div><dt>Actual amount received</dt><dd>0 BCH</dd></div><div><dt>Transaction ID</dt><dd>None · no transaction sent</dd></div></dl><p className="fine">{guest?'No guest wallet was created.':'The address you entered stayed in this page’s memory; it was not added to activity history.'}</p><button className="secondary full" onClick={onExploreSending}>Explore sending <span aria-hidden="true">→</span></button></div>}
 </div>;
}
