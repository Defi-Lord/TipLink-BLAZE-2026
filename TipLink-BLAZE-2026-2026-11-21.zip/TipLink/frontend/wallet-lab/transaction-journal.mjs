// Public transaction receipts only. No claim links, wallet words or private keys.
import {validateRecipient} from './preview-core.mjs';
import {parsePublicTransaction} from './broadcast-core.mjs';
const KEY='tiplink-public-transactions-v1';
const fields=['txid','hex','kind','envelopeTxid','status','height','createdAt','checkedAt'];
export function validateTransactionReceipt(r){
 const expected=r?.kind==='wallet-send'?[...fields,'walletAddress']:fields;
 if(!r||typeof r!=='object'||Object.keys(r).length!==expected.length||Object.keys(r).some(k=>!expected.includes(k))||!['funding','claim','recovery','wallet-send'].includes(r.kind)||!['unknown','submitted','seen','confirmed'].includes(r.status)||(r.kind==='wallet-send'?(r.envelopeTxid!==null||typeof r.walletAddress!=='string'||validateRecipient(r.walletAddress).address!==r.walletAddress):(typeof r.envelopeTxid!=='string'||!/^[a-f0-9]{64}$/.test(r.envelopeTxid)))||!Number.isSafeInteger(r.height)||r.height<0||(r.status==='confirmed')!==(r.height>0)||!Number.isSafeInteger(r.createdAt)||!Number.isSafeInteger(r.checkedAt)||r.createdAt<0||r.checkedAt<r.createdAt||parsePublicTransaction(r.hex).txid!==r.txid)throw Error('Invalid public transaction receipt.');
 return{...r};
}
export function readTransactionReceipts(storage=globalThis.localStorage){
 const raw=storage.getItem(KEY);if(!raw)return[];if(raw.length>1200000)throw Error('Transaction history is too large. Export your saved receipts before clearing browser data.');
 let rows;try{rows=JSON.parse(raw);}catch{throw Error('Could not read transaction history on this device. Do not resend while a previous result is uncertain.');}
 if(!Array.isArray(rows)||rows.length>25)throw Error('Invalid transaction history.');const seen=new Set();return rows.map(r=>{const checked=validateTransactionReceipt(r);if(seen.has(r.txid))throw Error('Duplicate transaction receipt.');seen.add(r.txid);return checked;});
}
export function saveTransactionReceipt(receipt,storage=globalThis.localStorage){
 const r=validateTransactionReceipt(receipt),rows=readTransactionReceipts(storage),index=rows.findIndex(x=>x.txid===r.txid);
 if(index>=0){const old=rows[index];if(old.hex!==r.hex||old.kind!==r.kind||old.envelopeTxid!==r.envelopeTxid||old.walletAddress!==r.walletAddress)throw Error('Receipt identity changed.');r.createdAt=old.createdAt;rows.splice(index,1);}
 // Never discard an uncertain/submitted receipt to make room for another payment.
 if(rows.length>=25)throw Error('This device has 25 saved transaction receipts. Export and manage them before sending more.');
 rows.unshift(r);const encoded=JSON.stringify(rows);storage.setItem(KEY,encoded);if(storage.getItem(KEY)!==encoded)throw Error('Could not save the transaction receipt. No new submission was made.');
 return r;
}
export function updateTransactionReceipt(txid,result,storage=globalThis.localStorage){const r=readTransactionReceipts(storage).find(row=>row.txid===txid);if(!r)return null;return saveTransactionReceipt({...r,...result},storage);}
export function transactionStatusLabel(r,now=Date.now()){
 if(!r)return'Not submitted';if(now-r.checkedAt>=30000)return'TipLink status sync delayed · fresh network check needed';return{unknown:'TipLink cannot verify status yet · retrying',submitted:'Submitted · awaiting BCH network detection',seen:'Payment detected · waiting for BCH block confirmation',confirmed:'Confirmed in BCH block · provider reported'}[r.status]||'Unknown';
}

export function removeTransactionReceipt(txid,{exported=false}={},storage=globalThis.localStorage){
 if(exported!==true)throw Error('Download this receipt before removing the saved copy.');
 const rows=readTransactionReceipts(storage);if(!rows.some(r=>r.txid===txid))throw Error('Receipt not found.');
 const encoded=JSON.stringify(rows.filter(r=>r.txid!==txid));storage.setItem(KEY,encoded);if(storage.getItem(KEY)!==encoded)throw Error('Could not remove the local receipt.');
}

export function importTransactionReceipt(value,storage=globalThis.localStorage,now=Date.now()){
 const r=validateTransactionReceipt(value);if(!Number.isSafeInteger(now)||now<r.createdAt)throw Error('Receipt date is in the future.');
 return saveTransactionReceipt({...r,status:'unknown',height:0,checkedAt:now},storage);
}
