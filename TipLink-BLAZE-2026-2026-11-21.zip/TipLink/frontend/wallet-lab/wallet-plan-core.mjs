import {deriveWalletAddresses} from './wallet-address-core.mjs';
import {previewTip,validateRecipient} from './preview-core.mjs';
import {buildUnsigned,verifyUnsigned} from './unsigned-core.mjs';
export const PLAN_MAX_AGE_MS=60000;
const knownFixtures=new Set([1,2,3,4,5].map(n=>`76a914${n.toString(16).padStart(2,'0').repeat(20)}88ac`));
export function prepareWalletPlan({manager,state,snapshot,amountBch,addresses,now=Date.now(),feeRate=1}) {
  if(state!=='connected'||snapshot?.manager!==manager)throw new Error('Connect this wallet and refresh its funding first.');
  const data=snapshot.value;
  const checkedAt=Date.parse(data?.checkedAt);
  if(!Number.isFinite(checkedAt)||!Number.isFinite(now)||now<checkedAt||now-checkedAt>PLAN_MAX_AGE_MS)throw new Error('Funding snapshot expired. Refresh funding before reviewing.');
  if(data.network!=='BCH mainnet'||data.checkpoint!==898374||data.scannedScripts!==4)throw new Error('A checked BCH mainnet funding snapshot is required.');
  const rows=deriveWalletAddresses(manager,state,'bitcoincash');
  if(!Array.isArray(snapshot.rows)||rows.some((row,i)=>snapshot.rows[i]?.scriptHex!==row.scriptHex||snapshot.rows[i]?.path!==row.path||snapshot.rows[i]?.index!==row.index))throw new Error('Wallet address paths changed. Refresh funding.');
  const preview=previewTip(amountBch,addresses);
  if(preview.outputs.some(o=>knownFixtures.has(o.scriptHex)))throw new Error('Example addresses are for demo mode only. Enter verified recipient addresses for a wallet-funded plan.');
  if(!Array.isArray(data.candidates)||data.candidates.length>20)throw new Error('Invalid funding snapshot.');
  const seen=new Set();
  const confirmed=[];
  for(const c of data.candidates) {
    const row=rows.find(r=>r.path===c.path&&r.index===c.addressIndex);
    if(!row||c.scriptHex!==row.scriptHex||c.status!=='RAW VERIFIED; PROVIDER REPORTS UNSPENT'||!Number.isSafeInteger(c.height))throw new Error('Funding candidate is not bound to a checked wallet path.');
    const key=`${c.txid}:${c.index}`;if(seen.has(key))throw new Error('Duplicate funding candidate.');seen.add(key);
    if(c.height>0)confirmed.push(c);
  }
  if(!confirmed.length)throw new Error('No confirmed BCH-only funding in the four scanned addresses. You can still explore the demo without adding funds.');
  const changeRow=rows.find(r=>r.path==='change'&&r.index===0);
  validateRecipient(changeRow.address);
  // Deterministic bounded selection: consider larger confirmed outputs first.
  confirmed.sort((a,b)=>BigInt(a.sats)===BigInt(b.sats)?`${a.txid}:${a.index}`.localeCompare(`${b.txid}:${b.index}`):BigInt(a.sats)>BigInt(b.sats)?-1:1);
  const selected=[];let plan;
  for(const c of confirmed) {
    selected.push(c);
    try{plan=buildUnsigned({amountBch,addresses,changeAddress:changeRow.address,utxos:selected,feeRate});break;}
    catch(e){if(!/Insufficient funding|Change is below/.test(e.message))throw e;}
  }
  if(!plan)throw new Error('Confirmed funding cannot cover this tip, estimated fee and valid change. Try a smaller amount or refresh funding.');
  verifyUnsigned(plan.unsignedHex,plan);
  return {...plan,mode:'WALLET-FUNDED UNSIGNED REVIEW — NOT SENT',inputPaths:selected.map((c,i)=>[i,c.path,c.addressIndex]),changeAddress:changeRow.address,checkedAt:data.checkedAt,expiresAt:new Date(checkedAt+PLAN_MAX_AGE_MS).toISOString()};
}
