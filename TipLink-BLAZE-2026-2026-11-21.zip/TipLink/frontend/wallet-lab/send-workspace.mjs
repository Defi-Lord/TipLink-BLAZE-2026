const KEY = 'tiplink.send-workspace.v1';
const MAX_BYTES = 120000;
const steps = new Set(['amount', 'recovery', 'review', 'restore', 'handoff']);

function browserStorage() {
  return globalThis.localStorage;
}

export function readSendWorkspace(storage) {
  try {
    storage ??= browserStorage();
    const raw = storage.getItem(KEY);
    if (!raw || raw.length > MAX_BYTES) return null;
    const value = JSON.parse(raw);
    if (value.version !== 1 || typeof value.amount !== 'string' || value.amount.length > 64 ||
        !['1', '24', '168', '720'].includes(value.hours) ||
        !['1', '2', '5', '10'].includes(value.feeRate) || !steps.has(value.step)) return null;
    const encrypted = ['tiplink-approved-transfer', 'tiplink-direct-funded'].includes(value.backup?.type)
      ? value.backup.encryptedDraft : value.backup;
    if (value.backup && (encrypted?.type !== 'tiplink-encrypted-draft' ||
        encrypted.version !== 1 || typeof encrypted.ciphertext !== 'string')) return null;
    return {version: 1, amount: value.amount, hours: value.hours, feeRate: value.feeRate,
      step: value.step, fundingMethod: value.fundingMethod === 'wizard' ? 'wizard' : 'direct', backup: value.backup || null};
  } catch {
    return null;
  }
}

export function saveSendWorkspace({amount, hours, feeRate, step, fundingMethod, backup}, storage) {
  try {
    storage ??= browserStorage();
    const value = {version: 1, amount, hours, feeRate, step, fundingMethod: fundingMethod === 'wizard' ? 'wizard' : 'direct', backup: backup || null};
    const raw = JSON.stringify(value);
    if (raw.length > MAX_BYTES) return false;
    // Store only this allowlist. Passwords and decrypted keys remain in memory.
    const encrypted = ['tiplink-approved-transfer', 'tiplink-direct-funded'].includes(backup?.type) ? backup.encryptedDraft : backup;
    if (backup && encrypted?.type !== 'tiplink-encrypted-draft') return false;
    storage.setItem(KEY, raw);
    return true;
  } catch {
    return false;
  }
}
