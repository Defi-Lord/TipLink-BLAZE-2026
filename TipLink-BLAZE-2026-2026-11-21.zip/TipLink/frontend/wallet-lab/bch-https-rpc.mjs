// Same-origin, read-only HTTPS transport to a fixed independent BCH Electrum TLS peer.
// Useful where browsers/mobile carriers cannot open outbound WSS on port 50004.
const READ_METHODS=new Set([
 'server.version','server.features','blockchain.block.header',
 'blockchain.scripthash.listunspent','blockchain.scripthash.get_history',
 'blockchain.transaction.get','blockchain.headers.subscribe'
]);
const PROVIDERS=new Set(['nordic','imaginary']);
export function openBchHttpsRpc({provider,signal,Fetcher=globalThis.fetch,timeoutMs=15000}={}){
 if(!PROVIDERS.has(provider)||typeof Fetcher!=='function')throw Error('Unsupported read-only BCH provider.');
 let closed=false;
 const active=new Set();
 return {
  close(){closed=true;for(const controller of active)controller.abort();active.clear();},
  async call(method,params=[]){
   if(!READ_METHODS.has(method)||!Array.isArray(params))throw Error('Only allowlisted read methods are available.');
   if(closed||signal?.aborted)throw Error('Funding lookup cancelled or closed.');
   const controller=new AbortController();
   const cancel=()=>controller.abort();
   signal?.addEventListener('abort',cancel,{once:true});
   const timer=setTimeout(()=>controller.abort(),timeoutMs);
   active.add(controller);
   try{
    const response=await Fetcher('/api/bch-read',{
     method:'POST',headers:{'Content-Type':'application/json'},
     body:JSON.stringify({provider,method,params}),
     signal:controller.signal,cache:'no-store',credentials:'same-origin',redirect:'error'
    });
    if(!response?.ok)throw Error('BCH HTTPS bridge could not reach its independent provider.');
    const data=await response.json();
    if(!data||typeof data!=='object'||!Object.hasOwn(data,'result'))throw Error('BCH HTTPS provider returned an invalid response.');
    return data.result;
   }finally{
    clearTimeout(timer);signal?.removeEventListener('abort',cancel);active.delete(controller);
   }
  }
 };
}
