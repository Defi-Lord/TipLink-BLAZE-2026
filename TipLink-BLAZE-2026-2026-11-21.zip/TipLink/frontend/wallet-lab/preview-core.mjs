import { decodeCashAddress, encodeCashAddress, binToHex } from '@bitauth/libauth';
import { parseBch, splitTip } from '../src/split.mjs';

export const PREVIEW_OUTPUT_MINIMUM = 1000n; // App minimum only; not a live network policy quote.
export function validateRecipient(value) {
  if (typeof value !== 'string') throw new Error('Enter a BCH CashAddr.');
  const address = value.trim();
  if (address !== address.toLowerCase() && address !== address.toUpperCase()) throw new Error('Mixed-case addresses are invalid.');
  const normalized = address.toLowerCase();
  if (normalized.startsWith('bchtest:') || normalized.startsWith('bchreg:')) throw new Error('Wrong network. Use a BCH mainnet address.');
  const decoded = decodeCashAddress(normalized.includes(':') ? normalized : 'bitcoincash:'+normalized);
  if (typeof decoded === 'string') throw new Error('Invalid CashAddr or checksum. Include the bitcoincash: prefix.');
  if (decoded.prefix !== 'bitcoincash') throw new Error('This preview accepts BCH mainnet addresses only.');
  if (decoded.type !== 'p2pkh' || decoded.payload.length !== 20) throw new Error('Use a standard BCH P2PKH address (bitcoincash:q…). Other types are not supported in this preview.');
  const hash = binToHex(decoded.payload);
  return { address: encodeCashAddress({ payload: decoded.payload, prefix: decoded.prefix, type: decoded.type }).address, scriptHex: `76a914${hash}88ac` };
}
export function previewTip(amountBch, addresses) {
  if (!Array.isArray(addresses) || addresses.length !== 3) throw new Error('Three recipient addresses required.');
  const recipients = addresses.map(validateRecipient);
  if (new Set(recipients.map(r => r.scriptHex)).size !== 3) throw new Error('Recipients must have three different locking scripts.');
  const totalSats = parseBch(amountBch);
  const members = [{ id: 'Host', bps: 6000 }, { id: 'Editor', bps: 2500 }, { id: 'Designer', bps: 1500 }];
  const split = splitTip(totalSats, members, PREVIEW_OUTPUT_MINIMUM);
  return { network: 'BCH mainnet (recipient preview only)', totalSats, outputs: split.map((row, i) => ({ ...row, ...recipients[i] })) };
}
export function formatBch(sats) {
  return `${sats / 100000000n}.${(sats % 100000000n).toString().padStart(8, '0')}`;
}
