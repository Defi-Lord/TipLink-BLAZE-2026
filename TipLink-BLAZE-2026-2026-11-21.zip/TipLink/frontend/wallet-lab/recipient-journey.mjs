import {validateLinkRecord} from './links-core.mjs';
import {validateRecipient} from './preview-core.mjs';

function activeDemo(record,now){
 const r=validateLinkRecord(record);
 if(r.kind!=='demo-send')throw Error('Payment requests use a separate checkout.');
 if(!Number.isSafeInteger(now)||now<r.createdAt)throw Error('This demo link is not active yet.');
 if(now>=r.expiresAt)throw Error('This demo link has expired. Ask for a new link.');
 return r;
}
export function startRecipientJourney(record){
 const r=validateLinkRecord(record);
 if(r.kind!=='demo-send')throw Error('Only demo envelopes use this preview.');
 return {link:JSON.stringify(r),stage:'welcome',mode:'guest',address:'',review:null};
}
export function advanceRecipientJourney(state,action,record,now=Date.now()){
 const r=activeDemo(record,now);
 if(!state||state.link!==JSON.stringify(r))throw Error('The link changed. Open it again to restart.');
 const next={...state};
 if(action.type==='start'&&state.stage==='welcome')return {...next,stage:'destination'};
 if(action.type==='mode'&&state.stage==='destination'&&['guest','existing'].includes(action.value))return {...next,mode:action.value,address:'',review:null};
 if(action.type==='address'&&state.stage==='destination'&&state.mode==='existing'&&typeof action.value==='string'&&action.value.length<=200)return {...next,address:action.value,review:null};
 if(action.type==='review'&&state.stage==='destination'){
  const address=state.mode==='existing'?validateRecipient(state.address).address:null;
  return {...next,stage:'review',review:{mode:state.mode,address,sats:r.sats}};
 }
 if(action.type==='back'&&state.stage==='review')return {...next,stage:'destination',review:null};
 if(action.type==='finish'&&state.stage==='review'&&state.review){
  const expected=state.mode==='existing'?validateRecipient(state.address).address:null;
  if(state.review.sats!==r.sats||state.review.mode!==state.mode||state.review.address!==expected)throw Error('Review the destination again before continuing.');
  return {...next,stage:'complete'};
 }
 throw Error('This step is unavailable. Return to the previous screen.');
}
