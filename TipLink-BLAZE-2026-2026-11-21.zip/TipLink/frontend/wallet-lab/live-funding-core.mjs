import {sha256,binToHex,hexToBin,decodeTransaction} from '@bitauth/libauth';
import {deriveWalletPath,inspectFundingTransaction} from './wallet-address-core.mjs';
export const GENESIS='000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f';
export const CHECKPOINT={height:898374,hash:'00000000000000000157a0a3dcdc80f1acd809648d238c1e893b26247091b3b4'};
export function scriptHash(scriptHex) {
  if(typeof scriptHex!=='string'||!/^76a914[0-9a-fA-F]{40}88ac$/.test(scriptHex))throw new Error('Expected a standard wallet P2PKH script.');
  return binToHex(sha256.hash(hexToBin(scriptHex)).reverse());
}
export function verifyProviderIdentity(features, header) {
  if(features?.genesis_hash!==GENESIS || features.hash_function!=='sha256')throw new Error('Provider network or hash algorithm mismatch.');
  if(typeof header!=='string'||!/^[0-9a-fA-F]{160}$/.test(header))throw new Error('Invalid BCH checkpoint header.');
  const hash=binToHex(sha256.hash(sha256.hash(hexToBin(header))).reverse());
  if(hash!==CHECKPOINT.hash)throw new Error('Provider did not match the BCH mainnet checkpoint.');
  return true;
}
export function validateUnspentList(list, maxOutputs=20) {
  if(!Array.isArray(list)||list.length>maxOutputs)throw new Error('Unexpected or oversized unspent list. Scan stopped; no partial balance is shown.');
  const seen=new Set();
  return list.map(row=>{
    if(!row||typeof row!=='object'||typeof row.tx_hash!=='string'||!/^[a-fA-F0-9]{64}$/.test(row.tx_hash)||!Number.isSafeInteger(row.tx_pos)||row.tx_pos<0||row.tx_pos>0xffffffff||!Number.isSafeInteger(row.height)||row.height < -1)throw new Error('Malformed unspent output.');
    const value=typeof row.value==='number'&&Number.isSafeInteger(row.value)?String(row.value):row.value;
    if(typeof value!=='string'||!/^[1-9]\d{0,15}$/.test(value)||BigInt(value)>2100000000000000n)throw new Error('Malformed unspent value.');
    const key=`${row.tx_hash.toLowerCase()}:${row.tx_pos}`;if(seen.has(key))throw new Error('Duplicate unspent outpoint.');seen.add(key);
    return {txid:row.tx_hash.toLowerCase(),index:row.tx_pos,sats:value,height:row.height,key};
  });
}
export async function discoverWalletFunding({rpc,manager,state,signal}){
  const check=()=>{if(signal?.aborted)throw Error('Funding lookup cancelled.');};
  check();
  await rpc.call('server.version',['TipLink wallet discovery','1.4.3']);
  verifyProviderIdentity(await rpc.call('server.features',[]),await rpc.call('blockchain.block.header',[CHECKPOINT.height]));
  const scan=async path=>{
    const funded=[];
    let gap=0;
    for(let start=0;start<200;start+=10){
      check();
      const batch=Array.from({length:10},(_,index)=>deriveWalletPath(manager,state,path,start+index));
      const histories=await Promise.all(batch.map(row=>rpc.call('blockchain.scripthash.get_history',[scriptHash(row.scriptHex)])));
      for(const [index,history] of histories.entries()){
        if(!Array.isArray(history)||history.some(entry=>typeof entry?.tx_hash!=='string'||!/^[a-f0-9]{64}$/.test(entry.tx_hash)||!Number.isSafeInteger(entry.height)||entry.height< -1))throw Error('Invalid wallet history.');
        if(history.length){gap=0;funded.push(batch[index]);}
        else if(++gap===20)return funded;
      }
    }
    throw Error('Wallet discovery reached 200 addresses on one path. Check funding in your wallet.');
  };
  const paths=await Promise.all(['receive','change'].map(scan));
  const baseline= ['receive','receive','receive','change'].map((path,index)=>deriveWalletPath(manager,state,path,index===3?0:index));
  const rows=[...new Map([...baseline,...paths.flat()].map(row=>[row.path+':'+row.index,row])).values()];
  const value=await lookupWalletFunding({rpc,rows,signal,discovered:true});
  return {rows,value};
}
export async function lookupWalletFunding({rpc,rows,signal,discovered=false}) {
  const check=()=>{if(signal?.aborted)throw new Error('Funding lookup cancelled.');};
  check();
  if(!Array.isArray(rows)||(discovered?rows.length<4||rows.length>400:rows.length!==4)||new Set(rows.map(r=>r.scriptHex)).size!==rows.length)throw new Error('Derive three receive scripts and one change script first.');
  const hashes=rows.map(r=>scriptHash(r.scriptHex));
  await rpc.call('server.version',['TipLink funding read lab','1.4.3']);check();
  const features=await rpc.call('server.features',[]);check();
  const header=await rpc.call('blockchain.block.header',[CHECKPOINT.height]);check();
  verifyProviderIdentity(features,header);
  const snapshots=[];let count=0;
  for(let i=0;i<rows.length;i+=10){
    check();
    const results=await Promise.all(hashes.slice(i,i+10).map(async hash=>validateUnspentList(await rpc.call('blockchain.scripthash.listunspent',[hash,'include_tokens']),discovered?1000:20)));
    for(const listed of results){
      count+=listed.length;
      if(count>(discovered?128:20))throw Error('Too many funding outputs for a single scan. Check funding in your wallet.');
      snapshots.push(listed);
    }
  }
  const candidates=[];const allOutpoints=new Set();const rawCache=new Map();let excludedTokens=0;let excludedCoinbase=0;
  for(let i=0;i<rows.length;i++)for(const item of snapshots[i]) {
    check();if(allOutpoints.has(item.key))throw new Error('Provider assigned one outpoint to multiple scripts.');allOutpoints.add(item.key);
    if(!rawCache.has(item.txid))rawCache.set(item.txid,await rpc.call('blockchain.transaction.get',[item.txid,false]));
    const raw=rawCache.get(item.txid);check();
    // Verify raw ID/script/value before excluding token outputs or accepting BCH-only candidates.
    if(typeof raw!=='string'||raw.length>2000000||!/^(?:[0-9a-fA-F]{2})+$/.test(raw))throw new Error('Invalid funding transaction bytes.');
    const tx=decodeTransaction(hexToBin(raw));
    if(typeof tx==='string')throw new Error('Funding transaction decode failed.');
    const output=tx.outputs[item.index];
    if(!output||binToHex(output.lockingBytecode)!==rows[i].scriptHex||output.valueSatoshis!==BigInt(item.sats))throw new Error('Provider funding amount/script does not match raw transaction.');
    // inspectFundingTransaction rejects tokens; verify the txid separately for excluded outputs too.
    const txHash=binToHex(sha256.hash(sha256.hash(hexToBin(raw))).reverse());
    if(txHash!==item.txid)throw new Error('Funding transaction ID mismatch.');
    if(output.token!==undefined){excludedTokens++;continue;}
    if(tx.inputs.length===1&&tx.inputs[0].outpointIndex===0xffffffff&&tx.inputs[0].outpointTransactionHash.every(v=>v===0)){excludedCoinbase++;continue;}
    const matched=inspectFundingTransaction({rawHex:raw,expectedTxid:item.txid,outputIndex:item.index,walletScriptHex:rows[i].scriptHex});
    candidates.push({...matched,path:rows[i].path,addressIndex:rows[i].index,height:item.height,status:'RAW VERIFIED; PROVIDER REPORTS UNSPENT'});
  }
  // Refresh every queried script; no result is returned if the snapshot changed mid-scan.
  for(let i=0;i<rows.length;i++) {
    check();const fresh=validateUnspentList(await rpc.call('blockchain.scripthash.listunspent',[hashes[i],'include_tokens']),discovered?1000:20);
    const fingerprint=l=>l.map(x=>`${x.key}:${x.sats}`).sort().join('|');
    if(fingerprint(fresh)!==fingerprint(snapshots[i]))throw new Error('Funding changed during lookup. Retry for a fresh snapshot.');
  }
  check();const totalSats=candidates.reduce((sum,c)=>sum+BigInt(c.sats),0n);
  if(totalSats>2100000000000000n)throw new Error('Aggregate funding outside supported range.');
  return {network:'BCH mainnet',checkpoint:CHECKPOINT.height,scannedScripts:rows.length,candidates,totalSats,excludedTokens,excludedCoinbase,checkedAt:new Date().toISOString()};
}
