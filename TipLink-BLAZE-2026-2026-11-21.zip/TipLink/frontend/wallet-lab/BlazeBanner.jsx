import React, {useState} from 'react';
import './blaze-banner.css';

const source = 'https://github.com/Defi-Lord/Tip-Link';
const baseline = '5bc094c40ccacbd3f6fb25165558004d2b832131';
const votingAddress = 'bitcoincash:zq8wkl4qvkkxaggr0006velyy86gwulsx563k4l39x';

export function BlazeBanner() {
  const [copyMessage, setCopyMessage] = useState('');
  const [detailsOpen, setDetailsOpen] = useState(false);

  async function copyAddress() {
    try {
      await navigator.clipboard.writeText(votingAddress);
      setCopyMessage('Address copied.');
    } catch {
      setCopyMessage('Select and copy the address manually.');
    }
  }

  return (
    <section className="blaze-banner" aria-labelledby="blaze-title">
      <div className="blaze-content">
        <h2 id="blaze-title">BCH BLAZE 2026</h2>
        <div className="blaze-links">
          <a href="/bch-blaze/TipLink-BCH-BLAZE-2026-Presentation.pdf" target="_blank" rel="noopener noreferrer">Presentation</a>
          <a href={source} target="_blank" rel="noopener noreferrer">Source code</a>
          <a href={source + '/tree/' + baseline} target="_blank" rel="noopener noreferrer">Pre-hackathon source</a>
        </div>
        <div className="blaze-vote">
          <span>EMBER2026 voting address</span>
          <code title={votingAddress}>{votingAddress}</code>
          <button type="button" onClick={copyAddress} aria-label="Copy EMBER2026 voting address">Copy</button>
        </div>
        <p className="blaze-copy-status" role="status">{copyMessage}</p>
      </div>
      <button type="button" className="blaze-details" aria-expanded={detailsOpen} aria-controls="blaze-details"
        onClick={() => setDetailsOpen(open => !open)}>Details <span aria-hidden="true">›</span></button>
      <p id="blaze-details" className="blaze-history-note" hidden={!detailsOpen}>
        TipLink started before BLAZE. During the event, we updated the dashboard and in-app help and fixed wallet and payment-flow issues.
      </p>
    </section>
  );
}
