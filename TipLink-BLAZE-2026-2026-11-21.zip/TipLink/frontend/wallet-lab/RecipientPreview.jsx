import React, { useState } from 'react';
import { previewTip, formatBch } from './preview-core.mjs';
import { buildSimulation } from './unsigned-core.mjs';

export function RecipientPreview() {
  const [amount, setAmount] = useState('0.001');
  const [addresses, setAddresses] = useState(['', '', '']);
  const [preview, setPreview] = useState(null);
  const [error, setError] = useState('');
  const [plan, setPlan] = useState(null);
  const [showScripts, setShowScripts] = useState(false);
  function invalidate() { setPreview(null); setPlan(null); setError(''); }
  function submit(event) {
    event.preventDefault(); setError(''); setPreview(null); setPlan(null);
    try { setPreview(previewTip(amount, addresses)); }
    catch (e) { setError(e.message || 'Preview failed. Check your entries.'); }
  }
  function simulate() {
    setPlan(null); setError('');
    try { setPlan(buildSimulation(amount, addresses)); }
    catch (e) { setError(e.message || 'Unsigned simulation failed.'); }
  }
  return <section className="card preview-card"><div className="step">03 / RECIPIENT PREVIEW</div><h2>See exactly who receives what.</h2><p>Enter three different BCH mainnet receiving addresses. Validation runs locally. Wallet connection is optional for this preview.</p>
    <form onSubmit={submit}>
      <label className="field">Tip amount (BCH)<input required inputMode="decimal" value={amount} onChange={e => { setAmount(e.target.value); invalidate(); }}/></label>
      <div className="recipient-fields">{['Host · 60%', 'Editor · 25%', 'Designer · 15%'].map((label, index) => <label className="field" key={label}>{label}<input required autoComplete="off" spellCheck={false} value={addresses[index]} placeholder="bitcoincash:q…" onChange={e => { setAddresses(addresses.map((a, i) => i === index ? e.target.value : a)); invalidate(); }}/></label>)}</div>
      <button type="submit">Validate & preview split</button>
    </form>
    {error && <p className="error" role="alert">{error}</p>}
    {preview && <div className="preview-result" role="status" aria-live="polite"><h3>Recipient amounts validated</h3><p>Total to recipients: <strong>{formatBch(preview.totalSats)} BCH</strong></p><div className="output-list">{preview.outputs.map(row => <div className="output-row" key={row.id}><strong>{row.id} · {(Number(row.sats) / Number(preview.totalSats) * 100).toFixed(3)}%</strong><span>{formatBch(row.sats)} BCH · {row.sats.toString()} sats</span><code>{row.address}</code></div>)}</div><details open={showScripts} onToggle={e => setShowScripts(e.currentTarget.open)}><summary>Inspect recipient locking scripts</summary>{preview.outputs.map(row => <p key={row.id}>{row.id}<br/><code>{row.scriptHex}</code></p>)}</details></div>}
    {preview && <div className="actions"><button type="button" className="secondary" onClick={simulate}>Build simulated unsigned transaction</button></div>}
    {plan && <div className="preview-result"><div className="step">04 / OFFLINE TRANSACTION LAB</div><h3>Unsigned transaction constructed</h3><p><strong>SIMULATED FUNDING — NOT A PAYMENT</strong></p><p>A fictional 1 BCH input is used. No wallet balance is read, no funds are needed, and this transaction is not submitted to a wallet or network.</p><div className="output-list">{[['Simulated input', plan.totalInputSats], ['Recipients', plan.recipientSats], ['Estimated miner fee', plan.minerFeeSats], ['Change', plan.changeSats]].map(([label, sats]) => <div className="person" key={label}><span>{label}</span><b>{formatBch(sats)} BCH</b></div>)}</div><p>Fee model: {plan.feeRate} sat/byte × {plan.estimatedSignedBytes} estimated signed bytes. Unsigned serialization: {plan.unsignedBytes} bytes.</p><p className="fine">The fee uses a conservative 108-byte P2PKH unlocking-script placeholder per input. Actual signed size and live network policy remain unchecked. Change is returned to a synthetic example script, not your wallet.</p><details><summary>Inspect unsigned transaction hex and outputs</summary><code>{plan.unsignedHex}</code>{plan.outputs.map(row => <p key={row.role}>{row.role} · {row.sats.toString()} sats<br/><code>{row.scriptHex}</code></p>)}</details><p className="fine">The hex was decoded and compared to the generated plan. That verifies serialization consistency only; the funding input does not represent a verified spendable output.</p></div>}
    <p className="fine">Recipient preview and offline unsigned construction only. Nothing is signed or sent. The application minimum is 1,000 satoshis per recipient. Miner fee, input funding, change and current network policy are not checked here. Address validity does not prove recipient ownership. Changing any entry clears the previous preview.</p>
  </section>;
}
