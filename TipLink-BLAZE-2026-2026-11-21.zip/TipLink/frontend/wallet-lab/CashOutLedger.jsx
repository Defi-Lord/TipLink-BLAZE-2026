import React from 'react';
function bch(sats) {
  const amount = BigInt(sats);
  return String(amount / 100000000n) + '.' + String(amount % 100000000n).padStart(8, '0');
}
export function CashOutLedger({ledger, currentCheck}) {
  return <section className="cash-ledger" aria-labelledby="cash-ledger-title">
    <h3 id="cash-ledger-title">Saved test deposits</h3>
    <strong className="cash-ledger-total">{bch(ledger.recordedSats)} <small>BCH test</small></strong>
    <p>{ledger.recordedCount} completed {ledger.recordedCount === 1 ? 'deposit' : 'deposits'} recorded.</p>
    <p className="cash-preview-note">Recorded test deposits only. Spendable balance is separate.</p>
    {!currentCheck && <p className="cash-sandbox-warning" role="status">Current Breet check unavailable. These are previously saved records.</p>}
    {ledger.reviewCount > 0 && <p className="cash-sandbox-warning" role="status">{ledger.reviewCount} {ledger.reviewCount === 1 ? 'record needs' : 'records need'} review because provider details changed.</p>}
    {ledger.items.length > 0 && <details className="cash-detail"><summary>View saved records</summary><ul className="cash-sandbox-history">{ledger.items.map(item => <li key={item.id}>
      <div><strong>{bch(item.amountSats)} BCH test</strong><span>{item.reviewRequired ? 'Held for review' : item.status === 'completed' ? 'Completed deposit recorded' : 'Provider status: ' + item.status}</span></div>
      <small>Wallet credit: {item.walletCredited === true ? 'reported by Breet' : item.walletCredited === false ? 'not credited' : 'not confirmed'}</small>
      {item.reportedCurrency && item.reportedAmount !== null && <p className="cash-ledger-settlement">Breet-reported amount: {item.reportedAmount} {item.reportedCurrency}. Net proceeds unverified.</p>}
      <small>Last checked {new Date(item.checkedAt).toLocaleString()} · Reference {item.id}</small>
    </li>)}</ul></details>}
    {ledger.hasMore && <p>Showing the latest 25 saved records. Totals include all recorded deposits.</p>}
  </section>;
}
