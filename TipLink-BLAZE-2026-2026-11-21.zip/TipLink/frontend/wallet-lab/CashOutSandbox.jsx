import React, {useEffect, useRef, useState} from 'react';
import {CashOutLedger} from './CashOutLedger.jsx';

// Credentials and provider requests stay on the backend. This component never sends BCH.
export function CashOutSandbox() {
  const [wallet, setWallet] = useState(null);
  const [history, setHistory] = useState(null);
  const [ledger, setLedger] = useState(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [signedIn, setSignedIn] = useState(false);
  const [acknowledged, setAcknowledged] = useState(false);
  const pending = useRef(false);
  const lifecycle = useRef(null);
  useEffect(() => {
    const controller = new AbortController();
    lifecycle.current = controller;
    return () => controller.abort();
  }, []);

  async function request(path, options = {}) {
    const response = await fetch('/api/v1/merchant' + path, {
      credentials: 'same-origin', cache: 'no-store', referrerPolicy: 'no-referrer',
      signal: lifecycle.current?.signal, ...options,
    });
    const result = await response.json();
    if (!response.ok) {
      if (response.status === 401 || response.status === 403) {
        setSignedIn(false); setWallet(null); setHistory(null); setLedger(null);
        throw Error('Open Business and sign in, then return here.');
      }
      throw Error(typeof result.error === 'string' ? result.error : 'Sandbox request unavailable.');
    }
    return result;
  }

  async function load(create = false) {
    if (pending.current) return;
    pending.current = true; setBusy(true); setMessage(''); setHistory(null); setLedger(null); setWallet(null);
    try {
      const session = await request('/auth/session');
      if (typeof session.csrfToken !== 'string') throw Error('Reload and sign in again.');
      setSignedIn(true);
      const result = await request('/cash-out/wallet', create ? {
        method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': session.csrfToken},
        body: JSON.stringify({acknowledgeSandbox: acknowledged}),
      } : {});
      if (result.environment !== 'sandbox' || result.asset !== 'BCH_TEST' || result.payoutVerified !== false ||
          !['ready', 'not_created', 'uncertain'].includes(result.state) ||
          (result.state === 'ready' && (typeof result.address !== 'string' || !/^bchtest:[a-z0-9]{20,110}$/.test(result.address)))) {
        throw Error('Unexpected sandbox response. No funds have been sent.');
      }
      setWallet(result);
      if (result.state === 'ready') {
        const transactions = await request('/cash-out/transactions');
        if (transactions.environment !== 'sandbox' || transactions.payoutVerified !== false ||
            !['checked', 'unavailable'].includes(transactions.state) || !Array.isArray(transactions.items) || transactions.items.length > 25) {
          throw Error('Transaction check unavailable.');
        }
        setHistory(transactions);
        const saved = await request('/cash-out/ledger');
        if (saved.environment !== 'sandbox' || saved.spendingEnabled !== false || saved.payoutVerified !== false ||
            !/^[0-9]{1,30}$/.test(saved.recordedSats) || !Number.isInteger(saved.recordedCount) || saved.recordedCount < 0 || !Number.isInteger(saved.reviewCount) || saved.reviewCount < 0 || !Array.isArray(saved.items) || saved.items.length > 25) throw Error('Saved deposit ledger unavailable.');
        if (saved.items.some(item => !item || !/^[a-f0-9]{24}$/.test(item.id) || !/^[1-9][0-9]{0,15}$/.test(item.amountSats) ||
            !['pending', 'completed', 'flagged', 'deleted', 'failed', 'unknown'].includes(item.status) || typeof item.reviewRequired !== 'boolean' ||
            ![true, false, null].includes(item.walletCredited) || ![null, 'USD', 'NGN', 'GHS'].includes(item.reportedCurrency) ||
            (item.reportedAmount !== null && (typeof item.reportedAmount !== 'string' || !/^(?:0|[1-9][0-9]{0,12})(?:\.[0-9]{1,18})?$/.test(item.reportedAmount))) || !Number.isFinite(Date.parse(item.checkedAt)))) throw Error('Saved deposit ledger could not be verified.');
        setLedger(saved);
      }
    } catch (error) {
      if (error.name !== 'AbortError') setMessage(create ?
        'Address creation may have reached Breet. Use “Load test address” to check; do not submit another creation. ' + error.message : error.message);
    } finally {pending.current = false; if (!lifecycle.current?.signal.aborted) setBusy(false);}
  }

  return <section className="cash-preview cash-sandbox" aria-labelledby="cash-sandbox-title">
    <h2 id="cash-sandbox-title">Test BCH deposit</h2>
    <p>Load your Breet test address and review deposits on the BCH test network.</p>
    <button type="button" className={wallet?.state === 'ready' ? 'secondary' : 'primary'} disabled={busy} onClick={() => load()}>{busy ? 'Checking…' : wallet?.state === 'ready' ? 'Refresh test deposits' : 'Load test address'}</button>
    {!signedIn && <p className="cash-preview-note">Sign in through the Business tab to access your own test address.</p>}
    {wallet?.state === 'not_created' && <>
      <label className="cash-sandbox-ack"><input type="checkbox" checked={acknowledged} onChange={event => setAcknowledged(event.target.checked)} />I understand this is a sandbox test.</label>
      <button type="button" className="cash-preview-action" disabled={busy || !acknowledged} onClick={() => load(true)}>Create test deposit address →</button>
    </>}
    {wallet?.state === 'uncertain' && <p role="status">Address creation is unconfirmed. Check Breet using the saved TipLink sandbox label; another address will not be requested automatically. Reference: <code>{wallet.label}</code></p>}
    {wallet?.state === 'ready' && <>
      <div className="cash-sandbox-address"><span>Your BCH test address</span><code>{wallet.address}</code>
        <button type="button" className="cash-sandbox-secondary" onClick={async () => {
          try {await navigator.clipboard.writeText(wallet.address); setMessage('Test address copied.');}
          catch {setMessage('Copy unavailable. Select the address above to copy it.');}
        }}>Copy test address</button>
      </div>
      <p className="cash-sandbox-warning">Sandbox only. Never send mainnet BCH to this address.</p>
      {ledger && <CashOutLedger ledger={ledger} currentCheck={history?.state === 'checked'}/> }
      <details className="cash-detail">
      <summary>Latest Breet activity</summary>
      {!history && <p>No current activity loaded.</p>}
      {history?.state === 'unavailable' && <p role="status">Breet could not confirm the current activity. Refresh later.</p>}
      {history?.state === 'checked' && <>
        <p className="cash-preview-note">Checked {new Date(history.checkedAt).toLocaleTimeString()}. Refreshes are cached for 30 seconds.</p>
        {history.items.length === 0 ? <p>No test deposits returned for this address.</p> : <ul className="cash-sandbox-history">{history.items.map(item => <li key={item.id}>
          <div><strong>{item.amountBch} BCH test</strong><span>{item.status === 'completed' ? 'Test deposit completed' : 'Provider status: ' + item.status}</span></div>
          <small>{new Date(item.createdAt).toLocaleString()}</small>
        </li>)}</ul>}
        {history.hasMore && <p>Showing the latest 25 results. More records are available in Breet.</p>}
      </>}
      </details>
    </>}
    {message && <p role="status" className="cash-preview-note">{message}</p>}
  </section>;
}
