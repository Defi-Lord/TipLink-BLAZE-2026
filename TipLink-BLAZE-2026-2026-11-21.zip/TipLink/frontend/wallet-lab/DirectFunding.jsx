import React,{useEffect,useRef,useState} from 'react';
import {formatBch} from './preview-core.mjs';
import {startDirectFundingMonitor} from './direct-funding-monitor.mjs';
import {useDeviceWallet} from './DeviceWallet.jsx';
import {TipLinkWalletFunding} from './TipLinkWalletFunding.jsx';

// Direct BCH funding watches the blockchain automatically and never asks
// Selene for a WizardConnect signature. A confirmed payment advances the flow.
export function DirectFunding({draft,encryptedDraft,onFunded}){
 const device=useDeviceWallet();const[fundingSource,setFundingSource]=useState('tiplink');
 const[monitor,setMonitor]=useState({phase:'starting',status:'unfunded',
  message:'Starting automatic BCH funding checks…'});
 const[busy,setBusy]=useState(false),[copied,setCopied]=useState(false),[error,setError]=useState('');
 const monitorRef=useRef(null),onFundedRef=useRef(onFunded);
 onFundedRef.current=onFunded;
 useEffect(()=>{
  setMonitor({phase:'starting',status:'unfunded',message:'Connecting to the BCH network…'});
  setBusy(true);
  const watcher=startDirectFundingMonitor({
   draft,encryptedDraft,
   onUpdate:next=>{
    setBusy(next.phase==='checking');
    setMonitor(old=>({...old,...next,message:next.message??old.message}));
   },
   onFunded:handoff=>onFundedRef.current(handoff),
   onDetected:handoff=>onFundedRef.current(handoff)
  });
  monitorRef.current=watcher;
  const onVisible=()=>{if(document.visibilityState==='visible')void watcher.refresh();};
  const onOnline=()=>{void watcher.refresh();};
  const onOffline=()=>{void watcher.refresh();};
  document.addEventListener('visibilitychange',onVisible);
  window.addEventListener('online',onOnline);
  window.addEventListener('offline',onOffline);
  return()=>{
   watcher.stop();
   if(monitorRef.current===watcher)monitorRef.current=null;
   document.removeEventListener('visibilitychange',onVisible);
   window.removeEventListener('online',onOnline);
   window.removeEventListener('offline',onOffline);
  };
 },[draft.contract.address,draft.amountSats,encryptedDraft]);
 async function copy(){
  try{await navigator.clipboard.writeText(draft.contract.address);setCopied(true);}
  catch{setCopied(false);setError('Clipboard is unavailable. Select and copy the address shown below.');}
 }
 const checking=busy||monitor.phase==='starting'||monitor.phase==='checking';
 const detected=monitor.status==='unconfirmed';
 const attention=monitor.phase==='attention';
 const statusText=monitor.phase==='error'
  ?'TipLink status sync interrupted. This is not a blockchain confirmation result.'
  :monitor.phase==='paused'?'Status checks paused. They resume when you return online.'
  :detected?'BCH payment detected. Waiting for blockchain confirmation. TipLink is watching automatically.'
  :monitor.phase==='watching'?'Watching for payment automatically…'
  :checking?'Checking BCH funding securely…'
  :attention?'Payment needs attention; do not pay twice.'
  :'Waiting for the BCH payment…';
 const remaining=draft.contract.reclaimAfter*1000-Date.now();
 return <div className="direct-bch-funding">
  <span className="guided-kicker">SEND MONEY · YOUR WALLET FIRST</span>
  <h2>Fund the link your way.</h2>
  <p className="guided-intro">Use your saved TipLink BCH wallet by default. Connecting an external wallet such as Selene is optional, particularly if your TipLink balance is insufficient.</p>
  <div className="claim-wallet-choice" role="group" aria-label="Choose funding wallet">
   <button type="button" className={fundingSource==='tiplink'?'secondary active':'secondary'} onClick={()=>setFundingSource('tiplink')}>Use my TipLink wallet<small>{device.slot?'Recognized on this device':'Create or restore once, then fund it'}</small></button>
   <button type="button" className={fundingSource==='external'?'secondary active':'secondary'} onClick={()=>setFundingSource('external')}>Use external wallet<small>Optional · Selene or other BCH wallet</small></button>
  </div>
  {fundingSource==='tiplink'&&<TipLinkWalletFunding draft={draft}/>}
  {fundingSource==='external'&&<div className="external-funding-steps">
  <div className="notice"><b>1. Your unique funding address</b>
   <p>Send exactly <strong>{formatBch(BigInt(draft.amountSats))} BCH</strong> to this Bitcoin Cash contract address. Selene will display its own additional sending network fee.</p>
   <label>One-time BCH funding address
    <textarea readOnly rows={3} value={draft.contract.address} onFocus={event=>event.target.select()} spellCheck={false}/>
   </label>
   <button className="secondary full" type="button" onClick={copy}>{copied?'Address copied':'Copy funding address'}</button>
  </div>
  <div className="notice"><b>2. Pay from your wallet</b>
   <p>Open Selene Wallet on your phone, choose Send, paste the address, and enter the exact BCH amount above. Review the contract address and amount in Selene before authorizing.</p>
   <p className="fine">This is a one-time contract address, not a TipLink deposit account. Do not send tokens, use an exchange withdrawal, send multiple payments, or pay a different amount. Do not share this address as the recipient claim link.</p>
   {remaining<=3600000?<p className="error" role="alert">The recovery time is too close. Do not pay this address. Create a new link with a longer recovery window.</p>
    :<p className="fine">Unclaimed-money recovery can be attempted after {new Date(draft.contract.reclaimAfter*1000).toLocaleString()}, not automatically. Keep the recovery file you saved in the previous step.</p>}
  </div>
  </div>}
  <div className="notice" aria-label="Automatic BCH payment monitor"><b>Automatic BCH verification</b>
   <p>TipLink checks the Bitcoin Cash network automatically. Once independent BCH providers detect your exact payment, your pending claim link can be prepared immediately. The recipient's money stays locked until the funding transaction receives a confirmation.</p>
   <div className="guided-file-ready" role="status" aria-live="polite">
    <span aria-hidden="true">{detected?'◉':checking?'◌':monitor.phase==='error'?'↻':'✓'}</span>
    <div><b>{statusText}</b><small>{monitor.phase==='error'?(monitor.issue==='provider-sync'?'BCH providers syncing · automatic retry':'Network status unavailable · automatic retry'):detected?'Payment seen · confirmation pending':monitor.phase==='watching'?'Monitoring active':'A detected payment can create a pending link; claiming waits for a block'}</small></div>
   </div>
   <p className="fine">{monitor.message}</p>
   {Number.isSafeInteger(monitor.checkedAt)&&<p className="fine">Last verified: {new Date(monitor.checkedAt).toLocaleTimeString()}. Checks pause while this tab is hidden or offline.</p>}
   <button className="secondary full" type="button" disabled={checking} onClick={()=>monitorRef.current?.refresh()}>{checking?'Checking securely…':'Check now'}</button>
   {detected&&<p className="fine">You don't need to send BCH again or refresh this page. Block confirmations depend on the Bitcoin Cash network, not TipLink.</p>}
   {attention&&<p className="fine">Stop and keep your recovery file. TipLink cannot automatically activate an unexpected or ambiguous amount.</p>}
   {error&&<div className="error" role="alert">{error}</div>}
  </div>
 </div>;
}
