const empty = () => ({phase: 'idle', result: null, message: ''});
const validName = value => typeof value === 'string' && value.trim().length >= 2 && value.length <= 120 && !/[\x00-\x1f\x7f]/.test(value);
export function createBankLookup({onChange, fetchImpl = fetch, delay = 500, now = Date.now}) {
  let version = 0, timer, request;
  function cancel() {version++; clearTimeout(timer); request?.abort(); request = null;}
  async function resolve(bank, number, current) {
    const controller = new AbortController(); request = controller;
    async function api(path, options = {}) {
      const response = await fetchImpl('/api/v1/merchant' + path, {credentials: 'same-origin', cache: 'no-store', referrerPolicy: 'no-referrer', signal: AbortSignal.any([controller.signal, AbortSignal.timeout(15000)]), ...options});
      const data = await response.json();
      if (!response.ok) throw Error(response.status === 401 || response.status === 403 ? 'Sign in through Business, then return here.' : typeof data.error === 'string' ? data.error : 'Account name lookup unavailable.');
      return data;
    }
    try {
      const session = await api('/auth/session');
      if (current !== version) return;
      if (typeof session.csrfToken !== 'string') throw Error('Reload and sign in again.');
      const data = await api('/cash-out/banks/verify', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': session.csrfToken}, body: JSON.stringify({bankId: bank.id, accountNumber: number})});
      if (current !== version) return;
      const checked = Date.parse(data.checkedAt), expiry = Date.parse(data.expiresAt);
      if (data.environment !== 'sandbox' || data.payoutVerified !== false || data.payoutEnabled !== false || !['resolved', 'details_mismatch'].includes(data.state) || data.bankId !== bank.id || data.bankName !== bank.name || data.accountLast4 !== number.slice(-4) || !Number.isFinite(checked) || expiry - checked !== 300000 || checked > now() + 5000 || expiry <= now() || (data.state === 'resolved' ? !validName(data.accountName) : data.accountName !== null)) throw Error('The account name could not be matched to this bank and number.');
      if (data.state !== 'resolved') throw Error('Breet returned masked, different or incomplete account details. Check the bank and number.');
      onChange({phase: 'resolved', result: data, message: ''});
    } catch (error) {
      if (current === version && !controller.signal.aborted) onChange({phase: 'error', result: null, message: error.name === 'TimeoutError' ? 'The lookup timed out. Try again.' : error.message === 'Failed to fetch' ? 'Could not reach the backend. Try again shortly.' : error.message});
    }
  }
  return {
    update(bank, number) {
      cancel(); onChange(empty());
      if (!bank || !/^\d{1,16}$/.test(bank.id) || !/^\d{10}$/.test(number)) return;
      const current = version;
      onChange({phase: 'loading', result: null, message: ''});
      timer = setTimeout(() => resolve({id: bank.id, name: bank.name}, number, current), delay);
    },
    dispose: cancel,
  };
}
