import {StatusMark} from './StatusReaction.jsx';
import React,{useEffect,useMemo,useRef,useState} from 'react';
import {formatBch} from './preview-core.mjs';
import {lookupClaimFunding,prepareRecipientClaim} from './claim-lookup.mjs';
import {openFundingRpc} from './funding-rpc.mjs';
import {DIRECT_FAST_PROVIDERS,recipientCheckDelay} from './direct-funding-monitor.mjs';
import {paymentCheckIssue,paymentStatusView,canSharePendingClaimLink} from './payment-status.mjs';
import {DeviceWalletSetup,useDeviceWallet} from './DeviceWallet.jsx';
import {TransactionAction} from './TransactionAction.jsx';
import {prepareRecovery,reviewFunding} from './broadcast-core.mjs';
import {claimTransferUrl,encodeClaimTransfer} from './envelope-handoff.mjs';

function downloadApproved(backup){const url=URL.createObjectURL(new Blob([JSON.stringify(backup)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='TipLink-Approved-Transfer.tiplink-transfer';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function useFundingCheck(transfer,{auto=false}={}){
 const[snapshot,setSnapshot]=useState(null),[busy,setBusy]=useState(false),[error,setError]=useState(''),[issue,setIssue]=useState(null);
 const active=useRef(null),session=useRef(null),sessionAbort=useRef(null),checkRef=useRef(null),statusRef=useRef('unknown');
 const[now,setNow]=useState(Date.now());
 useEffect(()=>{
  active.current?.abort();active.current=null;
  sessionAbort.current?.abort();sessionAbort.current=null;
  session.current?.close();session.current=null;
  setBusy(false);setSnapshot(null);setError('');setIssue(null);statusRef.current='unknown';
  const timer=setInterval(()=>setNow(Date.now()),1000);
  return()=>{
   active.current?.abort();active.current=null;
   sessionAbort.current?.abort();sessionAbort.current=null;
   session.current?.close();session.current=null;
   clearInterval(timer);
  };
 },[transfer]);
 async function check({quiet=false}={}){
  if(active.current)return;
  const controller=new AbortController();active.current=controller;
  setBusy(true);setError('');setIssue(null);if(!quiet)setSnapshot(null);
  const timeout=setTimeout(()=>controller.abort('timeout'),30000);
  try{
   if(!session.current){
    const connectionAbort=new AbortController();
    sessionAbort.current=connectionAbort;
    // Keep a validated, independent BCH quorum open for repeated fast checks.
    const connected=await openFundingRpc({
     signal:connectionAbort.signal,providers:[...DIRECT_FAST_PROVIDERS],timeoutMs:10000
    });
    if(active.current!==controller||controller.signal.aborted){
     connected.close();return;
    }
    session.current=connected;
   }
   const result=await lookupClaimFunding({transfer,rpc:session.current,signal:controller.signal});
   if(active.current===controller&&!controller.signal.aborted){
    statusRef.current=result.status;setSnapshot(result);setNow(Date.now());
   }
  }catch(cause){
   if(active.current===controller){
    // Old confirmations cannot unlock a new spend after failed re-verification.
    statusRef.current='unknown';setSnapshot(null);
    const diagnostic=paymentCheckIssue(controller.signal.reason==='timeout'?new Error('Funding provider request timed out'):cause);
    setIssue(diagnostic);
    setError(diagnostic.message);
   }
   sessionAbort.current?.abort();sessionAbort.current=null;
   session.current?.close();session.current=null;
  }finally{
   clearTimeout(timeout);
   if(active.current===controller){setBusy(false);active.current=null;}
  }
 }
 checkRef.current=check;
 useEffect(()=>{
  if(!auto)return;
  let disposed=false,timer;
  const refresh=()=>{
   if(!disposed&&document.visibilityState==='visible'&&navigator.onLine!==false)
    void checkRef.current?.({quiet:true});
  };
  const loop=()=>{
   if(disposed)return;
   refresh();
   // BCH confirmation itself is not accelerated; speed up only detection
   // while a recipient is viewing a pending claim.
   const delay=recipientCheckDelay(statusRef.current);
   timer=setTimeout(loop,delay);
  };
  loop();
  const onVisible=()=>{
   if(document.visibilityState!=='visible')clearTimeout(timer);
   else{clearTimeout(timer);loop();}
  };
  const onOnline=()=>{clearTimeout(timer);loop();};
  document.addEventListener('visibilitychange',onVisible);
  window.addEventListener('online',onOnline);
  return()=>{
   disposed=true;clearTimeout(timer);
   document.removeEventListener('visibilitychange',onVisible);
   window.removeEventListener('online',onOnline);
  };
 },[auto,transfer]);
 function cancel(){
  active.current?.abort('cancelled');
  sessionAbort.current?.abort();sessionAbort.current=null;
  session.current?.close();session.current=null;
 }
 return{snapshot,busy,error,issue,check,cancel,
  fresh:snapshot?.status==='confirmed'&&now>=snapshot.checkedAt&&now-snapshot.checkedAt<30000,now};
}
function CheckStatus({check}){
 const status=paymentStatusView({snapshot:check.snapshot,error:check.issue,now:check.now});
 return <div className={'payment-status payment-status-'+status.kind} role="status" aria-live="polite">
  <strong>{check.busy&&!check.snapshot?'Checking BCH network…':status.label}</strong>
  <p>{status.message}</p>
  {Number.isSafeInteger(check.snapshot?.checkedAt)&&<p className="fine">Network last checked: {new Date(check.snapshot.checkedAt).toLocaleTimeString()}.</p>}
  <p className="fine">Funding status is independently reported by BCH providers; TipLink never treats a relay acknowledgement or a failed status check as a block confirmation.</p>
  {check.busy&&<button className="text-button" onClick={check.cancel}>Cancel this check</button>}
 </div>;
}
export function ApprovedHandoff({handoff,onDone}){
 const[saved,setSaved]=useState(false),[ack,setAck]=useState(false),[notice,setNotice]=useState('');const review=useMemo(()=>reviewFunding(handoff),[handoff]);const check=useFundingCheck(handoff.transfer,{auto:true});const shareable=canSharePendingClaimLink({snapshot:check.snapshot,expectedIdentity:encodeClaimTransfer(handoff.transfer),saved,ack,now:check.now,error:check.issue});const url=claimTransferUrl(handoff.transfer,location.href);const local=['localhost','127.0.0.1','[::1]'].includes(location.hostname);
 async function copy(){if(!shareable)return;try{await navigator.clipboard.writeText(url);setNotice('Claim link copied. Share it privately with the intended recipient.');}catch{setNotice('Clipboard unavailable. Select and copy the link below.');}}
 return <section className="panel approved-handoff"><span className="tag">APPROVED TRANSFER</span><h2>Ready to put money in your link.</h2><p>The wallet approved a transaction for {formatBch(BigInt(handoff.transfer.utxo.sats))} BCH. Approval alone is not payment. Save your recovery file, then choose when to send.</p><dl className="recipient-summary"><div><dt>Into the link</dt><dd>{formatBch(BigInt(handoff.transfer.utxo.sats))} BCH</dd></div><div><dt>Funding network fee</dt><dd>{formatBch(review.plan.feeSats)} BCH</dd></div><div><dt>Total from your wallet</dt><dd>{formatBch(BigInt(handoff.transfer.utxo.sats)+review.plan.feeSats)} BCH</dd></div></dl><h3>1. Save the updated recovery file</h3><p>This file adds the approved transaction and funding details to your encrypted recovery draft. Keep the same recovery-file password. Keep this file private; its signed funding transaction can be broadcast by someone who obtains it.</p><button className="secondary full" onClick={()=>{downloadApproved(handoff.backup);setSaved(true);}}>Save updated recovery file</button><label className="backup-ack"><input type="checkbox" checked={ack} disabled={!saved} onChange={e=>setAck(e.target.checked)}/><span>I saved the updated file and know its password.</span></label><h3>2. Send the approved BCH</h3><TransactionAction kind="funding" hex={handoff.backup.signedFundingHex} transfer={handoff.transfer} handoff={handoff} disabled={!saved||!ack}/><h3>3. Your claim link, as soon as payment is detected</h3><p>TipLink watches the funding transaction automatically. Once independent BCH providers detect it, you may share a clearly marked pending claim link. The recipient cannot claim any BCH until the first block confirms this payment.</p><button className="primary full" disabled={!saved||!ack||check.busy} onClick={check.check}>{check.busy?'Checking envelope…':'Check now (optional)'}</button><CheckStatus check={check}/>{shareable&&<div className="claim-share"><h3 className="status-reaction"><StatusMark tone={check.fresh?'success':'pending'}/>{check.fresh?'Funding confirmed — claim link ready':'Payment detected — pending claim link ready'}</h3><p>{check.fresh?'The funding is confirmed and the recipient may claim after an independent check.':'Funding is still unconfirmed. You can share this link, but the recipient cannot claim or spend BCH until a block confirms the payment.'} Anyone holding this private link may claim once confirmation requirements pass. Send it only to the intended recipient.</p>{local&&<div className="notice">Local preview: this link opens only on this computer. Cross-device sharing needs a public HTTPS deployment.</div>}<label>Private claim link<textarea readOnly rows={4} value={url} onFocus={e=>e.target.select()}/></label><button className="primary full" onClick={copy}>Copy private claim link</button></div>}{notice&&<p role="status">{notice}</p>}<details><summary>Transaction and recovery details</summary><p>Funding transaction ID</p><code>{handoff.transfer.utxo.txid}</code><p>Recovery becomes possible after {new Date(handoff.transfer.contract.reclaimAfter*1000).toLocaleString()}. It does not happen automatically and does not disable the recipient’s claim. The first accepted conflicting spend wins.</p></details><RecoveryEnvelope handoff={handoff} check={check}/>{onDone&&<button className="text-button" onClick={onDone}>Back to Home</button>}</section>;
}
export function DirectFundedHandoff({handoff,onDone}){
 const [saved,setSaved]=useState(false),[ack,setAck]=useState(false),[notice,setNotice]=useState('');
 const check=useFundingCheck(handoff.transfer,{auto:true});
 const shareable=canSharePendingClaimLink({snapshot:check.snapshot,expectedIdentity:encodeClaimTransfer(handoff.transfer),saved,ack,now:check.now,error:check.issue});
 const pending=check.snapshot?.status==='unconfirmed'&&!check.issue;
 const url=claimTransferUrl(handoff.transfer,location.href);
 const local=['localhost','127.0.0.1','[::1]'].includes(location.hostname);
 async function copy(){
  if(!shareable)return;
  try{await navigator.clipboard.writeText(url);setNotice('Private claim link copied. Share it only with the intended recipient.');}
  catch{setNotice('Clipboard unavailable. Select and copy the private link below.');}
 }
 return <section className="panel approved-handoff">
  <span className="tag">{check.fresh?'DIRECT BCH · CONFIRMED':pending?'DIRECT BCH · PAYMENT DETECTED':'DIRECT BCH · VERIFYING FUNDING'}</span>
  <h2>{check.fresh?'Payment confirmed. Your link is ready.':'Payment detected. Prepare your link now.'}</h2>
  <p>TipLink identified an external-wallet payment of {formatBch(BigInt(handoff.transfer.utxo.sats))} BCH to your unique contract address. This did not require a WizardConnect signature.</p>
  <dl className="recipient-summary"><div><dt>Amount locked in link</dt><dd>{formatBch(BigInt(handoff.transfer.utxo.sats))} BCH</dd></div><div><dt>Funding transaction</dt><dd><code>{handoff.transfer.utxo.txid}</code></dd></div></dl>
  <h3>1. Save your updated recovery file</h3>
  <p>This updated file securely binds your encrypted recovery keys to the exact transaction, even while funding is pending. Keep it private, and remember the password. This is not the shareable recipient link.</p>
  <button className="secondary full" onClick={()=>{downloadApproved(handoff.backup);setSaved(true);}}>Save updated recovery file</button>
  <label className="backup-ack"><input type="checkbox" checked={ack} disabled={!saved} onChange={e=>setAck(e.target.checked)}/><span>I saved the updated recovery file and know its password.</span></label>
  <h3>2. Automatic payment status</h3>
  <p>TipLink automatically checks the payment using independent BCH providers. As soon as the exact transaction is detected, you may share a pending claim link after protecting your recovery file. Receiving BCH stays locked until the funding confirms; the recipient's page will update automatically.</p>
  <p className="fine" role="status">{check.busy?'Checking independent BCH providers…':check.fresh?'Confirmed in a BCH block and unspent.':pending?'Payment detected, awaiting a BCH block.':'Checking fresh on-chain payment status.'}</p>
  <button className="secondary full" disabled={check.busy} onClick={()=>check.check()}>{check.busy?'Checking network…':'Recheck now'}</button>
  <CheckStatus check={check}/>
  {shareable&&<div className="claim-share">
   <h3 className="status-reaction"><StatusMark tone={check.fresh?'success':'pending'}/>{check.fresh?'Confirmed claim link ready':'Pending claim link ready to share'}</h3>
   <p>{check.fresh?'Funding is confirmed. The recipient can prepare a claim after another on-chain check.':'The payment is visible but not confirmed. The recipient may open this link now, but TipLink will not allow claiming or spending until a block confirms the funding.'} Anyone holding this link may eventually claim, so share it only with the intended recipient.</p>
   {local&&<p className="notice">Local test links won't work across devices. Use a public HTTPS URL for recipients.</p>}
   <label>Private claim link<textarea readOnly rows={4} value={url} onFocus={e=>e.target.select()}/></label>
   <button className="primary full" onClick={copy}>{check.fresh?'Copy confirmed claim link':'Copy pending claim link'}</button>
  </div>}
  {notice&&<p role="status">{notice}</p>}
  <details><summary>Payment and recovery details</summary><p>Funding transaction ID</p><code>{handoff.transfer.utxo.txid}</code><p>Funding output index: {handoff.transfer.utxo.index}</p><p>Recovery may become possible after {new Date(handoff.transfer.contract.reclaimAfter*1000).toLocaleString()}. It is not automatic and can race with a recipient claim.</p></details>
  <RecoveryEnvelope handoff={handoff} check={check}/>
  {onDone&&<button className="text-button" onClick={onDone}>Back to Home</button>}
 </section>;
}

export function ClaimTransfer({transfer,onOpenWallet}){
 const device=useDeviceWallet();const[method,setMethod]=useState('choose'),[claimResult,setClaimResult]=useState(null);
 const check=useFundingCheck(transfer,{auto:true});const view=paymentStatusView({snapshot:check.snapshot,error:check.issue,now:check.now});const[address,setAddress]=useState(''),[plan,setPlan]=useState(null),[error,setError]=useState('');const heading=useRef(null);
 useEffect(()=>{setPlan(null);setError('');setClaimResult(null);},[transfer]);
 useEffect(()=>{if(method==='here'){setAddress(device.wallet?.address||'');setPlan(null);setClaimResult(null);}},[method,device.wallet?.address]);
 useEffect(()=>{if(!check.fresh||check.issue)setPlan(null);},[check.fresh,check.issue,check.snapshot?.status]);
 function prepare(e){e.preventDefault();setError('');try{setPlan(prepareRecipientClaim({transfer,snapshot:check.snapshot,destination:address}));heading.current?.focus();}catch(e){setPlan(null);setError(e.message);}}
 return <div className="public-checkout"><div className="checkout-story"><span className="eyebrow">MONEY, MADE SHAREABLE.</span><h1 tabIndex={-1}>A little something.<br/><em>For you.</em></h1><p>No TipLink account is needed to open this link. Check the envelope, then receive BCH in a TipLink wallet on this device or at an existing BCH address.</p><div className="notice">Keep this link private. Anyone who has it can use the claim key. Opening it does not automatically transfer money.</div></div><section className="panel checkout-card real-claim"><span className="tag">CLAIM LINK · AUTOMATIC VERIFICATION</span><div className="checkout-value">{formatBch(BigInt(transfer.utxo.sats))}<span>BCH · before receiving fee</span></div><p>This link can be received while the BCH payment is still pending. TipLink checks both independent network providers automatically, shows when the first block confirms, and unlocks claiming only after verified confirmation. Never send money again to speed up this link.</p><div className={'notice notice-'+view.kind} role="status" aria-live="polite"><strong>{view.label}</strong><p>{view.message}</p>{check.snapshot?.status==='unconfirmed'&&<p className="fine">Your claim link is valid to open now; preparing and broadcasting a BCH claim remains disabled until funding is confirmed.</p>}</div><button className="secondary full" disabled={check.busy} onClick={()=>{setPlan(null);check.check();}}>{check.busy?'Checking envelope…':'Check now'}</button><CheckStatus check={check}/>{check.snapshot?.status==='confirmed'&&!check.fresh&&<p role="status">The check is out of date. Check this envelope again.</p>}<div className="claim-wallet-choice" role="group" aria-label="Choose where to receive"><button className={method==='here'?'secondary active':'primary'} onClick={()=>{setMethod('here');setPlan(null);setAddress(device.wallet?.address||'');}}>Receive here in TipLink<small>Create or unlock a wallet on this device. No separate app or account needed.</small></button><button className={method==='existing'?'secondary active':'secondary'} onClick={()=>{setMethod('existing');setPlan(null);setAddress('');}}>Use my existing BCH address<small>Paste an address from your wallet.</small></button></div>{method==='here'&&<div className="claim-device-wallet"><DeviceWalletSetup/></div>}{(method==='existing'||method==='here'&&device.wallet)&&<form onSubmit={prepare}><label>{method==='here'?'Your TipLink receiving address':'Your BCH receiving address'}<textarea readOnly={method==='here'} maxLength={200} rows={3} value={address} onChange={e=>{setAddress(e.target.value);setPlan(null);}} placeholder="bitcoincash:q…" autoComplete="off" spellCheck={false} required/><small>{method==='here'?'This address belongs to the TipLink wallet you protected on this device.':'Copy Receive → BCH address from your wallet. Never enter recovery words or a private key.'}</small></label><button className="secondary full" type="submit" disabled={!check.fresh||check.busy}>Prepare claim for review</button></form>}{error&&<div className="error" role="alert">{error}</div>}{plan&&<div className="claim-prepared"><h2 tabIndex={-1} ref={heading}>Check where your money goes.</h2><dl className="recipient-summary"><div><dt>You would receive</dt><dd>{formatBch(plan.receiveSats)} BCH</dd></div><div><dt>Receiving network fee</dt><dd>{formatBch(plan.feeSats)} BCH</dd></div></dl><code>{plan.destination}</code><p>The receiving transaction was checked locally. Review the address and amount before sending it.</p><p className="fine">The fee uses a fixed 1 sat per byte estimate, not a live recommendation. Funding can change after a check.</p><TransactionAction kind="claim" hex={plan.hex} transfer={transfer} plan={plan} onResult={setClaimResult}/>{method==='here'&&claimResult&&onOpenWallet&&<button className="secondary full" onClick={onOpenWallet}>Open my TipLink wallet</button>}</div>}<div className="notice">Recovery becomes possible after {new Date(transfer.contract.reclaimAfter*1000).toLocaleString()}. Claims do not automatically expire at that time; the sender may also spend this envelope.</div><details><summary>Funding transaction ID</summary><code>{transfer.utxo.txid}</code></details></section></div>;
}

function RecoveryEnvelope({handoff,check}){
 const[address,setAddress]=useState(''),[plan,setPlan]=useState(null),[error,setError]=useState('');
 function prepare(e){e.preventDefault();setError('');try{setPlan(prepareRecovery({handoff,snapshot:check.snapshot,destination:address}));}catch(e){setPlan(null);setError(e.message);}}
 const mature=check.now>handoff.transfer.contract.reclaimAfter*1000;
 return <details className="recovery-envelope"><summary>Recover unclaimed money</summary><p>Recovery can become available after {new Date(handoff.transfer.contract.reclaimAfter*1000).toLocaleString()}. Network time may lag behind your clock. It is not automatic, and a recipient can still claim first.</p>{!handoff.draft?<p>Open your approved recovery file using its password to recover this envelope.</p>:<form onSubmit={prepare}><label>Your BCH address for recovery<textarea value={address} onChange={e=>{setAddress(e.target.value);setPlan(null);}} maxLength={200} rows={3} required placeholder="bitcoincash:q…" spellCheck={false} autoComplete="off"/></label><p className="fine">Use Check funding above for a fresh confirmed-and-unspent check first. The app checks network recovery time again before sending.</p><button className="secondary full" disabled={!mature||!check.fresh||check.busy}>Review recovery</button></form>}{error&&<div className="error" role="alert">{error}</div>}{plan&&<><dl className="recipient-summary"><div><dt>Back to your address</dt><dd>{formatBch(plan.receiveSats)} BCH</dd></div><div><dt>Recovery network fee</dt><dd>{formatBch(plan.feeSats)} BCH</dd></div></dl><code>{plan.destination}</code><TransactionAction kind="recovery" hex={plan.hex} transfer={handoff.transfer} handoff={handoff} plan={plan}/></>}</details>;
}
