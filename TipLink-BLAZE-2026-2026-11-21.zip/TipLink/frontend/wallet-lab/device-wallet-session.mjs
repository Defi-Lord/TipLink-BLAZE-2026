// Ephemeral unlock state. Locking invalidates in-flight asynchronous unlocks.
export function createDeviceWalletSession({clock=Date.now,onChange=()=>{},idleMs=300000}={}){
 let wallet=null,revision=0,lastActivity=clock(),disposed=false;
 function lock(){revision++;wallet=null;if(!disposed)onChange(null);}
 return{
  async open(load){if(disposed)throw Error('Wallet session is closed.');const token=++revision;const value=await load();if(disposed||token!==revision)throw Error('Wallet remains locked. Unlock it to continue.');wallet=value;lastActivity=clock();onChange(value);return value;},
  touch(){lastActivity=clock();},
  tick(){if(wallet&&clock()-lastActivity>=idleMs)lock();},
  lock,
  close(){lock();disposed=true;},
 };
}
