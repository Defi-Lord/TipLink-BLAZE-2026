import React, {useEffect, useRef, useState} from 'react';

const ngn = new Intl.NumberFormat('en-NG', {style: 'currency', currency: 'NGN', minimumFractionDigits: 2});
export function CashOutEstimate() {
  const [amount, setAmount] = useState('20');
  const [estimate, setEstimate] = useState(null);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [now, setNow] = useState(Date.now());
  const request = useRef(null);
  const version = useRef(0);
  useEffect(() => () => {version.current++; request.current?.abort();}, []);
  useEffect(() => {
    if (!estimate) return;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [estimate]);
  const stale = estimate && now >= Date.parse(estimate.refreshAfter);
  async function calculate(event) {
    event.preventDefault();
    request.current?.abort(); const controller = new AbortController(); request.current = controller;
    const current = ++version.current;
    setBusy(true); setEstimate(null); setMessage('');
    async function api(path, options = {}) {
      const response = await fetch('/api/v1/merchant' + path, {credentials: 'same-origin', cache: 'no-store', referrerPolicy: 'no-referrer', signal: controller.signal, ...options});
      const data = await response.json();
      if (!response.ok) throw Error(response.status === 401 || response.status === 403 ? 'Sign in through Business, then return here.' : typeof data.error === 'string' ? data.error : 'Sandbox estimate unavailable.');
      return data;
    }
    try {
      const session = await api('/auth/session');
      if (typeof session.csrfToken !== 'string') throw Error('Reload and sign in again.');
      const data = await api('/cash-out/estimate', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': session.csrfToken}, body: JSON.stringify({amountUsd: amount})});
      const start = Date.parse(data.checkedAt), end = Date.parse(data.refreshAfter);
      if (data.provider !== 'Breet' || data.environment !== 'sandbox' || data.asset !== 'BCH_TEST' || data.currency !== 'NGN' || data.feesQuoted !== false || data.payoutVerified !== false || data.amountUsd !== Number(amount).toFixed(2) ||
          !/^\d{1,13}\.\d{2}$/.test(data.estimatedNgn) || Number(data.estimatedNgn) <= 0 || !/^\d{1,8}\.\d{8}$/.test(data.approximateBch) || Number(data.approximateBch) <= 0 || !/^\d{1,9}\.\d{4}$/.test(data.rateNgnPerUsd) ||
          !Number.isFinite(start) || end - start !== 60000 || start > Date.now() + 5000 || end <= Date.now()) throw Error('The estimate could not be verified. Request a fresh estimate.');
      if (version.current !== current) return;
      setEstimate(data); setNow(Date.now());
    } catch (error) {
      if (error.name !== 'AbortError' && version.current === current) setMessage(error.message === 'Failed to fetch' ? 'Could not reach the backend. Try again shortly.' : error.message);
    } finally {if (version.current === current) setBusy(false);}
  }
  return <section className="cash-preview cash-estimate" aria-labelledby="cash-estimate-title">
    <h2 id="cash-estimate-title">Estimate naira value</h2>
    <p>Enter a USD amount for Breet’s sandbox NGN estimate and approximate BCH equivalent.</p>
    <form onSubmit={calculate}>
      <label htmlFor="cash-estimate-usd">USD value to estimate</label>
      <div className="cash-preview-input"><span aria-hidden="true">$</span><input id="cash-estimate-usd" value={amount} onChange={event => {
        version.current++; request.current?.abort(); setBusy(false); setEstimate(null); setMessage(''); setAmount(event.target.value);
      }} inputMode="decimal" maxLength={8} pattern="[0-9]+([.][0-9]{1,2})?" required /><span>USD</span></div>
      <button className="cash-preview-action" type="submit" disabled={busy}>{busy ? 'Getting Breet estimate…' : 'Get estimate'}</button>
    </form>
    {message && <p className="cash-preview-error" role="alert">{message}</p>}
    {estimate && <>
      {stale ? <div className="cash-estimate-stale" role="status"><strong>Estimate needs refreshing</strong><p>Request a new estimate to see the current rate.</p></div> : <>
        <div className="cash-preview-payout"><span>Estimated NGN value</span><strong>{ngn.format(Number(estimate.estimatedNgn))}</strong><span className="cash-preview-badge">Provider estimate · fees unconfirmed</span></div>
        <dl className="cash-preview-breakdown">
          <div><dt>USD value entered</dt><dd>${estimate.amountUsd}</dd></div>
          <div><dt>Approximate BCH test</dt><dd>{estimate.approximateBch}</dd></div>
          <div><dt>NGN per USD</dt><dd>{ngn.format(Number(estimate.rateNgnPerUsd))}</dd></div>
          <div><dt>Fees</dt><dd>Not quoted</dd></div>
        </dl>
        <p className="cash-preview-note">Checked {new Date(estimate.checkedAt).toLocaleTimeString()}. Refresh after {Math.max(0, Math.ceil((Date.parse(estimate.refreshAfter) - now) / 1000))} seconds.</p>
      </>}
      <p className="cash-preview-note">For reference only. Fees, final conversion rates, and bank payouts are unverified.</p>
    </>}
  </section>;
}
