// Pure status transition gate for transaction reaction animations.
export function shouldCelebrateTransaction(previous,next,{initiated=false}={}){
 return next==='confirmed'&&previous!=='confirmed'&&(previous!==null||initiated===true);
}

export function findNewBusinessConfirmation(previous, invoices){
 if(!previous)return undefined;
 return invoices.find(({id,receipt})=>receipt?.status==='confirmed'&&previous.get(id)!=='confirmed');
}
