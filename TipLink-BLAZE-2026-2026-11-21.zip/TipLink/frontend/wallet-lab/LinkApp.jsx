import {DeviceWalletProvider,DeviceWalletPanel,useDeviceWallet} from './DeviceWallet.jsx';
import {TransactionHistory} from './TransactionAction.jsx';
import React,{useEffect,useRef,useState} from 'react';
import {useWizardConnect} from '@wizardconnect/react';
import {BUSINESS_CANONICAL_URL,previewBusinessRedirect,previewBusinessNavigation} from './business-origin.mjs';
import {WalletChooser} from './WalletChooser.jsx';
import {BusinessWorkspace,InvoiceCheckout} from './BusinessWorkspace.jsx';
import {INVOICE_ID} from './business-core.mjs';
import {MobileDashboard} from './MobileDashboard.jsx';
import {HelpSheet} from './HelpSheet.jsx';
import {HomeScreen} from './HomeScreen.jsx';
import {useWalletBalance, WalletBalances} from './WalletBalances.jsx';
import {BlazeBanner} from './BlazeBanner.jsx';
import {EnvelopeFunding} from './EnvelopeFunding.jsx';
import {decodeClaimTransfer} from './envelope-handoff.mjs';
import {ClaimTransfer} from './ClaimTransfer.jsx';
import {Brand,AppPreferences,useAppExperience} from './app-experience.jsx';
import {formatBch} from './preview-core.mjs';
import {openFundingRpc} from './funding-rpc.mjs';
import {discoverWalletFunding} from './live-funding-core.mjs';
const primaryPages = [
 ['home','home','Home','Home'],
 ['send','send','Send money','Send'],
 ['request','links','Request payment','Request'],
 ['activity','activity','Activity','Activity'],
];
const mobilePages = [primaryPages[0], primaryPages[3], primaryPages[1], primaryPages[2]];
const workspacePages = [
 ['wallet','wallet','Wallet'],
 ['business','cash','Business'],
];
const pagePaths={home:'/',send:'/send',request:'/request',activity:'/activity',wallet:'/wallet',business:'/business'};
function currentPage(){const path=location.pathname.replace(/\/$/,'')||'/';return Object.keys(pagePaths).find(page=>pagePaths[page]===path)||'home';}
function incoming(){try{if(!location.hash||location.hash==='#content')return{};if(location.hash.startsWith('#invoice=')){const id=location.hash.slice(9);if(!INVOICE_ID.test(id))throw Error('Invalid business request link.');return{invoiceId:id};}if(location.hash.startsWith('#claim='))return{transfer:decodeClaimTransfer(location.hash.slice(7))};if(location.hash.startsWith('#tl='))throw Error('This link is no longer supported. Ask the sender for a new TipLink.');throw Error('Unrecognised link format.');}catch(e){return{error:e.message};}}
function Icon({name,size=20}){const d={home:'M3 10l9-7 9 7v11h-7v-7h-4v7H3z',activity:'M21 12a9 9 0 11-18 0 9 9 0 0118 0 M12 7v5l3 2',send:'M3 3l19 9-19 9 4-9z M7 12h15',request:'M12 3v13 M7 11l5 5 5-5 M4 20h16',links:'M10 13a5 5 0 007 0l4-4a5 5 0 00-7-7l-2 2 M14 11a5 5 0 00-7 0l-4 4a5 5 0 007 7l2-2',wallet:'M3 6h17v15H3z M3 6V3h13v3 M15 12h7v5h-7z',arrow:'M4 12h16 M14 6l6 6-6 6',check:'M5 12l4 4L20 5',copy:'M8 8h12v13H8z M16 8V3H3v13h5',shield:'M12 3l8 3v6c0 6-8 9-8 9s-8-3-8-9V6z M8 12l3 3 5-6',code:'M8 5l-6 7 6 7 M16 5l6 7-6 7',cash:'M3 6h18v13H3z M8 6a5 5 0 01-5 5 M21 14a5 5 0 00-5 5 M14 12a2 2 0 11-4 0 2 2 0 014 0',menu:'M4 6h16 M4 12h16 M4 18h16',help:'M21 12a9 9 0 11-18 0 9 9 0 0118 0 M9 9a3 3 0 116 0c0 2-3 2-3 4 M12 16v.1',close:'M5 5l14 14 M19 5L5 19'};return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={d[name]||d.links}/></svg>;}
function WorkspacePage({active, children}) {
 const visited=useRef(false);
 if(active)visited.current=true;
 return visited.current?<div hidden={!active} className="workspace-page">{children}</div>:null;
}
function BusinessOriginRedirect(){
 useEffect(()=>{window.location.replace(BUSINESS_CANONICAL_URL);},[]);
 return <main className="recovery-screen" role="status">
  <h1>Opening secure TipLink Business</h1>
  <p>Business sign-in requires TipLink's authorized website, rather than a temporary preview address.</p>
  <a className="primary" href={BUSINESS_CANONICAL_URL}>Continue to TipLink Business</a>
 </main>;
}
export function LinkApp(){
 if(previewBusinessRedirect(window.location.hostname,window.location.pathname))return <BusinessOriginRedirect/>;
 return <DeviceWalletProvider><LinkAppContent/></DeviceWalletProvider>;
}
function LinkAppContent(){
 const wc=useWizardConnect({dappName:'TipLink',persistSession:true});const device=useDeviceWallet();const [tab,setTab]=useState(currentPage);const [received,setReceived]=useState(incoming);
 const [error,setError]=useState('');const [now,setNow]=useState(Date.now());
 const walletBalance=useWalletBalance(!received.invoiceId&&!received.transfer&&!received.error?(device.slot?.address||device.wallet?.address):null);
 const [snapshot,setSnapshot]=useState(null);const [busy,setBusy]=useState(false);const active=useRef(null);
 const helpDialog=useRef(null);
 function openHelp(){
  const dialog=helpDialog.current;
  if(dialog&&!dialog.open)dialog.showModal();
 }
 const experience=useAppExperience();const errorRef=useRef(null);
 const [walletScreen,setWalletScreen]=useState(null);
 const [pairingError,setPairingError]=useState('');
 const pairingAttempt=useRef(0);
 useEffect(()=>{if(error)errorRef.current?.focus();},[error]);
 useEffect(()=>{if(!experience.moreOpen)Array.from(document.querySelectorAll('#content h1')).find(heading=>heading.getClientRects().length)?.focus({preventScroll:true});},[tab,received.invoiceId,received.transfer?.utxo.txid,received.error]);
 const connected=wc.state==='connected';const pairing=['connecting','reconnecting'].includes(wc.state);
 useEffect(()=>{if(connected)setWalletScreen(null);},[connected]);
 useEffect(()=>{if(received.transfer)history.replaceState(null,'',location.pathname+location.search);},[received.transfer]);
 useEffect(()=>{const update=()=>{setReceived(incoming());setTab(currentPage());setError('');};addEventListener('hashchange',update);addEventListener('popstate',update);const timer=setInterval(()=>setNow(Date.now()),1000);return()=>{removeEventListener('hashchange',update);removeEventListener('popstate',update);clearInterval(timer);};},[]);
 useEffect(()=>{setSnapshot(null);active.current?.abort();active.current=null;setBusy(false);return()=>active.current?.abort();},[wc.manager,wc.state]);
 function navigate(next){
  const approvedBusiness=previewBusinessNavigation(window.location.hostname,next);
  if(approvedBusiness){window.location.assign(approvedBusiness);return;}
  experience.closeMore();if(location.pathname!==pagePaths[next]||location.hash)history.pushState(null,'',pagePaths[next]);setReceived({});setTab(next);setError('');window.scrollTo({top:0,behavior:!experience.motionEnabled||matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});}
 function openWalletChoices(){setPairingError('');setWalletScreen('choose');}
 function openExternalWallet(fromChooser=false){
  setWalletScreen(fromChooser===true?'external':'external-only');
  void startPairing();
 }
 function closeWalletChooser(){
  pairingAttempt.current++;
  setWalletScreen(null);
  if(pairing)void disconnect();
 }
 async function startPairing(){
  if(pairing||connected)return;
  const attempt=++pairingAttempt.current;
  setPairingError('');
  try{
   if(wc.state==='disconnected')await wc.disconnect();
   if(attempt!==pairingAttempt.current)return;
   if(wc.connect()===false)throw Error('Could not start wallet pairing. Try again.');
  }catch(e){if(attempt===pairingAttempt.current)setPairingError(e.message);}
 }
 async function disconnect(){active.current?.abort();setSnapshot(null);try{await wc.disconnect();}catch{setError('Disconnect TipLink inside your wallet too if the connection remains visible.');}}
 async function refresh(){setError('');if(!connected)return openExternalWallet();const controller=new AbortController();active.current?.abort();active.current=controller;setBusy(true);setSnapshot(null);let rpc;const deadline=setTimeout(()=>controller.abort(),90000);try{rpc=await openFundingRpc({signal:controller.signal});const {value:result}=await discoverWalletFunding({rpc,manager:wc.manager,state:wc.state,signal:controller.signal});if(active.current===controller&&!controller.signal.aborted)setSnapshot(result);}catch(e){if(active.current===controller)setError(e.message);}finally{clearTimeout(deadline);rpc?.close();if(active.current===controller){active.current=null;setBusy(false);}}}

 const publicView=!!received.invoiceId||!!received.transfer||!!received.error;
 useEffect(()=>{
  if(!connected||publicView)return;
  function checkExternalBalance(){
   if(!document.hidden&&navigator.onLine!==false&&!active.current)void refresh();
  }
  checkExternalBalance();
  document.addEventListener('visibilitychange',checkExternalBalance);
  return()=>document.removeEventListener('visibilitychange',checkExternalBalance);
 },[connected,publicView,wc.manager]);
 const title=tab==='wallet'?'Your wallet':tab==='activity'?'Activity':[...primaryPages,...workspacePages].find(([key])=>key===tab)?.[2];
 return <div className={`tl-app ${publicView?'public-view':''}`} data-route={publicView?'checkout':tab} data-theme={experience.resolvedTheme} data-keyboard={experience.keyboardOpen?'open':'closed'} data-motion={experience.motionEnabled?'on':'off'}><a href="#content" className="skip" onClick={e=>{e.preventDefault();document.getElementById('content')?.focus();}}>Skip to content</a>
 {!publicView&&<aside className="rail">
   <button className="wordmark" onClick={()=>navigate('home')} aria-label="TipLink home"><Brand/></button>
   <nav aria-label="Main navigation">
     {[['Payments',primaryPages],['Workspace',workspacePages]].map(([group,pages])=><div className="rail-section" key={group}>
       <p>{group}</p>
       {pages.map(([key,icon,label])=><button title={label} aria-label={label} key={key} className={tab===key?'active':''} aria-current={tab===key?'page':undefined} onClick={()=>navigate(key)}><Icon name={icon}/><span>{label}</span></button>)}
     </div>)}
   </nav>
   <div className="rail-bottom"><button className="tools-button" title="Settings" aria-label="Settings" aria-haspopup="dialog" onClick={experience.openSettings}><Icon name="code"/><span>Settings</span></button></div>
 </aside>}
 <div className="app-body"><header className="topbar">{publicView?<button className="wordmark" onClick={()=>navigate('home')}><Brand/></button>:<><div className="mobile-brand">{tab==='home'&&<button type="button" className="payments-menu" aria-label="Open menu" aria-haspopup="dialog" onClick={experience.openMore}><Icon name="menu" size={19}/></button>}<button className="wordmark" onClick={()=>navigate('home')} aria-label="TipLink home"><Brand/></button></div><div className="crumb"><button className="breadcrumb-home" onClick={()=>navigate('home')}>Home</button>{tab!=='home'&&<b aria-current="page"> / {title}</b>}</div></>}<div className="top-actions"><span className="network"><i/>Bitcoin Cash</span>{!publicView&&<button className="wallet-connect" onClick={()=>navigate('wallet')}><Icon name="wallet" size={17}/>{device.slot?(device.wallet?'TipLink Wallet':'Wallet saved'):connected?(wc.walletName||'External connected'):'My TipLink wallet'}</button>}{publicView&&<span className="tag">{received.transfer?'CLAIM LINK':'PAYMENT REQUEST'}</span>}{!publicView&&<button className="mobile-wallet-button" onClick={()=>navigate('wallet')}><Icon name="wallet" size={17}/>{device.slot?'My wallet':'Create wallet'}</button>}{!publicView&&<button className="profile-button" onClick={experience.openMore} aria-label="Open app menu" aria-haspopup="dialog">T<span/></button>}</div></header>
 <main id="content" tabIndex={-1} className="content route-enter">
 <div className="payments-stars" aria-hidden="true"/>{(error||wc.error)&&<div className="error" role="alert" ref={errorRef} tabIndex={-1}>{error||'Wallet connection reported an error. Open Your wallet and reset the connection.'}</div>}
 {received.error&&<section className="panel invalid"><span className="tag">LINK UNAVAILABLE</span><h1 tabIndex={-1}>Let’s check<br/>that link.</h1><p>{received.error}</p><button className="primary" onClick={()=>navigate('home')}>Open TipLink<Icon name="arrow"/></button></section>}
 {received.invoiceId&&<InvoiceCheckout key={received.invoiceId} id={received.invoiceId} now={now}/>}
 {received.transfer&&<ClaimTransfer key={[received.transfer.utxo.txid,received.transfer.utxo.index,received.transfer.utxo.sats,received.transfer.utxo.scriptHex].join(':')} transfer={received.transfer} onOpenWallet={()=>navigate('wallet')}/>}
 <WorkspacePage active={!publicView&&tab==='business'}><BusinessWorkspace visible={!publicView&&tab==='business'}/></WorkspacePage>
 {!publicView&&tab==='request'&&<section className="panel"><h1 tabIndex={-1}>Request payment</h1><p>Create a BCH payment request in Business and share its checkout link with your customer.</p><button className="primary" onClick={()=>navigate('business')}>Open Business <Icon name="arrow"/></button></section>}
 {!publicView&&tab==='home'&&<>
 <div className="home-wallet-actions" aria-label="Bitcoin Cash wallets">
   <button type="button" className="home-external-wallet" disabled={pairing}
     aria-haspopup={!connected ? 'dialog' : undefined}
     onClick={connected ? () => navigate('wallet') : () => openExternalWallet()}>
     <Icon name="links" size={17}/>{connected ? 'External wallet connected' : pairing ? 'Connecting wallet…' : 'Connect BCH wallet'}
   </button>
   <button type="button" className="home-device-wallet" onClick={() => navigate('wallet')}>
     <Icon name="wallet" size={17}/>My TipLink wallet
   </button>
 </div>
 <BlazeBanner/><WalletBalances balance={walletBalance} connected={connected} external={snapshot} busy={busy} onRefresh={refresh}/><MobileDashboard now={now} navigate={navigate} onHelp={openHelp} Icon={Icon}/><div className="desktop-home"><HomeScreen onSend={()=>navigate('send')} onRequest={()=>navigate('request')} onWallet={()=>navigate('wallet')} onActivity={()=>navigate('activity')}/></div></>}
 <WorkspacePage active={!publicView&&tab==='send'}><EnvelopeFunding manager={wc.manager} state={wc.state} walletName={wc.walletName} onConnect={openExternalWallet} onDone={()=>navigate('home')}/></WorkspacePage>
 {!publicView&&tab==='activity'&&<><div className="page-heading"><div><h1 tabIndex={-1}>Activity</h1><p>Check BCH transactions saved on this device.</p></div><button type="button" className="secondary" onClick={()=>navigate('business')}>View payment requests</button></div><TransactionHistory/></>}
 <WorkspacePage active={!publicView&&tab==='wallet'}><><div className="page-heading"><div><span className="eyebrow">YOUR KEYS. YOUR CONTROL.</span><h1 tabIndex={-1}>Your wallet. <em>Your control.</em></h1><p>Your saved TipLink BCH wallet is the default for Send Money and Business. Connect an external wallet only if you choose.</p></div></div><DeviceWalletPanel balance={walletBalance}/><div className="wallet-grid"><section className="panel"><span className="tag">{connected?'CONNECTED':'NOT CONNECTED'}</span><h2>{connected?(wc.walletName||'Your BCH wallet'):'Bring your own wallet.'}</h2><p>Optional: connect another BCH wallet. Your saved TipLink wallet remains the default and does not need re-creating.</p><div className="button-row"><button className="primary" disabled={pairing||busy} onClick={connected?refresh:openExternalWallet}>{busy?'Checking funding…':connected?'Refresh funding':'Connect external wallet'}<Icon name="wallet" size={18}/></button>{(connected||pairing||wc.error)&&<button className="secondary" onClick={disconnect}>{pairing?'Cancel pairing':'Reset / disconnect'}</button>}</div><p className="fine">Refresh checks receive and change paths until 20 unused addresses in a row. Network providers can see the queried script hashes and your IP.</p>{busy&&<button className="text-button" onClick={()=>active.current?.abort()}>Cancel lookup</button>}</section><section className="balance-panel"><small>CHECKED CANDIDATE FUNDING</small><strong>{snapshot?formatBch(snapshot.totalSats):'—'}<span>BCH</span></strong><p>{snapshot?`${snapshot.candidates.length} outputs · ${snapshot.scannedScripts} funding scripts checked`:'Refresh to look for BCH funding.'}</p><Icon name="wallet" size={45}/></section></div>{snapshot&&<section className="panel funding"><h3>{snapshot.candidates.length?'Funding candidates found':'You can explore without adding funds.'}</h3><p>Checked {snapshot.checkedAt}. BCH checkpoint matched. Raw transaction IDs, values and scripts checked locally; confirmation and unspent status are provider-reported. Checks use network providers and raw transactions without SPV verification.</p><p className="fine">The Send screen can request wallet approval for a reviewed transaction. Sending requires a separate confirmation after wallet approval and saving the recovery file.</p></section>}</></WorkspacePage>
 <footer><span>tiplink<span>.</span><small>Money, made shareable.</small></span><span>BUILT BY NAZZITECH <i/> BITCOIN CASH</span></footer>
 </main></div>
 {!publicView&&tab==='home'&&<>
   <button className="payments-help" type="button" aria-label="Open Help" aria-haspopup="dialog" onClick={openHelp}>
     <Icon name="help" size={18}/>Help
   </button>
   <HelpSheet dialogRef={helpDialog} Icon={Icon}/>
 </>}
 {!publicView&&<nav className="mobile-dock" aria-label="App navigation">
   {mobilePages.map(([key,icon,label,shortLabel])=><button key={key} className={['dock-'+key,tab===key?'active':''].join(' ')} aria-current={tab===key?'page':undefined} onClick={()=>navigate(key)}><span><Icon name={icon} size={21}/></span><b>{shortLabel}</b></button>)}
   <button className={experience.moreOpen||['wallet','business'].includes(tab)?'active':''} aria-haspopup="dialog" aria-expanded={experience.moreOpen} onClick={experience.openMore}><span aria-hidden="true" className="dock-more-icon">•••</span><b>More</b></button>
 </nav>}{!publicView&&<AppPreferences experience={experience} onNavigate={navigate} activePage={tab}/>}{!publicView&&<WalletChooser screen={walletScreen==='external-only'?'external':walletScreen} wallet={wc}
   error={pairingError} onClose={closeWalletChooser}
   onExternal={()=>openExternalWallet(true)} onBack={walletScreen==='external'?openWalletChoices:undefined}
   onTipLink={()=>{closeWalletChooser();navigate('wallet');}} onPair={startPairing}/>}</div>;
}
