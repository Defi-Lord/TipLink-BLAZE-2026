import {defineConfig} from 'vite';
export default defineConfig({server:{host:'127.0.0.1',port:5173,strictPort:true,proxy:{'/api/v1/merchant':{target:'http://127.0.0.1:4100',changeOrigin:false},'/api/v1/public/invoices':{target:'http://127.0.0.1:4100',changeOrigin:false}}}});
