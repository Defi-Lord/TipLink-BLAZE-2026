import React, {useEffect, useState} from 'react';
import {CashOutBank} from './CashOutBank.jsx';
import {CashOutEstimate} from './CashOutEstimate.jsx';
import {CashOutSandbox} from './CashOutSandbox.jsx';
import './cash-out.css';

const tools = [
  ['deposit', 'Test deposit', CashOutSandbox],
  ['estimate', 'NGN estimate', CashOutEstimate],
  ['bank', 'Bank lookup', CashOutBank],
];

function SandboxStatus() {
  const [partner, setPartner] = useState('Checking Breet connection…');

  useEffect(() => {
    const controller = new AbortController();
    fetch('/api/v1/merchant/cash-out/status', {signal: controller.signal, cache: 'no-store', credentials: 'omit'})
      .then(response => {
        if (!response.ok) throw Error();
        return response.json();
      })
      .then(result => {
        if (controller.signal.aborted) return;
        if (result.provider !== 'Breet' || result.environment !== 'sandbox' || result.payoutVerified !== false) throw Error();
        const messages = {
          not_configured: 'Breet sandbox setup pending.',
          listed: result.activity === 'active' ? 'BCH test asset active.' : 'BCH test asset listed. Availability unconfirmed.',
          disabled: 'Breet BCH test asset is disabled.',
          missing: 'Breet BCH test asset unavailable.',
          unavailable: 'Breet connection unavailable. Try again later.',
        };
        setPartner(messages[result.state] || 'Breet status unavailable.');
      })
      .catch(() => {
        if (!controller.signal.aborted) setPartner('Breet connection unavailable.');
      });
    return () => controller.abort();
  }, []);

  return <div className="cash-availability">
    <div><span className="cash-preview-badge">Breet sandbox</span><p role="status">{partner}</p></div>
    <span className="cash-availability-limit">Live bank payouts unavailable</span>
  </div>;
}

export function CashOutPreview({onOpenBusiness, onOpenWallet}) {
  const [direction, setDirection] = useState('out');
  const [tool, setTool] = useState('deposit');
  const [opened, setOpened] = useState(['deposit']);

  function selectTool(next) {
    setTool(next);
    setOpened(current => current.includes(next) ? current : [...current, next]);
  }

  return (
    <section className="cash-workspace" aria-labelledby="cash-workspace-title">
      <header className="cash-workspace-heading">
        <h1 id="cash-workspace-title" tabIndex={-1}>Cash in &amp; out</h1>
        <p>Receive BCH in TipLink or try the Breet cash-out sandbox.</p>
      </header>
      <div className="cash-direction" role="group" aria-label="Cash in or cash out">
        <button type="button" aria-pressed={direction === 'in'} onClick={() => setDirection('in')}>Cash in</button>
        <button type="button" aria-pressed={direction === 'out'} onClick={() => setDirection('out')}>Cash out</button>
      </div>
      {direction === 'in' && <section className="cash-preview cash-in-panel" aria-labelledby="cash-in-title">
        <span className="cash-preview-badge">BCH mainnet</span>
        <h2 id="cash-in-title">Receive BCH</h2>
        <p>Open your TipLink wallet to copy your receiving address and share it with the sender.</p>
        <button type="button" className="primary" onClick={onOpenWallet}>Open TipLink wallet</button>
        <p className="cash-preview-note">Bank deposits and buying BCH are currently unavailable here.</p>
      </section>}
      <div hidden={direction !== 'out'}>
        <SandboxStatus/>
        <div className="cash-tool-nav" role="group" aria-label="Sandbox tools">
          {tools.map(([id, label]) => <button key={id} type="button" aria-pressed={tool === id}
            aria-controls={opened.includes(id) ? 'cash-tool-' + id : undefined}
            onClick={() => selectTool(id)}>{label}</button>)}
        </div>
        {tools.map(([id, , Tool]) => opened.includes(id) && <div key={id} id={'cash-tool-' + id} hidden={tool !== id}>
          <Tool/>
        </div>)}
        <div className="cash-workspace-help">
          <p>Sandbox tools use your TipLink Business account.</p>
          <button type="button" className="text-button" onClick={onOpenBusiness}>Open Business</button>
        </div>
      </div>
    </section>
  );
}
