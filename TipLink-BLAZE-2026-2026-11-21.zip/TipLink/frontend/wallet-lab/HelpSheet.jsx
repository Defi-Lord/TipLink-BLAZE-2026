import React from 'react';

const questions = [
  {
    title: 'Fees and confirmations',
    answer: 'TipLink charges no platform fee. Review the BCH network fee before confirming a transaction. Wait until TipLink reports the funding transaction confirmed before sharing a claim link.',
  },
  {
    title: 'Unclaimed links and recovery',
    answer: 'Keep your encrypted recovery file and its password. After the recovery delay, use the file to recover BCH that is still unclaimed. Recovery is manual. The recipient can still claim while the funds remain unspent.',
  },
  {
    title: 'Payment requests and expiry',
    answer: 'Use Request to create a link for an exact BCH amount in Business. An expired or cancelled request stops showing payment instructions. Someone who already copied the address can still send to it.',
  },
  {
    title: 'Safety and support',
    answer: 'This is the live Bitcoin Cash network. Share a claim link only with the intended recipient. Keep your recovery file, password and wallet keys private.',
  },
];

export function HelpSheet({dialogRef, Icon}) {
  return <dialog ref={dialogRef} className="tip-help-sheet" id="tip-help-sheet"
    aria-labelledby="tip-help-heading" onClick={event => {
      if (event.currentTarget === event.target) event.currentTarget.close();
    }}>
    <div className="tip-help-panel">
      <header>
        <h2 id="tip-help-heading">How TipLink works</h2>
        <form method="dialog">
          <button type="submit" aria-label="Close help" autoFocus><Icon name="close"/></button>
        </form>
      </header>
      <ol>
        <li><Icon name="links"/><div><strong>Create a send link</strong><p>Choose an amount, save your recovery file, and fund the link using your BCH wallet.</p></div></li>
        <li><Icon name="send"/><div><strong>Share it privately</strong><p>Once funding is confirmed, send the link to the intended recipient.</p></div></li>
        <li><Icon name="wallet"/><div><strong>Recipient claims the BCH</strong><p>They can use their own BCH address or create a wallet on their device.</p></div></li>
      </ol>
      <section aria-labelledby="tip-help-faq">
        <h3 id="tip-help-faq">FAQs</h3>
        {questions.map(({title, answer}) => <details key={title}><summary>{title}</summary><p>{answer}</p></details>)}
      </section>
      <p className="tip-help-contact"><a href="mailto:nazzitech@gmail.com">Email support</a><a href="/.well-known/security.txt">Report a security issue</a></p>
    </div>
  </dialog>;
}
