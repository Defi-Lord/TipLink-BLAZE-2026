// Presentation accounting only: no key handling, signing or network requests.
import {parseBch,normalizeBchInput} from '../src/split.mjs';
import {formatBch} from './preview-core.mjs';
const MAX=2100000000000000n;
export function validateSendAmount(value){const amount=parseBch(normalizeBchInput(value));if(amount<10000n||amount>MAX)throw Error('Enter at least 0.0001 BCH, within the supported amount.');return amount;}
export function summariseEnvelopeReview(plan){
 const values=['amountSats','feeSats','claimFeeEstimateSats','claimNetEstimateSats','totalInputSats','changeSats'];
 if(!plan||values.some(k=>typeof plan[k]!=='bigint'||plan[k]<0n||plan[k]>MAX))throw Error('Payment review amounts could not be verified.');
 if(plan.amountSats<10000n||plan.claimNetEstimateSats<1000n||plan.feeSats===0n||plan.claimFeeEstimateSats===0n||plan.claimNetEstimateSats+plan.claimFeeEstimateSats!==plan.amountSats||plan.totalInputSats!==plan.amountSats+plan.feeSats+plan.changeSats)throw Error('Payment review totals do not match.');
 const recipientSats=plan.claimNetEstimateSats,networkFeesSats=plan.feeSats+plan.claimFeeEstimateSats,totalFromWalletSats=plan.amountSats+plan.feeSats;
 if(totalFromWalletSats>MAX||recipientSats+networkFeesSats!==totalFromWalletSats)throw Error('Payment review totals do not match.');
 return{recipientSats,networkFeesSats,totalFromWalletSats,recipientBch:formatBch(recipientSats),networkFeesBch:formatBch(networkFeesSats),totalFromWalletBch:formatBch(totalFromWalletSats)};
}
export function explainSendError(error){
 const message=error?.message||'';
 if(/No confirmed/i.test(message))return'We could not find confirmed spendable BCH in the wallet addresses checked. No money has moved.';
 if(/cannot cover|Insufficient funding/i.test(message))return'Your checked wallet funds cannot cover this amount and the network fees. Try a smaller amount or add confirmed BCH.';
 if(/snapshot expired|review expired|15 minutes ahead|Funding changed during lookup|funding changed/i.test(message))return'This transfer needs a fresh check. Check the total again before continuing.';
 if(/Could not connect to two BCH providers/i.test(message))return'TipLink could not reach two independent BCH network providers. Your wallet is still connected and nothing was sent. Try another connection or try again later.';
 if(/BCH providers did not agree on funding/i.test(message))return'BCH network providers returned conflicting balance information. For safety, TipLink stopped this check without sending money. Try again later.';
 if(/Provider connection timed out|Funding provider request timed out|Cannot connect to funding provider|Provider connection closed|Provider request could not be sent|Funding lookup cancelled/i.test(message))return'The BCH network balance check could not finish. Your wallet is still connected and nothing was sent. Check your connection and retry.';
 if(/Connect an hdwalletv1 wallet|Wallet must supply both receive and change paths|Invalid wallet address path|Wallet returned an invalid compressed public key/i.test(message))return'The connected wallet did not provide the BCH receiving and change addresses needed for this check. Reconnect a compatible BCH wallet.';
 if(/Provider network or hash algorithm mismatch|Provider did not match the BCH mainnet checkpoint|Invalid BCH checkpoint header/i.test(message))return'TipLink could not verify the BCH network provider. For safety, the transfer was stopped before signing or sending.';
 if(/passphrase/.test(message))return'Choose a password of 12–256 characters for your recovery file.';
 if(/declined/i.test(message))return'Your wallet did not approve this request. You can try again when you are ready.';
 if(/cancelled/i.test(message))return'The check was cancelled. You can try again.';
 if(/amount|at least/.test(message))return message;
 if(/Connect a wallet/.test(message))return'Connect your wallet to continue.';
 return'We could not finish this step. Try again. If it continues, reconnect your wallet.';
}

/**
 * Never render raw wallet exceptions: the SDK can include relay metadata or
 * transaction-shaped content. Return only a fixed, phase-specific explanation.
 */
export function explainWalletApprovalError(error,stage='preflight'){
 const message=String(error?.message??'');
 const name=String(error?.name??'');
 if(/TipLink wallet signing timeout/i.test(message))
  return 'Selene did not finish the approval request within the review window (WC-TIMEOUT). The request was cancelled; nothing was broadcast. Reopen Selene and refresh the total before a new attempt.';
 if(/Do not know how to serialize a BigInt|circular structure|cyclic object/i.test(message))
  return 'The wallet signing request could not be encoded for the encrypted relay (WC-PAYLOAD). No BCH was broadcast.';
 if(/65,535|65535|chunked messages|supports chunk|message is larger|message too large/i.test(message))
  return 'The encrypted signing request is too large for the connected wallet or relay (WC-SIZE). No BCH was broadcast.';
 if(/relay|publish|WebSocket|Nostr|connection failure|connection failed|connection closed|not ready/i.test(message))
  return 'The WizardConnect relay could not deliver or confirm the signing request (WC-RELAY). No BCH was broadcast. Check that Selene remains connected.';
 if(/Not connected|paired public key not set|protocol mismatch|connection not active/i.test(message))
  return 'TipLink lost its active WizardConnect signing session (WC-SESSION). No BCH was broadcast. Reconnect Selene before retrying.';
 if(/wallet did not respond|response timeout|request timed out|request timeout/i.test(message))
  return 'TipLink did not receive the expected signing response (WC-RESPONSE). No BCH was broadcast.';
 if(name==='AbortError'&&!/cancel|aborted/i.test(message))
  return 'The signing request was interrupted (WC-ABORT). No BCH was broadcast.';
 if(/review expired|Funding snapshot expired|Prepare again|15 minutes ahead/i.test(message))
  return 'The wallet review expired before approval. Refresh the total, then approve a new review. No BCH was sent.';
 if(/Signing cancelled|cancelled|aborted/i.test(message))
  return 'Wallet approval was cancelled. No BCH was sent.';
 if(/declined|rejected|denied|refused/i.test(message))
  return 'Selene did not approve the transaction. Nothing was sent. You can retry after reviewing the request.';
 if(/Wallet changed|wallet address paths changed|Connect an hdwalletv1 wallet|disconnected/i.test(message))
  return 'The connected wallet or its address paths changed. Reconnect Selene and refresh the total before approving.';
 if(stage==='local-verification')
  return 'Selene responded, but TipLink could not verify the signed transaction against the reviewed inputs, outputs and fees. Nothing was broadcast. Do not attempt to send this transaction.';
 if(stage==='handoff')
  return 'TipLink verified the wallet approval but could not prepare the protected recovery handoff. Nothing was broadcast. Keep your existing recovery file.';
 if(stage==='wallet-request-published')
  return 'TipLink handed the signing request to a WizardConnect relay, but no usable Selene signature was received (WC-RESPONSE). No BCH was broadcast.';
 if(stage==='wallet-request')
  return 'TipLink could not complete the WizardConnect signing request before receiving a usable signature (WC-REQUEST). No BCH was broadcast. The exact failure has not yet been established.';
 return 'TipLink could not begin the transaction approval safely. Nothing was broadcast. Refresh the total before trying again.';
}
