// Pure, privacy-safe payment status policy. A relay acknowledgement, a missing
// network response and a confirmed block are three different states.
export const PAYMENT_FRESHNESS_MS=30000;
export function isRecentChainCheck(snapshot,now=Date.now()){
 return !!snapshot&&Number.isSafeInteger(snapshot.checkedAt)&&Number.isSafeInteger(now)&&
  now>=snapshot.checkedAt&&now-snapshot.checkedAt<PAYMENT_FRESHNESS_MS;
}
export function isVerifiedDetectedPayment(snapshot,now=Date.now()){
 return isRecentChainCheck(snapshot,now)&&
  (snapshot.status==='unconfirmed'||snapshot.status==='confirmed')&&
  !!snapshot.identity&&!!snapshot.transfer?.utxo?.txid;
}
export function canSharePendingClaimLink({snapshot,expectedIdentity,saved=false,ack=false,now=Date.now(),error=null}={}){
 return saved===true&&ack===true&&!error&&isRecentChainCheck(snapshot,now)&&
  typeof snapshot.identity==='string'&&snapshot.identity.length>0&&
  (expectedIdentity===undefined||expectedIdentity===snapshot.identity)&&
  (snapshot.status==='confirmed'||snapshot.status==='unconfirmed');
}
export function paymentCheckIssue(error){
 const message=String(error?.message||'');
 if(/BCH providers did not agree|inconsistent|changed while checking|changed during the check|tip changed/i.test(message))
  return{code:'provider-sync',message:'BCH nodes do not yet agree on this payment status. TipLink is syncing and retrying; this is not proof that miners are delayed. Do not send again.'};
 if(/network or hash algorithm mismatch|checkpoint|source transaction ID mismatch|invalid funding|funding output does not match/i.test(message))
  return{code:'verification-error',message:'BCH payment verification failed or the network identity was unexpected. TipLink will not unlock claiming or sharing on this check.'};
 if(/connect|timed out|timeout|network|provider|fetch|failed|abort/i.test(message))
  return{code:'network-unavailable',message:'TipLink could not complete a fresh BCH network check. This is a connection/status-sync issue, not a blockchain confirmation result. Retrying automatically.'};
 return{code:'verification-error',message:'TipLink could not verify the exact BCH funding output. The payment status is uncertain; claiming remains locked. Check again before taking action.'};
}
export function paymentStatusView({snapshot,error,now=Date.now()}={}){
 if(error)return{kind:error.code||'status-sync',label:'TipLink status check interrupted',message:error.message,confirmed:false};
 if(!snapshot)return{kind:'checking',label:'Checking BCH payment',message:'Waiting for independent BCH network verification.',confirmed:false};
 if(!isRecentChainCheck(snapshot,now))return{kind:'stale',label:'Status refresh required',message:'The last network check is no longer fresh. TipLink will retry; this is not proof that the blockchain is delayed.',confirmed:false};
 switch(snapshot.status){
  case 'confirmed':return{kind:'confirmed',label:'Confirmed on Bitcoin Cash',message:'Independent BCH providers report this exact funding output confirmed and unspent.',confirmed:true};
  case 'unconfirmed':return{kind:'detected',label:'Payment detected · confirmation pending',message:'Independent BCH providers see this exact payment, but it is not in a confirmed block yet. A claim link may be shared, but no BCH can be claimed until confirmation.',confirmed:false};
  case 'unavailable':return{kind:'unavailable',label:'Payment not currently available',message:'TipLink cannot find this unspent funding output. It may be unfunded, already claimed or recovered. Do not send a replacement payment.',confirmed:false};
  case 'unfunded':return{kind:'unfunded',label:'Awaiting payment',message:'No payment has been detected at this one-time BCH contract address.',confirmed:false};
  default:return{kind:'attention',label:'Payment requires attention',message:snapshot.message||'Check your BCH funding status before sharing or sending anything else.',confirmed:false};
 }
}
