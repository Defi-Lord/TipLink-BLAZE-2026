import {validateSavedInvoice} from './business-core.mjs';

function dateBoundary(value) {
  if (!value) return null;
  const time = Date.parse(value + 'T00:00:00.000Z');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(time) || new Date(time).toISOString().slice(0, 10) !== value) {
    throw new Error('Choose a valid export date.');
  }
  return time;
}

export function selectExportRequests(items, {from = '', to = '', status = 'all'} = {}, now = Date.now()) {
  const start = dateBoundary(from);
  const end = dateBoundary(to);
  if (start !== null && end !== null && start > end) {
    throw new Error('The start date must be on or before the end date.');
  }
  if (!['all', 'open', 'expired', 'cancelled'].includes(status)) {
    throw new Error('Choose a supported request status.');
  }
  return items.filter(item => {
    const request = validateSavedInvoice(item);
    const created = Date.parse(request.createdAt);
    const currentStatus = request.state === 'open' && now >= Date.parse(request.expiresAt) ? 'expired' : request.state;
    return (start === null || created >= start) &&
      (end === null || created < end + 86400000) &&
      (status === 'all' || status === currentStatus);
  });
}
