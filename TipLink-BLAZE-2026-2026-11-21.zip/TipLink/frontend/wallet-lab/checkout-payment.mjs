import {binToHex} from '@bitauth/libauth';
import {hashScript,parsePublicTransaction} from './broadcast-core.mjs';
import {INVOICE_ID,validateReceipt} from './business-core.mjs';
import {validateRecipient} from './preview-core.mjs';

const PREFIX='tiplink-checkout-payment:';
const TXID=/^[a-f0-9]{64}$/;
const HISTORY_LIMIT=200;
const LOOKUP_LIMIT=12;

export async function checkoutHistory(invoice,rpc,limit=HISTORY_LIMIT){
 const {scriptHex}=validateRecipient(invoice.address);
 const rows=await rpc.call('blockchain.scripthash.get_history',[hashScript(scriptHex)]);
 if(!Array.isArray(rows)||rows.length>limit||rows.some(row=>typeof row?.tx_hash!=='string'||!TXID.test(row.tx_hash)||!Number.isSafeInteger(row.height)||row.height< -1)||new Set(rows.map(row=>row.tx_hash)).size!==rows.length)
  throw Error('This address history needs a transaction ID or a smaller history to verify safely.');
 return rows;
}

export async function findCheckoutPayment({invoice,rpc,baseline,txid}){
 const rows=await checkoutHistory(invoice,rpc,txid?5000:HISTORY_LIMIT);
 const previous=new Set(invoice.receiptEligible?[]:(baseline??[]));
 const candidates=rows.filter(row=>txid?row.tx_hash===txid:!previous.has(row.tx_hash));
 if(candidates.length>LOOKUP_LIMIT)return {status:'ambiguous'};
 const {scriptHex}=validateRecipient(invoice.address);
 const matches=[];
 for(const row of candidates){
  const raw=await rpc.call('blockchain.transaction.get',[row.tx_hash,false]);
  const parsed=parsePublicTransaction(typeof raw==='string'?raw.toLowerCase():raw);
  if(parsed.txid!==row.tx_hash)throw Error('The network returned different transaction bytes.');
  const outputs=parsed.tx.outputs.filter(output=>!output.token&&binToHex(output.lockingBytecode)===scriptHex&&output.valueSatoshis===BigInt(invoice.amountSats));
  if(outputs.length>1)return {status:'ambiguous'};
  if(outputs.length===1)matches.push({status:row.height>0?'confirmed':'seen',txid:row.tx_hash,height:Math.max(0,row.height)});
 }
 if(matches.length>1)return {status:'ambiguous'};
 return matches[0]??{status:txid&&candidates.length?'mismatch':'waiting'};
}

export function readCheckoutPayment(id,storage=globalThis.localStorage){
 if(!INVOICE_ID.test(id))return null;
 const raw=storage.getItem(PREFIX+id);
 if(!raw)return null;
 const row=JSON.parse(raw);
 if(!row||row.id!==id||typeof row.address!=='string'||typeof row.amountSats!=='string'||!/^[1-9]\d{0,15}$/.test(row.amountSats)||!Number.isSafeInteger(row.openedAt)||!Array.isArray(row.baseline)||row.baseline.length>HISTORY_LIMIT||row.baseline.some(txid=>typeof txid!=='string'||!TXID.test(txid))||!['waiting','seen','confirmed'].includes(row.status)||row.txid&&(typeof row.txid!=='string'||!TXID.test(row.txid))||row.manualTxid&&(typeof row.manualTxid!=='string'||!TXID.test(row.manualTxid)))return null;
 return row;
}

export function saveCheckoutPayment(invoice,update,storage=globalThis.localStorage){
 const saved=readCheckoutPayment(invoice.id,storage);
 if(saved&&(saved.address!==invoice.address||saved.amountSats!==invoice.amountSats))throw Error('The payment request changed. Verify it with the recipient.');
 const row={id:invoice.id,address:invoice.address,amountSats:invoice.amountSats,baseline:[],status:'waiting',openedAt:Date.now(),...saved,...update};
 storage.setItem(PREFIX+invoice.id,JSON.stringify(row));
 return row;
}

export function listCheckoutPayments(storage=globalThis.localStorage){
 return Array.from({length:storage.length},(_,index)=>storage.key(index))
  .filter(key=>key?.startsWith(PREFIX)).slice(0,200)
  .map(key=>{try{return readCheckoutPayment(key.slice(PREFIX.length),storage);}catch{return null;}})
  .filter(Boolean).sort((a,b)=>b.openedAt-a.openedAt);
}

export async function recordCheckoutMatch(invoice,found,{manualId,signal,fetcher=globalThis.fetch,storage=globalThis.localStorage}={}){
 const update={status:found.status,height:found.height,txid:found.txid,checkedAt:Date.now(),
  ...(manualId?{manualTxid:manualId}:{}),receiptSyncPending:invoice.receiptEligible===true};
 const local=saveCheckoutPayment(invoice,update,storage);
 if(!local.receiptSyncPending)return local;

 try{
  const response=await fetcher('/api/v1/public/invoices/'+invoice.id+'/receipt',{
   method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({txid:found.txid}),
   signal,credentials:'omit',referrerPolicy:'no-referrer',
  });
  if(!response.ok)return local;
  const receipt=validateReceipt(await response.json());
  if(signal?.aborted||receipt.txid!==found.txid||receipt.status!==found.status)return local;
  const current=readCheckoutPayment(invoice.id,storage);
  if(current?.txid!==found.txid||current.status!==found.status)return current??local;
  return saveCheckoutPayment(invoice,{receiptSyncPending:false},storage);
 }catch{return local;}
}
