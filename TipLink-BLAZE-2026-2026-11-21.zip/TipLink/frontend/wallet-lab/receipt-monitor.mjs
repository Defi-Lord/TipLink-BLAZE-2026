import {validateSavedInvoice} from './business-core.mjs';

export function nextReceiptToCheck(items, now = Date.now()) {
  return items.map(validateSavedInvoice)
    .filter(item => item.receipt && now - Date.parse(item.receipt.checkedAt) >= 60000)
    .sort((a, b) => Date.parse(a.receipt.checkedAt) - Date.parse(b.receipt.checkedAt))[0] || null;
}

export function startReceiptMonitor({readState, request, onItems, onBusy, onError,
  clock = Date.now, schedule = setTimeout, cancel = clearTimeout}) {
  let stopped = false;
  let timer;
  let retryDelay = 15000;

  async function tick() {
    if (stopped) return;
    const state = readState();
    const candidate = !state.busy && !state.hidden ? nextReceiptToCheck(state.items, clock()) : null;
    if (candidate) {
      onBusy(true);
      try {
        await request('/invoices/' + candidate.id + '/receipt', {
          method: 'POST', body: {txid: candidate.receipt.txid, acknowledgeAssignment: true},
        });
        if (stopped) return;
        const result = await request('/invoices');
        const items = result.items.map(validateSavedInvoice);
        if (!stopped) onItems(items);
        retryDelay = 15000;
      } catch (error) {
        retryDelay = Math.min(retryDelay * 2, 120000);
        if (!stopped && error.name !== 'AbortError') onError(error);
      } finally {
        onBusy(false);
      }
    }
    if (!stopped) timer = schedule(tick, retryDelay);
  }

  timer = schedule(tick, 15000);
  return () => {
    stopped = true;
    cancel(timer);
  };
}
