// Read-only BCH Electrum bridge for browsers that cannot reach WSS port 50004.
// This endpoint connects to fixed independent Electrum TLS servers only.
// It cannot sign, store wallet keys, submit raw transactions or broadcast.
import {connect as tlsConnect} from 'node:tls';
import {createHash} from 'node:crypto';

const ENDPOINTS=Object.freeze({
 nordic:Object.freeze({host:'electrum-bch.nordiccrypto.no',port:50002}),
 imaginary:Object.freeze({host:'bch.imaginary.cash',port:50002})
});
const GENESIS='000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f';
const CHECKPOINT={height:898374,hash:'00000000000000000157a0a3dcdc80f1acd809648d238c1e893b26247091b3b4'};
const MAX_REQUEST=4096,MAX_RESPONSE=2200000, TIMEOUT=9000;
const READ_METHODS=new Set([
 'server.version','server.features','blockchain.block.header',
 'blockchain.scripthash.listunspent','blockchain.scripthash.get_history',
 'blockchain.transaction.get','blockchain.headers.subscribe'
]);
const isHash=value=>typeof value==='string'&&/^[a-fA-F0-9]{64}$/.test(value);
export function validateRequest(body){
 if(!body||typeof body!=='object'||Array.isArray(body)||!Object.hasOwn(ENDPOINTS,body.provider)||!READ_METHODS.has(body.method)||!Array.isArray(body.params))throw Error('Invalid request.');
 const p=body.params,m=body.method;
 const empty=p.length===0;
 if((m==='server.features'||m==='blockchain.headers.subscribe')&&!empty)throw Error('Invalid parameters.');
 if(m==='server.version'&&!(p.length===2&&p.every(x=>typeof x==='string'&&x.length>0&&x.length<=64)))throw Error('Invalid parameters.');
 if(m==='blockchain.block.header'&&!(p.length===1&&Number.isSafeInteger(p[0])&&p[0]>=0&&p[0]<=10000000))throw Error('Invalid parameters.');
 if((m==='blockchain.scripthash.get_history'||m==='blockchain.scripthash.listunspent')&&!(isHash(p[0])&&(p.length===1||(m==='blockchain.scripthash.listunspent'&&p.length===2&&p[1]==='include_tokens'))))throw Error('Invalid parameters.');
 if(m==='blockchain.transaction.get'&&!(p.length===2&&isHash(p[0])&&p[1]===false))throw Error('Invalid parameters.');
 return {provider:body.provider,method:m,params:p};
}
export function callElectrumTls({provider,method,params},{connect=tlsConnect,timeoutMs=TIMEOUT}={}){
 const endpoint=ENDPOINTS[provider];
 if(!endpoint)throw Error('Invalid provider.');
 return new Promise((resolve,reject)=>{
  let socket,finished=false,buffer='',timer;
  function finish(error,value){
   if(finished)return;
   finished=true;clearTimeout(timer);
   socket?.removeAllListeners();socket?.destroy();
   if(error)reject(error);else resolve(value);
  }
  try{
   socket=connect({host:endpoint.host,port:endpoint.port,servername:endpoint.host,rejectUnauthorized:true});
   socket.setEncoding('utf8');
   socket.on('secureConnect',()=>{try{socket.write(JSON.stringify({jsonrpc:'2.0',id:1,method,params})+'\n');}catch{finish(Error('Provider request failed.'));}});
   socket.on('data',chunk=>{
    buffer+=chunk;
    if(buffer.length>MAX_RESPONSE){finish(Error('Provider response too large.'));return;}
    const cut=buffer.indexOf('\n');
    if(cut<0)return;
    let response;
    try{response=JSON.parse(buffer.slice(0,cut));}catch{finish(Error('Invalid provider reply.'));return;}
    if(!response||Array.isArray(response)||response.id!==1||response.error||!Object.hasOwn(response,'result')){finish(Error('Provider RPC failed.'));return;}
    finish(null,response.result);
   });
   socket.on('error',()=>finish(Error('Provider connection failed.')));
   socket.on('close',()=>finish(Error('Provider connection closed.')));
   timer=setTimeout(()=>finish(Error('Provider timeout.')),timeoutMs);
  }catch{finish(Error('Provider connection failed.'));}
 });
}
function doubleHashHeader(header){
 if(typeof header!=='string'||!/^[a-fA-F0-9]{160}$/.test(header))throw Error('Invalid BCH header.');
 const first=createHash('sha256').update(Buffer.from(header,'hex')).digest();
 return Buffer.from(createHash('sha256').update(first).digest()).reverse().toString('hex');
}
async function probe(provider,call=callElectrumTls){
 const version=await call({provider,method:'server.version',params:['TipLink read-only probe','1.4.3']});
 const features=await call({provider,method:'server.features',params:[]});
 const header=await call({provider,method:'blockchain.block.header',params:[CHECKPOINT.height]});
 if(!Array.isArray(version)||features?.genesis_hash!==GENESIS||features.hash_function!=='sha256'||doubleHashHeader(header)!==CHECKPOINT.hash)throw Error('BCH identity verification failed.');
 return {ok:true,provider,network:'BCH mainnet',checkpoint:CHECKPOINT.height};
}
async function readBody(req){
 if(req.body!==undefined){
  const raw=typeof req.body==='string'?req.body:JSON.stringify(req.body);
  if(raw.length>MAX_REQUEST)throw Error('Request too large.');
  return typeof req.body==='string'?JSON.parse(raw):req.body;
 }
 let raw='';
 for await(const part of req){raw+=part.toString('utf8');if(raw.length>MAX_REQUEST)throw Error('Request too large.');}
 return JSON.parse(raw);
}
export default async function handler(req,res){
 res.setHeader('Cache-Control','no-store');
 res.setHeader('X-Content-Type-Options','nosniff');
 const host=String(req.headers['x-forwarded-host']||req.headers.host||'').split(',')[0].trim();
 let sameOrigin=true;
 if(req.headers.origin){try{sameOrigin=new URL(req.headers.origin).host===host;}catch{sameOrigin=false;}}
 if(!sameOrigin||req.headers['sec-fetch-site']==='cross-site')return res.status(403).json({error:'Cross-origin access denied.'});
 if(req.method==='GET'){
  const provider=String(req.query?.provider??'nordic');
  if(req.query?.probe!=='1'||!Object.hasOwn(ENDPOINTS,provider))return res.status(404).json({error:'Not found.'});
  try{return res.status(200).json(await probe(provider));}
  catch{return res.status(503).json({ok:false,provider,error:'Independent BCH provider not reachable or verified.'});}
 }
 if(req.method!=='POST')return res.status(405).json({error:'Method not allowed.'});
 if(!String(req.headers['content-type']||'').startsWith('application/json'))return res.status(415).json({error:'Expected JSON.'});
 try{
  const body=validateRequest(await readBody(req));
  const result=await callElectrumTls(body);
  return res.status(200).json({result});
 }catch(error){
  const invalid=/Invalid|Request too large|Unexpected token|JSON/.test(error?.message||'');
  return res.status(invalid?400:503).json({error:invalid?'Invalid read-only BCH request.':'Independent BCH provider unavailable.'});
 }
}
