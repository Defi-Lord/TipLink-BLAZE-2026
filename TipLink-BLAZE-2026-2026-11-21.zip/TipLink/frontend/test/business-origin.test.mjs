import {test} from 'node:test';
import assert from 'node:assert/strict';
import {BUSINESS_CANONICAL_URL,previewBusinessRedirect,previewBusinessNavigation} from '../wallet-lab/business-origin.mjs';

test('Business sign-in on rotating TipLink previews routes to the verified Railway customer origin',()=>{
 const host='tip-link-cm4j5rwe0-dammypeck-gmailcoms-projects.vercel.app';
 assert.equal(previewBusinessRedirect(host,'/business'),BUSINESS_CANONICAL_URL);
 assert.equal(previewBusinessRedirect(host,'/business/'),BUSINESS_CANONICAL_URL);
 assert.equal(previewBusinessNavigation(host,'business'),BUSINESS_CANONICAL_URL);
 assert.equal(previewBusinessNavigation(host,'request'),null);
 assert.equal(previewBusinessRedirect(host,'/send'),null);
 assert.equal(previewBusinessRedirect(host,'/request'),null);
});
test('Business redirect never trusts arbitrary domains or routes',()=>{
 for(const host of ['www.tip-link.xyz','tip-link.xyz','localhost','evil.vercel.app',
 'tip-link-preview.vercel.app.evil.com','other-tip-link-preview.vercel.app','tip-link-evil.vercel.app.attacker'])
  assert.equal(previewBusinessRedirect(host,'/business'),null,host);
 assert.equal(previewBusinessRedirect('tip-link-preview.vercel.app','/business/malicious'),null);
 assert.equal(BUSINESS_CANONICAL_URL,'https://www.tip-link.xyz/business');
});