import {test} from 'node:test';import assert from 'node:assert/strict';
import {DappConnectionManager} from '@wizardconnect/dapp';
import {isSignTransactionRequest} from '@wizardconnect/core';
import {deriveHdPrivateNodeFromSeed,deriveHdPrivateNodeChild,deriveHdPublicNode,encodeHdPublicKey,secp256k1,binToHex,hexToBin,decodeTransaction,encodeTransaction,encodeDataPush,generateSigningSerializationBCH,sha256} from '@bitauth/libauth';
import {createEnvelopeDraft,validateEnvelopeDraft,encryptEnvelopeDraft,decryptEnvelopeDraft} from '../wallet-lab/envelope-draft.mjs';
import {prepareEnvelopeFunding,envelopeSigningRequest,verifySignedEnvelopeFunding,requestEnvelopeSignature} from '../wallet-lab/envelope-funding.mjs';
import {deriveWalletAddresses} from '../wallet-lab/wallet-address-core.mjs';
const now=Date.parse('2026-10-30T09:00:00Z');const pass='a long test passphrase 123';
function setup(){const root=deriveHdPrivateNodeFromSeed(new Uint8Array(32).fill(81));const parents=[0,1].map(n=>deriveHdPrivateNodeChild(root,n));const manager=new DappConnectionManager('preflight tests',undefined,{session:false});manager.restoreSessionPaths(parents.map((n,i)=>({name:i?'change':'receive',xpub:encodeHdPublicKey({node:deriveHdPublicNode(n),network:'mainnet'}).hdPublicKey})));manager.protocol='hdwalletv1';const rows=deriveWalletAddresses(manager,'connected');const candidate=(n,sats='200000',height=900000)=>({txid:(n+10).toString(16).padStart(2,'0').repeat(32),index:0,sats,scriptHex:rows[0].scriptHex,path:'receive',addressIndex:0,height,status:'RAW VERIFIED; PROVIDER REPORTS UNSPENT'});const draft=createEnvelopeDraft({amountBch:'0.001',now});const config={manager,state:'connected',draft,now,snapshot:{manager,rows,value:{network:'BCH mainnet',checkpoint:898374,scannedScripts:4,checkedAt:new Date(now).toISOString(),candidates:[candidate(0)]}}};return{manager,config,rows,candidate,privateKey:deriveHdPrivateNodeChild(parents[0],0).privateKey};}
function signed(plan,key,{sighash=0x41,mutate=()=>{}}={}){const tx=decodeTransaction(hexToBin(plan.unsignedHex));mutate(tx);for(let i=0;i<tx.inputs.length;i++){const preimage=generateSigningSerializationBCH({transaction:tx,sourceOutputs:plan.sourceOutputs,inputIndex:i},{coveredBytecode:plan.sourceOutputs[i].lockingBytecode,signingSerializationType:Uint8Array.of(sighash)});const sig=secp256k1.signMessageHashSchnorr(key,sha256.hash(sha256.hash(preimage)));const push=encodeDataPush(Uint8Array.from([...sig,sighash]));const pub=encodeDataPush(secp256k1.derivePublicKeyCompressed(key));tx.inputs[i].unlockingBytecode=Uint8Array.from([...push,...pub]);}return binToHex(encodeTransaction(tx));}
test('private draft uses distinct valid keys and rejects amount and interval boundaries',()=>{const d=createEnvelopeDraft({amountBch:'0.001',now});assert.notEqual(d.claimPrivateKey,d.recoveryPrivateKey);assert.deepEqual(validateEnvelopeDraft(d),d);for(const amountBch of ['0.00001','21000001','1e2'])assert.throws(()=>createEnvelopeDraft({amountBch,now}));assert.throws(()=>createEnvelopeDraft({amountBch:'0.001',hours:0,now}));});
test('private draft rejects substituted key, contract and additional fields',()=>{const d=createEnvelopeDraft({amountBch:'0.001',now});assert.throws(()=>validateEnvelopeDraft({...d,claimPrivateKey:d.recoveryPrivateKey}),/does not match/);assert.throws(()=>validateEnvelopeDraft({...d,paid:true}));assert.throws(()=>validateEnvelopeDraft({...d,contract:{...d.contract,reclaimAfter:d.contract.reclaimAfter+1}}));});
test('encrypted backup roundtrips; fresh salts/IVs produce different ciphertext',async()=>{const d=createEnvelopeDraft({amountBch:'0.001',now});const a=await encryptEnvelopeDraft(d,pass),b=await encryptEnvelopeDraft(d,pass);assert.notEqual(a.salt,b.salt);assert.notEqual(a.iv,b.iv);assert.notEqual(a.ciphertext,b.ciphertext);assert.deepEqual(await decryptEnvelopeDraft(a,pass),d);assert.ok(!JSON.stringify(a).includes(d.claimPrivateKey));});
test('wrong passphrase, ciphertext tampering and KDF substitution reject',async()=>{const d=createEnvelopeDraft({amountBch:'0.001',now});const a=await encryptEnvelopeDraft(d,pass);await assert.rejects(decryptEnvelopeDraft(a,pass+'x'),/could not be unlocked/);const changed={...a,ciphertext:(a.ciphertext[0]==='A'?'B':'A')+a.ciphertext.slice(1)};await assert.rejects(decryptEnvelopeDraft(changed,pass),/could not be unlocked/);await assert.rejects(decryptEnvelopeDraft({...a,iterations:1},pass),/Unsupported/);await assert.rejects(encryptEnvelopeDraft(d,'short'),/12/);});
test('oversized and malformed encrypted backups reject before decryption',async()=>{const a=await encryptEnvelopeDraft(createEnvelopeDraft({amountBch:'0.001',now}),pass);await assert.rejects(decryptEnvelopeDraft({...a,ciphertext:'A'.repeat(12001)},pass),/encoding/);await assert.rejects(decryptEnvelopeDraft({...a,iv:'A'},pass));});
test('single-input funding pays contract once, derives wallet change and conserves every satoshi',()=>{const x=setup();try{const p=prepareEnvelopeFunding(x.config);const tx=decodeTransaction(hexToBin(p.unsignedHex));assert.equal(tx.outputs.length,2);assert.equal(binToHex(tx.outputs[0].lockingBytecode),x.config.draft.contract.scriptHex);assert.equal(tx.outputs[0].valueSatoshis,100000n);assert.equal(p.changeAddress,x.rows[3].address);assert.equal(p.totalInputSats,p.amountSats+p.feeSats+p.changeSats);assert.equal(p.feeSats,BigInt(p.estimatedSignedBytes));assert.equal(p.claimNetEstimateSats+p.claimFeeEstimateSats,p.amountSats);assert.deepEqual(p.inputPaths,[[0,'receive',0]]);}finally{x.manager.destroy();}});
test('another wallet, disconnected state and changed paths reject',()=>{const x=setup();try{assert.throws(()=>prepareEnvelopeFunding({...x.config,state:'idle'}));assert.throws(()=>prepareEnvelopeFunding({...x.config,snapshot:{...x.config.snapshot,manager:{}}}));assert.throws(()=>prepareEnvelopeFunding({...x.config,snapshot:{...x.config.snapshot,rows:x.rows.slice(0,3)}}));}finally{x.manager.destroy();}});
test('stale/future snapshot, wrong network/checkpoint and near-recovery drafts reject',()=>{const x=setup();try{for(const t of [now-1,now+60001])assert.throws(()=>prepareEnvelopeFunding({...x.config,now:t}));for(const patch of [{network:'testnet'},{checkpoint:1},{scannedScripts:3}])assert.throws(()=>prepareEnvelopeFunding({...x.config,snapshot:{...x.config.snapshot,value:{...x.config.snapshot.value,...patch}}}));assert.throws(()=>prepareEnvelopeFunding({...x.config,now:x.config.draft.contract.reclaimAfter*1000-1000}),/15 minutes/);}finally{x.manager.destroy();}});
test('no confirmed candidates cannot fall back to simulation funding',()=>{const x=setup();try{for(const candidates of [[],[x.candidate(0,'200000',0)]])assert.throws(()=>prepareEnvelopeFunding({...x.config,snapshot:{...x.config.snapshot,value:{...x.config.snapshot.value,candidates}}}),/No confirmed/);}finally{x.manager.destroy();}});
test('duplicate, forged, token-labelled and malformed funding reject',()=>{const x=setup();try{for(const candidates of [[x.candidate(0),x.candidate(0)],[{...x.candidate(0),scriptHex:'00'}],[{...x.candidate(0),token:{}}],[{...x.candidate(0),sats:'-1'}],[{...x.candidate(0),index:-1}]])assert.throws(()=>prepareEnvelopeFunding({...x.config,snapshot:{...x.config.snapshot,value:{...x.config.snapshot.value,candidates}}}));}finally{x.manager.destroy();}});
test('selection adds input rather than silently consuming subminimum change as fee',()=>{const x=setup();try{x.config.snapshot.value.candidates=[x.candidate(0,'100500'),x.candidate(1,'2000')];const p=prepareEnvelopeFunding(x.config);assert.equal(p.transaction.inputs.length,2);assert.ok(p.changeSats>=1000n);assert.equal(p.totalInputSats,p.amountSats+p.changeSats+p.feeSats);}finally{x.manager.destroy();}});
test('insufficient funding and excessive fee rate reject',()=>{const x=setup();try{x.config.snapshot.value.candidates=[x.candidate(0,'1000')];assert.throws(()=>prepareEnvelopeFunding(x.config),/cannot cover/);assert.throws(()=>prepareEnvelopeFunding({...x.config,feeRate:101}));}finally{x.manager.destroy();}});
test('wallet request is sign-only with source values, scripts and explicit paths',()=>{const x=setup();try{const p=prepareEnvelopeFunding(x.config),q=envelopeSigningRequest(p);assert.equal(q.transaction.broadcast,false);assert.equal(typeof q.transaction.transaction,'object');assert.equal(q.transaction.transaction.version,2);assert.equal(q.transaction.transaction.locktime,0);assert.deepEqual(q.transaction.transaction.inputs[0].outpointTransactionHash,Array.from(p.transaction.inputs[0].outpointTransactionHash));assert.deepEqual(q.transaction.transaction.outputs[0].lockingBytecode,Array.from(p.transaction.outputs[0].lockingBytecode));assert.equal(q.transaction.transaction.outputs[0].valueSatoshis,Number(p.transaction.outputs[0].valueSatoshis));assert.equal(q.transaction.sourceOutputs[0].valueSatoshis,200000);assert.deepEqual(q.transaction.sourceOutputs[0].lockingBytecode,Array.from(p.sourceOutputs[0].lockingBytecode));assert.equal(p.sourceOutputs[0].valueSatoshis,200000n);assert.doesNotThrow(()=>JSON.stringify(q));assert.deepEqual(q.inputPaths,[[0,'receive',0]]);q.inputPaths[0][1]='modified';assert.equal(p.inputPaths[0][1],'receive');}finally{x.manager.destroy();}});
test('signed funding accepted only after exact-plan and local BCH signature checks',()=>{const x=setup();try{const p=prepareEnvelopeFunding(x.config),hex=signed(p,x.privateKey),r=verifySignedEnvelopeFunding(hex,p);assert.equal(r.signedHex,hex);assert.match(r.txid,/^[a-f0-9]{64}$/);assert.match(r.status,/NOT BROADCAST/);}finally{x.manager.destroy();}});
test('wallet cannot substitute outputs, amounts, fees, sequences or extra outputs',()=>{const x=setup();try{const p=prepareEnvelopeFunding(x.config);for(const mutate of [tx=>tx.outputs[0].valueSatoshis--,tx=>{tx.outputs[0].lockingBytecode=tx.outputs[1].lockingBytecode;},tx=>tx.inputs[0].sequenceNumber--,tx=>tx.outputs.push({...tx.outputs[1]})])assert.throws(()=>verifySignedEnvelopeFunding(signed(p,x.privateKey,{mutate}),p),/changed/);}finally{x.manager.destroy();}});
test('unsigned inputs, wrong private key, invalid signatures and non-ALL sighash reject',()=>{const x=setup();try{const p=prepareEnvelopeFunding(x.config);assert.throws(()=>verifySignedEnvelopeFunding(p.unsignedHex,p));assert.throws(()=>verifySignedEnvelopeFunding(signed(p,hexToBin('33'.repeat(32))),p),/verification/);assert.throws(()=>verifySignedEnvelopeFunding(signed(p,x.privateKey,{sighash:0x42}),p),/SIGHASH_ALL/);const hex=signed(p,x.privateKey);const tx=decodeTransaction(hexToBin(hex));tx.inputs[0].unlockingBytecode[10]^=1;assert.throws(()=>verifySignedEnvelopeFunding(binToHex(encodeTransaction(tx)),p),/verification/);}finally{x.manager.destroy();}});
test('WizardConnect sign request uses the dapp protocol, verifies locally, and never broadcasts',async()=>{
 const x=setup();try{
  const p=prepareEnvelopeFunding(x.config),calls=[],events=[];
  assert.equal(typeof x.manager.nextSequence,'function');
  assert.equal(typeof x.manager.sendSignRequest,'function');
  assert.equal(typeof x.manager.signTransaction,'function');
  x.manager.nextSequence=()=>2468;
  x.manager.sendSignRequest=async request=>{
   calls.push(request);
   assert.equal(request.action,'sign_transaction_request');
   assert.equal(request.sequence,2468);
   assert.ok(Math.abs(request.time-Math.floor(Date.now()/1000))<=2);
   assert.equal(request.transaction.broadcast,false);
   assert.equal(typeof request.transaction.transaction,'object');assert.deepEqual(request.transaction.transaction.inputs[0].outpointTransactionHash,Array.from(p.transaction.inputs[0].outpointTransactionHash));assert.deepEqual(request.transaction.transaction.outputs.map(o=>o.valueSatoshis),p.transaction.outputs.map(o=>Number(o.valueSatoshis)));
   assert.deepEqual(request.inputPaths,p.inputPaths);
   assert.equal(request.transaction.sourceOutputs[0].valueSatoshis,200000);
   const transported=JSON.parse(JSON.stringify(request));
   assert.deepEqual(transported.transaction.sourceOutputs[0].lockingBytecode,Array.from(p.sourceOutputs[0].lockingBytecode));
   assert.equal(transported.transaction.sourceOutputs[0].valueSatoshis,200000);
   return{signedTransaction:signed(p,x.privateKey)};
  };
  const result=await requestEnvelopeSignature({manager:x.manager,state:'connected',plan:p,now,onStage:phase=>events.push(phase)});
  assert.deepEqual(events,['wallet-request','local-verification']);
  assert.equal(calls.length,1);
  assert.match(result.status,/NOT BROADCAST/);
  assert.match(result.txid,/^[a-f0-9]{64}$/);
  await assert.rejects(requestEnvelopeSignature({manager:x.manager,state:'connected',plan:p,now:now+60000}),/expired/);
  const abort=new AbortController();abort.abort();
  await assert.rejects(requestEnvelopeSignature({manager:x.manager,state:'connected',plan:p,now,signal:abort.signal}),/cancelled/);
  assert.equal(calls.length,1);
  x.manager.sendSignRequest=async()=>{throw Error('User rejected');};
  await assert.rejects(requestEnvelopeSignature({manager:x.manager,state:'connected',plan:p,now}),/User rejected/);
 }finally{x.manager.destroy();}
});

test('aborting a pending WizardConnect sign request cancels its sequence',async()=>{
 const x=setup();try{
  const p=prepareEnvelopeFunding(x.config),controller=new AbortController(),cancellations=[];
  x.manager.nextSequence=()=>97531;
  x.manager.sendSignCancel=async(...args)=>{cancellations.push(args);};
  x.manager.sendSignRequest=async()=>new Promise(()=>{});
  const pending=requestEnvelopeSignature({manager:x.manager,state:'connected',plan:p,now,signal:controller.signal});
  controller.abort();
  await assert.rejects(pending,/cancelled|aborted/i);
  assert.deepEqual(cancellations.map(row=>row[0]),[97531]);
 }finally{x.manager.destroy();}
});

test('real SDK relay serialization and response delivery preserve signed BCH plan without broadcasting',async()=>{
 const x=setup();
 const previous=x.manager.conn;
 try{
  const p=prepareEnvelopeFunding(x.config),stages=[],messages=[];
  x.manager.conn={
   nextSequence(){return 98765;},
   async relay(message){
    const wire=JSON.parse(JSON.stringify(message));
    messages.push(wire);
    assert.equal(wire.action,'sign_transaction_request');
    assert.equal(wire.transaction.broadcast,false);
    assert.equal(typeof wire.transaction.transaction,'object');assert.deepEqual(wire.transaction.transaction.inputs.map(i=>i.outpointIndex),p.transaction.inputs.map(i=>i.outpointIndex));assert.deepEqual(wire.transaction.transaction.outputs.map(o=>o.valueSatoshis),p.transaction.outputs.map(o=>Number(o.valueSatoshis)));
    assert.deepEqual(wire.inputPaths,p.inputPaths);
    assert.equal(wire.transaction.sourceOutputs.length,p.sourceOutputs.length);
    assert.ok(wire.transaction.sourceOutputs.every(o=>Number.isSafeInteger(o.valueSatoshis)&&o.valueSatoshis>0));
    // The real signing wrapper must work through the JSON relay, not a
    // fake manager.signTransaction or a shortcut bypassing publish logic.
    setImmediate(()=>x.manager.pendingSignatureRequests.get(wire.sequence)?.resolve({signedTransaction:signed(p,x.privateKey)}));
   }
  };
  const response=await requestEnvelopeSignature({manager:x.manager,state:'connected',plan:p,now,onStage:stage=>stages.push(stage)});
  assert.deepEqual(stages,['wallet-request','wallet-request-published','local-verification']);
  assert.equal(messages.length,1);
  assert.match(response.status,/NOT BROADCAST/);
  assert.match(response.txid,/^[a-f0-9]{64}$/);
 }finally{
  x.manager.conn=previous;
  x.manager.destroy();
 }
});

test('WizardConnect structured signing payload survives native JSON relay without modifying BCH transaction bytes',()=>{
 const x=setup();try{
  const p=prepareEnvelopeFunding(x.config),request=envelopeSigningRequest(p);
  const transported=JSON.parse(JSON.stringify({action:'sign_transaction_request',sequence:2,time:10,...request}));
  const tx=transported.transaction.transaction;
  assert.equal(isSignTransactionRequest(transported),true);
  assert.equal(typeof tx,'object');
  assert.ok(Array.isArray(tx.inputs)&&Array.isArray(tx.outputs));
  assert.ok(tx.inputs.every(input=>Array.isArray(input.outpointTransactionHash)&&input.unlockingBytecode.length===0));
  assert.ok(tx.outputs.every(output=>Array.isArray(output.lockingBytecode)&&Number.isSafeInteger(output.valueSatoshis)));
  const rebuilt={
   version:tx.version,locktime:tx.locktime,
   inputs:tx.inputs.map(input=>({...input,outpointTransactionHash:Uint8Array.from(input.outpointTransactionHash),unlockingBytecode:Uint8Array.from(input.unlockingBytecode)})),
   outputs:tx.outputs.map(output=>({...output,lockingBytecode:Uint8Array.from(output.lockingBytecode),valueSatoshis:BigInt(output.valueSatoshis)}))
  };
  assert.equal(binToHex(encodeTransaction(rebuilt)),p.unsignedHex);
  assert.equal(transported.transaction.broadcast,false);
  assert.deepEqual(transported.inputPaths,p.inputPaths);
  assert.equal(p.transaction.outputs[0].valueSatoshis,100000n);
  assert.ok(transported.transaction.sourceOutputs.every(row=>Number.isSafeInteger(row.valueSatoshis)));
  assert.throws(()=>envelopeSigningRequest({...p,transaction:{...p.transaction,outputs:[{...p.transaction.outputs[0],valueSatoshis:1n},...p.transaction.outputs.slice(1)]}}),/does not match/);
 }finally{x.manager.destroy();}
});
