import {test} from 'node:test';import assert from 'node:assert/strict';
import {encodeTransaction,hexToBin,binToHex,hashTransaction,decodeTransaction,createVirtualMachineBCH,decodeAuthenticationInstructions} from '@bitauth/libauth';
import {createDeviceWalletSession} from '../wallet-lab/device-wallet-session.mjs';
import {createDeviceWallet,validateDeviceWallet,encryptDeviceWallet,decryptDeviceWallet,activateDeviceWallet,readDeviceWalletSlot,unlockDeviceWalletSlot,validateWalletBackup} from '../wallet-lab/device-wallet-core.mjs';
import {lookupDeviceWallet,prepareDeviceWalletSend,prepareDeviceWalletExactSend,validateBchFundingDestination,broadcastDeviceWalletSend} from '../wallet-lab/device-wallet-network.mjs';
import {createEnvelopeDraft} from '../wallet-lab/envelope-draft.mjs';
import {hashScript} from '../wallet-lab/broadcast-core.mjs';
import {saveTransactionReceipt,readTransactionReceipts,importTransactionReceipt} from '../wallet-lab/transaction-journal.mjs';
import {GENESIS} from '../wallet-lab/live-funding-core.mjs';
const now=1800000000000,password='fixture only wallet password 1234';
const wallet=createDeviceWallet(now),other=createDeviceWallet(now),backup=await encryptDeviceWallet(wallet,password);
function memory(){const map=new Map();return{getItem:key=>map.get(key)??null,setItem:(key,value)=>map.set(key,value),dump:()=>JSON.stringify([...map])};}
const header='0040312bdba9b08737140488c02ee43532296d9763fa36feabd23c0100000000000000000eaa975763bf54a0e37dfc1a25f2e447fcf2ed2eef4f51ce2d7b96adaf8dec8470e5256829740218ba0d6201';
function fund({value=100000n,seed=1,height=900000,token,coinbase=false,script=wallet.scriptHex}={}){const bytes=encodeTransaction({version:2,locktime:0,inputs:[{outpointTransactionHash:new Uint8Array(32).fill(coinbase?0:seed),outpointIndex:coinbase?0xffffffff:0,sequenceNumber:0xffffffff,unlockingBytecode:new Uint8Array()}],outputs:[{lockingBytecode:hexToBin(script),valueSatoshis:value,...(token?{token}:{})}]});const hex=binToHex(bytes),txid=hashTransaction(bytes);return{hex,item:{tx_hash:txid,tx_pos:0,value:value.toString(),height}};}
const first=fund(),second=fund({seed:2,value:200000n}),pending=fund({seed:3,value:300000n,height:0});
function provider(options={}){const funds=options.funds??[first],calls=[];let lists=0;return{calls,async call(method,params=[]){calls.push({method,params});if(options.fail===method)throw Error('offline');if(method==='server.version')return['fixture','1.4.3'];if(method==='server.features')return{genesis_hash:options.wrongNetwork?'bad':GENESIS,hash_function:'sha256'};if(method==='blockchain.block.header')return header;if(method==='blockchain.scripthash.get_history')return options.publishedHex?[{tx_hash:hashTransaction(hexToBin(options.publishedHex)),height:900000}]:[];if(method==='blockchain.scripthash.listunspent'){lists++;return options.changed&&lists>1?[]:options.list??funds.map(f=>f.item);}if(method==='blockchain.transaction.get'){if(options.publishedHex&&params[0]===hashTransaction(hexToBin(options.publishedHex)))return options.publishedHex;return options.badRaw?'00':funds.find(f=>f.item.tx_hash===params[0])?.hex;}if(method==='blockchain.transaction.broadcast'){if(options.timeout)throw Error('response lost');return hashTransaction(hexToBin(params[0]));}throw Error('Unexpected method');}};}
const writes=rpc=>rpc.calls.filter(c=>c.method==='blockchain.transaction.broadcast');
async function snapshot(options){return lookupDeviceWallet({wallet,rpc:provider(options),now:()=>now});}
async function plan(options){return prepareDeviceWalletSend({wallet,snapshot:await snapshot(options),destination:other.address,now});}
test('wallet keys are unique and must match a standard BCH mainnet address',()=>{assert.notEqual(wallet.privateKey,other.privateKey);assert.notEqual(wallet.address,other.address);assert.equal(validateDeviceWallet(wallet).address,wallet.address);for(const patch of [{privateKey:'00'.repeat(32)},{address:other.address},{scriptHex:other.scriptHex},{network:'bchtest'},{extra:true},{createdAt:-1}])assert.throws(()=>validateDeviceWallet({...wallet,...patch}));});
test('wallet backup encrypts, roundtrips and uses fresh salts/IVs without exposing key or password',async()=>{const next=await encryptDeviceWallet(wallet,password);assert.notEqual(next.salt,backup.salt);assert.notEqual(next.iv,backup.iv);assert.deepEqual(await decryptDeviceWallet(backup,password),wallet);assert.ok(!JSON.stringify(backup).includes(wallet.privateKey));assert.ok(!JSON.stringify(backup).includes(password));});
test('wrong password, tampering, KDF downgrade, draft-file substitution and oversized backup fail closed',async()=>{await assert.rejects(decryptDeviceWallet(backup,password+'x'));for(const b of [{...backup,iterations:1},{...backup,type:'tiplink-encrypted-draft'},{...backup,ciphertext:'A'.repeat(2049)},{...backup,iv:'a'},{...backup,privateKey:wallet.privateKey}])assert.throws(()=>validateWalletBackup(b));await assert.rejects(decryptDeviceWallet({...backup,ciphertext:(backup.ciphertext[0]==='A'?'B':'A')+backup.ciphertext.slice(1)},password));await assert.rejects(encryptDeviceWallet(wallet,'short'));});
test('activation requires explicit saved-backup acknowledgement and writes encrypted data only',async()=>{const storage=memory();await assert.rejects(activateDeviceWallet({backup,password,backupSaved:false},storage),/Save/);assert.equal(readDeviceWalletSlot(storage),null);const result=await activateDeviceWallet({backup,password,backupSaved:true},storage);assert.equal(result.wallet.address,wallet.address);assert.ok(!storage.dump().includes(wallet.privateKey));assert.ok(!storage.dump().includes(password));assert.equal((await unlockDeviceWalletSlot(readDeviceWalletSlot(storage),password)).address,wallet.address);});
test('saved public address substitution cannot unlock a different wallet',async()=>{const storage=memory();await activateDeviceWallet({backup,password,backupSaved:true},storage);await assert.rejects(unlockDeviceWalletSlot({...readDeviceWalletSlot(storage),address:other.address},password),/changed/);await assert.rejects(unlockDeviceWalletSlot(readDeviceWalletSlot(storage),'wrong password 1234'));});
test('restoring another wallet cannot overwrite an existing wallet; same-wallet restore remains possible',async()=>{const storage=memory();await activateDeviceWallet({backup,password,backupSaved:true},storage);const otherBackup=await encryptDeviceWallet(other,password);await assert.rejects(activateDeviceWallet({backup:otherBackup,password,backupSaved:true},storage),/another TipLink wallet/);assert.equal(readDeviceWalletSlot(storage).address,wallet.address);assert.equal((await activateDeviceWallet({backup,password,backupSaved:true},storage)).wallet.address,wallet.address);});
test('storage refusal prevents wallet activation; corrupted and oversized stored records do not become new empty wallets',async()=>{await assert.rejects(activateDeviceWallet({backup,password,backupSaved:true},{getItem:()=>null,setItem:()=>{throw Error('denied');}}),/denied/);for(const raw of ['bad','a'.repeat(4001),JSON.stringify({type:'tiplink-device-wallet-slot',privateKey:wallet.privateKey})])assert.throws(()=>readDeviceWalletSlot({getItem:()=>raw}));});
test('funding lookup verifies raw IDs/scripts/value and separates confirmed from pending BCH',async()=>{const rpc=provider({funds:[first,pending]});const s=await lookupDeviceWallet({wallet,rpc,now:()=>now});assert.equal(s.confirmedSats,100000n);assert.equal(s.pendingSats,300000n);assert.equal(s.coins.length,2);assert.equal(rpc.calls.filter(c=>c.method==='blockchain.scripthash.listunspent').length,2);assert.ok(!JSON.stringify(rpc.calls).includes(wallet.privateKey));});
test('token and coinbase outputs are excluded from spendable wallet funds',async()=>{const token=fund({seed:5,token:{category:new Uint8Array(32).fill(8),amount:1n}}),coinbase=fund({coinbase:true});const s=await snapshot({funds:[first,token,coinbase]});assert.equal(s.confirmedSats,100000n);assert.equal(s.excludedTokens,1);assert.equal(s.excludedCoinbase,1);});
test('provider outage, wrong network, bad raw, mismatched amounts, changed and excessive lists never become zero balance',async()=>{for(const options of [{wrongNetwork:true},{fail:'blockchain.transaction.get'},{badRaw:true},{changed:true},{list:[{...first.item,value:'100001'}]},{list:Array(21).fill(first.item)}])await assert.rejects(snapshot(options));});
test('empty successful lookup is distinct from provider failure',async()=>{const s=await snapshot({funds:[]});assert.equal(s.confirmedSats,0n);assert.equal(s.pendingSats,0n);assert.throws(()=>prepareDeviceWalletSend({wallet,snapshot:s,destination:other.address,now}),/confirmed BCH/);});
test('send-all conserves exact satoshis, binds destination and uses verified UTXOS signatures for every input',async()=>{const p=await plan({funds:[first,second,pending]});assert.equal(p.totalInputSats,300000n);assert.equal(p.receiveSats+p.feeSats,300000n);assert.equal(p.feeSats,BigInt(p.bytes));const tx=decodeTransaction(hexToBin(p.hex));assert.equal(tx.inputs.length,2);assert.equal(tx.outputs.length,1);assert.equal(tx.outputs[0].valueSatoshis,p.receiveSats);for(const i of tx.inputs)assert.equal(decodeAuthenticationInstructions(i.unlockingBytecode)[0].data.at(-1),0x61);assert.ok(!p.hex.includes(wallet.privateKey));});
test('stale/future snapshots, wrong wallet, same destination, wrong network and impossible fees reject',async()=>{const s=await snapshot();for(const time of [now-1,now+30000,NaN])assert.throws(()=>prepareDeviceWalletSend({wallet,snapshot:s,destination:other.address,now:time}));for(const patch of [{wallet:other},{destination:wallet.address},{destination:'bchtest:bad'},{feeRate:101}])assert.throws(()=>prepareDeviceWalletSend({wallet,snapshot:s,destination:other.address,now,...patch}));});
test('forged totals, duplicate coins, unconfirmed-only and insufficient dust fail before signing a spend',async()=>{const s=await snapshot();for(const patch of [{confirmedSats:1n},{coins:[...s.coins,...s.coins]}])assert.throws(()=>prepareDeviceWalletSend({wallet,snapshot:{...s,...patch},destination:other.address,now}));for(const funds of [[pending],[fund({value:1000n})]]){const s=await snapshot({funds});assert.throws(()=>prepareDeviceWalletSend({wallet,snapshot:s,destination:other.address,now}));}});
test('wallet payment requires explicit authorisation and a durable public receipt before one write',async()=>{const p=await plan(),rpc=provider();await assert.rejects(broadcastDeviceWalletSend({wallet,plan:p,rpc}),/Confirm/);assert.equal(rpc.calls.length,0);const storage=memory();const r=await broadcastDeviceWalletSend({wallet,plan:p,rpc,authorise:true,beforeSubmit:row=>{assert.equal(writes(rpc).length,0);saveTransactionReceipt(row,storage);}});assert.equal(r.status,'submitted');assert.equal(writes(rpc).length,1);const receipt=readTransactionReceipts(storage)[0];assert.equal(receipt.kind,'wallet-send');assert.equal(receipt.envelopeTxid,null);assert.equal(receipt.walletAddress,wallet.address);assert.ok(!storage.dump().includes(wallet.privateKey));assert.ok(!JSON.stringify(rpc.calls).includes(wallet.privateKey));});
test('changed balance, altered hex/destination/txid/amount and wrong wallet block all payment writes',async()=>{const p=await plan();for(const patch of [{hex:'00'},{txid:'ab'.repeat(32)},{destination:wallet.address},{receiveSats:p.receiveSats+1n}]){const rpc=provider();await assert.rejects(broadcastDeviceWalletSend({wallet,plan:{...p,...patch},rpc,authorise:true,beforeSubmit:()=>{}}));assert.equal(writes(rpc).length,0);}for(const funds of [[],[second]]){const rpc=provider({funds});await assert.rejects(broadcastDeviceWalletSend({wallet,plan:p,rpc,authorise:true,beforeSubmit:()=>{}}),/balance changed/);assert.equal(writes(rpc).length,0);}});
test('storage failure/cancellation block writes; lost response remains uncertain without retry',async()=>{const p=await plan(),rpc=provider();await assert.rejects(broadcastDeviceWalletSend({wallet,plan:p,rpc,authorise:true,beforeSubmit:()=>{throw Error('storage full');}}),/storage full/);assert.equal(writes(rpc).length,0);const c=new AbortController();await assert.rejects(broadcastDeviceWalletSend({wallet,plan:p,rpc,signal:c.signal,authorise:true,beforeSubmit:()=>c.abort()}));assert.equal(writes(rpc).length,0);const uncertain=provider({timeout:true});assert.equal((await broadcastDeviceWalletSend({wallet,plan:p,rpc:uncertain,authorise:true,beforeSubmit:()=>{}})).status,'unknown');assert.equal(writes(uncertain).length,1);});
test('an already published wallet payment reconciles without a second broadcast',async()=>{const p=await plan(),rpc=provider({publishedHex:p.hex,funds:[]});const r=await broadcastDeviceWalletSend({wallet,plan:p,rpc,authorise:true,beforeSubmit:()=>{}});assert.equal(r.status,'confirmed');assert.equal(writes(rpc).length,0);});
test('wallet-send receipt import keeps its address but resets untrusted success and rejects secrets',async()=>{const p=await plan(),storage=memory(),r={txid:p.txid,hex:p.hex,kind:'wallet-send',envelopeTxid:null,walletAddress:wallet.address,status:'confirmed',height:900000,createdAt:now,checkedAt:now};assert.equal(importTransactionReceipt(r,storage,now).status,'unknown');assert.equal(readTransactionReceipts(storage)[0].walletAddress,wallet.address);assert.throws(()=>saveTransactionReceipt({...r,privateKey:wallet.privateKey},storage));});

test('lock prevents a late asynchronous unlock from reopening the wallet',async()=>{let release;const updates=[],session=createDeviceWalletSession({onChange:value=>updates.push(value)});const unlock=session.open(()=>new Promise(resolve=>release=resolve));session.lock();release(wallet);await assert.rejects(unlock,/remains locked/);assert.ok(!updates.includes(wallet));session.close();});
test('inactivity locks after five minutes, activity resets the deadline, and closed sessions cannot unlock',async()=>{let clock=0;const updates=[],session=createDeviceWalletSession({clock:()=>clock,onChange:value=>updates.push(value)});await session.open(async()=>wallet);clock=299999;session.tick();assert.equal(updates.at(-1),wallet);session.touch();clock=599998;session.tick();assert.equal(updates.at(-1),wallet);clock=599999;session.tick();assert.equal(updates.at(-1),null);session.close();await assert.rejects(session.open(async()=>wallet),/closed/);});

test('twenty dust outputs cannot block reading or spending the wallet balance',async()=>{
 const dust=Array.from({length:20},(_,index)=>fund({seed:index+10,value:546n}));
 const funds=[first,...dust];
 const scanned=await snapshot({funds});
 assert.equal(scanned.coins.length,21);
 assert.equal(scanned.confirmedSats,100000n+20n*546n);
 const payment=prepareDeviceWalletSend({wallet,snapshot:scanned,destination:other.address,now});
 const tx=decodeTransaction(hexToBin(payment.hex));
 assert.equal(tx.inputs.length,20);
 assert.ok(tx.inputs.some(input=>binToHex(input.outpointTransactionHash)===first.item.tx_hash));
 assert.equal(payment.remainingConfirmedSats,546n);
 assert.equal(payment.receiveSats+payment.feeSats+payment.remainingConfirmedSats,scanned.confirmedSats);
 const rpc=provider({funds:[...funds,fund({seed:99,value:546n})]});
 const result=await broadcastDeviceWalletSend({wallet,plan:payment,rpc,authorise:true,beforeSubmit:()=>{}});
 assert.equal(result.status,'submitted');
 assert.equal(writes(rpc).length,1);
});

test('a large output set shows a partial verified balance and still prepares payment',async()=>{
 const funds=[first,...Array.from({length:128},(_,index)=>fund({seed:index+10,value:546n}))];
 const scanned=await snapshot({funds});
 assert.equal(scanned.coins.length,128);
 assert.equal(scanned.unscannedOutputs,1);
 assert.equal(scanned.confirmedSats,100000n+127n*546n);
 const payment=prepareDeviceWalletSend({wallet,snapshot:scanned,destination:other.address,now});
 assert.equal(decodeTransaction(hexToBin(payment.hex)).inputs.length,20);
});

test('wallet-first BCH payment link sends exact amount with change and locally checked VM signatures',async()=>{
 const snapshotValue=await snapshot({funds:[first,second]});
 const p=prepareDeviceWalletExactSend({wallet,snapshot:snapshotValue,destination:other.address,amountSats:'50000',now});
 const tx=decodeTransaction(hexToBin(p.hex));
 assert.notEqual(typeof tx,'string');
 assert.equal(p.exactAmountSats,'50000');
 assert.equal(p.receiveSats,50000n);
 assert.equal(tx.outputs[0].valueSatoshis,50000n);
 assert.equal(tx.outputs[0].lockingBytecode.length,25);
 assert.equal(tx.outputs.length,2);
 assert.equal(tx.outputs[1].valueSatoshis,p.changeSats);
 assert.equal(p.feeSats,p.totalInputSats-p.receiveSats-p.changeSats);
 assert.equal(p.remainingConfirmedSats,snapshotValue.confirmedSats-p.receiveSats-p.feeSats);
 assert.equal(tx.inputs.length,1,'Spend one confirmed output when enough');
 const used=tx.inputs.map(i=>snapshotValue.coins.find(c=>c.txid===binToHex(i.outpointTransactionHash)&&c.index===i.outpointIndex));
 assert.ok(used.every(Boolean));
 const sourceOutputs=used.map(c=>({lockingBytecode:hexToBin(c.scriptHex),valueSatoshis:BigInt(c.sats)}));
 assert.equal(createVirtualMachineBCH().verify({transaction:tx,sourceOutputs}),true);
 assert.ok(!p.hex.includes(wallet.privateKey));
});
test('wallet-first link funding rejects underfunding, unconfirmed-only and tampered destination',async()=>{
 const confirmed=await snapshot({funds:[first]});
 assert.throws(()=>prepareDeviceWalletExactSend({wallet,snapshot:confirmed,destination:other.address,amountSats:'99999999',now}),/Insufficient confirmed BCH/);
 assert.throws(()=>prepareDeviceWalletExactSend({wallet,snapshot:confirmed,destination:other.address,amountSats:'500',now}),/Invalid exact/);
 assert.throws(()=>prepareDeviceWalletExactSend({wallet,snapshot:confirmed,destination:wallet.address,amountSats:'50000',now}),/different BCH receiving/);
 const unconfirmed=await snapshot({funds:[pending]});
 assert.throws(()=>prepareDeviceWalletExactSend({wallet,snapshot:unconfirmed,destination:other.address,amountSats:'50000',now}),/confirmed BCH/);
 const p=prepareDeviceWalletExactSend({wallet,snapshot:confirmed,destination:other.address,amountSats:'50000',now});
 const rpc=provider({funds:[first]});
 await assert.rejects(broadcastDeviceWalletSend({wallet,plan:{...p,exactAmountSats:'51000'},rpc,authorise:true,beforeSubmit:async()=>{}}),/changed/);
 assert.equal(writes(rpc).length,0);
});
test('wallet session lasts through tab hide and expires after the configured inactivity timeout',async()=>{
 let time=now,unlocked=null;
 const session=createDeviceWalletSession({clock:()=>time,idleMs:900000,onChange:value=>{unlocked=value;}});
 await session.open(async()=>wallet);
 time+=899000;session.tick();assert.equal(unlocked?.address,wallet.address);
 session.touch();time+=899000;session.tick();assert.equal(unlocked?.address,wallet.address);
 time+=1001;session.tick();assert.equal(unlocked,null);
 session.close();
});

test('built-in wallet funds exact, genuine P2SH TipLink envelope without altering BCH claim amount',async()=>{
 const envelope=createEnvelopeDraft({amountBch:'0.0005',hours:24,now});
 const destination=validateBchFundingDestination(envelope.contract.address);
 assert.equal(destination.scriptHex,envelope.contract.scriptHex);
 const current=await snapshot({funds:[first,second]});
 const p=prepareDeviceWalletExactSend({wallet,snapshot:current,destination:envelope.contract.address,
  amountSats:envelope.amountSats,now});
 const tx=decodeTransaction(hexToBin(p.hex));
 assert.notEqual(typeof tx,'string');
 assert.equal(p.receiveSats,BigInt(envelope.amountSats));
 assert.equal(binToHex(tx.outputs[0].lockingBytecode),envelope.contract.scriptHex);
 assert.equal(tx.outputs[0].valueSatoshis,50000n);
 assert.equal(p.changeSats>0n,true);
 assert.equal(tx.outputs[1].valueSatoshis,p.changeSats);
 const spent=tx.inputs.map(i=>current.coins.find(c=>c.txid===binToHex(i.outpointTransactionHash)&&c.index===i.outpointIndex));
 assert.equal(createVirtualMachineBCH().verify({transaction:tx,sourceOutputs:spent.map(c=>({lockingBytecode:hexToBin(c.scriptHex),valueSatoshis:BigInt(c.sats)}))}),true);
 assert.throws(()=>prepareDeviceWalletSend({wallet,snapshot:current,destination:envelope.contract.address,now}),/P2PKH/);
 assert.throws(()=>validateBchFundingDestination(envelope.contract.address.replace('bitcoincash:','bchtest:')),/mainnet/);
});

test('reopened encrypted wallet can inspect on-chain funds without unlocking private key',async()=>{
 const publicWallet={watchOnly:true,address:wallet.address};
 const rpc=provider({funds:[first,pending]});
 const result=await lookupDeviceWallet({wallet:publicWallet,rpc,now:()=>now});
 assert.equal(result.address,wallet.address);
 assert.equal(result.confirmedSats,100000n);
 assert.equal(result.pendingSats,300000n);
 assert.equal(JSON.stringify(rpc.calls).includes(wallet.privateKey),false);
 await assert.rejects(lookupDeviceWallet({wallet:{...publicWallet,privateKey:wallet.privateKey},rpc,now:()=>now}),/Unsupported|Invalid/);
 assert.throws(()=>prepareDeviceWalletSend({wallet:publicWallet,snapshot:result,destination:other.address,now}),/Unsupported|Invalid/);
});
