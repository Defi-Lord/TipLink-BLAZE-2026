import {test} from 'node:test';
import assert from 'node:assert/strict';
import {secp256k1,hexToBin} from '@bitauth/libauth';
import {createDeviceWallet} from '../wallet-lab/device-wallet-core.mjs';
import {bitcoinMessageHash,signDeviceWalletBusinessChallenge} from '../wallet-lab/device-wallet-business-signin.mjs';
import {findNewBusinessConfirmation,shouldCelebrateTransaction} from '../wallet-lab/transaction-reaction.mjs';
const wallet=createDeviceWallet();
const origin='https://www.tip-link.xyz';
function challenge(intent='signin',time=Date.now()){
 const id='18c78d57-7b1a-4619-92f6-4b29a7258ef1';
 const expiresAt=new Date(time+300000).toISOString();
 const purpose=intent==='link'?'Add wallet sign-in to merchant account 123.':'Sign in or create a TipLink merchant account.';
 const message='TipLink Business\n\nOrigin: '+origin+'\nAddress: '+wallet.address+'\nNetwork: Bitcoin Cash mainnet\nPurpose: '+purpose+
 '\nChallenge ID: '+id+'\nNonce: random-nonce\nIssued at: '+new Date(time).toISOString()+
 '\nExpires at: '+expiresAt+'\n\nThis is a sign-in message, not a payment. It does not authorise transactions or access to private keys.';
 return {id,address:wallet.address,expiresAt,message};
}
test('TipLink built-in wallet signs exact backend-compatible BCH merchant challenge',()=>{
 const c=challenge(),signature=signDeviceWalletBusinessChallenge({wallet,challenge:c,origin});
 assert.match(signature,/^[A-Za-z0-9+/]{87}=$/);
 const bytes=Uint8Array.from(atob(signature),c=>c.charCodeAt(0));
 assert.equal(bytes.length,65);
 assert.ok(bytes[0]>=31&&bytes[0]<=34);
 const pub=secp256k1.recoverPublicKeyCompressed(bytes.slice(1),bytes[0]-31,bitcoinMessageHash(c.message));
 assert.notEqual(typeof pub,'string');
 assert.deepEqual(pub,secp256k1.derivePublicKeyCompressed(hexToBin(wallet.privateKey)));
 assert.equal(secp256k1.verifySignatureCompactLowS(bytes.slice(1),pub,bitcoinMessageHash(c.message)),true);
 assert.ok(!signature.includes(wallet.privateKey));
});
test('wallet Business sign-in rejects modified origin, address, purpose, and expired challenge',()=>{
 const c=challenge();
 for(const altered of [
  {...c,message:c.message.replace(origin,'https://evil.example')},
  {...c,message:c.message.replace(wallet.address,'bitcoincash:invalid')},
  {...c,message:c.message.replace('sign-in message','money transfer')},
  {...c,message:c.message.replace('Sign in or create a TipLink merchant account.','Send funds.')},
  {...c,address:'bitcoincash:incorrect'}
 ])assert.throws(()=>signDeviceWalletBusinessChallenge({wallet,challenge:altered,origin}),/challenge|authentic|address/i);
 assert.throws(()=>signDeviceWalletBusinessChallenge({wallet,challenge:c,origin:'https://evil.example'}));
 assert.throws(()=>signDeviceWalletBusinessChallenge({wallet,challenge:c,origin,now:Date.parse(c.expiresAt)}));
 assert.equal(typeof signDeviceWalletBusinessChallenge({wallet,challenge:challenge('link'),origin}),'string');
});
test('successful BCH reaction plays only on fresh confirmation transitions',()=>{
 assert.equal(shouldCelebrateTransaction('seen','confirmed'),true);
 assert.equal(shouldCelebrateTransaction('submitted','confirmed'),true);
 assert.equal(shouldCelebrateTransaction('unknown','confirmed'),true);
 assert.equal(shouldCelebrateTransaction(null,'confirmed'),false);
 assert.equal(shouldCelebrateTransaction(null,'confirmed',{initiated:true}),true);
 assert.equal(shouldCelebrateTransaction('confirmed','confirmed'),false);
 assert.equal(shouldCelebrateTransaction('seen','unknown'),false);
});

test('Business reactions play for newly confirmed payments and do not replay on refresh',()=>{
 const invoice={id:'invoice',receipt:{status:'confirmed',lastStatus:'confirmed'}};
 assert.equal(findNewBusinessConfirmation(null,[invoice]),undefined);
 assert.equal(findNewBusinessConfirmation(new Map(),[invoice]),invoice);
 assert.equal(findNewBusinessConfirmation(new Map([[invoice.id,'seen']]),[invoice]),invoice);
 assert.equal(findNewBusinessConfirmation(new Map([[invoice.id,'confirmed']]),[invoice]),undefined);
 assert.equal(findNewBusinessConfirmation(new Map([[invoice.id,'seen']]),[{...invoice,receipt:{status:'seen'}}]),undefined);
 assert.equal(findNewBusinessConfirmation(new Map([[invoice.id,'seen']]),[{...invoice,receipt:{status:'stale',lastStatus:'confirmed'}}]),undefined);
});
