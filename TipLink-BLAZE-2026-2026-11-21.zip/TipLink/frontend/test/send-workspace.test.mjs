import test from 'node:test';
import assert from 'node:assert/strict';
import {readSendWorkspace, saveSendWorkspace} from '../wallet-lab/send-workspace.mjs';
import {createEnvelopeDraft, encryptEnvelopeDraft, decryptEnvelopeDraft} from '../wallet-lab/envelope-draft.mjs';

function memoryStorage() {
  const data = new Map();
  return {getItem: key => data.get(key) ?? null, setItem: (key, value) => data.set(key, value), data};
}
const fields = {amount: '0.0025', hours: '24', feeRate: '2', step: 'review', fundingMethod: 'direct'};

test('reload restores the same encrypted transfer and requires its password', async () => {
  const storage = memoryStorage();
  const draft = createEnvelopeDraft({amountBch: fields.amount});
  const password = 'test recovery password';
  const backup = await encryptEnvelopeDraft(draft, password);
  assert.equal(saveSendWorkspace({...fields, backup, password, draft}, storage), true);
  const raw = [...storage.data.values()][0];
  assert.ok(!raw.includes(password));
  assert.ok(!raw.includes(draft.claimPrivateKey));
  assert.ok(!raw.includes(draft.recoveryPrivateKey));
  const saved = readSendWorkspace(storage);
  assert.equal(saved.amount, fields.amount);
  assert.equal(saved.step, 'review');
  assert.equal(saved.fundingMethod, 'direct');
  const restored = await decryptEnvelopeDraft(saved.backup, password);
  assert.deepEqual(restored, draft);
  await assert.rejects(decryptEnvelopeDraft(saved.backup, 'incorrect password'));
  for (const type of ['tiplink-approved-transfer', 'tiplink-direct-funded']) {
    const checkpoint = {type, version: 1, encryptedDraft: backup, publicFundingData: 'test'};
    assert.equal(saveSendWorkspace({...fields, step: 'handoff', backup: checkpoint}, storage), true);
    assert.deepEqual(readSendWorkspace(storage).backup, checkpoint);
  }
});

test('a new transfer removes the previous recovery checkpoint', () => {
  const storage = memoryStorage();
  assert.equal(saveSendWorkspace({...fields, backup: {type: 'tiplink-encrypted-draft', version: 1, ciphertext: 'test'}}, storage), true);
  assert.equal(saveSendWorkspace({...fields, step: 'amount', backup: null}, storage), true);
  assert.equal(readSendWorkspace(storage).backup, null);
});

test('damaged storage, access denial and plaintext drafts fail safely', () => {
  const storage = memoryStorage();
  storage.data.set('tiplink.send-workspace.v1', '{broken');
  assert.equal(readSendWorkspace(storage), null);
  storage.data.set('tiplink.send-workspace.v1', 'x'.repeat(120001));
  assert.equal(readSendWorkspace(storage), null);
  assert.equal(saveSendWorkspace({...fields, backup: {type: 'tiplink-private-draft', claimPrivateKey: 'secret'}}, storage), false);
  const denied = {getItem() {throw Error('denied');}, setItem() {throw Error('quota');}};
  assert.equal(readSendWorkspace(denied), null);
  assert.equal(saveSendWorkspace(fields, denied), false);
});
