import { test } from 'node:test';
import assert from 'node:assert/strict';
import { encodeCashAddress } from '@bitauth/libauth';
import { previewTip, validateRecipient, formatBch } from '../wallet-lab/preview-core.mjs';
const address = (n, prefix = 'bitcoincash', type = 'p2pkh') => encodeCashAddress({ prefix, type, payload: new Uint8Array(20).fill(n) }).address;
const recipients = [address(1), address(2), address(3)];
test('validates, normalizes and builds the exact P2PKH recipient script', () => {
  const result = validateRecipient(` ${recipients[0].toUpperCase()} `);
  assert.equal(result.address, recipients[0]);
  assert.equal(result.scriptHex, `76a914${'01'.repeat(20)}88ac`);
});
test('rejects altered checksums and mixed case', () => {
  assert.throws(() => validateRecipient(recipients[0].slice(0,-1) + (recipients[0].endsWith('q') ? 'p' : 'q')));
  assert.throws(() => validateRecipient('B' + recipients[0].slice(1)));
});
test('rejects wrong networks, token-aware addresses and unsupported scripts', () => {
  assert.throws(() => validateRecipient(address(1, 'bchtest')));
  assert.throws(() => validateRecipient(address(1, 'bchreg')));
  assert.throws(() => validateRecipient(address(1, 'bitcoincash', 'p2pkhWithTokens')));
  assert.throws(() => validateRecipient(address(1, 'bitcoincash', 'p2sh')));
});
test('rejects duplicate recipient scripts even with different address casing', () => {
  assert.throws(() => previewTip('0.01', [recipients[0], recipients[0].toUpperCase(), recipients[2]]), /different locking scripts/);
});
test('preview outputs conserve the tip with exact amounts and formatting', () => {
  const result = previewTip('0.01', recipients);
  assert.deepEqual(result.outputs.map(o => o.sats), [600000n, 250000n, 150000n]);
  assert.equal(result.outputs.reduce((sum,o) => sum+o.sats,0n), result.totalSats);
  assert.equal(formatBch(1n), '0.00000001');
  assert.equal(formatBch(result.totalSats), '0.01000000');
});
test('enforces application minimum and rejects missing recipients', () => {
  assert.throws(() => previewTip('0.00001', recipients));
  assert.throws(() => previewTip('0.01', recipients.slice(0,2)));
  assert.throws(() => previewTip('0.01', ['', recipients[1], recipients[2]]));
});
