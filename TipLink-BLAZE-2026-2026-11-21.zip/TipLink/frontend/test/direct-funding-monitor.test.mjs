import {test} from 'node:test';
import assert from 'node:assert/strict';
import {startDirectFundingMonitor,directNextDelay,DIRECT_FAST_PROVIDERS,DIRECT_POLL_MS,recipientCheckDelay,receiptCheckDelay} from '../wallet-lab/direct-funding-monitor.mjs';
const draft={contract:{address:'bitcoincash:test-contract'},amountSats:'50000'};
const encryptedDraft={type:'tiplink-encrypted-draft'};
function timers(){
 const pending=[];
 return{
  pending,
  schedule:(fn,ms)=>{const task={fn,ms,cancelled:false};pending.push(task);return task;},
  unschedule:task=>{task.cancelled=true;},
  async next(){
   const task=pending.find(x=>!x.cancelled&&!x.fired);
   assert.ok(task,'Expected a scheduled automatic check');
   task.fired=true;task.fn();
   await new Promise(resolve=>setImmediate(resolve));
   return task.ms;
  }
 };
}
test('automatic BCH monitor detects confirmation and advances only once without a second click',async()=>{
 const fake=timers(),events=[],confirmed=[],rpc={close(){},call(){}};
 const outputs=['unfunded','unconfirmed','confirmed'],probes=[];
 const watcher=startDirectFundingMonitor({
  draft,encryptedDraft,schedule:fake.schedule,unschedule:fake.unschedule,
  openRpc:async options=>{assert.deepEqual(options.providers,DIRECT_FAST_PROVIDERS);return rpc;},
  lookup:async args=>{assert.equal(args.rpc,rpc);const status=outputs[probes.length];probes.push(status);return{status,message:status,checkedAt:123,transfer:{utxo:{txid:'abc'}}};},
  buildHandoff:({snapshot})=>{assert.equal(snapshot.status,'confirmed');return{id:'secure-handoff'};},
  onUpdate:e=>events.push(e),onFunded:h=>confirmed.push(h)
 });
 assert.equal(await fake.next(),0);
 assert.equal(fake.pending.find(x=>!x.cancelled&&!x.fired).ms,DIRECT_POLL_MS.unfunded);
 await fake.next();
 assert.equal(fake.pending.find(x=>!x.cancelled&&!x.fired).ms,DIRECT_POLL_MS.unconfirmed);
 assert.equal(confirmed.length,0);
 await fake.next();
 assert.deepEqual(confirmed,[{id:'secure-handoff'}]);
 assert.equal(watcher.isDone(),true);
 assert.equal(fake.pending.filter(x=>!x.cancelled&&!x.fired).length,0);
 assert.ok(events.some(e=>e.phase==='confirming'));
 watcher.stop();
});
test('polling is sequential, can pause offline, and cancels outstanding work on unmount',async()=>{
 const fake=timers();let calls=0,closed=0,resolveLookup;let online=false,visible=true;
 const watcher=startDirectFundingMonitor({
  draft,encryptedDraft,schedule:fake.schedule,unschedule:fake.unschedule,
  isOnline:()=>online,isVisible:()=>visible,
  openRpc:async()=>({close(){closed++;}}),
  lookup:async()=>{calls++;return new Promise(resolve=>{resolveLookup=resolve;});}
 });
 assert.equal(fake.pending.length,0,'Offline pages must not start polling');
 await watcher.refresh();assert.equal(calls,0);
 online=true;visible=false;await watcher.refresh();assert.equal(calls,0);
 visible=true;const inflight=watcher.refresh();
 await Promise.resolve();await Promise.resolve();
 assert.equal(calls,1);
 assert.equal(watcher.isBusy(),true);
 await watcher.refresh();assert.equal(calls,1,'No overlapping requests');
 resolveLookup({status:'unconfirmed',checkedAt:1,message:'pending'});
 await inflight;
 assert.equal(fake.pending.find(x=>!x.cancelled&&!x.fired).ms,DIRECT_POLL_MS.unconfirmed);
 watcher.stop();
 assert.equal(closed,1);
 assert.ok(fake.pending.filter(x=>!x.cancelled&&!x.fired).length===0);
});
test('ambiguous and wrong-amount payments never auto-activate or loop indefinitely',async()=>{
 for(const status of ['wrong-amount','ambiguous']){
  const fake=timers(),sent=[];
  const w=startDirectFundingMonitor({
   draft,encryptedDraft,schedule:fake.schedule,unschedule:fake.unschedule,
   openRpc:async()=>({close(){}}),
   lookup:async()=>({status,message:'Do not pay twice',checkedAt:100}),
   onFunded:h=>sent.push(h)
  });
  await fake.next();
  assert.deepEqual(sent,[]);
  assert.equal(fake.pending.filter(x=>!x.cancelled&&!x.fired).length,0);
  w.stop();
 }
});
test('automatic funding retries network outages with bounded backoff',async()=>{
 const fake=timers(),events=[];
 const w=startDirectFundingMonitor({
  draft,encryptedDraft,schedule:fake.schedule,unschedule:fake.unschedule,
  openRpc:async()=>({close(){}}),
  lookup:async()=>{throw Error('transient network error');},
  onUpdate:e=>events.push(e)
 });
 for(let i=1;i<=5;i++){
  await fake.next();
  const t=fake.pending.find(x=>!x.cancelled&&!x.fired);
  assert.equal(t.ms,directNextDelay('error',i));
 }
 assert.equal(directNextDelay('error',50),DIRECT_POLL_MS.retryMax);
 assert.ok(events.every(e=>e.phase!=='confirmed'));
 w.stop();
});

test('recipient and receipt checks are responsive, bounded and distinguish pending from confirmed',()=>{
 assert.equal(recipientCheckDelay('unconfirmed'),9000);
 assert.equal(recipientCheckDelay('confirmed'),20000);
 assert.equal(recipientCheckDelay('unknown'),12000);
 assert.equal(receiptCheckDelay('submitted'),10000);
 assert.equal(receiptCheckDelay('seen'),10000);
 assert.equal(receiptCheckDelay('unknown'),10000);
 assert.equal(receiptCheckDelay('confirmed'),0);
 assert.equal(receiptCheckDelay('lost'),0);
});

test('first verified unconfirmed payment prepares a pending claim link automatically without a second click',async()=>{
 const fake=timers(),events=[],handoffs=[],funded=[];
 let closed=0;
 const monitor=startDirectFundingMonitor({
  draft,encryptedDraft,schedule:fake.schedule,unschedule:fake.unschedule,
  openRpc:async()=>({close(){closed++;}}),
  lookup:async()=>({status:'unconfirmed',height:0,checkedAt:123,transfer:{utxo:{txid:'abc'}},message:'detected'}),
  buildHandoff:({snapshot,allowPending})=>{
   assert.equal(allowPending,true);
   assert.equal(snapshot.status,'unconfirmed');
   return{status:'pending',id:'same-link'};
  },
  onUpdate:next=>events.push(next),
  onDetected:handoff=>handoffs.push(handoff),
  onFunded:handoff=>funded.push(handoff)
 });
 await fake.next();
 assert.deepEqual(handoffs,[{status:'pending',id:'same-link'}]);
 assert.deepEqual(funded,[]);
 assert.equal(monitor.isDone(),true);
 assert.equal(closed,1);
 assert.equal(fake.pending.filter(task=>!task.cancelled&&!task.fired).length,0);
 monitor.stop();
});
test('provider disagreement is reported as status sync, not as a mining delay',async()=>{
 const fake=timers(),events=[];
 const m=startDirectFundingMonitor({
  draft,encryptedDraft,schedule:fake.schedule,unschedule:fake.unschedule,
  openRpc:async()=>({close(){}}),
  lookup:async()=>{throw Error('BCH providers did not agree on funding. Try again shortly.');},
  onUpdate:e=>events.push(e)
 });
 await fake.next();
 assert.ok(events.some(e=>e.issue==='provider-sync'&&/nodes do not yet agree/i.test(e.message)));
 assert.equal(events.some(e=>e.message?.includes('Waiting for a block confirmation')),false);
 m.stop();
});
