import {test} from 'node:test';
import assert from 'node:assert/strict';
import {encodeCashAddress} from '@bitauth/libauth';
import {nextReceiptToCheck, startReceiptMonitor} from '../wallet-lab/receipt-monitor.mjs';

const now = Date.parse('2026-11-07T12:00:00Z');
const address = encodeCashAddress({prefix: 'bitcoincash', type: 'p2pkh', payload: new Uint8Array(20).fill(83)}).address;
function invoice(age = 60000, status = 'seen') {
  return {
    id: '11111111-1111-4111-8111-111111111111', merchantName: 'Studio Finch',
    amountSats: '100000', address, memo: '', state: 'open', version: 1,
    createdAt: new Date(now - 3600000).toISOString(),
    expiresAt: new Date(now + 3600000).toISOString(),
    paymentStatus: status, monitoringConnected: true,
    receipt: {txid: 'ab'.repeat(32), outputIndex: 0, status, lastStatus: status,
      height: status === 'confirmed' ? 900000 : 0,
      checkedAt: new Date(now - age).toISOString(), source: 'rostrum.riften.net'},
  };
}
function harness({state = {items: [invoice()], busy: false, hidden: false}, request} = {}) {
  const pending = new Map();
  const calls = [], updates = [], errors = [], busy = [];
  let counter = 0;
  const stop = startReceiptMonitor({
    readState: () => state,
    request: async (path, options) => {
      calls.push({path, options});
      return request ? request(path, options) : {items: [invoice(0, 'confirmed')]};
    },
    onItems: items => updates.push(items),
    onBusy: value => busy.push(value),
    onError: error => errors.push(error),
    clock: () => now,
    schedule: (callback, delay) => {const id = ++counter; pending.set(id, {callback, delay}); return id;},
    cancel: id => pending.delete(id),
  });
  return {pending, calls, updates, errors, busy, stop, state,
    tick: async () => {
      const [id, task] = pending.entries().next().value;
      pending.delete(id);
      await task.callback();
    }};
}
test('chooses the oldest linked receipt after sixty seconds, including confirmed receipts', () => {
  const recent = invoice(59999);
  const old = invoice(90000, 'confirmed');
  const unlinked = {...invoice(), paymentStatus: 'not_checked', monitoringConnected: false};
  delete unlinked.receipt;
  assert.equal(nextReceiptToCheck([recent, unlinked], now), null);
  assert.equal(nextReceiptToCheck([invoice(), old], now).receipt.checkedAt, old.receipt.checkedAt);
  assert.equal(nextReceiptToCheck([invoice()], now).receipt.status, 'seen');
});
test('does not schedule lookups for busy or hidden pages or unlinked requests', async () => {
  for (const patch of [{busy: true}, {hidden: true}, {items: []}]) {
    const h = harness();
    Object.assign(h.state, patch);
    await h.tick();
    assert.equal(h.calls.length, 0);
    assert.equal(h.pending.size, 1);
    h.stop();
  }
});
test('checks the assigned transaction then reloads validated statuses, one receipt at a time', async () => {
  const h = harness();
  await h.tick();
  assert.equal(h.calls.length, 2);
  assert.deepEqual(h.calls[0], {
    path: '/invoices/' + invoice().id + '/receipt',
    options: {method: 'POST', body: {txid: invoice().receipt.txid, acknowledgeAssignment: true}},
  });
  assert.equal(h.calls[1].path, '/invoices');
  assert.equal(h.updates[0][0].receipt.status, 'confirmed');
  assert.deepEqual(h.busy, [true, false]);
  h.stop();
});
test('provider or rate-limit failures back off without publishing a confirmation', async () => {
  const h = harness({request: async () => {throw Object.assign(new Error('Rate limited'), {status: 429});}});
  for (const expected of [30000, 60000, 120000, 120000]) {
    await h.tick();
    assert.equal(h.pending.values().next().value.delay, expected);
  }
  assert.equal(h.updates.length, 0);
  assert.equal(h.errors.length, 4);
  assert.deepEqual(h.busy, [true, false, true, false, true, false, true, false]);
  h.stop();
});
test('stopping before a scheduled tick cancels all future work', () => {
  const h = harness();
  h.stop();
  assert.equal(h.pending.size, 0);
  assert.equal(h.calls.length, 0);
});
test('stopping an in-flight check prevents a reload and late screen update', async () => {
  let finish;
  const h = harness({request: () => new Promise(resolve => {finish = resolve;})});
  const running = h.tick();
  assert.equal(h.calls.length, 1);
  assert.equal(h.pending.size, 0);
  h.stop();
  finish({});
  await running;
  assert.equal(h.calls.length, 1);
  assert.equal(h.pending.size, 0);
  assert.equal(h.updates.length, 0);
  assert.deepEqual(h.busy, [true, false]);
});
test('malformed reloads are errors and never replace valid request data', async () => {
  const h = harness({request: async path => path.endsWith('/receipt') ? {} : {items: [{paid: true}]}});
  await h.tick();
  assert.equal(h.updates.length, 0);
  assert.equal(h.errors.length, 1);
  h.stop();
});
