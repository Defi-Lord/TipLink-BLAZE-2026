import {test} from 'node:test';
import assert from 'node:assert/strict';
import {binToHex,hexToBin,encodeTransaction,hashTransaction} from '@bitauth/libauth';
import {setup} from './handoff-fixture.mjs';
import {createEnvelopeDraft,encryptEnvelopeDraft} from '../wallet-lab/envelope-draft.mjs';
import {GENESIS} from '../wallet-lab/live-funding-core.mjs';
import {lookupDirectFunding,validateDirectFundingTransaction,createDirectFundedHandoff,verifyDirectFundedBackup,restoreDirectFundedHandoff} from '../wallet-lab/direct-funding.mjs';
import {encodeClaimTransfer,decodeClaimTransfer,claimTransferUrl} from '../wallet-lab/envelope-handoff.mjs';
import {lookupClaimFunding,prepareRecipientClaim} from '../wallet-lab/claim-lookup.mjs';
import {prepareRecovery,broadcastFunding,reviewFunding} from '../wallet-lab/broadcast-core.mjs';
const now=Date.parse('2026-11-19T03:00:00.000Z');
const header='0040312bdba9b08737140488c02ee43532296d9763fa36feabd23c0100000000000000000eaa975763bf54a0e37dfc1a25f2e447fcf2ed2eef4f51ce2d7b96adaf8dec8470e5256829740218ba0d6201';
const pass='a strong manual funding password 123';
const draft=createEnvelopeDraft({amountBch:'0.0005',hours:24,now});
const wallet=setup();
const otherScript=wallet.rows[0].scriptHex;
wallet.manager.destroy();
function funding({amount=50000n,duplicate=false,token=false,index=1}={}){
 const contractOutput={valueSatoshis:amount,lockingBytecode:hexToBin(draft.contract.scriptHex),
 ...(token?{token:{category:new Uint8Array(32).fill(7),amount:1n}}:{})};
 const outputs=[
  {valueSatoshis:10000n,lockingBytecode:hexToBin(otherScript)},
  contractOutput
 ];
 if(index===0)outputs.reverse();
 if(duplicate)outputs.push({...contractOutput});
 const tx={version:2,locktime:0,inputs:[{outpointTransactionHash:new Uint8Array(32).fill(6),outpointIndex:5,sequenceNumber:0xffffffff,unlockingBytecode:new Uint8Array()}],outputs};
 const bytes=encodeTransaction(tx),raw=binToHex(bytes),txid=hashTransaction(bytes);
 return{tx,raw,txid,index,entry:{tx_hash:txid,tx_pos:index,value:Number(amount),height:900000}};
}
function mock(f,{entries=[f.entry],raw=f.raw,stale=false,wrongNetwork=false}={}){
 let count=0;const calls=[];
 return{calls,async call(method,params){
  calls.push({method,params});
  if(method==='server.version')return['fixture','1.4.3'];
  if(method==='server.features')return{genesis_hash:wrongNetwork?'01'.repeat(32):GENESIS,hash_function:'sha256'};
  if(method==='blockchain.block.header')return header;
  if(method==='blockchain.scripthash.listunspent')return stale&&++count>1?[]:entries;
  if(method==='blockchain.transaction.get')return raw;
  throw Error('Unexpected read '+method);
 }};
}
test('a regular Selene payment to output 1 becomes a confirmed one-time claim link',async()=>{
 const f=funding(),rpc=mock(f),verified=await lookupDirectFunding({draft,rpc,now:()=>now+10000});
 assert.equal(verified.status,'confirmed');
 assert.equal(verified.transfer.utxo.index,1);
 assert.equal(verified.transfer.utxo.txid,f.txid);
 assert.equal(verified.transfer.utxo.sats,'50000');
 assert.deepEqual(decodeClaimTransfer(encodeClaimTransfer(verified.transfer)),verified.transfer);
 assert.match(claimTransferUrl(verified.transfer,'https://tip-link.xyz/send'),/#claim=/);
 assert.ok(!JSON.stringify(rpc.calls).includes(draft.claimPrivateKey));
 assert.ok(!JSON.stringify(rpc.calls).includes(draft.recoveryPrivateKey));
 assert.equal(rpc.calls.filter(c=>c.method==='blockchain.scripthash.listunspent').length,2);
 assert.equal(rpc.calls.some(c=>c.method==='blockchain.transaction.broadcast'),false);
 const encryptedDraft=await encryptEnvelopeDraft(draft,pass);
 const handoff=createDirectFundedHandoff({draft,encryptedDraft,snapshot:verified,now:verified.checkedAt+500});
 assert.equal(reviewFunding(handoff).transfer.utxo.index,1);
 assert.equal(handoff.backup.rawFundingHex,f.raw);
 assert.ok(!JSON.stringify(handoff.backup).includes(draft.recoveryPrivateKey));
 assert.deepEqual(verifyDirectFundedBackup({backup:handoff.backup,draft}),handoff.transfer);
 const restored=await restoreDirectFundedHandoff(handoff.backup,pass);
 assert.deepEqual(restored.transfer,handoff.transfer);
 assert.deepEqual(restored.draft,draft);
 await assert.rejects(restoreDirectFundedHandoff(handoff.backup,pass+'bad'));
 await assert.rejects(broadcastFunding({handoff,rpc,authorise:true}),/must never broadcast/);
 const claimSnapshot=await lookupClaimFunding({transfer:verified.transfer,rpc:mock(f),now:()=>now+20000});
 assert.equal(claimSnapshot.status,'confirmed');
 assert.equal(prepareRecipientClaim({transfer:verified.transfer,snapshot:claimSnapshot,destination:wallet.rows[0].address,now:now+21000}).branch,'claim');
 assert.equal(prepareRecovery({handoff,snapshot:claimSnapshot,destination:wallet.rows[0].address,now:now+21000}).branch,'reclaim');
});
test('external funding never activates claim link for missing, unconfirmed or altered BCH',async()=>{
 const f=funding();
 const noPay=await lookupDirectFunding({draft,rpc:mock(f,{entries:[]}),now:()=>now});
 assert.equal(noPay.status,'unfunded');
 const pending=await lookupDirectFunding({draft,rpc:mock(f,{entries:[{...f.entry,height:0}]}),now:()=>now});
 assert.equal(pending.status,'unconfirmed');
 assert.throws(()=>createDirectFundedHandoff({draft,encryptedDraft:{type:'tiplink-encrypted-draft'},snapshot:pending,now}),/verify/);
 assert.equal((await lookupDirectFunding({draft,rpc:mock(f,{entries:[{...f.entry,value:50001}]}),now:()=>now})).status,'wrong-amount');
 assert.equal((await lookupDirectFunding({draft,rpc:mock(f,{entries:[f.entry,{...f.entry,tx_pos:2}]}),now:()=>now})).status,'ambiguous');
 await assert.rejects(lookupDirectFunding({draft,rpc:mock(f,{raw:f.raw.replace(/^02/,'03')}),now:()=>now}),/verified|mismatch|Invalid/);
 await assert.rejects(lookupDirectFunding({draft,rpc:mock(f,{stale:true}),now:()=>now}),/changed/);
 const blocked=mock(f,{wrongNetwork:true});
 await assert.rejects(lookupDirectFunding({draft,rpc:blocked,now:()=>now}),/network/);
 assert.equal(blocked.calls.some(c=>c.method.includes('scripthash')),false);
});
test('external funding rejects tokens, ambiguous output, misaddressed and mismatched value',()=>{
 const f=funding(),t=funding({token:true}),dup=funding({duplicate:true}),incorrect=funding({amount:50001n});
 assert.throws(()=>validateDirectFundingTransaction({draft,rawHex:t.raw,txid:t.txid,index:t.index}),/exact BCH amount|contract address/);
 assert.throws(()=>validateDirectFundingTransaction({draft,rawHex:dup.raw,txid:dup.txid,index:dup.index}),/Multiple outputs/);
 assert.throws(()=>validateDirectFundingTransaction({draft,rawHex:incorrect.raw,txid:incorrect.txid,index:incorrect.index}),/exact BCH amount/);
 assert.throws(()=>validateDirectFundingTransaction({draft,rawHex:f.raw,txid:'00'.repeat(32),index:1}),/verified/);
 assert.throws(()=>validateDirectFundingTransaction({draft,rawHex:f.raw,txid:f.txid,index:0}),/exact BCH amount/);
 assert.throws(()=>validateDirectFundingTransaction({draft,rawHex:f.raw,txid:f.txid,index:-1}),/Invalid/);
});

test('sender may prepare a backed-up PENDING claim link only from independently verified exact funding',async()=>{
 const f=funding(),encryptedDraft=await encryptEnvelopeDraft(draft,pass);
 const pending=await lookupDirectFunding({draft,rpc:mock(f,{entries:[{...f.entry,height:0}]}),now:()=>now+1000});
 assert.equal(pending.status,'unconfirmed');
 assert.equal(pending.height,0);
 assert.match(pending.message,/detected/i);
 const h=createDirectFundedHandoff({draft,encryptedDraft,snapshot:pending,allowPending:true,now:pending.checkedAt+1000});
 assert.match(h.status,/UNCONFIRMED/);
 assert.equal(h.transfer.utxo.txid,f.txid);
 assert.equal(h.transfer.utxo.index,1);
 assert.equal(h.backup.type,'tiplink-direct-funded');
 assert.equal(h.backup.rawFundingHex,f.raw);
 assert.equal(encodeClaimTransfer(h.transfer),pending.identity);
 assert.equal(reviewFunding(h).transfer.utxo.txid,f.txid);
 const restored=await restoreDirectFundedHandoff(h.backup,pass);
 assert.equal(restored.transfer.utxo.txid,f.txid);
 // The link exists before the block, but no claim/recovery can be prepared
 // from an unconfirmed UTXO, even with the authentic claim private key.
 const stillPending=await lookupClaimFunding({transfer:h.transfer,rpc:mock(f,{entries:[{...f.entry,height:0}]}),now:()=>now+2100});
 assert.equal(stillPending.status,'unconfirmed');
 assert.throws(()=>prepareRecipientClaim({transfer:h.transfer,snapshot:stillPending,destination:wallet.rows[0].address,now:now+2200}),/confirmed/);
 assert.throws(()=>prepareRecovery({handoff:h,snapshot:stillPending,destination:wallet.rows[0].address,now:now+2200}),/confirmed/);
 const confirmed=await lookupClaimFunding({transfer:h.transfer,rpc:mock(f),now:()=>now+4000});
 assert.equal(confirmed.status,'confirmed');
 assert.equal(prepareRecipientClaim({transfer:h.transfer,snapshot:confirmed,destination:wallet.rows[0].address,now:now+4200}).branch,'claim');
});
test('unfunded, stale, changed, wrong amount and ambiguous outputs cannot create pending claim handoff',async()=>{
 const f=funding(),encryptedDraft=await encryptEnvelopeDraft(draft,pass);
 const pending=await lookupDirectFunding({draft,rpc:mock(f,{entries:[{...f.entry,height:0}]}),now:()=>now+5000});
 const attempt=(s)=>createDirectFundedHandoff({draft,encryptedDraft,snapshot:s,allowPending:true,now:now+5500});
 assert.throws(()=>attempt({...pending,status:'unfunded'}),/verify/);
 assert.throws(()=>attempt({...pending,status:'unconfirmed',height:900000}),/verify/);
 assert.throws(()=>attempt({...pending,checkedAt:now-30000}),/verify/);
 assert.throws(()=>attempt({...pending,identity:pending.identity.slice(0,-5)+'aaaaa'}),/proof changed/);
 assert.throws(()=>attempt({...pending,rawFundingHex:f.raw.slice(2)}),/Invalid|verified/);
 const wrong=await lookupDirectFunding({draft,rpc:mock(f,{entries:[{...f.entry,value:50001}]}),now:()=>now+5000});
 assert.throws(()=>attempt(wrong),/verify/);
});
