import {test} from 'node:test';
import assert from 'node:assert/strict';
import {paymentCheckIssue,paymentStatusView,isRecentChainCheck,canSharePendingClaimLink} from '../wallet-lab/payment-status.mjs';
import {transactionStatusLabel} from '../wallet-lab/transaction-journal.mjs';
const now=Date.parse('2026-11-19T11:00:00.000Z');
const pending={status:'unconfirmed',height:0,checkedAt:now-1000,identity:'claim-proof',transfer:{utxo:{txid:'ef'.repeat(32)}}};
const confirmed={...pending,status:'confirmed',height:977967};
test('detected unconfirmed BCH is shareable after backup but remains distinctly NOT confirmed',()=>{
 const state=paymentStatusView({snapshot:pending,now});
 assert.equal(state.kind,'detected');
 assert.equal(state.confirmed,false);
 assert.match(state.label,/detected/i);
 assert.match(state.message,/no BCH can be claimed/i);
 assert.equal(canSharePendingClaimLink({snapshot:pending,saved:false,ack:true,now}),false);
 assert.equal(canSharePendingClaimLink({snapshot:pending,saved:true,ack:false,now}),false);
 assert.equal(canSharePendingClaimLink({snapshot:pending,saved:true,ack:true,now}),true);
 assert.equal(canSharePendingClaimLink({snapshot:confirmed,saved:true,ack:true,now}),true);
 assert.equal(canSharePendingClaimLink({snapshot:pending,expectedIdentity:'claim-proof',saved:true,ack:true,now}),true);
 assert.equal(canSharePendingClaimLink({snapshot:pending,expectedIdentity:'a-different-link',saved:true,ack:true,now}),false);
 assert.equal(canSharePendingClaimLink({snapshot:{...pending,identity:''},saved:true,ack:true,now}),false);
 assert.equal(paymentStatusView({snapshot:confirmed,now}).confirmed,true);
});
test('frozen or failed app status may never masquerade as a slow BCH block',()=>{
 assert.equal(isRecentChainCheck(pending,now),true);
 assert.equal(paymentStatusView({snapshot:{...pending,checkedAt:now-31000},now}).kind,'stale');
 assert.equal(canSharePendingClaimLink({snapshot:{...pending,checkedAt:now-31000},saved:true,ack:true,now}),false);
 const disagreement=paymentCheckIssue(Error('BCH providers did not agree on funding.'));
 assert.equal(disagreement.code,'provider-sync');
 assert.match(disagreement.message,/nodes do not yet agree/i);
 assert.equal(paymentStatusView({snapshot:pending,error:disagreement,now}).kind,'provider-sync');
 assert.equal(canSharePendingClaimLink({snapshot:pending,saved:true,ack:true,error:disagreement,now}),false);
 const network=paymentCheckIssue(Error('Funding provider request timed out'));
 assert.equal(network.code,'network-unavailable');
 assert.match(network.message,/connection\/status-sync/i);
 const verify=paymentCheckIssue(Error('Claim funding output does not match the envelope'));
 assert.equal(verify.code,'verification-error');
 assert.equal(paymentStatusView({snapshot:null,now}).kind,'checking');
 assert.equal(paymentStatusView({snapshot:{status:'unavailable',checkedAt:now},now}).kind,'unavailable');
 assert.equal(paymentStatusView({snapshot:{status:'unfunded',checkedAt:now},now}).kind,'unfunded');
});
test('pending link shareability requires a fresh independent check, saved backup, and user acknowledgement',()=>{
 for(const bad of [
  {...pending,checkedAt:now+100},
  {...pending,checkedAt:now-30000},
  {...pending,checkedAt:NaN},
  {...pending,status:'unknown'},
  {...pending,status:'unfunded'}
 ])assert.equal(canSharePendingClaimLink({snapshot:bad,saved:true,ack:true,now}),false);
 assert.equal(canSharePendingClaimLink({snapshot:pending,saved:true,ack:true,now}),true);
});

test('transaction receipt tells BCH block delay apart from TipLink status-sync errors',()=>{
 const base={txid:'ab'.repeat(32),status:'seen',checkedAt:now,height:0};
 assert.match(transactionStatusLabel(base,now+5000),/Payment detected.*waiting for BCH block/);
 assert.match(transactionStatusLabel({...base,status:'submitted'},now),/Submitted.*awaiting BCH network detection/);
 assert.match(transactionStatusLabel({...base,status:'unknown'},now),/TipLink cannot verify status/);
 assert.match(transactionStatusLabel({...base,status:'confirmed',height:10},now),/Confirmed in BCH block/);
 assert.match(transactionStatusLabel(base,now+31000),/TipLink status sync delayed/);
});
