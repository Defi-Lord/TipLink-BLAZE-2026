import {test} from 'node:test';
import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {sha256,binToHex,hexToBin,encodeTransaction,hashTransaction,secp256k1} from '@bitauth/libauth';
import {discoverWalletFunding,lookupWalletFunding,scriptHash,validateUnspentList,verifyProviderIdentity,GENESIS} from '../wallet-lab/live-funding-core.mjs';
import {openFundingRpc,BCH_PROVIDERS} from '../wallet-lab/funding-rpc.mjs';
import {deriveWalletPath} from '../wallet-lab/wallet-address-core.mjs';
const header='0040312bdba9b08737140488c02ee43532296d9763fa36feabd23c0100000000000000000eaa975763bf54a0e37dfc1a25f2e447fcf2ed2eef4f51ce2d7b96adaf8dec8470e5256829740218ba0d6201';
const features={genesis_hash:GENESIS,hash_function:'sha256'};
const rows=[1,2,3,4].map((n,i)=>({path:i<3?'receive':'change',index:i<3?i:0,scriptHex:`76a914${n.toString(16).padStart(2,'0').repeat(20)}88ac`}));
function fixture(token){const bytes=encodeTransaction({version:2,locktime:0,inputs:[{outpointTransactionHash:new Uint8Array(32).fill(9),outpointIndex:0,sequenceNumber:0xffffffff,unlockingBytecode:new Uint8Array()}],outputs:[{valueSatoshis:10000n,lockingBytecode:hexToBin(rows[0].scriptHex),...(token?{token}: {})}]});return {raw:binToHex(bytes),item:{tx_hash:hashTransaction(bytes),tx_pos:0,value:10000,height:900000}};}
function provider({fund=fixture(),empty=false,wrongNetwork=false,mutateList,raw,stale=false}={}) {
 const calls=[];let firstCalls=0;
 return {calls,async call(method,params){calls.push({method,params});if(method==='server.version')return ['fixture','1.4.3'];if(method==='server.features')return wrongNetwork?{...features,genesis_hash:'00'.repeat(32)}:features;if(method==='blockchain.block.header')return header;if(method==='blockchain.transaction.get')return raw??fund.raw;if(method==='blockchain.scripthash.listunspent'){if(params[0]!==scriptHash(rows[0].scriptHex)||empty)return [];firstCalls++;if(stale&&firstCalls>1)return [];return mutateList?mutateList(fund.item):[fund.item];}throw new Error('Unexpected method');}};
}
test('checks real BCH checkpoint bytes and rejects another network/header',()=>{assert.equal(verifyProviderIdentity(features,header),true);assert.throws(()=>verifyProviderIdentity({...features,genesis_hash:'bad'},header));assert.throws(()=>verifyProviderIdentity(features,'00'.repeat(80)));assert.throws(()=>verifyProviderIdentity(features,'a'));});
test('script hash uses reversed SHA256 of the locking script',()=>{const hex=rows[0].scriptHex;assert.equal(scriptHash(hex),binToHex(sha256.hash(hexToBin(hex)).reverse()));assert.throws(()=>scriptHash('51'));});
test('empty scan returns zero only after all four scripts and their refreshes succeed',async()=>{const rpc=provider({empty:true});const r=await lookupWalletFunding({rpc,rows});assert.equal(r.totalSats,0n);assert.equal(r.scannedScripts,4);assert.equal(rpc.calls.filter(c=>c.method==='blockchain.scripthash.listunspent').length,8);});
test('verifies raw funding and retains wallet path/index before reporting candidate',async()=>{const rpc=provider();const r=await lookupWalletFunding({rpc,rows});assert.equal(r.totalSats,10000n);assert.equal(r.candidates[0].path,'receive');assert.equal(r.candidates[0].addressIndex,0);assert.match(r.candidates[0].status,/PROVIDER REPORTS UNSPENT/);});
test('rejects network mismatch before sending any wallet script hash',async()=>{const rpc=provider({wrongNetwork:true});await assert.rejects(lookupWalletFunding({rpc,rows}));assert.equal(rpc.calls.some(c=>c.method==='blockchain.scripthash.listunspent'),false);});
test('rejects malformed/duplicate lists and inconsistent amounts',async()=>{const f=fixture();assert.throws(()=>validateUnspentList([f.item,f.item]));assert.throws(()=>validateUnspentList({...f.item}));for(const patch of [{value:0},{height:0.2},{tx_pos:-1},{value:'1e4'},{value:Number.MAX_SAFE_INTEGER+1}])assert.throws(()=>validateUnspentList([{...f.item,...patch}]));await assert.rejects(lookupWalletFunding({rpc:provider({mutateList:i=>[{...i,value:10001}]}),rows}),/amount\/script/);});
test('rejects tampered raw bytes and stale unspent snapshot',async()=>{await assert.rejects(lookupWalletFunding({rpc:provider({raw:fixture().raw.replace(/^02/,'03')}),rows}),/ID mismatch/);await assert.rejects(lookupWalletFunding({rpc:provider({stale:true}),rows}),/changed during/);});
test('token output is inspected then excluded even without provider token labels',async()=>{const fund=fixture({category:new Uint8Array(32).fill(8),amount:1n});const r=await lookupWalletFunding({rpc:provider({fund}),rows});assert.equal(r.candidates.length,0);assert.equal(r.excludedTokens,1);});
test('provider failure or cancellation never becomes an empty successful balance',async()=>{await assert.rejects(lookupWalletFunding({rpc:{call:async()=>{throw new Error('offline');}},rows}),/offline/);const c=new AbortController();c.abort();const rpc=provider();await assert.rejects(lookupWalletFunding({rpc,rows,signal:c.signal}),/cancelled/);assert.equal(rpc.calls.length,0);});
class FakeSocket extends EventTarget {
 constructor(){super();queueMicrotask(()=>this.dispatchEvent(new Event('open')));}
 send(raw){const m=JSON.parse(raw);queueMicrotask(()=>this.dispatchEvent(new MessageEvent('message',{data:JSON.stringify({id:m.id,result:m.params})})));}
 close(){this.dispatchEvent(new Event('close'));}
}
test('RPC correlates responses and blocks write methods',async()=>{const rpc=await openFundingRpc({Socket:FakeSocket,timeoutMs:100});assert.deepEqual(await rpc.call('server.version',['lab','1.4.3']),['lab','1.4.3']);await assert.rejects(rpc.call('blockchain.transaction.broadcast',['deadbeef']),/allowlisted/);rpc.close();});
test('RPC abort and request timeout reject pending reads',async()=>{class Silent extends FakeSocket{send(){}}const c=new AbortController();const rpc=await openFundingRpc({Socket:Silent,signal:c.signal,timeoutMs:100});const pending=rpc.call('server.features');c.abort();await assert.rejects(pending,/cancelled/);const r=await openFundingRpc({Socket:Silent,timeoutMs:10});await assert.rejects(r.call('server.features'),/timed out/);r.close();});

test('gap discovery finds a payment at receive index 8 and checks change history too',async()=>{
 const manager={protocol:'hdwalletv1',hasPath:()=>true,getPubkey(path,index){
  const key=new Uint8Array(32);
  key[30]=path;
  key[31]=Number(index)+1;
  return secp256k1.derivePublicKeyCompressed(key);
 }};
 const row=deriveWalletPath(manager,'connected','receive',8);
 const target=scriptHash(row.scriptHex);
 const oldChange=scriptHash(deriveWalletPath(manager,'connected','change',5).scriptHex);
 const raw=encodeTransaction({version:2,locktime:0,inputs:[{outpointTransactionHash:new Uint8Array(32).fill(9),outpointIndex:0,sequenceNumber:0xffffffff,unlockingBytecode:new Uint8Array()}],outputs:[{valueSatoshis:10000n,lockingBytecode:hexToBin(row.scriptHex)}]});
 const item={tx_hash:hashTransaction(raw),tx_pos:0,value:10000,height:900000};
 const checked=[];
 const rpc={async call(method,params){
  if(method==='server.version')return ['fixture','1.4.3'];
  if(method==='server.features')return features;
  if(method==='blockchain.block.header')return header;
  if(method==='blockchain.scripthash.get_history'){
   checked.push(params[0]);
   return [target,oldChange].includes(params[0])?[item]:[];
  }
  if(method==='blockchain.scripthash.listunspent')return params[0]===target?[item]:[];
  if(method==='blockchain.transaction.get')return binToHex(raw);
  throw Error('Unexpected method');
 }};
 const result=await discoverWalletFunding({rpc,manager,state:'connected'});
 assert.equal(result.value.totalSats,10000n);
 assert.equal(result.value.candidates[0].addressIndex,8);
 assert.ok(result.rows.some(path=>path.path==='change'&&path.index===5));
 assert.ok(checked.includes(oldChange));
 assert.ok(checked.length>=49);
});

test('cross-checked providers tolerate one disagreeing peer and reject disagreement without a majority',async()=>{
 class Peer extends FakeSocket {
  constructor(url){super();this.url=url;}
  send(raw){
   const msg=JSON.parse(raw);
   const result={
    'server.version':['fixture','1.4.3'],'server.features':features,'blockchain.block.header':header,
    'blockchain.scripthash.listunspent':this.url==='odd'?[fixture().item]:[]
   }[msg.method];
   queueMicrotask(()=>this.dispatchEvent(new MessageEvent('message',{data:JSON.stringify({id:msg.id,result})})));
  }
 }
 for(const providers of [['odd','one','two'],['odd','one']]){
  const rpc=await openFundingRpc({Socket:Peer,providers,timeoutMs:100});
  try{
   const read=rpc.call('blockchain.scripthash.listunspent',['aa'.repeat(32)]);
   if(providers.length===3)assert.deepEqual(await read,[]);
   else await assert.rejects(read,/did not agree/);
  }finally{rpc.close();}
 }
});

test('BCH provider quorum includes an independent same-origin HTTPS TLS route',()=>{
 assert.ok(BCH_PROVIDERS.includes('wss://rostrum.riften.net:443'));
 assert.ok(BCH_PROVIDERS.includes('proxy:nordic'));
 assert.ok(BCH_PROVIDERS.includes('proxy:imaginary'));
 assert.equal(new Set(BCH_PROVIDERS).size,BCH_PROVIDERS.length);
});

test('funding RPC continues with two independently verified peers when another endpoint fails',async()=>{
 class MixedSocket extends EventTarget {
  constructor(url){super();this.url=url;queueMicrotask(()=>this.dispatchEvent(new Event(url.includes('unavailable')?'error':'open')));}
  send(raw){
   const message=JSON.parse(raw);
   const response={
    'server.version':['fixture','1.4.3'],
    'server.features':features,
    'blockchain.block.header':header,
    'blockchain.scripthash.listunspent':[]
   };
   queueMicrotask(()=>this.dispatchEvent(new MessageEvent('message',{data:JSON.stringify({id:message.id,result:response[message.method]})})));
  }
  close(){this.dispatchEvent(new Event('close'));}
 }
 const rpc=await openFundingRpc({Socket:MixedSocket,providers:['wss://unavailable.example','wss://healthy-one.example','wss://healthy-two.example'],timeoutMs:100});
 try{
  const rows=await rpc.call('blockchain.scripthash.listunspent',['ab'.repeat(32)]);
  assert.deepEqual(rows,[]);
  await assert.rejects(rpc.call('blockchain.transaction.broadcast',['ab']),/allowlisted|Broadcast/);
 }finally{rpc.close();}
});

test('production CSP explicitly permits every configured BCH websocket provider',()=>{
 const config=JSON.parse(readFileSync(new URL('../vercel.json',import.meta.url),'utf8'));
 const security=config.headers.find(row=>row.source==='/(.*)')?.headers.find(header=>header.key==='Content-Security-Policy')?.value;
 assert.ok(security,'Expected production CSP');
 const directive=security.split(';').map(part=>part.trim()).find(part=>part.startsWith('connect-src '));
 assert.ok(directive,'Expected connect-src directive');
 const allowed=new Set(directive.split(/\s+/).slice(1));
 for(const provider of BCH_PROVIDERS.filter(value=>value.startsWith('wss://')))assert.ok(allowed.has(provider),'Provider missing from connect-src: '+provider);
 assert.ok(allowed.has("'self'"),'Same-origin HTTPS bridge requires self');
 assert.ok(!allowed.has('*'),'Do not allow unrestricted connections');
 assert.ok(!allowed.has('wss:'),'Do not allow unrestricted WebSockets');
});

test('provider connection failure reports only safe host and phase diagnostics',async()=>{
 class FailedSocket extends EventTarget {
  constructor(url){super();this.url=url;queueMicrotask(()=>this.dispatchEvent(new Event('error')));}
  close(){this.dispatchEvent(new Event('close'));}
  send(){throw Error('should not send');}
 }
 const hosts=['wss://first.example','wss://second.example'];
 await assert.rejects(
  openFundingRpc({Socket:FailedSocket,providers:hosts,timeoutMs:100}),
  error=>{
   assert.match(error.message,/two BCH providers/);
   assert.equal(error.providerDiagnostics.length,2);
   assert.deepEqual(error.providerDiagnostics.map(row=>row.host),['first.example','second.example']);
   assert.ok(error.providerDiagnostics.every(row=>row.phase==='connecting'));
   assert.ok(error.providerDiagnostics.every(row=>row.reason==='Socket connection failed or was blocked'));
   assert.ok(!JSON.stringify(error.providerDiagnostics).includes('wallet'));
   return true;
  }
 );
});

test('cross-checked funding uses independent read-only HTTPS Electrum proxy and still verifies network identity',async()=>{
 class Peer extends EventTarget{
  constructor(url){super();this.url=url;queueMicrotask(()=>this.dispatchEvent(new Event('open')));}
  send(raw){
   const message=JSON.parse(raw);
   const result={'server.version':['fixture','1.4.3'],'server.features':features,'blockchain.block.header':header,'blockchain.scripthash.listunspent':[]}[message.method];
   queueMicrotask(()=>this.dispatchEvent(new MessageEvent('message',{data:JSON.stringify({id:message.id,result})})));
  }
  close(){this.dispatchEvent(new Event('close'));}
 }
 const calls=[];
 const Fetcher=async(url,options)=>{
  calls.push({url,body:JSON.parse(options.body),method:options.method,credentials:options.credentials});
  const result={'server.version':['fixture','1.4.3'],'server.features':features,'blockchain.block.header':header,'blockchain.scripthash.listunspent':[]}[calls.at(-1).body.method];
  return {ok:true,json:async()=>({result})};
 };
 const rpc=await openFundingRpc({Socket:Peer,providers:['wss://direct.example','proxy:nordic'],Fetcher,timeoutMs:100});
 try{
  assert.deepEqual(await rpc.call('blockchain.scripthash.listunspent',['ab'.repeat(32)]),[]);
  assert.ok(calls.length>=4);
  assert.ok(calls.every(c=>c.url==='/api/bch-read'&&c.method==='POST'&&c.credentials==='same-origin'));
  assert.ok(calls.every(c=>c.body.provider==='nordic'));
  await assert.rejects(rpc.call('blockchain.transaction.broadcast',['deadbeef']),/allowlisted|Broadcast/);
 }finally{rpc.close();}
});
