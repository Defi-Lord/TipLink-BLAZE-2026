import {test} from 'node:test';import assert from 'node:assert/strict';import {summariseEnvelopeReview,validateSendAmount,explainSendError,explainWalletApprovalError} from '../wallet-lab/send-review.mjs';
const plan={amountSats:100000n,feeSats:227n,claimFeeEstimateSats:248n,claimNetEstimateSats:99752n,totalInputSats:200000n,changeSats:99773n};
test('plain-language total includes both network fees once and excludes returned wallet change',()=>{const r=summariseEnvelopeReview(plan);assert.equal(r.recipientSats,99752n);assert.equal(r.networkFeesSats,475n);assert.equal(r.totalFromWalletSats,100227n);assert.equal(r.recipientSats+r.networkFeesSats,r.totalFromWalletSats);assert.equal(r.totalFromWalletSats,plan.totalInputSats-plan.changeSats);assert.equal(r.totalFromWalletBch,'0.00100227');});
test('review works with exact funding and no change',()=>{const r=summariseEnvelopeReview({...plan,totalInputSats:100227n,changeSats:0n});assert.equal(r.totalFromWalletSats,100227n);});
test('inconsistent recipient amount, fee or change cannot be displayed as a valid total',()=>{for(const patch of [{claimNetEstimateSats:99999n},{changeSats:1n},{feeSats:0n},{claimFeeEstimateSats:0n},{amountSats:0n}])assert.throws(()=>summariseEnvelopeReview({...plan,...patch}));});
test('invalid, negative and non-bigint values cannot reach payment summary',()=>{for(const patch of [{feeSats:-1n},{feeSats:227},{amountSats:'100000'},{totalInputSats:2100000000000001n}])assert.throws(()=>summariseEnvelopeReview({...plan,...patch}));});
test('amount entry preserves satoshis and enforces the same preparation minimum',()=>{assert.equal(validateSendAmount('0.00010001'),10001n);for(const v of ['0.00001','0.000100001','-1','1e2','21000001'])assert.throws(()=>validateSendAmount(v));});
test('technical errors have plain explanations without displaying raw provider output',()=>{assert.match(explainSendError(Error('No confirmed BCH-only funding')),/No money has moved/);assert.match(explainSendError(Error('Funding review expired.')),/fresh check/);assert.match(explainSendError(Error('Wallet declined.')),/did not approve/);assert.ok(!explainSendError(Error('arbitrary provider output')).includes('arbitrary'));});

test('specific read-only BCH network failures are explained without leaking provider details',()=>{
 const cases=[
  ['Could not connect to two BCH providers. Try again shortly.',/two independent BCH network providers/],
  ['BCH providers did not agree on funding. Try again shortly.',/conflicting balance information/],
  ['Funding provider request timed out.',/network balance check could not finish/],
  ['Wallet must supply both receive and change paths.',/receiving and change addresses/],
  ['Provider did not match the BCH mainnet checkpoint.',/could not verify the BCH network provider/],
  ['Funding changed during lookup.',/fresh check/],
 ];
 for(const [message,expected] of cases){const friendly=explainSendError(Error(message));assert.match(friendly,expected);assert.ok(!friendly.includes(message));}
});

test('wallet signing errors identify the failed stage without displaying untrusted SDK content',()=>{
 const secret='external raw wallet diagnostic:private-do-not-show';
 for(const phase of ['preflight','wallet-request','local-verification','handoff']){
  const message=explainWalletApprovalError(Error(secret),phase);
  assert.ok(message.length>25);
  assert.ok(!message.includes(secret));
  assert.match(message,/Nothing was (sent|broadcast)|No BCH was sent|No BCH was broadcast/i);
 }
 assert.match(explainWalletApprovalError(Error('Funding review expired.'),'preflight'),/expired/);
 assert.match(explainWalletApprovalError(Error('Wallet declined request'),'wallet-request'),/did not approve/);
 assert.match(explainWalletApprovalError(Error('Signing cancelled.'),'wallet-request'),/cancelled/);
});

test('WizardConnect transport error categories remain private and actionable',()=>{
 const cases=[
  ['Cannot send sign_transaction_request: message is larger than NIP-44\'s 65,535-byte ceiling',/WC-SIZE/],
  ['Failed to publish sign_transaction_request to a relay: connection failure',/WC-RELAY/],
  ['Cannot relay message: paired public key not set',/WC-RELAY|WC-SESSION/],
  ['Do not know how to serialize a BigInt',/WC-PAYLOAD/],
  ['TipLink wallet signing timeout.',/WC-TIMEOUT/],
  ['[wizardconnect/dapp] Not connected',/WC-SESSION/]
 ];
 for(const [raw,pattern] of cases){
  const message=explainWalletApprovalError(Error(raw),'wallet-request');
  assert.match(message,pattern);
  assert.equal(message.includes(raw),false);
  assert.match(message,/No BCH was broadcast|nothing was broadcast/i);
 }
 const unpublished=explainWalletApprovalError(Error('unrecognized private diagnostic'),'wallet-request');
 const published=explainWalletApprovalError(Error('unrecognized private diagnostic'),'wallet-request-published');
 assert.match(unpublished,/WC-REQUEST/);
 assert.match(published,/WC-RESPONSE/);
 assert.ok(!published.includes('unrecognized'));
});
