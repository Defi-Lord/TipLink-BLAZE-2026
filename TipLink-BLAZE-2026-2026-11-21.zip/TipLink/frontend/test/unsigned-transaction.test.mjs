import { test } from 'node:test';
import assert from 'node:assert/strict';
import { encodeCashAddress, decodeTransaction, encodeTransaction, hexToBin, binToHex } from '@bitauth/libauth';
import { buildUnsigned, buildSimulation, verifyUnsigned } from '../wallet-lab/unsigned-core.mjs';
const addr = n => encodeCashAddress({prefix:'bitcoincash',type:'p2pkh',payload:new Uint8Array(20).fill(n)}).address;
const addresses = [addr(1),addr(2),addr(3)];
const input = {txid:'0123456789abcdef'.repeat(4),index:7,sats:'100000000',scriptHex:`76a914${'05'.repeat(20)}88ac`};
const config = () => ({amountBch:'0.14',addresses,changeAddress:addr(4),utxos:[{...input}],feeRate:1});
test('builds and round-trips a three-recipient transaction plus change', () => {
 const p=buildUnsigned(config()); const tx=decodeTransaction(hexToBin(p.unsignedHex));
 assert.equal(typeof tx,'object'); assert.equal(tx.version,2); assert.equal(tx.locktime,0);
 assert.equal(binToHex(tx.inputs[0].outpointTransactionHash),input.txid); assert.equal(tx.inputs[0].outpointIndex,7);
 assert.equal(tx.inputs[0].unlockingBytecode.length,0);
 assert.deepEqual(tx.outputs.slice(0,3).map(o=>o.valueSatoshis),[8400000n,3500000n,2100000n]);
 assert.equal(p.estimatedSignedBytes,295); assert.equal(p.minerFeeSats,295n); assert.equal(p.changeSats,85999705n);
 assert.equal(p.totalInputSats,p.outputs.reduce((s,o)=>s+o.sats,0n)+p.minerFeeSats);
 assert.equal(verifyUnsigned(p.unsignedHex,p),true);
});
test('exact funding creates no change output', () => {
 const c=config();c.utxos[0].sats='14000261';const p=buildUnsigned(c);
 assert.equal(p.outputs.length,3); assert.equal(p.changeSats,0n);assert.equal(p.minerFeeSats,261n);
});
test('rejects insufficient inputs and subminimum change rather than donating excess', () => {
 for (const sats of ['14000260','14000262','14001294']) {const c=config();c.utxos[0].sats=sats;assert.throws(()=>buildUnsigned(c));}
 const c=config();c.utxos[0].sats='14001295';assert.equal(buildUnsigned(c).changeSats,1000n);
});
test('multiple inputs are accounted for with a size-based fee', () => {
 const c=config();c.utxos=[{...input,sats:'10000000'},{...input,index:8,sats:'10000000'}];
 const p=buildUnsigned(c); assert.equal(p.minerFeeSats,444n);assert.equal(p.totalInputSats,20000000n);assert.equal(p.changeSats,5999556n);
});
test('rejects duplicate, malformed and token-labelled funding', () => {
 const c=config();c.utxos.push({...input});assert.throws(()=>buildUnsigned(c));
 for(const patch of [{txid:'bad'},{index:-1},{index:1.1},{sats:'1e8'},{sats:1000},{sats:'2100000000000001'},{token:{}},{tokenData:null},{scriptHex:'51'}]) {
  const v=config();Object.assign(v.utxos[0],patch);assert.throws(()=>buildUnsigned(v));
 }
});
test('rejects invalid fees and change address overlap', () => {
 for(const feeRate of [0,-1,1.5,101,Infinity]) assert.throws(()=>buildUnsigned({...config(),feeRate}));
 assert.throws(()=>buildUnsigned({...config(),changeAddress:addresses[0]}));
});
test('detects recipient substitution and changed funding outpoint', () => {
 const p=buildUnsigned(config());
 for(const mutate of [tx=>{tx.outputs[0].valueSatoshis-=1n;tx.outputs[1].valueSatoshis+=1n;},tx=>{tx.outputs[0].lockingBytecode[3]^=1;},tx=>{tx.inputs[0].outpointIndex+=1;}]) {
  const tx=decodeTransaction(hexToBin(p.unsignedHex));mutate(tx);assert.throws(()=>verifyUnsigned(binToHex(encodeTransaction(tx)),p));
 }
});
test('rejects invalid/trailing hex and inconsistent fee summaries', () => {
 const p=buildUnsigned(config());assert.throws(()=>verifyUnsigned('zz',p));assert.throws(()=>verifyUnsigned(p.unsignedHex+'00',p));
 assert.throws(()=>verifyUnsigned(p.unsignedHex,{...p,minerFeeSats:p.minerFeeSats+1n}));
});
test('fixed offline simulation is explicitly identified and reconciles', () => {
 const p=buildSimulation('0.14',addresses);assert.match(p.mode,/OFFLINE/);assert.equal(p.totalInputSats,100000000n);assert.equal(verifyUnsigned(p.unsignedHex,p),true);
});
