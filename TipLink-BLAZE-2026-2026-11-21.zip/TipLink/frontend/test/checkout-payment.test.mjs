import {test} from 'node:test';
import assert from 'node:assert/strict';
import {binToHex,encodeCashAddress,encodeTransaction,hashTransaction,hexToBin} from '@bitauth/libauth';
import {checkoutHistory,findCheckoutPayment,listCheckoutPayments,recordCheckoutMatch,saveCheckoutPayment} from '../wallet-lab/checkout-payment.mjs';
import {validateRecipient} from '../wallet-lab/preview-core.mjs';

const address=encodeCashAddress({prefix:'bitcoincash',type:'p2pkh',payload:new Uint8Array(20).fill(83)}).address;
const invoice={id:'11111111-1111-4111-8111-111111111111',address,amountSats:'100000'};
const script=hexToBin(validateRecipient(address).scriptHex);
function payment(seed,height,value=100000n){
 const bytes=encodeTransaction({
  version:2,locktime:0,
  inputs:[{outpointTransactionHash:new Uint8Array(32).fill(seed),outpointIndex:0,sequenceNumber:0xffffffff,unlockingBytecode:new Uint8Array()}],
  outputs:[{lockingBytecode:script,valueSatoshis:value}]
 });
 return {tx_hash:hashTransaction(bytes),height,hex:binToHex(bytes)};
}
function rpc(rows){
 return {async call(method,[id]){
  if(method==='blockchain.scripthash.get_history')return rows;
  assert.equal(method,'blockchain.transaction.get');
  return rows.find(row=>row.tx_hash===id)?.hex;
 }};
}
const old=payment(1,900000), pending=payment(2,0), wrongAmount=payment(3,900001,99999n);
const newer={...pending,height:900002};

test('external checkout tracks only a new exact payment as pending then confirmed',async()=>{
 const baseline=(await checkoutHistory(invoice,rpc([old]))).map(row=>row.tx_hash);
 assert.deepEqual(await findCheckoutPayment({invoice,rpc:rpc([old]),baseline}),{status:'waiting'});
 assert.deepEqual(await findCheckoutPayment({invoice,rpc:rpc([old,pending,wrongAmount]),baseline}),{status:'seen',txid:pending.tx_hash,height:0});
 assert.deepEqual(await findCheckoutPayment({invoice,rpc:rpc([old,newer,wrongAmount]),baseline,txid:pending.tx_hash}),{status:'confirmed',txid:pending.tx_hash,height:900002});
});
test('ambiguous discovery and wrong transaction amounts do not imply payment',async()=>{
 assert.deepEqual(await findCheckoutPayment({invoice,rpc:rpc([old,pending]),baseline:[]}),{status:'ambiguous'});
 assert.deepEqual(await findCheckoutPayment({invoice,rpc:rpc([old,wrongAmount]),txid:wrongAmount.tx_hash}),{status:'mismatch'});
 await assert.rejects(findCheckoutPayment({invoice,rpc:rpc([{...pending,hex:old.hex}]),baseline:[]}),/different transaction bytes/);
});
test('payment request tracking survives a reload and rejects a changed recipient',()=>{
 const data=new Map();
 const storage={get length(){return data.size;},key:index=>[...data.keys()][index],getItem:key=>data.get(key)||null,setItem:(key,value)=>data.set(key,value)};
 saveCheckoutPayment(invoice,{baseline:[old.tx_hash]},storage);
 saveCheckoutPayment(invoice,{status:'seen',txid:pending.tx_hash,height:0},storage);
 assert.equal(listCheckoutPayments(storage)[0].txid,pending.tx_hash);
 assert.deepEqual(listCheckoutPayments(storage)[0].baseline,[old.tx_hash]);
 assert.throws(()=>saveCheckoutPayment({...invoice,amountSats:'200000'},{},storage),/request changed/);
});

test('a dedicated invoice detects an existing exact payment without a manual transaction ID',async()=>{
 const result=await findCheckoutPayment({invoice:{...invoice,receiptEligible:true},rpc:rpc([newer,wrongAmount]),baseline:[newer.tx_hash]});
 assert.deepEqual(result,{status:'confirmed',txid:newer.tx_hash,height:900002});
});

test('an interrupted merchant sync keeps a retryable local receipt and sends only the public transaction ID',async()=>{
 const data=new Map();
 const storage={getItem:key=>data.get(key)||null,setItem:(key,value)=>data.set(key,value)};
 const dedicated={...invoice,receiptEligible:true};
 const found={status:'confirmed',txid:newer.tx_hash,height:900002};
 const local=await recordCheckoutMatch(dedicated,found,{storage,fetcher:async()=>({ok:false})});
 assert.equal(local.receiptSyncPending,true);
 const saved=await recordCheckoutMatch(dedicated,found,{storage,fetcher:async(url,options)=>{
  assert.equal(url,'/api/v1/public/invoices/'+invoice.id+'/receipt');
  assert.equal(options.credentials,'omit');
  assert.deepEqual(JSON.parse(options.body),{txid:newer.tx_hash});
  return {ok:true,json:async()=>({...found,outputIndex:0,lastStatus:found.status,checkedAt:new Date().toISOString(),source:'rostrum.riften.net'})};
 }});
 assert.equal(saved.receiptSyncPending,false);
 const legacy=await recordCheckoutMatch(invoice,found,{storage,fetcher:async()=>{assert.fail('Legacy request should not sync');}});
 assert.equal(legacy.receiptSyncPending,false);
});
