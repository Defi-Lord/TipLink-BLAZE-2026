import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createBankLookup} from '../wallet-lab/cash-out-bank-client.mjs';
const bank={id:'25',name:'OPay - Paycom'},second={id:'26',name:'PalmPay'},number='1234567890';
const result=(bank,number,change={})=>{const checked=Date.now();return {environment:'sandbox',payoutVerified:false,payoutEnabled:false,state:'resolved',bankId:bank.id,bankName:bank.name,accountLast4:number.slice(-4),accountName:'FIXTURE PERSON',checkedAt:new Date(checked).toISOString(),expiresAt:new Date(checked+300000).toISOString(),...change};};
const reply=data=>({ok:true,json:async()=>data});
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function until(predicate){for(let i=0;i<100;i++){if(predicate())return;await pause(5);}throw Error('Lookup did not settle');}
test('lookup starts automatically only for a bank and ten digits; sends no typed account name',async()=>{
 const calls=[],states=[];const s=createBankLookup({delay:5,onChange:value=>states.push(value),fetchImpl:async(path,options)=>{calls.push({path,options});return reply(path.endsWith('/auth/session')?{csrfToken:'fixture'}:result(bank,number));}});
 try{
  s.update(null,number);s.update(bank,'123456789');await pause(15);assert.equal(calls.length,0);
  s.update(bank,number);assert.equal(states.at(-1).phase,'loading');await until(()=>states.at(-1).phase==='resolved');
  assert.equal(states.at(-1).result.accountName,'FIXTURE PERSON');assert.equal(calls.length,2);assert.deepEqual(JSON.parse(calls[1].options.body),{bankId:'25',accountNumber:number});assert.equal(calls[1].options.headers['X-CSRF-Token'],'fixture');assert.equal(calls[1].options.credentials,'same-origin');assert.equal(calls[1].options.cache,'no-store');
 }finally{s.dispose();}
});
test('rapid edits debounce; late responses cannot restore a name after number or bank changes',async()=>{
 const states=[],pending=[],calls=[];const s=createBankLookup({delay:5,onChange:value=>states.push(value),fetchImpl:async(path,options)=>{if(path.endsWith('/auth/session'))return reply({csrfToken:'fixture'});const body=JSON.parse(options.body);calls.push(body);return new Promise(resolve=>pending.push({body,resolve,signal:options.signal}));}});
 try{
  s.update(bank,number);s.update(bank,'1234567891');await until(()=>pending.length===1);assert.equal(calls[0].accountNumber,'1234567891');
  s.update(second,number);assert.equal(states.at(-1).result,null);assert.equal(pending[0].signal.aborted,true);await until(()=>pending.length===2);
  pending[1].resolve(reply(result(second,number)));await until(()=>states.at(-1).phase==='resolved');assert.equal(states.at(-1).result.bankId,'26');
  pending[0].resolve(reply(result(bank,'1234567891')));await pause(10);assert.equal(states.at(-1).result.bankId,'26');
  s.update(second,'123');assert.equal(states.at(-1).phase,'idle');assert.equal(states.at(-1).result,null);
 }finally{s.dispose();}
});
test('mismatched, missing or expired names stay empty; authentication failures do not submit lookups',async()=>{
 for(const change of [{bankId:'39'},{accountLast4:'0000'},{accountName:''},{accountName:'BAD\r\nNAME'},{state:'details_mismatch',accountName:null},{expiresAt:'2020-01-01T00:00:00Z'}]){
  const states=[];const s=createBankLookup({delay:0,onChange:value=>states.push(value),fetchImpl:async path=>reply(path.endsWith('/auth/session')?{csrfToken:'fixture'}:result(bank,number,change))});
  try{s.update(bank,number);await until(()=>states.at(-1).phase==='error');assert.equal(states.at(-1).result,null);}finally{s.dispose();}
 }
 let calls=0;const states=[];const s=createBankLookup({delay:0,onChange:value=>states.push(value),fetchImpl:async()=>{calls++;return {ok:false,status:401,json:async()=>({error:'Sign in'})};}});
 try{s.update(bank,number);await until(()=>states.at(-1).phase==='error');assert.equal(calls,1);assert.match(states.at(-1).message,/Sign in through Business/);}finally{s.dispose();}
});
test('dispose before the debounce fires prevents any request',async()=>{
 let calls=0;const s=createBankLookup({delay:5,onChange:()=>{},fetchImpl:async()=>{calls++;throw Error();}});s.update(bank,number);s.dispose();await pause(15);assert.equal(calls,0);
});
