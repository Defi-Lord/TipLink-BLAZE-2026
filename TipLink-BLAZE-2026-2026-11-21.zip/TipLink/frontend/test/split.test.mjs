import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseBch, splitTip, fundingSummary } from '../src/split.mjs';
const team = [{ id: 'host', bps: 6000 }, { id: 'editor', bps: 2500 }, { id: 'designer', bps: 1500 }];
test('parses decimal BCH exactly', () => {
  assert.equal(parseBch('0.00000001'), 1n);
  assert.equal(parseBch('0.01'), 1000000n);
  for (const bad of ['1e-8', '-1', '0', '1.000000001', ' 1', '01', '21000001']) assert.throws(() => parseBch(bad));
});
test('splits 60/25/15 without losing satoshis', () => {
  assert.deepEqual(splitTip(1000000n, team, 1n).map(r => r.sats), [600000n, 250000n, 150000n]);
});
test('rounding is deterministic and conserves value across amounts', () => {
  for (let total = 100n; total < 10000n; total += 13n) {
    const result = splitTip(total, team, 1n);
    assert.equal(result.reduce((sum, r) => sum + r.sats, 0n), total);
    for (const row of result) {
      const floor = total * BigInt(row.bps) / 10000n;
      assert.ok(row.sats === floor || row.sats === floor + 1n);
    }
  }
  const equal = [{ id: 'a', bps: 5000 }, { id: 'b', bps: 5000 }];
  assert.deepEqual(splitTip(101n, equal, 1n).map(r => r.sats), [51n, 50n]);
});
test('rejects invalid shares, duplicate identities and small outputs', () => {
  assert.throws(() => splitTip(1000n, [{ id: 'a', bps: 5000 }, { id: 'a', bps: 5000 }], 1n));
  assert.throws(() => splitTip(1000n, [{ id: 'a', bps: 5000 }, { id: 'b', bps: 4000 }], 1n));
  assert.throws(() => splitTip(1000n, team, 200n));
});
test('fee is additional and subminimum change cannot silently become a fee', () => {
  assert.deepEqual(fundingSummary(11000n, 10000n, 200n, 500n), { recipientSats: 10000n, minerFeeSats: 200n, changeSats: 800n, platformFeeSats: 0n });
  assert.equal(fundingSummary(10200n, 10000n, 200n, 500n).changeSats, 0n);
  assert.throws(() => fundingSummary(10100n, 10000n, 200n, 500n));
  assert.throws(() => fundingSummary(10300n, 10000n, 200n, 500n));
});
