import {test} from 'node:test';import assert from 'node:assert/strict';import {encodeCashAddress} from '@bitauth/libauth';
import {parseBusinessAmount,validateSavedInvoice,invoiceActive,savedInvoiceUri,savedInvoiceUrl,createMerchantClient,fetchInvoiceCheckout} from '../wallet-lab/business-core.mjs';
const now=1800000000000;const address=encodeCashAddress({prefix:'bitcoincash',type:'p2pkh',payload:new Uint8Array(20).fill(83)}).address;
const invoice=()=>({id:'11111111-1111-4111-8111-111111111111',merchantName:'Nazzitech',amountSats:'100000',address,memo:'Design & delivery',state:'open',version:1,createdAt:new Date(now).toISOString(),expiresAt:new Date(now+3600000).toISOString(),paymentStatus:'not_checked',monitoringConnected:false});
test('saved request URL contains only its public id and strips query data',()=>{const r=invoice(),url=new URL(savedInvoiceUrl(r,'https://example.com/?token=private#claim=secret'));assert.equal(url.search,'');assert.equal(url.hash,'#invoice='+r.id);assert.ok(!url.href.includes(r.address));assert.throws(()=>savedInvoiceUrl(r,'http://example.com'));});
test('active URI has exact BCH amount and correctly encodes public note',()=>{const r=invoice();const uri=savedInvoiceUri(r,now);const params=new URLSearchParams(uri.split('?')[1]);assert.equal(params.get('amount'),'0.00100000');assert.equal(params.get('message'),r.memo);assert.equal(params.get('label'),r.merchantName);});
test('expired, future and cancelled checkouts cannot produce payment URI',()=>{const r=invoice();for(const t of [now-1,now+3600000])assert.throws(()=>savedInvoiceUri(r,t));assert.equal(invoiceActive({...r,state:'cancelled'},now),false);assert.throws(()=>savedInvoiceUri({...r,state:'cancelled'},now));});
test('unexpected private fields, fake paid status and invalid money fail closed',()=>{const r=invoice();for(const patch of [{claimPrivateKey:'secret'},{paymentStatus:'paid'},{amountSats:'01'},{amountSats:'999'},{amountSats:'2100000000000001'},{state:'paid'},{expiresAt:r.createdAt}])assert.throws(()=>validateSavedInvoice({...r,...patch}));});
test('client keeps CSRF in memory, scopes API paths and never reads current claim URL',async()=>{const calls=[];const client=createMerchantClient({fetcher:async(url,options)=>{calls.push({url,options});return{ok:true,json:async()=>url.endsWith('/auth/session')?{csrfToken:'a'.repeat(64)}:{ok:true}};}});await client.request('/auth/session');await client.request('/quotes',{method:'POST',body:{kind:'merchant'}});assert.equal(calls[1].options.headers['X-CSRF-Token'],'a'.repeat(64));assert.equal(calls[1].url,'/api/v1/merchant/quotes');assert.equal(calls[1].options.referrerPolicy,'no-referrer');await assert.rejects(client.request('/../admin/overview'));await assert.rejects(client.request('/auth/session?claim=secret'));});
test('failed network save is reported as uncertain and never retried automatically',async()=>{let calls=0;const client=createMerchantClient({fetcher:async()=>{calls++;throw Error('offline');}});await assert.rejects(client.request('/invoices',{method:'POST',body:{}}),/refresh your list/);assert.equal(calls,1);});

test('calculator permits exact zero network estimates but requires positive recipient amounts',()=>{for(const value of ['0','0.00000000'])assert.equal(parseBusinessAmount(value,true),0n);assert.throws(()=>parseBusinessAmount('0'));for(const value of ['00','0.000000000','1e-8','-1'])assert.throws(()=>parseBusinessAmount(value,true));assert.equal(parseBusinessAmount('0.00000001'),1n);});

test('a fresh checkout request detects cancellation and rejects a substituted invoice',async()=>{
 const original=invoice();
 const fetcher=async(url,options)=>{
  assert.equal(url,'/api/v1/public/invoices/'+original.id);
  assert.equal(options.cache,'no-store');
  return {ok:true,json:async()=>({...original,state:'cancelled',version:2})};
 };
 const current=await fetchInvoiceCheckout(original.id,{fetcher});
 assert.equal(invoiceActive(original,now),true);
 assert.equal(invoiceActive(current,now),false);
 assert.throws(()=>savedInvoiceUri(current,now));
 await assert.rejects(fetchInvoiceCheckout(original.id,{fetcher:async()=>({ok:true,json:async()=>({...original,id:'22222222-2222-4222-8222-222222222222'})})}),/does not match/);
});
