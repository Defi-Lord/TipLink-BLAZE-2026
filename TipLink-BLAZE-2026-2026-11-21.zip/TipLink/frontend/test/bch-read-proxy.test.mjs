import {test} from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {validateRequest,callElectrumTls} from '../api/bch-read.mjs';
import {openBchHttpsRpc} from '../wallet-lab/bch-https-rpc.mjs';

test('BCH bridge only allows fixed independent providers and limited read-only Electrum RPC methods',()=>{
 const good={provider:'nordic',method:'blockchain.scripthash.get_history',params:['ab'.repeat(32)]};
 assert.deepEqual(validateRequest(good),good);
 for(const body of [
  {...good,provider:'https://malicious.invalid'}, {...good,provider:'127.0.0.1'},
  {...good,method:'blockchain.transaction.broadcast'},
  {...good,params:['bad']},
  {...good,params:[good.params[0],{host:'127.0.0.1'}]},
  {...good,method:'blockchain.transaction.get',params:['ab'.repeat(32),true]}
 ])assert.throws(()=>validateRequest(body));
 assert.equal(validateRequest({provider:'imaginary',method:'blockchain.scripthash.listunspent',params:['ab'.repeat(32),'include_tokens']}).provider,'imaginary');
});

test('TLS bridge uses certificate validation, SNI, fixed host and one framed JSON-RPC read',async()=>{
 let dial,query;
 class FakeTls extends EventEmitter{
  setEncoding(){}
  write(data){query=JSON.parse(data);queueMicrotask(()=>this.emit('data',JSON.stringify({id:1,result:{genesis_hash:'ok'}})+'\n'));}
  destroy(){this.emit('close');}
 }
 const connect=options=>{dial=options;const socket=new FakeTls();queueMicrotask(()=>socket.emit('secureConnect'));return socket;};
 const result=await callElectrumTls({provider:'nordic',method:'server.features',params:[]},{connect,timeoutMs:100});
 assert.deepEqual(result,{genesis_hash:'ok'});
 assert.deepEqual({host:dial.host,port:dial.port,servername:dial.servername,rejectUnauthorized:dial.rejectUnauthorized},{host:'electrum-bch.nordiccrypto.no',port:50002,servername:'electrum-bch.nordiccrypto.no',rejectUnauthorized:true});
 assert.equal(query.method,'server.features');
 assert.deepEqual(query.params,[]);
});

test('HTTPS transport refuses broadcasting and only sends same-origin read-only requests',async()=>{
 const calls=[];
 const rpc=openBchHttpsRpc({provider:'nordic',Fetcher:async(url,options)=>{
  calls.push({url,options});
  return {ok:true,json:async()=>({result:{genesis_hash:'valid'}})};
 }});
 assert.deepEqual(await rpc.call('server.features',[]),{genesis_hash:'valid'});
 assert.equal(calls.length,1);
 assert.equal(calls[0].url,'/api/bch-read');
 assert.equal(calls[0].options.credentials,'same-origin');
 assert.equal(calls[0].options.redirect,'error');
 await assert.rejects(rpc.call('blockchain.transaction.broadcast',['00']),/read methods/);
 rpc.close();
 await assert.rejects(rpc.call('server.features',[]),/closed/);
});
