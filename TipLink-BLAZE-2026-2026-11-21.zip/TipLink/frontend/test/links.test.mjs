import {test} from 'node:test';import assert from 'node:assert/strict';import {encodeCashAddress} from '@bitauth/libauth';
import {createLinkRecord,encodeLink,decodeLink,decodePublicDemoLink,linkUrl,paymentUri,isExpired,exportRecords,validateLinkRecord} from '../wallet-lab/links-core.mjs';
const now=1800000000000;const address=encodeCashAddress({prefix:'bitcoincash',type:'p2pkh',payload:new Uint8Array(20).fill(9)}).address;
const request=(extra={})=>createLinkRecord({kind:'request',amountBch:'0.00005',address,memo:'Repair 🛠',name:'Nazzitech',now,...extra});
test('request roundtrip preserves exact amount and unicode',()=>{const r=request();assert.deepEqual(decodeLink(encodeLink(r),now),r);assert.equal(r.sats,'5000');});
test('payment URI includes amount, merchant and memo safely',()=>{const uri=paymentUri(request(),now);assert.equal(uri.split('?')[0],address);const q=new URLSearchParams(uri.split('?')[1]);assert.equal(q.get('amount'),'0.00005000');assert.equal(q.get('message'),'Repair 🛠');});
test('expiry disables checkout without claiming on-chain reversal',()=>{const r=request();assert.equal(isExpired(r,r.expiresAt),true);assert.throws(()=>paymentUri(r,r.expiresAt),/not active/);assert.throws(()=>paymentUri(r,now-1),/not active/);});
test('invalid and fractional-satoshi amounts, excessive lifetimes and wrong network rejected',()=>{for(const amountBch of ['0','-1','0.000000001','21000001','1e2'])assert.throws(()=>request({amountBch}));assert.throws(()=>request({hours:721}));assert.throws(()=>request({address:address.replace('bitcoincash:','bchtest:')}));});
test('untrusted paid flags, secrets and demo receiving addresses rejected',()=>{const r=request();for(const field of ['paid','privateKey','status'])assert.throws(()=>validateLinkRecord({...r,[field]:true}));const d=createLinkRecord({kind:'demo-send',amountBch:'0.001',now});assert.throws(()=>validateLinkRecord({...d,address}));assert.throws(()=>paymentUri(d,now));});
test('URL uses a fragment and removes previous query data',()=>{const r=request();const url=new URL(linkUrl(r,'https://example.com/?old=1#secret'));assert.equal(url.search,'');assert.match(url.hash,/^#tl=/);assert.deepEqual(decodeLink(url.hash.slice(4),now),r);});
test('malformed, oversize and unsupported URLs rejected',()=>{for(const encoded of ['!', 'A'.repeat(2501),btoa('{}')])assert.throws(()=>decodeLink(encoded));assert.throws(()=>linkUrl(request(),'javascript:alert(1)'));});
test('CSV export quotes cells, neutralises formula injection and never says paid',()=>{const csv=exportRecords([request({name:'=SUM(1,2)',memo:'test,"ok"'})],now);assert.match(csv,/"'=SUM/);assert.match(csv,/"test,""ok"""/);assert.match(csv,/payment status not checked/);});
test('demo mode remains explicitly separate from payment requests',()=>{const d=createLinkRecord({kind:'demo-send',amountBch:'0.001',now});assert.equal(decodeLink(encodeLink(d),now).kind,'demo-send');assert.throws(()=>paymentUri(d,now));assert.match(exportRecords([d],now),/no money sent/);});

test('public links block unsigned payments and strip demo impersonation text',()=>{
 assert.throws(()=>decodePublicDemoLink(encodeLink(request()),now),/cannot verify/);
 const demo=createLinkRecord({kind:'demo-send',amountBch:'0.001',name:'TipLink\u200b Support',memo:'\u202eOfficial refund',now});
 assert.equal(demo.name,'TipLink Support');
 assert.equal(demo.memo,'Official refund');
 const forged=btoa(JSON.stringify(demo)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
 const publicDemo=decodePublicDemoLink(forged,now);
 assert.equal(decodeLink(encodeLink(demo),now).name,'');
 assert.equal(publicDemo.name,'');
 assert.equal(publicDemo.memo,'');
 assert.throws(()=>decodePublicDemoLink(encodeLink(demo),now-300001),/too far ahead/);
 assert.throws(()=>createLinkRecord({kind:'demo-send',amountBch:'0.01000001',now}),/0.01 BCH/);
});

test('customer amounts accept decimal commas and whitespace without changing exact satoshis',()=>{
 assert.equal(createLinkRecord({kind:'demo-send',amountBch:' 0,001 ',now}).sats,'100000');
 assert.equal(createLinkRecord({kind:'demo-send',amountBch:' .001 ',now}).sats,'100000');
 assert.throws(()=>createLinkRecord({kind:'demo-send',amountBch:'-5',now}),/greater than zero/);
 assert.equal(createLinkRecord({kind:'request',amountBch:'0.001',address:address.split(':')[1],now}).address,address);
});
