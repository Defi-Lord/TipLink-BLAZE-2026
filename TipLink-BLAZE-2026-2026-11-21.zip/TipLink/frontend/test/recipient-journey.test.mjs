import {test} from 'node:test';
import assert from 'node:assert/strict';
import {encodeCashAddress} from '@bitauth/libauth';
import {createLinkRecord} from '../wallet-lab/links-core.mjs';
import {startRecipientJourney,advanceRecipientJourney} from '../wallet-lab/recipient-journey.mjs';
const now=1800000000000;
const address=encodeCashAddress({prefix:'bitcoincash',type:'p2pkh',payload:new Uint8Array(20).fill(91)}).address;
const record=()=>createLinkRecord({kind:'demo-send',amountBch:'0.001',now});
const run=(s,type,r,value,t=now)=>advanceRecipientJourney(s,{type,value},r,t);
test('guest preview requires destination and review; creates no wallet or money',()=>{
 const r=record();let s=startRecipientJourney(r);s=run(s,'start',r);s=run(s,'review',r);
 assert.deepEqual(s.review,{mode:'guest',address:null,sats:'100000'});
 s=run(s,'finish',r);assert.equal(s.stage,'complete');assert.ok(!('privateKey'in s));assert.ok(!('txid'in s));
});
test('existing wallet requires a valid address and canonicalises it',()=>{
 const r=record();let s=run(startRecipientJourney(r),'start',r);s=run(s,'mode',r,'existing');
 assert.throws(()=>run(s,'review',r),/CashAddr/);
 s=run(s,'address',r,' '+address.toUpperCase()+' ');s=run(s,'review',r);
 assert.equal(s.review.address,address);assert.equal(run(s,'finish',r).stage,'complete');
});
test('rejects wrong network, bad checksum and mixed case',()=>{
 const r=record();let s=run(startRecipientJourney(r),'start',r);s=run(s,'mode',r,'existing');
 const testnet=encodeCashAddress({prefix:'bchtest',type:'p2pkh',payload:new Uint8Array(20).fill(91)}).address;
 for(const value of [testnet,address.slice(0,-1)+'!',address.replace('q','Q')])assert.throws(()=>run(run(s,'address',r,value),'review',r));
});
test('expiry between review and finish blocks completion',()=>{
 const r=record();let s=run(startRecipientJourney(r),'start',r);s=run(s,'review',r);
 assert.throws(()=>run(s,'finish',r,undefined,r.expiresAt),/expired/);
});
test('not-yet-active and invalid clocks fail closed',()=>{
 const r=record();for(const t of [now-1,NaN,Infinity])assert.throws(()=>run(startRecipientJourney(r),'start',r,undefined,t));
});
test('modified link metadata cannot reuse a previous review',()=>{
 const r=record();let s=run(startRecipientJourney(r),'start',r);s=run(s,'review',r);
 for(const changed of [{...r,sats:'200000'},{...r,memo:'Changed'},{...r,id:'a'.repeat(32)}])assert.throws(()=>run(s,'finish',changed),/link changed/);
});
test('back discards review; changing methods discards address',()=>{
 const r=record();let s=run(startRecipientJourney(r),'start',r);s=run(s,'mode',r,'existing');s=run(s,'address',r,address);s=run(s,'review',r);
 s=run(s,'back',r);assert.equal(s.review,null);s=run(s,'mode',r,'guest');assert.equal(s.address,'');assert.equal(s.review,null);
});
test('cannot skip review, edit after review or complete twice',()=>{
 const r=record();let s=startRecipientJourney(r);assert.throws(()=>run(s,'finish',r));s=run(s,'start',r);assert.throws(()=>run(s,'finish',r));
 s=run(s,'review',r);assert.throws(()=>run(s,'address',r,address));s=run(s,'finish',r);assert.throws(()=>run(s,'finish',r));
});
test('tampered review amount or destination blocks completion',()=>{
 const r=record();let s=run(startRecipientJourney(r),'start',r);s=run(s,'review',r);
 for(const review of [{...s.review,sats:'200000'},{...s.review,address}])assert.throws(()=>run({...s,review},'finish',r),/Review the destination/);
});
test('payment requests cannot enter the demo recipient flow',()=>{
 const r=createLinkRecord({kind:'request',amountBch:'0.001',address,now});assert.throws(()=>startRecipientJourney(r),/Only demo/);
 assert.throws(()=>run(startRecipientJourney(record()),'start',r),/separate checkout/);
});
