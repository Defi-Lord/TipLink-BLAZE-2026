import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DappConnectionManager} from '@wizardconnect/dapp';
import {deriveHdPrivateNodeFromSeed,deriveHdPrivateNodeChild,deriveHdPublicNode,encodeHdPublicKey,encodeCashAddress,decodeTransaction,hexToBin,binToHex} from '@bitauth/libauth';
import {deriveWalletAddresses} from '../wallet-lab/wallet-address-core.mjs';
import {prepareWalletPlan} from '../wallet-lab/wallet-plan-core.mjs';
const time=Date.parse('2026-10-28T02:00:00Z');
const address=n=>encodeCashAddress({prefix:'bitcoincash',type:'p2pkh',payload:new Uint8Array(20).fill(n)}).address;
const addresses=[address(6),address(7),address(8)];
function setup(){
 const root=deriveHdPrivateNodeFromSeed(new Uint8Array(32).fill(58));
 const manager=new DappConnectionManager('plan tests',undefined,{session:false});
 manager.restoreSessionPaths([0,1].map(n=>({name:n===0?'receive':'change',xpub:encodeHdPublicKey({node:deriveHdPublicNode(deriveHdPrivateNodeChild(root,n)),network:'mainnet'}).hdPublicKey})));manager.protocol='hdwalletv1';
 const rows=deriveWalletAddresses(manager,'connected');
 const candidate=(index,sats,height=900000)=>({txid:(index+10).toString(16).padStart(2,'0').repeat(32),index:0,sats,scriptHex:rows[0].scriptHex,path:'receive',addressIndex:0,height,status:'RAW VERIFIED; PROVIDER REPORTS UNSPENT'});
 const config={manager,state:'connected',snapshot:{manager,rows,value:{network:'BCH mainnet',checkpoint:898374,scannedScripts:4,checkedAt:new Date(time).toISOString(),candidates:[candidate(0,'200000')]}},addresses,amountBch:'0.001',now:time};
 return{config,manager,rows,candidate};
}
test('constructs wallet-bound unsigned plan using derived change and input paths',()=>{const{config,manager,rows}=setup();try{const p=prepareWalletPlan(config);assert.equal(p.changeAddress,rows[3].address);assert.deepEqual(p.inputPaths,[[0,'receive',0]]);assert.equal(p.changeSats,99705n);assert.equal(p.minerFeeSats,295n);const tx=decodeTransaction(hexToBin(p.unsignedHex));assert.equal(binToHex(tx.outputs[3].lockingBytecode),rows[3].scriptHex);assert.match(p.mode,/WALLET-FUNDED/);}finally{manager.destroy();}});
test('rejects expired/future funding snapshots',()=>{const{config,manager}=setup();try{assert.throws(()=>prepareWalletPlan({...config,now:time+60001}),/expired/);assert.throws(()=>prepareWalletPlan({...config,now:time-1}),/expired/);}finally{manager.destroy();}});
test('rejects another wallet, disconnected state or changed derivation',()=>{const{config,manager}=setup();try{assert.throws(()=>prepareWalletPlan({...config,state:'disconnected'}));assert.throws(()=>prepareWalletPlan({...config,snapshot:{...config.snapshot,manager:{}}}));const bad={...config.snapshot,rows:config.snapshot.rows.map((r,i)=>i===0?{...r,scriptHex:'bad'}:r)};assert.throws(()=>prepareWalletPlan({...config,snapshot:bad}),/paths changed/);}finally{manager.destroy();}});
test('rejects wrong network, unknown checkpoint and partial scan',()=>{const{config,manager}=setup();try{for(const patch of [{network:'Chipnet'},{checkpoint:0},{scannedScripts:3}])assert.throws(()=>prepareWalletPlan({...config,snapshot:{...config.snapshot,value:{...config.snapshot.value,...patch}}}));}finally{manager.destroy();}});
test('example fixture recipients never enter wallet-funded plans',()=>{const{config,manager}=setup();try{assert.throws(()=>prepareWalletPlan({...config,addresses:[address(1),address(2),address(3)]}),/demo mode only/);}finally{manager.destroy();}});
test('empty or unconfirmed-only funding is rejected without fictional fallback',()=>{const{config,manager,candidate}=setup();try{for(const candidates of [[],[candidate(0,'200000',0)]])assert.throws(()=>prepareWalletPlan({...config,snapshot:{...config.snapshot,value:{...config.snapshot.value,candidates}}}),/No confirmed/);}finally{manager.destroy();}});
test('selects larger confirmed funding first without adding unneeded inputs',()=>{const{config,manager,candidate}=setup();try{config.snapshot.value.candidates=[candidate(0,'10000'),candidate(1,'200000'),candidate(2,'30000')];const p=prepareWalletPlan(config);assert.equal(p.inputPaths.length,1);assert.equal(p.totalInputSats,200000n);}finally{manager.destroy();}});
test('adds an input when initial selection would create subminimum change',()=>{const{config,manager,candidate}=setup();try{config.snapshot.value.candidates=[candidate(0,'100500'),candidate(1,'2000')];const p=prepareWalletPlan(config);assert.equal(p.inputPaths.length,2);assert.equal(p.minerFeeSats,444n);assert.equal(p.changeSats,2056n);}finally{manager.destroy();}});
test('rejects duplicate candidates and forged script/path bindings',()=>{const{config,manager,candidate}=setup();try{const base=config.snapshot.value;for(const candidates of [[candidate(0,'200000'),candidate(0,'200000')],[{...candidate(0,'200000'),scriptHex:'bad'}],[{...candidate(0,'200000'),status:'unchecked'}]])assert.throws(()=>prepareWalletPlan({...config,snapshot:{...config.snapshot,value:{...base,candidates}}}));}finally{manager.destroy();}});
test('insufficient real funding produces an error and cannot reuse simulation funding',()=>{const{config,manager,candidate}=setup();try{config.snapshot.value.candidates=[candidate(0,'1000')];assert.throws(()=>prepareWalletPlan(config),/cannot cover/);}finally{manager.destroy();}});
