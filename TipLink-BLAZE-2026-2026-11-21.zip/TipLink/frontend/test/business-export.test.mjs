import {test} from 'node:test';
import assert from 'node:assert/strict';
import {encodeCashAddress} from '@bitauth/libauth';
import {selectExportRequests} from '../wallet-lab/business-export.mjs';
import {invoiceCsv} from '../wallet-lab/business-core.mjs';

const now = Date.parse('2026-11-05T12:00:00Z');
const address = encodeCashAddress({
  prefix: 'bitcoincash', type: 'p2pkh', payload: new Uint8Array(20).fill(83),
}).address;
function invoice(createdAt, state = 'open') {
  return {
    id: '11111111-1111-4111-8111-111111111111', merchantName: 'Studio Finch',
    amountSats: '100001', address, memo: 'Design, "delivery"', state, version: 1,
    createdAt, expiresAt: new Date(Date.parse(createdAt) + 86400000).toISOString(),
    paymentStatus: 'not_checked', monitoringConnected: false,
  };
}
test('export date range includes the whole end day in UTC', () => {
  const rows = [
    invoice('2026-11-03T23:59:59.999Z'),
    invoice('2026-11-04T00:00:00.000Z'),
    invoice('2026-11-04T23:59:59.999Z'),
    invoice('2026-11-05T00:00:00.000Z'),
  ];
  assert.deepEqual(selectExportRequests(rows, {from: '2026-11-04', to: '2026-11-04'}, now), rows.slice(1, 3));
  assert.deepEqual(selectExportRequests(rows, {}, now), rows);
});
test('export rejects reversed, malformed and nonexistent calendar dates', () => {
  for (const from of ['2026-02-30', '2026-2-1', 'invalid', '2026-13-01']) {
    assert.throws(() => selectExportRequests([], {from}, now));
  }
  assert.throws(() => selectExportRequests([], {from: '2026-11-05', to: '2026-11-04'}, now));
  assert.throws(() => selectExportRequests([], {status: 'paid'}, now));
});
test('export status filters respect expiry boundaries and preserve cancellations', () => {
  const old = invoice('2026-11-04T12:00:00Z');
  const open = invoice('2026-11-05T00:00:00Z');
  const cancelled = {...old, state: 'cancelled'};
  const rows = [old, open, cancelled];
  assert.deepEqual(selectExportRequests(rows, {status: 'expired'}, now), [old]);
  assert.deepEqual(selectExportRequests(rows, {status: 'open'}, now), [open]);
  assert.deepEqual(selectExportRequests(rows, {status: 'cancelled'}, now), [cancelled]);
});
test('export adds merchant identity, exact satoshis and a consistent snapshot time', () => {
  const row = invoice('2026-11-05T00:00:00Z');
  const csv = invoiceCsv([row], now);
  assert.match(csv, /"Merchant name","Amount satoshis","Exported at UTC"/);
  assert.ok(csv.includes('"Studio Finch","100001","2026-11-05T12:00:00.000Z"'));
  assert.ok(csv.includes('"0.00100001"'));
  assert.ok(csv.includes('"Design, ""delivery"""'));
  const formula = invoiceCsv([{...row, merchantName: '=1+1', memo: '@SUM(1)'}], now);
  assert.ok(formula.includes('"\'=1+1"'));
  assert.ok(formula.includes('"\'@SUM(1)"'));
});
test('export snapshot labels stale receipts without claiming current payment confirmation', () => {
  const row = invoice('2026-11-05T00:00:00Z');
  row.receipt = {
    txid: 'ab'.repeat(32), outputIndex: 0, status: 'confirmed', lastStatus: 'confirmed',
    height: 900000, checkedAt: '2026-11-05T11:58:00Z', source: 'rostrum.riften.net',
  };
  row.paymentStatus = 'confirmed';
  row.monitoringConnected = true;
  const csv = invoiceCsv([row], now);
  assert.match(csv, /Needs a fresh check/);
  assert.doesNotMatch(csv, /Confirmed · provider reported/);
});
